#    Author: Alex Savatieiev (osavatieiev@mirantis.com; a.savex@gmail.com)
#    Copyright 2019-2022 Mirantis, Inc.
from .command import cli_command


def entrypoint():
    cli_command(
        "# Mirantis Cloud Network checker",
        'network'
    )


if __name__ == '__main__':
    entrypoint()
