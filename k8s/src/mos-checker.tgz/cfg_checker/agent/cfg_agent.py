#    Author: Alex Savatieiev (osavatieiev@mirantis.com; a.savex@gmail.com)
#    Copyright 2019-2022 Mirantis, Inc.
from .webserver import agent_server


def entrypoint():
    agent_server()


if __name__ == '__main__':
    entrypoint()
