#    Author: Alex Savatieiev (osavatieiev@mirantis.com; a.savex@gmail.com)
#    Copyright 2019-2022 Mirantis, Inc.
from cfg_checker.common.log import logger, logger_cli

from cfg_checker.common.other import Utils


def nested_set(_d, _keys, _value):
    # # import and deepcopy for safety
    # from copy import deepcopy
    # _d = deepcopy(_dict)
    # process
    for k in _keys[:-1]:
        _d = _d.setdefault(k, {})
    _d[_keys[-1]] = _value


utils = Utils()
logger = logger
logger_cli = logger_cli
