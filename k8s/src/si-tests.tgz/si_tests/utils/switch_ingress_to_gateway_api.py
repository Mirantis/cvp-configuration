#    Copyright 2026 Mirantis, Inc.
#
#    Licensed under the Apache License, Version 2.0 (the "License"); you may
#    not use this file except in compliance with the License. You may obtain
#    a copy of the License at
#
#         http://www.apache.org/licenses/LICENSE-2.0
#
#    Unless required by applicable law or agreed to in writing, software
#    distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
#    WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
#    License for the specific language governing permissions and limitations
#    under the License.

import re

from si_tests import logger
from si_tests.deployments.utils import wait_utils, kubectl_utils
from si_tests.deployments.utils.namespace import NAMESPACE

LOG = logger.logger


def switch_ingress_to_envoy(os_manager):
    LOG.info("Wait for app-gateway service")

    app_gateway_svc_obj = os_manager.get_os_service("app-gateway")
    app_gateway_svc_obj.wait_for_external_ip()

    LOG.info("Switching DNS to Envoy Gateway")
    LOG.debug("Get app-gateway ip")
    envoy_ip = app_gateway_svc_obj.get_external_addr()
    coredns_config_map = os_manager.api.configmaps.get(
        "coredns-coredns", NAMESPACE.coredns)
    LOG.debug("Update coredns configmap with Envoy Gateway's IP")
    dns_entries_content = coredns_config_map.read().data["it.just.works.db"]
    updated_dns_entries = re.sub(
        r'(\sIN\s+A\s+)(\d+\.\d+\.\d+\.\d+)',
        rf'\g<1>{envoy_ip}',
        dns_entries_content
    )

    patch_body = {
        "data": {
            "it.just.works.db": updated_dns_entries
        }
    }

    os_manager.api.configmaps.update(
        "coredns-coredns",
        NAMESPACE.coredns,
        patch_body
    )

    LOG.debug("Restart coredns pods")
    kubectl = kubectl_utils.Kubectl(kubeconfig=os_manager.kubeconfig)
    kubectl.rollout_restart("deployment", "coredns-coredns", namespace=NAMESPACE.coredns)

    wait = wait_utils.Waiter(os_manager, 600)
    wait.wait_pass(lambda: wait.wait_for_dns_warmup(kubectl,
                                                    keystone_pod_name=os_manager.api.pods.list_starts_with(
                                                        "keystone-client", NAMESPACE.openstack
                                                    )[0].read().metadata.name,
                                                    resolved_expected_ip=envoy_ip,
                                                    ns=NAMESPACE.openstack),
                   expected=Exception)
    LOG.info("Envoy gateway successfully configured")
