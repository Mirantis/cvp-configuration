#!/usr/bin/env python3

"""Validate spec.publishDate in a KaaSRelease YAML.

Checks:
  1. spec.publishDate must be present.
  2. spec.publishDate must parse as an ISO-8601 timestamp.
  3. spec.publishDate must not be in the future (relative to current UTC time).
  4. spec.publishDate must not be older than 1 day from now.

Usage:
  python3 check_publish_date.py --kaas-release-filepath kaas/2.31.3.yaml

Exit 0 on success, 1 on violations, 2 on usage errors. Requires PyYAML.
"""

from __future__ import annotations

import optparse
import os
import sys
from datetime import datetime, timedelta, timezone
from typing import Optional

try:
    import yaml
except ImportError:
    sys.stderr.write("PyYAML is required: pip install PyYAML\n")
    sys.exit(2)


MAX_AGE = timedelta(days=1)


def parse_iso(value: str) -> Optional[datetime]:
    s = value.strip()
    # Python's fromisoformat learned to accept the trailing 'Z' only in 3.11;
    # normalise it so older interpreters work too.
    if s.endswith("Z"):
        s = s[:-1] + "+00:00"
    try:
        dt = datetime.fromisoformat(s)
    except ValueError:
        return None
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    return dt


def check_release_data(
    release_data: dict, now: datetime
) -> Optional[str]:
    spec = release_data.get("spec") or {}
    raw = spec.get("publishDate")
    if raw is None:
        return "spec.publishDate is missing"
    dt = parse_iso(str(raw))
    if dt is None:
        return f"spec.publishDate {raw!r} is not a valid ISO-8601 timestamp"
    if dt > now:
        return (
            f"spec.publishDate is in the future: {dt.isoformat()} "
            f"(now {now.isoformat()})"
        )
    age = now - dt
    if age > MAX_AGE:
        return (
            f"spec.publishDate is too old: {dt.isoformat()} "
            f"(age {age}, max allowed {MAX_AGE})"
        )
    return None


def main():
    parser = optparse.OptionParser(
        usage="Usage: %prog --kaas-release-filepath <path_to_KaaSRelease_yaml>"
    )
    parser.add_option(
        '--kaas-release-filepath',
        action="store", dest="releasefile",
        help="Path to KaaSRelease YAML file."
    )
    options, _args = parser.parse_args()

    if not options.releasefile:
        parser.print_usage()
        print("Error: --kaas-release-filepath is required")
        return 2

    if not os.path.isfile(options.releasefile):
        print(f"Error: file not found: {options.releasefile}")
        return 2

    with open(options.releasefile, 'r') as f:
        release_data = yaml.safe_load(f)

    now = datetime.now(timezone.utc)
    print(f"Source: {options.releasefile}")
    print(f"Now (UTC): {now.isoformat()}")
    print(f"Max allowed age: {MAX_AGE}")

    error = check_release_data(release_data, now)
    if error:
        print(f"\nFAIL: {error}")
        return 1
    raw = release_data.get("spec", {}).get("publishDate")
    print(f"\nOK: spec.publishDate = {raw}")
    return 0


if __name__ == '__main__':
    sys.exit(main())
