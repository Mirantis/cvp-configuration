#!/usr/bin/env python3

"""
Validate availableUpgrades in a KaaSRelease YAML.

Rule: for each source X.Y.Z in spec.supportedClusterReleases, every entry
in its availableUpgrades must be either
  (a) same minor series  -- target X.Y.W (any patch), or
  (b) cross-minor between .0 releases -- X.Y.0 -> X.Z.0, or
  (c) an explicitly whitelisted bridge passed via
      --allow-bridge FROM=TO (repeatable).

Cross-minor upgrades from a patch release (e.g. 21.0.5 -> 21.1.0) are
rejected unless whitelisted. Two default bridges are always allowed:
  21.0.5=21.1.0  and  20.0.5=20.1.0

Usage:
  # Check a specific file:
  python3 check_release_upgrades_paths.py --kaas-release-filepath kaas/2.31.3.yaml
  # Get release data from a live cluster (requires KUBECONFIG):
  python3 check_release_upgrades_paths.py
  # With extra bridges:
  python3 check_release_upgrades_paths.py --kaas-release-filepath kaas/2.31.3.yaml \\
      --allow-bridge 21.0.7=21.1.0

Exit 0 on success, 1 on violations, 2 on usage errors. Requires PyYAML.
"""

from __future__ import annotations

import optparse
import os
import re
import sys
from typing import List, Optional, Set, Tuple

sys.path.append(os.getcwd())

try:
    import yaml
except ImportError:
    sys.stderr.write("PyYAML is required: pip install PyYAML\n")
    sys.exit(2)


SEMVER_RE = re.compile(r"^(\d+)\.(\d+)\.(\d+)")

Version = Tuple[int, int, int]
Edge = Tuple[Version, Version]

# Cross-minor bridges that are always allowed regardless of CLI flags.
DEFAULT_BRIDGES: Set[Edge] = {
    # MOSK
    ((21, 0, 5), (21, 1, 0)),
    ((21, 0, 9), (21, 1, 5)),
    ((21, 1, 6), (21, 2, 0)),
    # MKE
    ((20, 0, 5), (20, 1, 0)),
    ((20, 0, 9), (20, 1, 5)),
    # MKE to K0S transition
    ((20, 1, 0), (22, 0, 0)),
    ((20, 1, 6), (22, 0, 0)),
}


def parse_version(value: str) -> Optional[Version]:
    m = SEMVER_RE.match(value.strip())
    if not m:
        return None
    return int(m.group(1)), int(m.group(2)), int(m.group(3))


def parse_allow_bridge(raw: str) -> Edge:
    if "=" not in raw:
        raise ValueError(
            f"--allow-bridge expects FROM=TO, got {raw!r}"
        )
    src_raw, tgt_raw = raw.split("=", 1)
    src, tgt = parse_version(src_raw), parse_version(tgt_raw)
    if src is None or tgt is None:
        raise ValueError(
            f"--allow-bridge values must be X.Y.Z semver, got {raw!r}"
        )
    return src, tgt


def _fmt_version(v: Version) -> str:
    return f"{v[0]}.{v[1]}.{v[2]}"


def check_release_data(
    release_data: dict, allowed_bridges: Set[Edge],
) -> Tuple[List[str], List[str]]:
    """Return (errors, default_bridge_hits) for the given KaaSRelease data."""
    supported = (release_data.get("spec") or {}).get(
        "supportedClusterReleases"
    ) or []

    errors: List[str] = []
    default_bridge_hits: List[str] = []
    for entry in supported:
        src_raw = str(entry.get("version", ""))
        src = parse_version(src_raw)
        if src is None:
            continue

        # Example: for 21.0.5 src_major=21, src_minor=0, src_patch=5
        src_major, src_minor, src_patch = src
        for up in entry.get("availableUpgrades") or []:
            tgt_raw = str(up.get("version", ""))
            tgt = parse_version(tgt_raw)
            if tgt is None:
                errors.append(
                    f"  {src_raw} -> {tgt_raw!r}: cannot parse target version"
                )
                continue

            # Example: for 21.0.7 tgt_major=21, tgt_minor=0, tgt_patch=7
            tgt_major, tgt_minor, tgt_patch = tgt
            # Same minor series (e.g. 21.0.5 -> 21.0.7) — always OK
            if tgt_major == src_major and tgt_minor == src_minor:
                continue
            # Cross-minor between .0 releases (e.g. 21.0.0 -> 21.1.0) — always OK
            if tgt_major == src_major and src_patch == 0 and tgt_patch == 0:
                continue
            if (src, tgt) in DEFAULT_BRIDGES:
                default_bridge_hits.append(
                    f"  {src_raw} -> {tgt_raw}: would be rejected, but "
                    f"hardcoded in DEFAULT_BRIDGES — allowed"
                )
                continue
            if (src, tgt) in allowed_bridges:
                continue
            errors.append(
                f"  {src_raw} -> {tgt_raw}: cross-minor upgrade not allowed; "
                f"add `--allow-bridge {src_raw}={tgt_raw}` if intentional"
            )
    return errors, default_bridge_hits


def main():
    parser = optparse.OptionParser(
        usage="Usage: %prog --kaas-release-filepath <path_to_KaaSRelease_yaml> "
              "[--allow-bridge FROM=TO]"
    )
    parser.add_option(
        '--kaas-release-filepath',
        action="store", dest="releasefile",
        help="Path to KaaSRelease YAML file. If not set, data is fetched "
             "from the active KaaSRelease on the cluster (requires KUBECONFIG)."
    )
    parser.add_option(
        '--allow-bridge',
        action="append", dest="allow_bridges", default=[],
        metavar="FROM=TO",
        help="Whitelist a cross-minor upgrade edge (e.g. 21.0.5=21.1.0). "
             "Repeatable. Same-minor and .0-to-.0 cross-minor are always allowed."
    )
    options, args = parser.parse_args()

    # Load release data from file or from a live cluster
    if options.releasefile:
        if not os.path.isfile(options.releasefile):
            print(f"Error: file not found: {options.releasefile}")
            return 2
        with open(options.releasefile, 'r') as f:
            release_data = yaml.safe_load(f)
        source = options.releasefile
    else:
        try:
            from si_tests import settings
            from si_tests.managers.kaas_manager import Manager
        except ImportError:
            print("ImportError: Run the application from the si-tests "
                  "directory or set the PYTHONPATH environment variable to "
                  "directory which contains ./si_tests")
            return 2
        if not settings.KUBECONFIG_PATH or \
                not os.path.isfile(settings.KUBECONFIG_PATH):
            print("Please set KUBECONFIG environment variable with "
                  "the path to the kubeconfig file for KaaS management "
                  "cluster")
            return 2
        kaas_manager = Manager(kubeconfig=settings.KUBECONFIG_PATH)
        release_data = kaas_manager.get_active_kaasrelease().data
        source = "active KaaSRelease from cluster"

    print(f"Source: {source}")

    # Parse --allow-bridge values
    allowed: Set[Edge] = set()
    for raw in options.allow_bridges:
        try:
            allowed.add(parse_allow_bridge(raw))
        except ValueError as e:
            print(f"Error: {e}")
            return 2

    print("Hardcoded DEFAULT_BRIDGES (always allowed):")
    for src, tgt in sorted(DEFAULT_BRIDGES):
        print(f"  {_fmt_version(src)} -> {_fmt_version(tgt)}")

    errors, default_hits = check_release_data(release_data, allowed)

    if default_hits:
        print(f"\nWARNING: {len(default_hits)} cross-minor edge(s) allowed "
              f"only because they are hardcoded in DEFAULT_BRIDGES:")
        for h in default_hits:
            print(h)

    if errors:
        print(f"\nFAIL: {source}: {len(errors)} invalid upgrade edge(s):")
        for e in errors:
            print(e)
        return 1
    print(f"\nOK: {source}: all availableUpgrades valid "
          f"({len(allowed)} extra bridge(s) from --allow-bridge)")
    return 0


if __name__ == '__main__':
    sys.exit(main())
