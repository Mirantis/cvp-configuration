import yaml

from si_tests import logger

LOG = logger.logger

# Inline python3 script run as an unprivileged user to attempt a ptrace attach.
# PTRACE_ATTACH=16; returns exit code 0 if attach succeeded (BAD), 1 if denied (GOOD).
_PTRACE_PROBE = (
    "python3 -c \""
    "import ctypes, sys, errno; "
    "libc = ctypes.CDLL('libc.so.6', use_errno=True); "
    "ret = libc.ptrace(16, {pid}, 0, 0); "
    "sys.exit(0 if ret == 0 else 1)"
    "\""
)


def check_unprivileged_ptrace_blocked(cluster) -> bool:
    """Return True if unprivileged ptrace is actually denied on every node.

    Spawns a background process on each node, then attempts to ptrace-attach
    to it as a temporary unprivileged user via python3 ctypes (no strace needed).
    Exit code 1 from the probe means the kernel denied the attach — correct.
    Exit code 0 means the attach succeeded — the mitigation is missing.

    Designed to be called after distribution or cluster upgrades to verify
    that the CVE-2026-46333 mitigation survived the upgrade.
    """
    machines = cluster.get_machines()
    ptrace_results_map = {}

    setup_cmd = (
        "useradd -M -s /sbin/nologin ptrace-probe-user 2>/dev/null || true; "
        "sleep 300 & echo $!"
    )

    for machine in machines:
        try:
            # Start the background target process and capture its PID
            pid_result = machine.run_cmd(
                f"bash -c '{setup_cmd}'",
                timeout=15,
                verbose=False,
            )
            target_pid = pid_result.stdout_str.strip().splitlines()[-1].strip()

            probe_cmd = _PTRACE_PROBE.format(pid=target_pid)
            attach_result = machine.run_cmd(
                f"sudo -u ptrace-probe-user bash -c '{probe_cmd}'; "
                f"echo EXIT:$?; "
                f"kill {target_pid} 2>/dev/null || true",
                timeout=30,
                verbose=False,
            )
            output = attach_result.stdout_str

            # sudo -u runs the probe; the trailing echo EXIT:$? captures probe exit code
            if "EXIT:1" in output:
                ptrace_results_map[machine.name] = "BLOCKED"
            elif "EXIT:0" in output:
                ptrace_results_map[machine.name] = "ALLOWED"
            else:
                LOG.warning(
                    "Unexpected probe output on %s: %r", machine.name, output
                )
                ptrace_results_map[machine.name] = None

        except Exception as e:
            LOG.warning("Failed ptrace probe on %s: %s", machine.name, e)
            ptrace_results_map[machine.name] = None

    is_blocked = all(v == "BLOCKED" for v in ptrace_results_map.values())

    if not is_blocked:
        LOG.warning(
            "Unprivileged ptrace restriction validation failed:\n%s",
            yaml.dump(ptrace_results_map),
        )

    return is_blocked
