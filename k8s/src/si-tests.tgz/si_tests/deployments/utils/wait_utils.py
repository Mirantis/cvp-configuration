import time

from si_tests.utils import waiters


class Waiter:
    def __init__(self, os_manager, timeout, namespace=None):
        self.timeout = timeout
        self.os_manager = os_manager
        self.namespace = namespace

    def statefulset(self, name, replicas=1, namespace=None):
        namespace = namespace or self.namespace
        self.pods(name, replicas, namespace)

        k8s_object = self.os_manager.api.statefulsets.get(name, namespace)

        def _wait():
            return k8s_object.read().status.ready_replicas

        self.wait(_wait)
        return self

    def pods(self, pod_name, replicas, namespace=None):
        namespace = namespace or self.namespace
        pods_api = self.os_manager.api.pods

        def _wait():
            return len(pods_api.list_starts_with(
                pod_name, namespace)) >= replicas

        self.wait(_wait)
        return self

    def daemonset(self, name, replicas=3, namespace=None):
        namespace = namespace or self.namespace

        self.pods(name, replicas, namespace)

        daemonset = self.os_manager.api.daemonsets.get(name, namespace)

        def _wait():
            return daemonset.read().status.number_ready >= replicas

        self.wait(_wait)
        return self

    def tf_vrouter_daemonsets(self, type, vrouter_nodes=1, namespace=None):
        namespace = namespace or self.namespace
        name_prefix = f"tf-vrouter-{type}"

        self.pods(name_prefix, vrouter_nodes, namespace)
        d_list = self.os_manager.api.daemonsets.list_starts_with(name_prefix)
        for d in d_list:
            def _wait():
                return d.read().status.number_ready == \
                       d.read().status.desired_number_scheduled

            self.wait(_wait)
        return self

    def deployment(self, name, replicas=1, namespace=None):
        namespace = namespace or self.namespace

        self.pods(name, replicas, namespace)

        k8s_object = self.os_manager.api.deployments.get(name, namespace)

        def _wait():
            return k8s_object.read().status.ready_replicas

        self.wait(_wait)
        return self

    def wait_pass(self, func, expected, *args, **kwargs):
        start_time = time.time()
        waiters.wait_pass(func, expected, timeout=self.timeout,
                          predicate_args=args, predicate_kwargs=kwargs)
        self.update_timeout(time.time() - start_time)
        return self

    def wait(self, func, *args, **kwargs):
        start_time = time.time()
        waiters.wait(func, timeout=self.timeout, predicate_args=args,
                     predicate_kwargs=kwargs)
        self.update_timeout(time.time() - start_time)
        return self

    @staticmethod
    def read_checker(k8s_object):
        k8s_object.read()
        return True

    def update_timeout(self, timedelta):
        self.timeout = self.timeout - timedelta
