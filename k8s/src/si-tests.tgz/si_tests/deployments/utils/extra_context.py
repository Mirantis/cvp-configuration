import os

from si_tests import settings
from . import file_utils
from si_tests import logger
from si_tests.managers.kaas_manager import Manager

LOG = logger.logger


class ExtraContext:
    def __init__(self):
        context_file = settings.OPENSTACK_DEPLOY_EXTRA_CONTEXT_FILE

        if os.path.exists(context_file):
            self._data = file_utils.render_yaml_content(context_file) or {}
            LOG.info(f"Extra context updated from {context_file}")
        else:
            self._data = {}
            LOG.info("Extra context is empty")

        self.kaas_manager = None
        self.kaas_child_manager = Manager()
        if settings.KUBECONFIG_MGMT_PATH:
            self.kaas_manager = Manager(kubeconfig=settings.KUBECONFIG_MGMT_PATH)

    def _get_child_cluster(self):
        k8s_node = self.kaas_child_manager.api.nodes.list()[0].name
        child_cluster = None
        for cluster in self.kaas_manager.get_clusters():
            for machine in cluster.get_machines():
                if machine.get_k8s_node_name() == k8s_node:
                    child_cluster = cluster
                    break
        return child_cluster

    @property
    def data(self):
        return self._data

    @property
    def third_party(self):
        return self.data.get("3rd-party", {})

    @property
    def metallb(self):
        return self.third_party.get("metallb", {})

    @property
    def ceph(self):
        return self.third_party.get("ceph", {})

    @property
    def openstack_cluster(self):
        return self.data.get("openstack", {})

    @property
    def openstack_controller(self):
        return self.data.get("operator", {})

    @property
    def tf_helm(self):
        return self.data.get("tf-helm", {})

    @property
    def tf_operator(self):
        return self.data.get("tf-operator", {})

    @property
    def openstack_opts(self):
        return self.data.get("openstack_opts", {})
