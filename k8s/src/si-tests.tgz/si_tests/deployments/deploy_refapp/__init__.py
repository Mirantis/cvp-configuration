import importlib

from si_tests import settings

module = importlib.import_module(f"si_tests.deployments.deploy_refapp.refapp_{settings.OPENSTACK_REFAPP_DEPLOYER}")
Refapp = getattr(module, f"Refapp{settings.OPENSTACK_REFAPP_DEPLOYER.capitalize()}")
