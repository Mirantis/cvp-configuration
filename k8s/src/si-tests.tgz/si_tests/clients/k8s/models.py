# coding: utf-8

from si_tests.clients.k8s.base import BaseModel, BaseModelList


class V1IAMClusterRoleBinding(BaseModel):
    pass


class V1IAMClusterRoleBindingList(BaseModelList):
    pass


class V1IAMGlobalRoleBinding(BaseModel):
    pass


class V1IAMGlobalRoleBindingList(BaseModelList):
    pass


class V1IAMRoleBinding(BaseModel):
    pass


class V1IAMRoleBindingList(BaseModelList):
    pass


class V1KaaSAWSResource(BaseModel):
    pass


class V1KaaSAWSResourceList(BaseModelList):
    pass


class V1KaaSCluster(BaseModel):
    pass
