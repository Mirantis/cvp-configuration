#    Copyright 2017 Mirantis, Inc.
#
#    Licensed under the Apache License, Version 2.0 (the "License"); you may
#    not use this file except in compliance with the License. You may obtain
#    a copy of the License at
#
#         http://www.apache.org/licenses/LICENSE-2.0
#
#    Unless required by applicable law or agreed to in writing, software
#    distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
#    WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
#    License for the specific language governing permissions and limitations


from si_tests.clients.k8s.base import K8sNamespacedResource
from si_tests.clients.k8s.base import K8sBaseManager


class K8sComponentStatus(K8sNamespacedResource):
    resource_type = 'componentstatus'

    def _read(self, **kwargs):
        return self._manager.api.read_component_status(self.name, **kwargs)


class K8sComponentStatusManager(K8sBaseManager):
    resource_class = K8sComponentStatus

    @property
    def api(self):
        return self._cluster.api_core

    def _list(self, namespace, **kwargs):
        return self.api.list_component_status(**kwargs)

    def _list_all(self, **kwargs):
        return self._list(None, **kwargs)

    def describe_fixed_resources(self):
        """Collect the release-independent properties of the resources

        To check that the upgrades don't change any collected here property.
        """
        data = {}
        for x in self.list_raw().to_dict()['items']:
            name = '{0}/{1}/{2}'.format(x['metadata']['namespace'],
                                        self.resource_type,
                                        x['metadata']['name'])
            conditions = x['conditions']
            #  conditions:
            #  - message: '{"health":"true"}'
            #    status: "True"
            #    ...
            for i, cond in enumerate(conditions):
                for k, v in cond.items():
                    res_name = '{0}/{1}/{2}'.format(name, i, k)
                    data[res_name] = v
        return data
