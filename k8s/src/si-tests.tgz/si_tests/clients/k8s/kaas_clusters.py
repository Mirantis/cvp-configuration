#    Copyright 2022 Mirantis, Inc.
#
#    Licensed under the Apache License, Version 2.0 (the "License"); you may
#    not use this file except in compliance with the License. You may obtain
#    a copy of the License at
#
#         http://www.apache.org/licenses/LICENSE-2.0
#
#    Unless required by applicable law or agreed to in writing, software
#    distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
#    WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
#    License for the specific language governing permissions and limitations

from si_tests.clients.k8s import base


class V1KaaSCluster(base.BaseModel):
    pass


class V1KaaSClusterList(base.BaseModelList):
    pass


class KaaSCluster(base.K8sNamespacedResource):
    resource_type = 'cluster'
    model = V1KaaSCluster

    @property
    def region(self) -> str:
        return self.data.get('metadata', {}).get('labels', {}).get('kaas.mirantis.com/region', '')

    @property
    def provider(self) -> str:
        return self.data.get('metadata', {}).get('labels', {}).get('kaas.mirantis.com/provider', '')


class KaaSClusterManager(base.K8sBaseManager):
    model = V1KaaSClusterList
    resource_class = KaaSCluster
    resource_group = 'cluster.k8s.io'
    resource_version = 'v1alpha1'
    resource_plural = 'clusters'
