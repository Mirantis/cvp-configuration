import os
import re

import yaml
from cassandra.cluster import Cluster
from packaging import version

import si_tests.utils.templates as template_utils
from si_tests import logger, settings
from si_tests.clients.k8s import K8sCluster
from si_tests.clients.k8s.base import K8sNamespacedResource
from si_tests.clients.k8s.daemonsets import K8sDaemonSet
from si_tests.clients.k8s.pods import K8sPod
from si_tests.clients.k8s.statefulsets import K8sStatefulSet
from si_tests.utils import utils, waiters

LOG = logger.logger


class TFManager(object):
    kubeconfig = None
    _tfoperator_version = None

    _tf_dbrestore = "tf-dbrestore"
    _tf_dbbackup_cronjob = "tf-dbbackup-job"
    _tf_dbrepair_cronjob = "tf-dbrepair-job"
    _cassandra_cluster_tf_config = "tf-cassandra-config"
    _backup_nfs_type = "pv_nfs"

    def __init__(self, kubeconfig=settings.KUBECONFIG_PATH):
        self._api = None
        self.kubeconfig = kubeconfig
        self.tf_namespace = "tf"
        self.tfoperator_name = settings.TF_OPERATOR_CR_NAME
        self._pod_tf_cli = None

        # Remote name for rclone. Value defined in TFOperator
        self.rclone_remote = "tf_backup"

    @property
    def api(self):
        """
        :rtype: cluster.K8sCluster
        """
        if self._api is None:
            if not os.path.isfile(self.kubeconfig):
                raise FileNotFoundError(
                    "kubeconfig file={} not found!".format(self.kubeconfig)
                )
            self._api = K8sCluster(kubeconfig=self.kubeconfig)
        return self._api

    def cql_session(self, ips):
        if not isinstance(ips, list):
            ips = [ips]
        return Cluster(ips).connect()

    def get_k8s_resource(self, resources_type, resource_name, read=False):
        resources_api = getattr(self.api, resources_type)
        resource = resources_api.get(name=resource_name, namespace=self.tf_namespace)
        if read:
            return resource.read()
        return resource

    def get_tf_helmbundle(self, read=False):
        return self.get_k8s_resource(
            "kaas_helmbundles", "tungstenfabric-operator", read
        )

    def get_tfoperator_deployment(self, read=False):
        return self.get_k8s_resource(
            "deployments", "tungstenfabric-operator", read
        )

    def tfoperator_version(self, cache=False):
        if self._tfoperator_version is None or cache is False:
            tfoperator_deployment = self.get_tfoperator_deployment()
            tf_deployment = tfoperator_deployment.read()
            tf_containers = tf_deployment.spec.template.spec.containers
            tf_container = [c for c in tf_containers if c.name == "manager" or c.name == "controller-v2"][0]
            img_ver = tf_container.image.split(':')[-1]
            # Cut stamp/hash for dev versions if present
            self._tfoperator_version = img_ver.split('-')[0]

        return self._tfoperator_version

    def get_tf_version(self):
        # Get TungstenFabric version from status
        return self.tfoperator(read=True).status.get("tfVersion")

    def tfoperator(self, read=False):
        resource_type = "tfoperator_v2"
        return self.get_k8s_resource(
            resource_type, self.tfoperator_name, read
        )

    def tfanalytics(self, read=False):
        resource_type = "tfanalytics_v2"
        return self.get_k8s_resource(
            resource_type, "tf-analytics", read
        )

    def tfconfig(self, read=False):
        resource_type = "tfconfig_v2"
        return self.get_k8s_resource(
            resource_type, "tf-config", read
        )

    def tfcontrol(self, read=False):
        resource_type = "tfcontrol_v2"
        return self.get_k8s_resource(
            resource_type, "tf-control", read
        )

    def tfvrouter(self, read=False):
        resource_type = "tfvrouter_v2"
        return self.get_k8s_resource(
            resource_type, "tf-vrouter", read
        )

    def tftest(self, read=False):
        resource_type = "tftest_v2"
        return self.get_k8s_resource(
            resource_type, "tf-test", read
        )

    def tftool(self, read=False):
        resource_type = "tftool_v2"
        return self.get_k8s_resource(
            resource_type, "tf-tool", read
        )

    def tfwebui(self, read=False):
        resource_type = "tfwebui_v2"
        return self.get_k8s_resource(
            resource_type, "tf-webui", read
        )

    def tfimageprecaching(self, read=False):
        resource_type = "tfimageprecaching_v2"
        return self.get_k8s_resource(
            resource_type, "tf-image-pre-caching", read
        )

    def tfdbbackup(self, read=False):
        resource_type = "tfdbbackup_v2"
        return self.get_k8s_resource(
            resource_type, "tf-dbbackup", read
        )

    def tfdbrestore(self, read=False):
        resource_type = "tfdbrestores_v2"
        return self.get_k8s_resource(
            resource_type, self._tf_dbrestore, read
        )

    def tfdbrepair(self, read=False):
        return self.get_k8s_resource(
            "tfdbrepairs", "tf-dbrepair", read
        )

    # 3rd party components
    def cassandracluster(self, read=False):
        return self.get_k8s_resource(
            "cassandracluster", self._cassandra_cluster_tf_config, read
        )

    def is_tf_tfdbbackup_remote_enabled(self):
        # Only apiv2 supports remoteSync
        path = 'spec:features:dbBackup:remoteSync:enabled'
        return self._get(self.tfoperator().data, path, default=False)

    def is_tfdbrestore_present(self):
        return self.api.tfdbrestores_v2.present(self._tf_dbrestore, self.tf_namespace)

    def _trigger_cronjob(self, cronjob):
        job_name = f"{cronjob.metadata.name}-{utils.gen_random_string(3)}"
        job_template = cronjob.spec.job_template
        job_template.metadata.name = job_name
        self.api.jobs.create(body=job_template, namespace=self.tf_namespace,
                             log_body=False)
        job = self.api.jobs.get(name=job_name, namespace=self.tf_namespace)
        return job

    def tfdbbackup_cronjob(self, read=False):
        return self.get_k8s_resource(
            "cronjobs", self._tf_dbbackup_cronjob, read
        )

    def is_tfdbbackup_cronjob_present(self):
        return self.api.cronjobs.present(self._tf_dbbackup_cronjob, self.tf_namespace)

    def trigger_tfdbbackup_cronjob(self):
        cronjob = self.tfdbbackup_cronjob(read=True)
        job = self._trigger_cronjob(cronjob)
        job.wait_finished()
        assert job.succeeded, f"Job {job.name} isn't succeeded"
        return job

    def get_db_pvc_name(self):
        path = 'spec:features:dbBackup:backupType'
        backup_type = self._get(self.tfoperator().data, path, default=None)
        pvc_name = "tf-dbbackup-nfs-pvc" if backup_type == self._backup_nfs_type else "tf-dbbackup-pvc"
        return pvc_name

    def tfdbrepair_cronjob(self, read=False):
        return self.get_k8s_resource(
            "cronjobs", self._tf_dbrepair_cronjob, read
        )

    def is_tfdbrepair_cronjob_present(self):
        return self.api.cronjobs.present(self._tf_dbrepair_cronjob, self.tf_namespace)

    def trigger_tfdbrepair_cronjob(self):
        cronjob = self.tfdbrepair_cronjob(read=True)
        job = self._trigger_cronjob(cronjob)
        job.wait_finished()
        assert job.succeeded, f"Job {job.name} isn't succeeded"
        return job

    def wait_casasndracluster_status(self, status="Running", timeout=600):
        cassandracluster = self.cassandracluster()
        waiters.wait(lambda: cassandracluster.data['status']['phase'] == status,
                     timeout=timeout, interval=5,
                     timeout_msg=f"Timeout wait for getting status {status}")

    def get_tf_control_pods(self):
        return self.api.pods.list(namespace=self.tf_namespace,
                                  label_selector='app=tf-control')

    def wait_tfcontrol_status(self, status="Ready", timeout=300):
        LOG.info(f"Wait until TF Control status becomes {status}")
        waiters.wait(lambda: self.tfcontrol().data['status']['health'] == status,
                     timeout=timeout, interval=3,
                     timeout_msg=f"Timeout wait for getting status {status}")

    def get_config_daemonset(self, read=False):
        return self.get_k8s_resource(
            "daemonsets", "tf-config", read
        )

    def get_tf_config_pods(self):
        return self.api.pods.list(namespace=self.tf_namespace,
                                  label_selector='tungstenfabric=config')

    def wait_tfconfig_status(self, status="Ready", timeout=300):
        LOG.info(f"Wait until TF Config status becomes {status}")
        waiters.wait(lambda: self.tfconfig().data['status']['health'] == status,
                     timeout=timeout, interval=3,
                     timeout_msg=f"Timeout wait for getting status {status}")

    def get_precaching_daemonsets(self):
        return self.api.daemonsets.list(namespace=self.tf_namespace,
                                        label_selector="app=tf-image-pre-caching")

    def get_vrouter_daemonsets(self):
        daemonsets = []
        for kind in ['agent', 'agent-dpdk']:
            label = ('app=tf-vrouter-{}'.format(kind))
            ds_filtered = self.api.daemonsets.list(namespace=self.tf_namespace,
                                                   label_selector=label)
            daemonsets.extend(ds_filtered)
        return daemonsets

    def get_vrouter_pods(self):
        pods = []
        for kind in ['agent', 'agent-dpdk']:
            label = ('app=tf-vrouter-{}'.format(kind))
            pods_filtered = self.api.pods.list(namespace=self.tf_namespace,
                                               label_selector=label)
            pods.extend(pods_filtered)
        return pods

    def get_vrouter_nodes(self):
        nodes = []
        selectors = ['tfvrouter=enabled', 'tfvrouter-dpdk=enabled']
        for selector in selectors:
            nodes.extend(self.api.nodes.list(
                namespace=self.tf_namespace,
                label_selector=selector
            ))
        return nodes

    def update_tfvrouter_pods(self):
        path = 'spec:containers'
        if not self.is_vrouter_component_updated():
            LOG.info("TFVrouter components weren't updated. Restart vRouter pods")
            for pod in self.get_vrouter_pods():
                containers = self._get(pod.data, path, default=[])
                container = self._get_item_by_attribute(containers, 'name', 'agent')
                LOG.info(f"Delete {pod.name} pod (image: {container['image']})")
                pod.delete()
            LOG.info("Wait until TFVrouter is updated.")
            waiters.wait(
                self.is_vrouter_component_updated,
                timeout=180,
                timeout_msg="TFVrouter components weren't updated",
            )
        LOG.info("TFVrouter components are updated:")
        for pod in self.get_vrouter_pods():
            containers = self._get(pod.data, path, default=[])
            container = self._get_item_by_attribute(containers, 'name', 'agent')
            LOG.info(f"{pod.name} image: {container['image']}")

    def get_analytics_nodes(self):
        nodes = []
        selectors = ['tfanalytics=enabled,tfanalyticsdb=enabled',
                     'tfanalytics=disabled,tfanalyticsdb=disabled']
        for selector in selectors:
            nodes.extend(self.api.nodes.list(
                namespace=self.tf_namespace,
                label_selector=selector
            ))
        return nodes

    def get_tf_services_cfgmap(self):
        return self.api.configmaps.get(name="tf-services-cfgmap",
                                       namespace=self.tf_namespace)

    @staticmethod
    def _is_k8s_res_not_exist(k8s_res: K8sNamespacedResource):
        return not utils.is_k8s_res_exist(k8s_res)

    @staticmethod
    def _is_ds_updated(k8s_obj: K8sDaemonSet):
        current_num = k8s_obj.data['status'].get('current_number_scheduled')
        updated_num = k8s_obj.data['status'].get('updated_number_scheduled')
        LOG.info(f"DaemonSet {k8s_obj} update status: {updated_num}/{current_num}")
        return updated_num == current_num

    @staticmethod
    def _is_ds_ready(k8s_obj: K8sDaemonSet):
        desired_num = k8s_obj.data['status'].get('desired_number_scheduled')
        ready_num = k8s_obj.data['status'].get('number_ready')
        LOG.info(f"DaemonSet {k8s_obj} ready status: {ready_num}/{desired_num}")
        return ready_num == desired_num

    @staticmethod
    def _is_sts_ready(k8s_obj: K8sStatefulSet):
        desired_num = k8s_obj.data['status'].get('replicas')
        ready_num = k8s_obj.data['status'].get('ready_replicas')
        LOG.info(f"StatefulSet {k8s_obj} ready status: {ready_num}/{desired_num}")
        return ready_num == desired_num

    @staticmethod
    def _get(dict_obj: dict, path, default=None):
        for key in path.split(':'):
            dict_obj = dict_obj.get(key, {})
        if dict_obj == {}:
            dict_obj = default
        return dict_obj

    @staticmethod
    def _get_item_by_attribute(list_obj: list, attr, name):
        for obj in list_obj:
            if obj.get(attr, None) == name:
                return obj
        return None

    def _get_env_var(self, k8s_obj: K8sNamespacedResource, path, env_name):
        envs = self._get(k8s_obj.data, path, default=[])
        env = list(filter(lambda x: x['name'] == env_name, envs))[0]['value']
        return env

    def get_storage_class(self):
        path = 'spec:dataStorageClass'
        return self._get(self.tfoperator().data, path, default=False)

    def set_netns_availability_zone(self, az_name):
        patch = {
            "spec": {
                "features": {
                    "config": {
                        "netnsAZ": az_name
                    }
                }
            }
        }
        self.tfoperator().patch(patch)

        def tf_config_netns_az():
            env_name = 'NETNS_AVAILABILITY_ZONE'
            path = 'spec:envSettings:svcMonitor'
            envs = self._get(self.tfconfig().data, path, default=[])
            env = self._get_item_by_attribute(envs, 'name', env_name)
            return env['value'] if env else env

        def ds_config_netns_az():
            env_name = 'NETNS_AVAILABILITY_ZONE'
            path = 'spec:template:spec:containers'
            containers = self._get(self.get_config_daemonset().data, path)
            container = self._get_item_by_attribute(containers, 'name', 'svc-monitor')
            env = self._get_item_by_attribute(container['env'], 'name', env_name)
            return env['value'] if env else env

        waiters.wait(lambda: tf_config_netns_az() == az_name, timeout=180, interval=10)
        waiters.wait(lambda: ds_config_netns_az() == az_name, timeout=180, interval=10)
        waiters.wait(self._is_ds_updated, predicate_args=[self.get_config_daemonset()],
                     timeout=180, interval=10)
        waiters.wait(self._is_ds_ready, predicate_args=[self.get_config_daemonset()],
                     timeout=180, interval=10)

    def is_tf_cli_enabled(self):
        path = 'spec:features:tfTools:tfCliEnabled'
        return self._get(self.tfoperator().data, path, default=False)

    def enable_tf_cli(self, state=True):
        LOG.info(f"Set TF cli to ${state}")
        tfoperator = self.tfoperator()
        current = self.is_tf_cli_enabled()
        if current == state:
            LOG.info(f"TF cli state is already: {current}")
        else:
            patch = {
                "spec": {
                    "features": {
                        "tfTools": {
                            "tfCliEnabled": state
                        }
                    }
                }
            }
            tfoperator.patch(patch)

    def is_ctools_enabled(self):
        path = 'spec:features:tfTools:tfToolsEnabled'
        return self._get(self.tfoperator().data, path, default=False)

    def enable_ctools(self, state=True, labels=None):
        LOG.info(f"Set TF contrail-tools to ${state}")
        if not labels:
            labels = {'tfvrouter': 'enabled'}
        tfoperator = self.tfoperator()
        current = self.is_ctools_enabled()
        if current == state:
            LOG.info(f"TF contrail-tools (ctools) state is already: {current}")
        else:
            patch = {
                "spec": {
                    "features": {
                        "tfTools": {
                            "tfToolsEnabled": state,
                            "labels": labels
                        }
                    }
                }
            }
            tfoperator.patch(patch)

    def is_image_precaching_enabled(self):
        path = 'spec:features:imagePreCaching'
        return self._get(self.tfoperator().data, path, default=True)

    def enable_image_precaching(self, state=True):
        LOG.info(f"Set TF imagePreCaching feature state: {state}")
        tfoperator = self.tfoperator()
        current = self.is_image_precaching_enabled()
        if current == state:
            LOG.info(f"TF imagePreCaching state is already: {current}")
        else:
            patch = {
                "spec": {
                    "features": {
                        "imagePreCaching": state
                    }
                }
            }
            tfoperator.patch(patch)

    def wait_tf_imageprecaching(self, exist=True, timeout=300, interval=10):
        LOG.info(f"Waiting until TF ImagePreCaching resource is existed == {exist}")
        waiters.wait(
            lambda: utils.is_k8s_res_exist(self.tfimageprecaching()) is exist,
            interval=interval,
            timeout=timeout,
        )

    def get_imageprecaching_pods(self):
        return self.api.pods.list(namespace=self.tf_namespace,
                                  label_selector='app=tf-image-pre-caching')

    def is_dbrepair_enabled(self):
        # Only apiv2 is supported
        path = 'spec:features:dbRepair:enabled'
        return self._get(self.tfoperator().data, path, default=False)

    def configure_dbrepair(self, state=True, suspend=None, schedule=None):
        patch = {
            "spec": {
                "features": {
                    "dbRepair": {
                        "enabled": state,
                    }
                }
            }
        }
        dbrepair = patch["spec"]["features"]["dbRepair"]
        if suspend:
            dbrepair["suspend"] = suspend
        if schedule:
            dbrepair["schedule"] = schedule
        self.tfoperator().patch(patch)

    def is_analytics_enabled(self):
        if version.parse(self.tfoperator_version()) >= version.parse("0.14"):
            default = False
        else:
            default = True
        path = 'spec:services:analytics:enabled'
        state = self._get(self.tfoperator().data, path, default=default)
        return state

    def enable_analytics(self, state=True):
        LOG.info(f"Set TF Analytics to ${state}")
        tfoperator = self.tfoperator()
        current = self.is_analytics_enabled()
        if current == state:
            LOG.info(f"TF Analytics state is already: {current}")
        else:
            patch = {
                "spec": {
                    "services": {
                        "analytics": {
                            "enabled": state,
                        }
                    }
                }
            }
            tfoperator.patch(patch)
        self.wait_tf_analytics(exist=state)

    def wait_tf_analytics(self, exist=True, timeout=180, interval=10):
        tfanalytics = self.tfanalytics()
        if exist:
            LOG.info("Wait until TF Analytics resource is created")
            check_func = utils.is_k8s_res_exist
        else:
            LOG.info("Wait until TF Analytics resource is deleted")
            check_func = self._is_k8s_res_not_exist
        waiters.wait(
            check_func,
            predicate_args=[tfanalytics],
            interval=interval,
            timeout=timeout,
        )

    def is_gracefulRestart_enabled(self):
        path = 'spec:features:control:gracefulRestart:enabled'
        return self._get(self.tfoperator().data, path, default=False)

    def db_backup(self, state=True):
        LOG.info(f"Set TF DB backup to ${state}")
        tfoperator = self.tfoperator()
        patch = {
            "spec": {
                "features": {
                    "dbBackup": {
                        "enabled": state,
                    }
                }
            }
        }
        tfoperator.patch(patch)
        self.wait_db_backup_cronjob(exist=state)

    def wait_db_backup_cronjob(self, exist=True, timeout=180, interval=10):
        dbbackup_cronjob = self.tfdbbackup_cronjob()
        if exist:
            LOG.info("Wait until TF DB Backup cronjob is created")
            check_func = utils.is_k8s_res_exist
        else:
            LOG.info("Wait until TF DB Backup cronjob is deleted")
            check_func = self._is_k8s_res_not_exist
        waiters.wait(
            check_func,
            predicate_args=[dbbackup_cronjob],
            interval=interval,
            timeout=timeout,
        )

    def db_restore(self, backup_file=""):
        LOG.info("Enable TF DB Restore procedure")
        tfoperator = self.tfoperator()
        patch = {
            "spec": {
                "features": {
                    "dbRestoreMode": {
                        "dbDumpName": backup_file,
                        "enabled": True,
                    }
                }
            }
        }
        tfoperator.patch(patch)
        self.wait_db_restore()

    def wait_db_restore(self):
        tfdbrestore = self.tfdbrestore()
        waiters.wait(utils.is_k8s_res_exist, predicate_args=[tfdbrestore],
                     timeout=600, interval=10,
                     timeout_msg="Timeout wait for tfdbrestore object")
        waiters.wait(lambda: tfdbrestore.data['status']['health'] == "Ready",
                     timeout=7200, interval=30,
                     timeout_msg="Timeout wait for restoration status Ready")

    @property
    def _devOptions(self) -> dict:
        tf_operator_cr = self.tfoperator()
        spec = tf_operator_cr.data['spec']
        return spec.get('devOptions', {})

    def unpin_images(self):
        """Unpin images in TFOperator CR by removing tfImage and images from devOptions.

        This allows the operator to use images from the helmbundle during upgrade
        instead of pinned image versions.
        """
        LOG.info("Unpinning images in TFOperator CR before upgrade")
        tfoperator = self.tfoperator()
        spec = tfoperator.data.get('spec', {})

        # Check if devOptions exists and has image overrides
        dev_options = spec.get('devOptions') or {}
        has_tf_image = dev_options.get('tfImage') is not None
        has_images = dev_options.get('images') is not None

        if not has_tf_image and not has_images:
            LOG.info("No pinned images found in TFOperator CR")
            return

        # Wait for TF Operator deployment only
        def _tf_operator_deployment_ready():
            dep = self.get_tfoperator_deployment().read()
            status = getattr(dep, 'status', None)
            dep_spec = getattr(dep, 'spec', None)
            ready = getattr(status, 'ready_replicas', None) if status else None
            replicas = getattr(dep_spec, 'replicas', None) if dep_spec else None
            return (
                ready is not None
                and replicas is not None
                and ready == replicas
            )

        LOG.info("Wait for TF Operator deployment ready before patching CR")
        waiters.wait(
            _tf_operator_deployment_ready,
            timeout=120,
            interval=10,
            timeout_msg="TF Operator deployment not ready",
        )

        # Build patch to remove image overrides
        # In Kubernetes merge patches, we must explicitly set fields to None to remove them
        patch = {
            "spec": {
                "devOptions": {}
            }
        }

        # Preserve other devOptions fields if they exist
        if dev_options:
            for key, value in dev_options.items():
                if key not in ['tfImage', 'images']:
                    patch["spec"]["devOptions"][key] = value

        # Explicitly set tfImage and images to None to remove them
        if has_tf_image:
            LOG.info("Removing tfImage override from TFOperator CR")
            patch["spec"]["devOptions"]["tfImage"] = None
        if has_images:
            LOG.info("Removing images override from TFOperator CR")
            patch["spec"]["devOptions"]["images"] = None

        def _patch_and_check_unpinned():
            tfoperator.patch(patch)
            op = self.tfoperator()
            dev_opts = (op.data.get('spec') or {}).get('devOptions') or {}
            return (dev_opts.get('tfImage') is None and
                    dev_opts.get('images') is None)

        waiters.wait(
            _patch_and_check_unpinned,
            timeout=120,
            interval=10,
            timeout_msg="Failed to patch TFOperator CR",
        )
        LOG.info("Images unpinned successfully")

    def is_forceUpdate(self):
        return self._devOptions.get('forceUpdate', True)

    def is_vgw_disabled(self):
        return self._devOptions.get('disableVirtualGateway', False)

    def get_vgw_nodes(self):
        """Return k8s Node objects labeled as Octavia/Simple-VGW gateways.

        These are the computes carrying both ``openstack-gateway=enabled`` and
        ``tfvrouter=enabled`` where the ``tf-vrouter-vgw`` DaemonSet provisions
        the ``vgw`` interface into the ``lb-mgmt-net`` overlay VRF
        (PRODX-61681).
        """
        return self.api.nodes.list(
            label_selector="openstack-gateway=enabled,tfvrouter=enabled")

    def get_vgw_daemonset_pods(self):
        """Return the tf-vrouter-vgw DaemonSet pods."""
        return self.api.pods.list(namespace=self.tf_namespace,
                                  label_selector="app=tf-vrouter-vgw")

    def get_node_vgw_routes(self, node_name):
        """Return the list of routes pointing to the ``vgw`` interface on a
        gateway compute (as raw ``ip route`` lines)."""
        cmd = "ip route show table all | grep -w vgw || true"
        res = self.exec_pod_cmd(node_name, cmd, verbose=False)
        lines = [ln.strip() for ln in (res.get('logs') or '').splitlines()
                 if ln.strip()]
        LOG.info(f"[{node_name}] vgw routes: {lines}")
        return lines

    def get_node_vgw_snat_rules(self, node_name):
        """Return POSTROUTING SNAT rules that target the ``vgw`` interface on a
        gateway compute. The rules are added by the vgw provisioning script to
        iptables (legacy backend on MOSK nodes); we query both backends."""
        cmd = ("(iptables-legacy -t nat -S POSTROUTING 2>/dev/null; "
               "iptables -t nat -S POSTROUTING 2>/dev/null) | "
               "grep -w vgw || true")
        res = self.exec_pod_cmd(node_name, cmd, verbose=False)
        lines = [ln.strip() for ln in (res.get('logs') or '').splitlines()
                 if ln.strip() and not ln.strip().startswith('#')]
        LOG.info(f"[{node_name}] vgw SNAT rules: {lines}")
        return lines

    def get_node_vgw_snat_sources(self, node_name):
        """Return the set of ``--to-source`` IPs used by the vgw SNAT rules on
        a gateway compute (should be that compute's own LCM IP)."""
        sources = set()
        for rule in self.get_node_vgw_snat_rules(node_name):
            m = re.search(r'--to-source\s+(\d+\.\d+\.\d+\.\d+)', rule)
            if m:
                sources.add(m.group(1))
        LOG.info(f"[{node_name}] vgw SNAT sources: {sources}")
        return sources

    def check_vgw_routing(self, node_name):
        """Validate the PRODX-61108 per-node Simple-VGW routing model.

        The selective host-scoped (``/32``) route lives inside the Contrail
        ``lb-mgmt-net`` VRF (not the host routing table), so on the host we
        assert the parts that are visible there and that distinguish the fixed
        behaviour from the obsolete single-gateway one:

          * the ``vgw`` interface is provisioned (has an overlay route),
          * it carries the selective overlay subnet, not a ``0.0.0.0/0``
            default route,
          * a POSTROUTING SNAT rule for control-plane traffic towards the
            overlay via ``vgw`` exists -- the host-visible signature of the
            PRODX-61108/IDEA-2487 fix (the legacy script only added a FORWARD
            accept, no SNAT).
        """
        routes = self.get_node_vgw_routes(node_name)
        snat_rules = self.get_node_vgw_snat_rules(node_name)

        assert routes, (f"No routes via vgw interface found on gateway node "
                        f"{node_name}; Simple VGW is not provisioned")
        assert not any(r.startswith('default') or '0.0.0.0/0' in r
                       for r in routes), (
            f"Obsolete default route (0.0.0.0/0) is present via vgw on "
            f"{node_name}: {routes} (regression of PRODX-61108/IDEA-2487)")
        assert any('SNAT' in r for r in snat_rules), (
            f"No SNAT rule towards the overlay via vgw on {node_name}: "
            f"{snat_rules} (PRODX-61108 fix not applied)")
        return True

    def is_tftest_enabled(self):
        path = 'spec:features:tfTest:enabled'
        return self._get(self.tfoperator().data, path, default=False)

    def enable_tf_test(self, state=True):
        LOG.info(f"Set TF Test parameter enabled={state}")
        tfoperator = self.tfoperator()
        current = self.is_tftest_enabled()
        if current == state:
            LOG.info(f"TF Test (tungsten-pytest) state is already: {current}")
        else:
            patch = {
                "spec": {
                    "features": {
                        "tfTest": {
                            "enabled": state,
                        }
                    }
                }
            }
            tfoperator.patch(patch)
        self.wait_tf_test(enabled=state)

    def wait_tf_test(self, enabled=True, timeout=300, interval=10):
        tftest = self.tftest()
        LOG.info(f"Wait until TF Test parameter enabled={enabled}")
        path = 'spec:enabled'
        waiters.wait(
            lambda: self._get(tftest.data, path) == enabled,
            timeout=timeout, interval=interval,
            timeout_msg=f"Timeout wait for TF Test state {enabled}"
        )

    def run_pytest(self):
        # Run TF verification tests (tungsten-pytest) and return pod status.
        LOG.info("Run TF Test (tungsten-pytest)")
        tftest_pod_name = "tf-test-tungsten-pytest"
        if self.is_tftest_enabled():
            LOG.info("Disable tungsten-pytest before new run")
            self.enable_tf_test(state=False)
            # Wait until pod will be deleted
            waiters.wait(
                lambda: not self.api.pods.present(
                    tftest_pod_name, namespace=self.tf_namespace),
                timeout=180, interval=10
            )
        LOG.info("Enable tungsten-pytest")
        self.enable_tf_test(state=True)
        waiters.wait(
            lambda:
            self.api.pods.present(tftest_pod_name, namespace=self.tf_namespace),
            timeout=180, interval=10
        )
        test_pod = self.api.pods.get(tftest_pod_name,
                                     namespace=self.tf_namespace)
        LOG.info("Wait for pod to be Completed...")
        test_pod.wait_phase(['Succeeded', 'Failed'], timeout=900)
        return test_pod.read().status.phase

    @staticmethod
    def _check_health_status(k8s_resource: K8sNamespacedResource,
                             expected_status):
        return k8s_resource.read().status.get("health") == expected_status

    def _check_modules_health_status(self, k8s_tf_resources, expected_status):
        status = True
        for k8s_resource in k8s_tf_resources:
            if not self._check_health_status(k8s_resource, expected_status):
                status = False
        return status

    def is_vrouter_component_updated(self):
        return self.tfvrouter().read().status.get("updated") == "Yes"

    @staticmethod
    def _is_pod_restarted(pod: K8sPod, init_restarts: int):
        return pod.get_restarts_number() != init_restarts

    def wait_pod_restarted(self, pod: K8sPod, timeout=180, interval=5):
        init_restarts = pod.get_restarts_number()
        waiters.wait(
            self._is_pod_restarted,
            predicate_args=[pod, init_restarts],
            interval=interval,
            timeout=timeout,
            timeout_msg=f"K8s {pod.resource_type} {pod.name} wasn't restarted",
        )
        LOG.info(f"Number of container restarts for {pod.resource_type}"
                 f" {pod.name} was changed from {init_restarts} to"
                 f" {pod.get_restarts_number()}")

    def wait_tfoperator_healthy(self, expected_status="Ready", timeout=900,
                                interval=10):
        LOG.info(f"Wait until TF operator health status becomes {expected_status}")
        waiters.wait(
            self._check_health_status,
            predicate_args=[self.tfoperator(), expected_status],
            interval=interval,
            timeout=timeout,
            timeout_msg=f"TFOperator doesn't reached status "
                        f"`{expected_status}`",
        )

    def wait_for_hold_healthy(self, expected_status="Ready", interval=5, hold_duration=120,  timeout=600):
        LOG.info(f"Wait until TF operator is healthy for {hold_duration} seconds:")

        waiters.wait_for_hold(
            self._check_health_status,
            predicate_args=[self.tfoperator(), expected_status],
            interval=interval,
            timeout=timeout,
            hold_duration=hold_duration,
            timeout_msg=f"TFOperator doesn't reached status "
                        f"`{expected_status}`",
        )
        LOG.info(f"TFOperator health status is {expected_status}.")

    def wait_tf_modules_updated(self, timeout=300, interval=10):
        LOG.info("Wait until TF operator modules to be updated:")
        not_updated = {}

        def _check_modules_updated():
            nonlocal not_updated
            modules = self.tfoperator().read().status.get('modules') or {}
            not_updated = {name: info.get('updated')
                           for name, info in modules.items()
                           if info.get('updated') != "Yes"}
            for name, updated in not_updated.items():
                LOG.info(f"TF module {name} updated: {updated}")
            return not not_updated

        waiters.wait(
            _check_modules_updated,
            interval=interval,
            timeout=timeout,
            timeout_msg="TFOperator modules aren't updated",
            status_msg_function=lambda: f" Not updated modules: {not_updated}",
        )
        LOG.info("TFOperator modules are updated.")

    def wait_tf_controllers_healthy(self, expected_status="Ready", timeout=180,
                                    interval=10):
        LOG.info("Wait TF controllers are healthy:")
        # Main components, enabled by default:
        resources = [self.tfconfig(), self.tfcontrol(),  self.tfvrouter()]
        if self.is_analytics_enabled():
            resources.append(self.tfanalytics())
            self.wait_tf_analytics(exist=True, timeout=450)
        waiters.wait(
            self._check_modules_health_status,
            predicate_args=[resources, expected_status],
            interval=interval,
            timeout=timeout,
            timeout_msg=f"TF controllers don't reached status: {expected_status}",
        )
        LOG.info(f"TF controllers have status: {expected_status}")

    def _are_pods_on_node_ready(self, node_name):
        pods = self.api.pods.list_raw(
            field_selector=f"spec.nodeName={node_name}")
        inactive = [p.metadata.name for p in pods.items if
                    p.status.phase.lower()
                    not in ('running', 'succeeded')]
        if inactive:
            LOG.info(f"Following pods are not ready: {inactive}")
            return False
        return True

    def wait_all_pods_on_node(self, node_name, timeout=300, interval=5):
        LOG.info(f"Wait all pods on node {node_name} are ready.")
        waiters.wait(
            self._are_pods_on_node_ready,
            predicate_args=[node_name],
            interval=interval,
            timeout=timeout,
            timeout_msg="Some pods aren't in running/succeeded phase",
        )

    def get_gr_job(self, read=False):
        return self.get_k8s_resource(
            "jobs", "gr-settings", read
        )

    def wait_gr_gob(self, timeout=120, interval=3):
        job = self.get_gr_job()
        LOG.info(f"Wait {job} is created.")
        waiters.wait(
            utils.is_k8s_res_exist,
            predicate_args=[job],
            interval=interval,
            timeout=timeout,
        )
        return job

    def get_api_conversion_job(self, read=False):
        return self.get_k8s_resource(
            "jobs", "tungstenfabric-operator-covert-to-v2", read
        )

    def wait_api_conversation_job(self, timeout=120, interval=3):
        job = self.get_api_conversion_job()
        LOG.info(f"Wait {job} is created.")
        waiters.wait(
            utils.is_k8s_res_exist,
            predicate_args=[job],
            interval=interval,
            timeout=timeout,
        )
        return job

    def get_confmap_apiv1_backup(self, read=False):
        return self.get_k8s_resource(
            "configmaps", "tfoperator-v1alpha1-copy", read
        )

    @property
    def pod_tf_cli(self):
        if ((self._pod_tf_cli and not self.api.pods.present(name=self._pod_tf_cli.name, namespace=self.tf_namespace))
                or not self._pod_tf_cli):
            pods = self.api.pods.list(namespace=self.tf_namespace, name_prefix="tf-tool-cli")
            self._pod_tf_cli = pods[0]
        return self._pod_tf_cli

    def exec_tf_cli_pod(self, cmd):
        return self.pod_tf_cli.exec(['/bin/sh', '-c', cmd])

    def exec_pod_cmd(self, node_name, cmd, verbose=True, timeout=600,
                     delete_pod=True):
        """Execute cmd in a privileged pod on the given node

        Doesn't require SSH access to the Node.

        * The {cmd} is executed in the privileged container from
          the chroot to the node's root filesystem /

        * A separated pod is started and removed for each {cmd}, so
          it will spend some time to pull the image and start the pod.

        * There is no way to interact with {cmd} from shell while it
          is executed. All required parameters must be set in {cmd}

        * There is no way to separate stdout from stderr, all the
          info is collected from the pod "logs".

        :rtype dict: {'logs': <str>, 'events': <str>, 'exit_code': <int>}
        """
        pod_name = "exec-pod-cmd-{}".format(utils.gen_random_string(6))
        pod_namespace = 'default'
        render_options = {
            'POD_NAME': pod_name.lower(),
            'POD_CMD': cmd,
            'NODE_NAME': str(node_name).lower(),
            'MCP_DOCKER_REGISTRY': "mirantis.azurecr.io",
        }
        pod_template = yaml.safe_load(template_utils.render_template(
            settings.MACHINE_PRIVELEGED_POD_YAML, options=render_options,
            log_env_vars=False, log_template=False))

        pod = self.api.pods.create(name=pod_name, namespace=pod_namespace,
                                   body=pod_template, log_body=False)
        if verbose:
            _LOG = LOG.info
            _ERRLOG = LOG.error
        else:
            _LOG = LOG.debug
            _ERRLOG = LOG.debug
        try:
            pod.wait_phase(['Succeeded', 'Failed'],
                           timeout=timeout, interval=1)
            pod_status = pod.read().status
            container_state = pod_status.container_statuses[0].state
            if container_state.terminated is not None:
                exit_code = container_state.terminated.exit_code
            else:
                exit_code = -1
                LOG.debug(f"Pod {pod.name} has wrong container status:\n"
                          f"{pod_status}")

            logs = pod.get_logs()
            events = None
            _LOG(f"[{node_name}] Output of the command "
                 f"\"{cmd}\":\n{logs}")
            _LOG(f"Events after command execution:\n{events}")
            _LOG(f"Exit code: {exit_code}")
            return {'logs': logs,
                    'events': events,
                    'exit_code': exit_code}
        except Exception as e:
            _ERRLOG(f"Error while running pod {pod_name}:\n{e}")
            raise (e)
        finally:
            if delete_pod:
                pod.delete()

    def get_rabbitmq_pods(self):
        return self.api.pods.list(namespace=self.tf_namespace,
                                  label_selector='app=rabbitmq')

    def wait_sts_redis_ready(self, timeout=180, interval=3):
        sts = self.api.statefulsets.get(name="tf-rabbitmq", namespace=self.tf_namespace)
        waiters.wait(self._is_sts_ready, predicate_args=[sts],
                     timeout=timeout, interval=interval)

    def get_redis_pods(self):
        return self.api.pods.list(namespace=self.tf_namespace,
                                  label_selector='redis=tf-redis')

    def wait_sts_rabbitmq_ready(self, timeout=180, interval=3):
        sts = self.api.statefulsets.get(name="redis-tf-redis", namespace=self.tf_namespace)
        waiters.wait(self._is_sts_ready, predicate_args=[sts],
                     timeout=timeout, interval=interval)

    def get_zookeeper_pods(self):
        return self.api.pods.list(namespace=self.tf_namespace,
                                  label_selector='app=tf-zookeeper')

    def wait_sts_zookeeper_ready(self, timeout=180, interval=3):
        sts = self.api.statefulsets.get(name="tf-zookeeper", namespace=self.tf_namespace)
        waiters.wait(self._is_sts_ready, predicate_args=[sts],
                     timeout=timeout, interval=interval)

    def get_cassandra_pods(self):
        return self.api.pods.list(namespace=self.tf_namespace,
                                  label_selector=f'cassandracluster={self._cassandra_cluster_tf_config}')

    def get_cassandra_pvcs(self):
        return self.api.pvolumeclaims.list(namespace=self.tf_namespace,
                                           label_selector=f'cassandracluster={self._cassandra_cluster_tf_config}')

    def get_cassandra_svc(self):
        return self.api.services.get(name=self._cassandra_cluster_tf_config, namespace=self.tf_namespace)

    def check_cassandra_cluster(self) -> bool:
        # Check cassandra cluster consistency and node statuses.
        healthy = True
        sts_name = f"{self._cassandra_cluster_tf_config}-dc1-rack1"
        sts = self.api.statefulsets.get(name=sts_name, namespace=self.tf_namespace)
        replicas = int(sts.read().spec.replicas)
        pods = self.api.pods.list_starts_with(sts_name, namespace=self.tf_namespace)
        LOG.info(f"Total {sts_name} pods: {len(pods)}/{replicas}")

        cmd = ['/bin/sh', '-c',
               "nodetool status 2>/dev/null | grep rack | awk '{print $1\";\"$2\";\"$7}'"]
        output = pods[0].exec(cmd, container='cassandra')
        if len(output) > 0:
            LOG.info(f"Status of cassandra nodes:\n{output}")
            cassandra_nodes = output.splitlines()
            if len(cassandra_nodes) != replicas:
                LOG.warning(f"Amount of cassandra nodes ({len(cassandra_nodes)}) in config isn't equal to the number "
                            f"of replicas")
                healthy = False
            for cassandra_node in cassandra_nodes:
                status = cassandra_node.split(";")[0]
                ip = cassandra_node.split(";")[1]
                node_id = cassandra_node.split(";")[2]
                if status != "UN":
                    LOG.warning(f"Unexpected cassandra node status: {status} {ip} {node_id}")
                    healthy = False
        else:
            LOG.error("Cant read cassandra nodes list, command returned empty data")
            return False

        cmd = ['/bin/sh', '-c', "nodetool describecluster"]
        output = pods[0].exec(cmd, container='cassandra')
        LOG.info(f"Schema versions of cassandra cluster:\n{output}")
        schema_pattern = re.compile(r'\s*([0-9a-fA-F\-]{36})\s*:\s*\[(.*)\]')
        unreachable_pattern = re.compile(r'\s*UNREACHABLE\s*:\s*\[(.*)\]', re.IGNORECASE)
        schemas = schema_pattern.findall(output)
        unreachables = unreachable_pattern.findall(output)
        if len(schemas) != 1:
            LOG.warning(f"The number of schemas in the Cassandra cluster is not equal to 1: ({len(schemas)})")
            healthy = False
        if unreachables:
            LOG.warning(f"Cassandra cluster contains UNREACHABLE nodes: {unreachables}")
            healthy = False
        nodes = schemas[0][1].split(',')
        if len(nodes) != replicas:
            LOG.warning(f"Amount of cassandra nodes ({len(nodes)}) in cluster schema isn't equal to the number "
                        f"of replicas")
            healthy = False

        return healthy
