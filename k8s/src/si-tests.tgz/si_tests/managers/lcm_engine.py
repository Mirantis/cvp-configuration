"""LCM-engine abstraction for HA tests.

Management/child clusters can run one of two LCM engines:

* **MKE** (``lcmType: ucp``)  -- control-plane components run as Docker Swarm
  containers named ``ucp-*``; the node LCM daemon is ``docker.service``.
* **k0s** (``lcmType: k0s``) -- control-plane components run as host processes
  supervised by k0s (``/var/lib/k0s/bin/kube-apiserver`` etc.); the node LCM
  daemon is ``k0scontroller.service`` and the runtime is containerd at
  ``/run/k0s/containerd.sock``.

HA checks used to talk to Docker directly (``docker ps/kill/pause``), which only
works on MKE and is skipped on k0s. This module hides the difference behind a
single interface so that a single HA scenario works on both engines.

Entry point: ``cluster.lcm_engine`` (see ``kaas_manager.Cluster``) returns the
right implementation based on ``cluster.lcm_type``.
"""
from si_tests import logger
from si_tests import settings
from si_tests.utils import waiters

import pytest

LOG = logger.logger


class LcmEngine(object):
    """Common interface for the node-level LCM engine used by HA checks."""

    name = "base"

    def __init__(self, cluster):
        self._cluster = cluster
        self._key = settings.KAAS_CLUSTER_PRIVATE_KEY_FILE

    @property
    def cluster(self):
        return self._cluster

    @property
    def control_component_names(self):
        """Names of control-plane components a supervisor is expected to keep
        alive on a control node."""
        raise NotImplementedError

    def runtime_sock(self):
        """Container-runtime endpoint used by ``crictl``/``ctr`` on the node."""
        raise NotImplementedError

    def restart_engine(self, node):
        """Restart the node LCM daemon and wait until it is healthy again."""
        raise NotImplementedError

    def wait_engine_healthy(self, node, timeout=360, interval=30):
        """Block until the LCM engine reports a healthy control plane."""
        raise NotImplementedError

    def kill_control_component(self, node, component, **kw):
        """Send SIGKILL to a single control-plane component (container/process).
        The engine's supervisor is expected to restart it automatically."""
        raise NotImplementedError

    def pause_kube_api(self, node, **kw):
        """Make the local kube-apiserver backend unreachable (for HAProxy/VIP
        failover tests). Reversible by :meth:`resume_kube_api`.

        Must NOT take down etcd on the node (doing so on N-1 nodes would break
        the etcd quorum and invalidate the test)."""
        raise NotImplementedError

    def resume_kube_api(self, node, **kw):
        raise NotImplementedError

    def simulate_kube_api_failure(self, node, **kw):
        """Drop the local kube-apiserver so the engine supervisor restarts it
        automatically (HAProxy self-healing test)."""
        raise NotImplementedError

    def diag_kube_api(self, node, **kw):
        """Return a short diagnostic command output about the local
        kube-apiserver / runtime (best-effort, for logs)."""
        raise NotImplementedError

    def _ssh(self, node, cmd, **kw):
        kw.setdefault("ssh_key", self._key)
        return node._run_cmd(cmd, **kw)


class MkeEngine(LcmEngine):
    """MKE (UCP / Docker Swarm) engine."""

    name = "ucp"
    # Components we never touch when killing "system" containers (PRODX-15408).
    _skip = ("ucp-kubectl", "ucp-cluster-agent")

    @property
    def control_component_names(self):
        return ["ucp-kube-apiserver", "ucp-controller",
                "ucp-kube-scheduler", "ucp-kube-controller-manager", "ucp-kv"]

    def runtime_sock(self):
        return "unix:///var/run/docker.sock"

    def restart_engine(self, node):
        LOG.info("[MKE] restart docker.service on %s", node.name)
        self._ssh(node, "sudo systemctl restart docker.service")
        self.wait_engine_healthy(node)

    def wait_engine_healthy(self, node, timeout=360, interval=30):
        mke = self.cluster.get_mke_dashboardclient()

        def _ok():
            swarm_node = mke.get_node_by_name(node_name=node.get_k8s_node_name())
            return (swarm_node["Spec"]["Availability"] == "active" and
                    swarm_node["Status"]["State"] != "down")

        waiters.wait(_ok, timeout=timeout, interval=interval,
                     timeout_msg=f"[MKE] docker swarm node {node.name} not active")

    def list_control_containers(self, node):
        out = self._ssh(
            node, "docker ps --format '{{.Names}}' | grep -v k8s").stdout_str
        return [c.split(".")[0] for c in out.split("\n") if c.strip()]

    def kill_control_component(self, node, component, **kw):
        if component in self._skip:
            LOG.info("[MKE] skip container %s (skip-list)", component)
            return
        self._ssh(node,
                  f"id=`docker ps | grep {component} | awk '{{print $1}}'`;"
                  f"docker kill --signal=9 $id", **kw)
        waiters.wait(
            lambda: self._ssh(
                node, f"docker ps | grep {component} | wc -l",
                **kw).stdout_str == "1",
            timeout=60, interval=5,
            timeout_msg=f"[MKE] container {component} did not restart")

    def pause_kube_api(self, node, **kw):
        self._ssh(node, "sudo docker pause ucp-kube-apiserver", **kw)

    def resume_kube_api(self, node, **kw):
        self._ssh(node, "sudo docker unpause ucp-kube-apiserver || true", **kw)

    def simulate_kube_api_failure(self, node, **kw):
        # MKE restarts these containers automatically within a few seconds.
        self._ssh(node,
                  "sudo docker stop ucp-kube-apiserver; "
                  "sudo docker stop ucp-controller", **kw)

    def diag_kube_api(self, node, **kw):
        return self._ssh(
            node, "docker ps | grep ucp-kube-apiserver; sudo ctr tasks ls;",
            **kw).stdout_str


class K0sEngine(LcmEngine):
    """k0s engine (host-supervised control plane + containerd)."""

    name = "k0s"

    @property
    def control_component_names(self):
        # Host processes launched from /var/lib/k0s/bin by the k0s supervisor.
        return ["kube-apiserver", "kube-scheduler",
                "kube-controller-manager", "etcd"]

    def runtime_sock(self):
        return "unix:///run/k0s/containerd.sock"

    def restart_engine(self, node):
        LOG.info("[k0s] restart k0scontroller.service on %s", node.name)
        self._ssh(node, "sudo systemctl restart k0scontroller.service")
        self.wait_engine_healthy(node)

    def wait_engine_healthy(self, node, timeout=360, interval=30):
        def _ok():
            out = self._ssh(node, "sudo k0s status 2>/dev/null").stdout_str
            return "Kube-api probing successful: true" in out

        waiters.wait(_ok, timeout=timeout, interval=interval,
                     timeout_msg=f"[k0s] k0scontroller on {node.name} not healthy")

    def _pid_of(self, node, component, **kw):
        # k0s runs components from /var/lib/k0s/bin/<component>.
        out = self._ssh(
            node,
            f"pgrep -f '/var/lib/k0s/bin/{component}' | head -1",
            **kw).stdout_str.strip()
        return out

    def kill_control_component(self, node, component, **kw):
        pid = self._pid_of(node, component, **kw)
        if not pid:
            LOG.warning("[k0s] process %s not found on %s", component, node.name)
            return
        LOG.info("[k0s] kill -9 %s (%s) on %s", component, pid, node.name)
        self._ssh(node, f"sudo kill -9 {pid}", **kw)
        # k0s supervisor restarts the component; wait for a fresh PID.
        waiters.wait(
            lambda: self._pid_of(node, component, **kw) not in ("", pid),
            timeout=120, interval=5,
            timeout_msg=f"[k0s] {component} was not restarted by k0s supervisor")

    # Default kube-apiserver secure port on k0s (behind mcc-haproxy).
    _default_api_port = 12388

    def _kube_api_port(self, node, **kw):
        out = self._ssh(
            node,
            "ps -C kube-apiserver -o args= | "
            "grep -o -- '--secure-port=[0-9]*' | head -1",
            **kw).stdout_str.strip()
        if out.startswith("--secure-port="):
            return out.split("=", 1)[1]
        return str(self._default_api_port)

    def pause_kube_api(self, node, **kw):
        # Do NOT stop k0scontroller here: that would also stop etcd and break
        # the quorum on N-1 nodes. Instead firewall the apiserver port so
        # HAProxy's local backend goes down while etcd keeps running.
        port = self._kube_api_port(node, **kw)
        self._ssh(node, f"sudo iptables -I INPUT 1 -p tcp --dport {port} "
                        f"-j DROP", **kw)

    def resume_kube_api(self, node, **kw):
        port = self._kube_api_port(node, **kw)
        self._ssh(node, f"sudo iptables -D INPUT -p tcp --dport {port} "
                        f"-j DROP || true", **kw)

    def simulate_kube_api_failure(self, node, **kw):
        # k0s supervisor restarts the apiserver process automatically.
        self.kill_control_component(node, "kube-apiserver")

    def diag_kube_api(self, node, **kw):
        return self._ssh(
            node,
            "sudo k0s status 2>/dev/null | grep -i 'probing successful'; "
            "pgrep -af /var/lib/k0s/bin/kube-apiserver",
            **kw).stdout_str


def skip_if_not_engine(cluster, engine):
    """pytest.skip the current test if ``cluster`` does not run ``engine``.

    :param engine: one of ``'k0s'`` / ``'ucp'`` (aliases: ``'mke'``).
    """
    engine = "ucp" if engine == "mke" else engine
    actual = get_lcm_engine(cluster).name
    if actual != engine:
        pytest.skip(f"Test requires LCM engine '{engine}', "
                    f"cluster runs '{actual}'")


def get_lcm_engine(cluster):
    """Factory: pick the engine implementation for ``cluster``.

    Uses ``lcm_type`` when the cluster already has status, and falls back to
    the ``is_k0s`` property (release-based) otherwise so it also works
    pre-provisioning.
    """
    is_k0s = cluster.lcm_type_is_k0s if cluster.lcm_type else cluster.is_k0s
    return K0sEngine(cluster) if is_k0s else MkeEngine(cluster)
