from si_tests.utils import packaging_version as version
from si_tests import settings

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from si_tests.managers.kaas_manager import Cluster


class WorkaroundCheckManagerBase(object):
    """Common methods useful for workarounds check"""

    def __init__(self, cluster: "Cluster"):
        self._cluster: "Cluster" = cluster

    @property
    def cluster(self) -> "Cluster":
        return self._cluster

    @property
    def k8sclient(self):
        return self._cluster.k8sclient

    @property
    def mcc_version(self):
        """Active MCC release version"""
        mgmt_cluster = self._cluster._manager.get_mgmt_cluster()
        return mgmt_cluster.get_kaasrelease_version()

    @property
    def clusterrelease_version(self):
        """Current Cluster version"""
        return self._cluster.clusterrelease_version


class WorkaroundCheckManager(WorkaroundCheckManagerBase):
    """Workaround check manager

    Purpose of this class is to keep all the checks for workarounds in a single place.

    - Each method should return 'True' if the related workaround should be applied.
      Please don't add any waiters/actions here. Only checks for versions/providers/cluster objects/etc...

    - Methods should be named using PRODX bugs/tasks, for example:

          def prodx_12345(self):

    - Please clear the code from outdated workarounds after the related tasks are resolved
    """

    def field_5850(self):
        # https://mirantis.jira.com/browse/FIELD-5850
        # current status is pending investigation
        return True

    def prodx_51513(self):
        # https://mirantis.jira.com/browse/PRODX-51513
        if (('mke-20' in self.clusterrelease_version and
             version.parse(self.clusterrelease_version) >= version.parse('mke-20-0-0-rc-3-7')) or
                ('mosk' in self.clusterrelease_version and
                 version.parse(self.clusterrelease_version) >= version.parse('mosk-21-0-0-rc-25-2'))):
            return True
        return False

    def prodx_42401(self):
        """Remove GracefulRebootRequest manually before moving SL/Ceph labels to other Machines"""
        # https://mirantis.jira.com/browse/PRODX-42401
        # Always apply the workaround, as described in PRODX-42401
        return True

    def prodx_44228(self):
        """Check that ceph cluster is affected because of OSD replace procedure and
           update ceph keyrings if needed
        """
        return True

    def prodx_47907(self):
        # https://mirantis.jira.com/browse/PRODX-47907
        return ['Kubelet', 'AgentTokenRotation']

    def prodx_60827(self):
        # https://mirantis.jira.com/browse/PRODX-60827
        # AgentTokenRotation condition flaps transiently during Ceph HA tests
        # and is unrelated to Ceph. Empty pattern => condition ignored
        # regardless of its ready state.
        return {'AgentTokenRotation': ''}

    def prodx_55279(self):
        # https://mirantis.jira.com/browse/PRODX-55279
        return ['Kubelet', 'Evacuation']

    def child_with_cephdeployment(self):
        # https://mirantis.jira.com/browse/PRODX-42306
        # https://mirantis.jira.com/browse/PRODX-53709
        """ Since 20.1.0 and 21.1.0 MOSK is switched on CephDeployment Ceph object instead of MiraCeph"""
        if 'mke' in self.clusterrelease_version:
            return version.parse(self.clusterrelease_version) >= version.parse('mke-20-1-0-rc-3-7')
        if 'mosk' in self.clusterrelease_version:
            return version.parse(self.clusterrelease_version) >= version.parse('mosk-21-1-0-rc-26-1')
        if 'k0s' in self.clusterrelease_version:
            return version.parse(self.clusterrelease_version) >= version.parse('k0s-22-0-0-rc-1-33-9')
        return False

    def child_with_new_cephdeployment_api(self):
        # https://mirantis.jira.com/browse/PRODX-53710
        """ Since 21.2.0 and 20.2.0 CephDeployment switched on new API"""
        if 'mke' in self.clusterrelease_version:
            return version.parse(self.clusterrelease_version) >= version.parse('mke-20-2-0-rc-3-7')
        if 'mosk' in self.clusterrelease_version:
            return version.parse(self.clusterrelease_version) >= version.parse('mosk-21-2-0-rc-26-2')
        if 'k0s' in self.clusterrelease_version:
            return version.parse(self.clusterrelease_version) >= version.parse('k0s-22-0-0-rc-1-33-9')
        return False

    def use_ceph_mon_ip(self):
        # https://mirantis.jira.com/browse/PRODX-49314
        """ Since 21.2.0 and 20.2.0 try use Ceph Frontend network and static Ceph Mon ip
            if separate ceph networks found"""
        if 'mke' in self.clusterrelease_version:
            return version.parse(self.clusterrelease_version) >= version.parse('mke-20-2-0-rc-3-7')
        if 'mosk' in self.clusterrelease_version:
            return version.parse(self.clusterrelease_version) >= version.parse('mosk-21-2-0-rc-26-2')
        if 'k0s' in self.clusterrelease_version:
            return version.parse(self.clusterrelease_version) >= version.parse('k0s-22-0-0-rc-1-33-9')
        return False

    def prodx_52237(self):
        """
        Workaround for PRODX-52237:
        Ignore any pods in the node-feature-discovery namespace.
        https://mirantis.jira.com/browse/PRODX-52237
        """
        return (version.parse(self.clusterrelease_version) >= version.parse('mke-16-3-9-3-7-23') or
                version.parse(self.clusterrelease_version) >= version.parse('mosk-17-3-9-24-3-6')
                )

    def check_auditd_managed_field_value_mgmt(self):
        # https://mirantis.jira.com/browse/PRODX-49076
        """ Check that managed field presents in auditd cluster since 2-31 """
        return (version.parse(self.mcc_version) >= version.parse("kaas-2-31-0-rc")
                and settings.AUDITD_ENABLE
                and settings.AUDITD_MANAGED_MIGRATION_CHECK)

    def check_auditd_managed_field_value_child(self):
        # https://mirantis.jira.com/browse/PRODX-49076
        """ Check that managed field presents in auditd cluster since child cluster mosk-21-1-0-rc-26-1"""
        return (version.parse(self.clusterrelease_version) >= version.parse('mosk-21-1-0-rc-26-1')
                and settings.AUDITD_ENABLE
                and settings.AUDITD_MANAGED_MIGRATION_CHECK)

    def deploy_auditd_via_hoc_mgmt(self):
        # https://mirantis.jira.com/browse/PRODX-57469
        """ Check that we can deploy AUDITD via HOC for cluster since 2-31 """
        return (version.parse(self.mcc_version) >= version.parse("kaas-2-31-0-rc")
                and settings.DEPLOY_AUDITD_VIA_HOC)

    def deploy_auditd_via_hoc_child(self):
        # https://mirantis.jira.com/browse/PRODX-57469
        """ Check that we can deploy AUDITD via HOC since child cluster mosk-21-1-0-rc-26-1"""
        return (version.parse(self.clusterrelease_version) >= version.parse('mosk-21-1-0-rc-26-1')
                and settings.DEPLOY_AUDITD_VIA_HOC)

    def cluster_with_unpinned_runc_ee(self):
        """Clusters deployed with MOSK 26.1 (Cluster release 21.1.0) have unpinned runc-ee

        In such clusters the runc-ee package is installed from a constantly updated
        repository, so lcm-ansible fails to upgrade them to MOSK 26.1.x (Cluster releases
        21.1.x) patch releases or MOSK 26.2 (Cluster release 21.2.0), where the package
        version is pinned:
          E: Packages were downgraded and -y was used without --allow-downgrades.
        :return: True/False
        """
        return (self.clusterrelease_version or '').startswith('mosk-21-1-0')

    def cluster_supports_backups(self):
        # https://mirantis.jira.com/browse/PRODX-52004
        """
        Since MCC 2.31.0(mke-20-1-0-3-7) and child mosk-21-1-0-rc-26-1 we support mcc clusterbackups. So we need to
        use condition for upgrade cases
        :return: True/False
        """
        if 'mke' in self.clusterrelease_version:
            return version.parse(self.clusterrelease_version) >= version.parse('mke-20-1-0-rc-3-7')
        if 'mosk' in self.clusterrelease_version:
            return version.parse(self.clusterrelease_version) >= version.parse('mosk-21-1-0-rc-26-1')
        if 'k0s' in self.clusterrelease_version:
            return version.parse(self.clusterrelease_version) >= version.parse('k0s-22-0-0-rc-1-33-9')
        return False

    def cluster_supports_envoy(self):
        # https://mirantis.jira.com/browse/PRODX-56279
        """
        Since MCC 2.32.0 and child mosk-21-2-0-rc-26-2 we support Envoy.
        :return: True/False
        """
        if 'mosk' in self.clusterrelease_version:
            return version.parse(self.clusterrelease_version) >= version.parse('mosk-21-2-0-rc-26-2')
        return False

    def netchecker_new_status_message(self):
        """
        Starting from 2.32.x netchecker controller has new logic for status message
        https://mirantis.jira.com/browse/PRODX-58587
        :return: True/False
        """
        return version.parse(self.mcc_version) >= version.parse("kaas-2-32-0-rc")

    def prodx_59965(self):
        """
        Starting from 2.32.x clustebackup will include fix for this issue
        https://mirantis.jira.com/browse/PRODX-59965
        :return: True/False
        """
        return version.parse(self.mcc_version) < version.parse("kaas-2-32-0-rc")

    def prodx_64703(self):
        """
        If wireguard is enabled on the cluster, there might be a race in address assignment
        https://mirantis.jira.com/browse/PRODX-64703
        :return: True/False
        """
        return self._cluster.is_k0s and str(
            self._cluster.data.get("spec", {}).get("providerSpec", {}).get(
                "value", {}).get("secureOverlay")).lower() == "true"

    def prodx_42896(self):
        """
        Remove inactive cassandra cluster members
        in case when present replacement node test before rolling reboot test
        """
        # https://mirantis.jira.com/browse/PRODX-42896
        return True


def wa_phys429_hack_mgmt_deploy_on_vsphere():
    """
    PRODX-42152  Hack-owner: bm-team.
    Special hack for quick deployment mgmt on standalone vsphere seed.
    Hardcoded everything
    :return:
    """
    from si_tests.managers import si_config_manager
    from si_tests import logger
    from si_tests import settings
    from si_tests.managers import bootstrap_manager

    LOG = logger.logger

    if not settings.BM_DEPLOY_MGMT_ON_VSPHERE:
        raise Exception('Wrong test invocation')
    vs_seed_ip = '172.16.38.123'
    LOG.warning(f'Switching to work with hardcoded vs-seed:{vs_seed_ip}')
    si_config = si_config_manager.SIConfigManager(si_config_path=settings.SI_CONFIG_PATH)
    si_config.store_seed_ip(vs_seed_ip)
    bootstrap = bootstrap_manager.BootstrapManager.get_si_config_bootstrap_manager()
    remote = bootstrap.remote_seed()
    # perform ugly hard-coded cleanup
    remote.execute('~/bootstrap/dev/bin/kind delete cluster --name clusterapi', verbose=True)
    remote.execute('rm -rf ~/kaas_releases ~/bootstrap '
                   '/tmp/step_003_prepare_bm_seed_node '
                   '/var/lib/si-tests/workspace_ptr* ', verbose=True)
    env_config_name = bootstrap.bm_determine_env_config_name()
    bootstrap.step_003_prepare_bm_seed_node()
    # need to init for sync kaas-bm-env and some default pkgs
    bootstrap.ansible_init()
    bootstrap.prepare_bm_seed_node_templates(env_config_name)

    envs = ['HOME=/home/ubuntu/bootstrap/dev/',
            'KAAS_BOOTSTRAP_DEBUG=True',
            'KAAS_BM_ENABLED=True',
            'KAAS_BM_PXE_BRIDGE=br0',
            'KAAS_BM_PXE_IP="10.0.25.20"',
            'KAAS_BM_PXE_MASK=24']
    for i in envs:
        remote.execute(f"echo 'export {i}' >> /home/ubuntu/bootstrap/dev/bootstrap.env", verbose=True)
    return bootstrap
