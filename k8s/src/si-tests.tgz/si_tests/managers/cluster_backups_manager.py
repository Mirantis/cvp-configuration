#    Copyright 2025 Mirantis, Inc.
#
#    Licensed under the Apache License, Version 2.0 (the "License"); you may
#    not use this file except in compliance with the License. You may obtain
#    a copy of the License at
#
#         http://www.apache.org/licenses/LICENSE-2.0
#
#    Unless required by applicable law or agreed to in writing, software
#    distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
#    WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
#    License for the specific language governing permissions and limitations
#    under the License.

import boto3
import cachetools.func as cachetools_func
import secrets
import yaml

from botocore.exceptions import ClientError
from kubernetes.client import ApiException

from si_tests import logger
from si_tests.managers import bootstrap_manager
from si_tests.utils import waiters
from si_tests import settings

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from si_tests.managers.kaas_manager import Cluster

LOG = logger.logger


class ClusterBackupManager(object):
    """MCC backups manager"""

    def __init__(self, cluster: "Cluster"):
        self._cluster: "Cluster" = cluster
        self._remote_seed = None
        self.s3_access_key_id = settings.MCC_CLUSTER_BACKUP_S3_ACCESS_KEY_ID
        self.s3_access_secret_key = settings.MCC_CLUSTER_BACKUP_S3_ACCESS_SECRET_KEY
        # Read-only creds for verification (head/list). Fall back to write creds if unset.
        self.s3_ro_access_key_id = (settings.MCC_CLUSTER_BACKUP_S3_RO_ACCESS_KEY_ID
                                    or self.s3_access_key_id)
        self.s3_ro_access_secret_key = (settings.MCC_CLUSTER_BACKUP_S3_RO_ACCESS_SECRET_KEY
                                        or self.s3_access_secret_key)
        self.s3_endpoint = settings.MCC_CLUSTER_BACKUP_S3_ENDPOINT
        self.s3_bucket_name = settings.MCC_CLUSTER_BACKUP_S3_BUCKET_NAME
        self.s3_dir_path = self.s3_bucket_name + '/' + settings.ENV_NAME
        self.clusterbackup_name = (settings.MCC_CLUSTER_BACKUP_NAME + '-' +
                                   self.cluster.namespace + '-' + self.cluster.name)
        self.kek_name = settings.MCC_CLUSTER_BACKUP_KEYENCRYPTIONKEY_NAME
        self.kek_value = secrets.token_urlsafe(32)
        self.rclone_cred_name = settings.MCC_CLUSTER_BACKUP_RCLONE_CRED_NAME
        self.cluster_backup_file_path = settings.MCC_CLUSTER_BACKUP_FILE_PATH
        self.cluster_backup_kek_file_path = settings.MCC_CLUSTER_BACKUP_KEK_FILE_PATH
        self.cluster_backup_rclone_cred_file_path = settings.MCC_CLUSTER_BACKUP_RCLONE_CRED_FILE_PATH
        self._nfs_endpoint = settings.MCC_CLUSTER_BACKUP_NFS_ENDPOINT
        self.nfs_share_path = '/exports/data'
        self.seed_nfs_share_mount_path = '/mnt/nfs/exports/data'

    @property
    def cluster(self) -> "Cluster":
        return self._cluster

    @property
    @cachetools_func.ttl_cache(ttl=300)
    def k8sclient(self):
        return self._cluster.k8sclient

    @property
    @cachetools_func.ttl_cache(ttl=300)
    def s3_client(self):
        """Write-capable client. Use only for destructive test-side cleanup."""
        return boto3.client(
            "s3",
            aws_access_key_id=self.s3_access_key_id,
            aws_secret_access_key=self.s3_access_secret_key,
            endpoint_url=self.s3_endpoint,
            region_name="eu"
        )

    @property
    @cachetools_func.ttl_cache(ttl=300)
    def s3_client_ro(self):
        """Read-only client for backup verification (head/list)."""
        return boto3.client(
            "s3",
            aws_access_key_id=self.s3_ro_access_key_id,
            aws_secret_access_key=self.s3_ro_access_secret_key,
            endpoint_url=self.s3_endpoint,
            region_name="eu"
        )

    @property
    def nfs_endpoint(self):
        if not self._nfs_endpoint:
            assert settings.NFS_SHARE_VM_FIXED_IP, ("No endpoint and no IP address of VM with share are provided. "
                                                    "Can't configure cluster for share")
            self._nfs_endpoint = settings.NFS_SHARE_VM_FIXED_IP + ':' + self.nfs_share_path
        return self._nfs_endpoint

    @property
    def remote_seed(self):
        if self._remote_seed is None:
            self._remote_seed = bootstrap_manager.BootstrapManager.get_si_config_bootstrap_manager().remote_seed()
        return self._remote_seed

    @property
    def clusterbackups(self):
        return self._cluster._manager.api.mcc_clusterbackups

    @property
    def applicationbackups(self):
        return self.k8sclient.mcc_applicationbackups

    @property
    def keyencryptionkeys(self):
        return self._cluster._manager.api.keyencryptionkeys

    @property
    def rclonecredentials(self):
        return self._cluster._manager.api.rclonecredentials

    def get_clusterbackup(self, name=None):
        return self.clusterbackups.get(namespace=self.cluster.namespace, name=name)

    def get_applicationbackup(self, name=None):
        appbackups = [backup for backup in self.applicationbackups.list_all() if backup.name == name]
        return appbackups[0] if appbackups else []

    def get_keyencryptionkey(self, name=None):
        keks = [k for k in self.keyencryptionkeys.list(namespace=self.cluster.namespace) if k.name == name]
        return keks[0] if keks else []

    def get_rclonecredential(self, name=None):
        rccred = [rc for rc in self.rclonecredentials.list(namespace=self.cluster.namespace) if rc.name == name]
        return rccred[0] if rccred else []

    def create_clusterbackup(self, data=None):
        return self.clusterbackups.create(namespace=self.cluster.namespace, body=data)

    def get_backup_file_full_path(self, cb_name):
        cb = self.get_clusterbackup(name=cb_name)
        key_name = 'K0S' if self.cluster.lcm_type_is_k0s else 'MKE'
        return cb.data.get('status', {}).get('fileNames', {}).get(key_name, '')

    def create_keyencryptionkey(self, data=None):
        return self.keyencryptionkeys.create(namespace=self.cluster.namespace, body=data)

    def create_rclonecredential(self, data=None):
        return self.rclonecredentials.create(namespace=self.cluster.namespace, body=data)

    def check_clusterbackup_status(self, name, expected_status='Completed'):
        """
        :param name: mcc_clusterbackup object name
        :param expected_status: Expected status. Available statuses are:
                                - Pending
                                - InProgress
                                - Completed
                                - Failed
                                - Stuck
        :return: bool
        """
        try:
            backup_obj = self.get_clusterbackup(name=name)
            status = backup_obj.data.get('status', {}) or {}
            current_status = status.get('status', '')
            return current_status == expected_status
        except ApiException as e:
            if e.status == 404:
                LOG.info(f"Clusterbackup {name} wasn't found on environment..")
                return False
            raise e

    def wait_clusterbackup_status(self, name=None, expected_status='Completed', timeout=600, interval=30):
        def _status_message():
            cluster_backup_status = self.get_clusterbackup(name=name).data.get('status', {})
            if cluster_backup_status is None:
                LOG.warning(f"MCC cluster backup object {name} has ho field 'status' yet")
                current_status = None
            else:
                current_status = cluster_backup_status.get('status', '')
            LOG.info(f"Current cluster backup status is: {current_status}")
        err_msg = f"MCC clusterbackup {name} failed to become {expected_status} status in {timeout} sec."
        LOG.info(f"Waiting for clusterbackup object status == {expected_status}")
        waiters.wait(lambda: self.check_clusterbackup_status(name=name, expected_status=expected_status),
                     timeout=timeout, interval=interval, status_msg_function=_status_message, timeout_msg=err_msg)

    def check_applicationbackup_status(self, name, expected_status='Completed'):
        """
        :param name: mcc_applicationbackup object name
        :param expected_status: Expected status. Available statuses are:
                                - Pending
                                - InProgress
                                - Completed
                                - Failed
                                - Stuck
        :return: bool
        """

        app_backup_obj = self.get_applicationbackup(name=name)
        status = app_backup_obj.data.get('status', {}) or {}
        current_status = status.get('state', '')
        return current_status == expected_status

    def wait_applicationbackup_state(self, name=None, expected_status='Completed', timeout=600, interval=30):
        def _status_message():
            app_backup_status = self.get_applicationbackup(name=name).data.get('status', {})
            if app_backup_status is None:
                LOG.warning(f"MCC application backup object {name} has ho field 'status' yet")
                current_status = None
            else:
                current_status = app_backup_status.get('state', '')
            LOG.info(f"Current application backup status is: {current_status}")
        err_msg = f"MCC applicationbackup {name} failed to become {expected_status} status in {timeout} sec."
        waiters.wait(lambda: self.check_applicationbackup_status(name=name, expected_status=expected_status),
                     timeout=timeout, interval=interval, status_msg_function=_status_message, timeout_msg=err_msg)

    def configure_cluster(self, share_type, encrypted=settings.MCC_CLUSTER_BACKUP_ENCRYPT_BACKUPS):
        """
        Configure cluster backup share (s3 / nfs)
        """

        if not self.cluster.workaround.cluster_supports_backups():
            LOG.info(f"Cluster {self.cluster.clusterrelease_version} can't be configured. Feature is available "
                     f"starting from mcc 2.31.x")
            return None

        patch_data = {
            "spec": {
                "providerSpec": {
                    "value": {
                        "backup": {}
                    }
                }
            }
        }
        # We can't use both configs at a same time. So it is better to cleanup config before applying new values
        LOG.info("Cleanup old config")
        self.cluster.patch({'spec': {'providerSpec': {'value': {'backup': None}}}})

        if share_type == "s3":
            patch_data["spec"]["providerSpec"]["value"]["backup"] = {
                "rclone": {
                    "bucket": self.s3_dir_path,
                    "credential": self.rclone_cred_name,
                },
            }

        elif share_type == "nfs":
            patch_data["spec"]["providerSpec"]["value"]["backup"] = {
                "nfsUploadUrl": self.nfs_endpoint
            }

        else:
            raise NotImplementedError(
                f"Unknown share type '{share_type}' is not implemented"
            )
        if encrypted:
            patch_data["spec"]["providerSpec"]["value"]["backup"]['keyEncryptionKey'] = self.kek_name

        LOG.info(f"Configuring cluster object for share type {share_type}")

        return self.cluster.patch(patch_data)

    def s3_object_exists(self, bucket_name, file_name):
        try:
            self.s3_client_ro.head_object(Bucket=bucket_name, Key=file_name)
            LOG.info(f"File {file_name} exists in bucket {bucket_name}")
            return True
        except ClientError as e:
            if e.response["Error"]["Code"] in ("404", "NoSuchKey"):
                LOG.info(f"File {file_name} is not existed in bucket {bucket_name}")
                return False
            else:
                raise Exception(e)

    def nfs_object_exists(self, file_name):
        seed_mount_path = self.seed_nfs_share_mount_path
        is_seed_prepared = False
        with self.remote_seed.sudo(enforce=True):
            exit_code = self.remote_seed.check_call(f'[ -d {seed_mount_path} ]', raise_on_err=False).exit_code.value
            if exit_code == 0:
                is_seed_prepared = True
        if not is_seed_prepared:
            LOG.info(f"First time run check. Preparing seed node and mount remote share to {seed_mount_path}")
            # Prepare seed for mounting nfs share
            self.remote_seed.check_call('DEBIAN_FRONTEND=noninteractive sudo apt install -y nfs-common')
            self.remote_seed.check_call(f'sudo mkdir -p {seed_mount_path}')
            self.remote_seed.check_call(f'sudo mount -t nfs {self.nfs_endpoint} {seed_mount_path}')
        with self.remote_seed.sudo(enforce=True):
            res = self.remote_seed.check_call(
                f'[ -f {seed_mount_path}/{file_name} ]', raise_on_err=False).exit_code
            if res.value == 0:
                LOG.info(f"File {file_name} exists in nfs share {self.nfs_endpoint}")
                return True
            else:
                LOG.info(f"File {file_name} IS NOT EXISTED in nfs share {self.nfs_endpoint}")
                return False

    def wait_objects_exist_on_remote(self, files_list, share_type):
        def _files_existance():
            files_map = {}
            for file in files_list:
                if share_type == "s3":
                    bucket_name = self.s3_bucket_name
                    file_path = settings.ENV_NAME + "/" + file
                    files_map[file] = self.s3_object_exists(bucket_name, file_path)
                else:
                    files_map[file] = self.nfs_object_exists(file)
            LOG.info(f"Current files statuses:\n{yaml.dump(files_map)}")
            return all(files_map.values())
        waiters.wait(lambda: _files_existance(), timeout=300, interval=15)

    def wait_object_exists_locally(self, file_name, target_node_name, cluster=None):
        if not cluster:
            cluster = self.cluster
        cluster_type = 'child' if cluster.is_child else 'management'

        def _local_file_exists():
            machine = cluster.get_machine_by_k8s_name(name=target_node_name)
            if machine is None:
                LOG.error(f"[Cluster type: {cluster_type}] No machine found for k8s node "
                          f"'{target_node_name}' in cluster '{cluster.name}'; cannot check "
                          f"file {file_name} locally")
                return False
            res = machine.run_cmd(f"sudo find /srv/ -name {file_name}", check_exit_code=False, verbose=False).stdout_str
            if not res:
                msg = f"[Cluster type: {cluster_type}] File {file_name} not found on target node {target_node_name}"
                LOG.error(msg)
                return False
            else:
                backups_dir = res.split(file_name)[0]
                LOG.info(f"[Cluster type: {cluster_type}] File {file_name} exist on node {target_node_name} "
                         f"in directory {backups_dir}")
                return True
        LOG.info(f"[Cluster type: {cluster_type}] Waiting for file {file_name} exists "
                 f"on target_node {target_node_name}")
        waiters.wait(lambda: _local_file_exists(), timeout=300, interval=30)
