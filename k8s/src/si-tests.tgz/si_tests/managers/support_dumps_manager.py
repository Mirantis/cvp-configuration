#    Copyright 2026 Mirantis, Inc.
#
#    Licensed under the Apache License, Version 2.0 (the "License"); you may
#    not use this file except in compliance with the License. You may obtain
#    a copy of the License at
#
#         http://www.apache.org/licenses/LICENSE-2.0
#
#    Unless required by applicable law or agreed to in writing, software
#    distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
#    WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
#    License for the specific language governing permissions and limitations
#    under the License.

import yaml
from kubernetes.client import ApiException

from si_tests import logger
from si_tests.utils import waiters, templates
from si_tests import settings

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from si_tests.managers.kaas_manager import Cluster

LOG = logger.logger


class SupportDumpManager(object):
    """MCC supportdump manager"""

    def __init__(self, cluster: "Cluster"):
        self._cluster: "Cluster" = cluster
        self.supportdump_name = f"{settings.MCC_SUPPORTDUMP_NAME}-{self.cluster.namespace}-{self.cluster.name}"
        self.supportdump_template_file_path = settings.MCC_SUPPORTDUMP_TEMPLATE_PATH

    @property
    def cluster(self) -> "Cluster":
        return self._cluster

    @property
    def supportdumps(self):
        return self._cluster._manager.api.mcc_supportdumps

    def get_supportdumps(self, name=None):
        return self.supportdumps.get(namespace=self.cluster.namespace, name=name)

    def _wait_supportdump_created(self, name):
        creation_timeout = 60
        creation_interval = 5
        creation_timeout_msg = f"SupportDump object {name} has not been created in {creation_timeout} sec"
        LOG.info(f"Wait until SupportDump object {name} created")
        waiters.wait(lambda: bool(self.supportdumps.present_all(name=name)),
                     timeout=creation_timeout,
                     interval=creation_interval,
                     timeout_msg=creation_timeout_msg)

    def create_supportdump(self, name, spec=None):
        """Create a SupportDump from the default template and wait until it appears."""
        if not spec:
            sd_data = yaml.safe_load(templates.render_template(self.supportdump_template_file_path))
            if self.cluster.lcm_type_is_k0s:
                collectors = sd_data['spec'].get('collectors', [])
                sd_data['spec']['collectors'] = [c for c in collectors if 'underlayKubernetesLogs' not in c]
                LOG.info(f"Cluster {self.cluster.name} is k0s-based, "
                         f"excluding unsupported 'underlayKubernetesLogs' collector")
        else:
            sd_data = {
                'apiVersion': 'kaas.mirantis.com/v1alpha1',
                'kind': 'SupportDump',
                'metadata': {'name': name, 'namespace': self.cluster.namespace},
                'spec': spec,
            }

        LOG.info(f"Create SupportDump {yaml.dump(sd_data)}")
        self.supportdumps.create(namespace=self.cluster.namespace, name=name, body=sd_data)
        self._wait_supportdump_created(name)
        return self.get_supportdumps(name=name)

    def get_supportdumps_status(self, name):
        """
        :param name: mcc_supportdumps object name
        :return: status string
        """
        try:
            sd_obj = self.get_supportdumps(name=name)
            status = sd_obj.data.get('status', {}) or {}
            current_status = status.get('status', '')
            return current_status
        except ApiException as e:
            if e.status == 404:
                LOG.info(f"supportdump {name} wasn't found")
                return False
            raise e

    def check_supportdumps_status(self, name, expected_status='Completed', failed_status='Failed'):
        """
        :param name: mcc_supportdumps object name
        :param expected_status: Expected status. Available statuses are:
                                - Pending
                                - InProgress
                                - Completed
                                - Failed
        :param failed_status: Catch bad status and stop test
        :return: bool
        """
        try:
            sd_obj = self.get_supportdumps(name=name)
            status = sd_obj.data.get('status', {}) or {}
            current_status = status.get('status', '')
            if current_status == failed_status:
                raise Exception(f"Supportdumps {name} status is 'Failed': {status}")
            LOG.info(f"Current supportdump status is: {current_status}")
            return current_status == expected_status
        except ApiException as e:
            if e.status == 404:
                LOG.info(f"supportdump {name} wasn't found")
                return False
            raise e

    def wait_supportdumps_status(self, name=None, expected_status='Completed', timeout=3600, interval=15):
        def _status_message():
            sd_status = self.get_supportdumps(name=name).data.get('status', {})
            if sd_status is None:
                LOG.info(f"Supportdump object {name} has no field 'status' yet")
            else:
                current_status = sd_status.get('status', '')
                LOG.info(f"Current supportdump status is: {current_status}")
        err_msg = f"Supportdumps {name} failed to become {expected_status} status in {timeout} sec."
        LOG.info(f"Waiting for supportdumps object status == {expected_status}")
        waiters.wait(lambda: self.check_supportdumps_status(name=name, expected_status=expected_status),
                     timeout=timeout, interval=interval, status_msg_function=_status_message, timeout_msg=err_msg)

    def check_collectors_status(self, name, expected_status='Completed', failed_status='Failed'):
        """
        Check status of every individual collector reported in status.collectors.

        :param name: mcc_supportdumps object name
        :param expected_status: status every collector is expected to reach
        :param failed_status: catch bad collector status and stop the test
        :return: bool, True only when every collector reached expected_status
        """
        try:
            sd_obj = self.get_supportdumps(name=name)
            status = sd_obj.data.get('status', {}) or {}
            collectors = status.get('collectors') or []
            if not collectors:
                LOG.info(f"Supportdump object {name} has no collectors in status yet")
                return False

            failed = [c for c in collectors if c.get('status') == failed_status]
            if failed:
                raise Exception(f"Supportdumps {name} has failed collector(s): {failed}")

            for collector in collectors:
                LOG.info(f"Collector '{collector.get('type')}' status is: {collector.get('status')}")

            return all(c.get('status') == expected_status for c in collectors)
        except ApiException as e:
            if e.status == 404:
                LOG.info(f"supportdump {name} wasn't found")
                return False
            raise e

    def wait_supportdumps_collectors_status(self, name=None, expected_status='Completed', timeout=3600, interval=15):
        def _status_message():
            sd_status = self.get_supportdumps(name=name).data.get('status', {}) or {}
            collectors = sd_status.get('collectors') or []
            if not collectors:
                LOG.info(f"Supportdump object {name} has no collectors in status yet")
            else:
                for collector in collectors:
                    LOG.info(f"Collector '{collector.get('type')}' status is: {collector.get('status')}")
        err_msg = f"Not all collectors of supportdump {name} became {expected_status} status in {timeout} sec."
        LOG.info(f"Waiting for all supportdump collectors status == {expected_status}")
        waiters.wait(lambda: self.check_collectors_status(name=name, expected_status=expected_status),
                     timeout=timeout, interval=interval, status_msg_function=_status_message, timeout_msg=err_msg)
