import copy
import time

import cachetools.func as cachetools_func
from si_tests import logger
from si_tests.utils import utils, waiters, exceptions
from kubernetes.client.rest import ApiException

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from si_tests.managers.kaas_manager import Cluster


LOG = logger.logger


class Day2OperationsManager(object):
    """Day2 Operations manager"""

    def __init__(self, cluster: "Cluster"):
        self._cluster: "Cluster" = cluster

    @property
    def cluster(self) -> "Cluster":
        return self._cluster

    @property
    @cachetools_func.ttl_cache(ttl=300)
    def k8sclient(self):
        return self._cluster.k8sclient

    def get_machine_to_disable(self):
        """
        Get a Machine with label 'si-role/node-for-disable' to disable it during tests
        """
        machines = self.cluster.get_machines()
        machines_for_disable = []
        for machine in machines:
            labels = machine.data.get('metadata', {}).get('labels', {})
            if 'si-role/node-for-disable' in labels:
                machines_for_disable.append(machine)
        # TODO(ddmitriev): for now, only one Machine is available to run the 'disable' tests
        # on the same Cluster.
        # To make possible to use different Machines for different runs on the same Cluster,
        # we can do the following:
        # 1. Label more than one Machines with 'si-role/node-for-disable'
        # 2. Select only one Machine with such label per test, and use this Machine for disable test
        # 3. During the test, label the selected Machine with another label, for example:
        #    'si-role/selected-node-for-disable'
        # 4. Add a new method like 'get_selected_machine_to_disable', which will search a node with
        #    label 'si-role/selected-node-for-disable'
        # 5. Use this new method in the enable/replace tests, where the Cluster Machines operations
        #    are restored
        # With this approach, 'disable' tests get a Machine from some labeled set of Machines,
        # but 'enable'/'replace' tests get the selected Machine because it was labeled.
        # Also need to consider removing both labels after tests, to not use the same Machine twice
        assert len(machines_for_disable) > 0, "No Machines with label 'si-role/node-for-disable' found"
        assert len(machines_for_disable) == 1, (
            "Multiple Machines with label 'si-role/node-for-disable' found, while expected only 1 Machine")
        return machines_for_disable[0]

    def get_storage_candidate_machines(self, exclude_machine_names=None):
        """
        Get Machines suitable to move there Ceph roles from disabled Machines
        Machines are selected by label 'si-role/storage-candidate-node'
        """
        exclude_machine_names = exclude_machine_names or []
        cluster_machines = [m for m in self.cluster.get_machines()
                            if m.name not in exclude_machine_names and not m.is_disabled()]

        storage_candidate_machines = [
            m for m in cluster_machines
            if 'si-role/storage-candidate-node' in m.data.get('metadata', {}).get('labels', {})]

        return storage_candidate_machines

    def get_stacklight_candidate_machines(self):
        """
        Get Machines suitable to move there StackLight nodeLabels from disabled Machines
        """
        cluster_machines = self.cluster.get_machines()
        disabled_machines = [m for m in cluster_machines if m.is_disabled()]
        sl_nodelabel = [{"key": "stacklight", "value": "enabled"}]
        non_sl_machines = [m for m in cluster_machines
                           if (not m.has_nodelabels(sl_nodelabel)) and (m not in disabled_machines)]
        # TODO(ddmitriev): consider to select suitable Machines for SL nodeLabels using additional Machine label
        #                  in the child_data
        return non_sl_machines

    def disable_machines(self, machines):
        """
        Disable LCM operations for specified Machines and move Ceph/SL roles to other Machines
        """
        machine_names = [m.name for m in machines]
        LOG.banner(f"Disable Machines {machine_names}")

        # Power off Machines
        for machine in machines:
            LOG.info(f"Power off the Machine '{machine.name}'")
            machine.set_baremetalhost_power(online=False)
        for machine in machines:
            machine_ip = machine.public_ip or machine.internal_ip
            LOG.info(f"Wait until machine '{machine.name}' is no longer available via ICMP on IP:{machine_ip}")
            waiters.wait(lambda: not waiters.icmp_ping(machine_ip), interval=5, timeout=600)

        LOG.info("Machines for disable were powered off, sleeping for couple of minutes")
        time.sleep(120)

        for machine in machines:
            LOG.info(f"Disable LCM operations for Machine {machine.namespace}/{machine.name}")
            machine.disable()

        self.wait_machines_disable(machines)

    def enable_machines(self, machines):
        """
        Enable LCM operations for specified Machines
        """

        for machine in machines:
            LOG.info(f"Enable LCM operations for Machine {machine.namespace}/{machine.name}")
            machine.enable()

        # Power on Machines
        for machine in machines:
            machine.set_baremetalhost_power(online=True)
        for machine in machines:
            machine_ip = machine.public_ip or machine.internal_ip
            LOG.info(f"Wait until machine {machine.name} becomes available via ICMP on IP:{machine_ip}")
            waiters.wait(lambda: waiters.icmp_ping(machine_ip), interval=5, timeout=1800)

        self.wait_machines_enable(machines)

        # TODO(ddmitriev):
        # 1. Wait Machines readiness (timeout must be the same as for Machine deploy)
        # 2. Check LCMMachine release version (spec.release and status.release
        #                                      are the same as in all other LCMMachines)

    def wait_machines_disable(self, machines):
        LOG.banner("Wait until NodeDisableNotifications are created for 'disabled' Machines", sep='-')
        for machine in machines:
            self.cluster.check.wait_evacuation_status(machine.name, 'disable')
            lcmmachine = self.cluster.get_cluster_lcmmachine(name=machine.name, namespace=machine.namespace)
            assert lcmmachine.data.get('spec', {}).get('haltAgent', False), \
                f"agent of LCMMachine {lcmmachine.name} is not halted"
            machine.wait_for_status_presence("Disabled")
            LOG.info("Verifying that docker node is absent")
            node_name = machine.get_k8s_node_name()
            dashboardclient = self.cluster.mkedashboardclient
            mke_nodes = dashboardclient.get_nodes()
            for mke_node in mke_nodes:
                if mke_node['Description']['Hostname'] == node_name:
                    raise Exception(f"Node {node_name} is present in MKE nodes list but it should not be present "
                                    f"because LCMMachine has evacuation disable status")
            LOG.info("Verifying that nodedisablenotification is created")
            ndn = self.cluster.get_nodedisablenotification(node_name)
            assert ndn is not None, (
                f"NodeDisableNotification {node_name} is not created but it is expected to be created")

        self._wait_machines_disabled_nodes_deleted(machines)

    def _wait_machines_disabled_nodes_deleted(self, machines):
        """Ensure that k8s nodes are actually deleted from the k8s cluster"""
        LOG.banner("Wait for K8sNodes removal from cluster for 'disabled' Machines", sep='-')
        for machine in machines:
            node_name = machine.get_k8s_node_name()
            try:
                LOG.info(f"Waiting until K8sNode '{node_name}' is deleted from cluster")
                waiters.wait(lambda: not self.k8sclient.nodes.present(node_name),
                             interval=30, timeout=600)
                LOG.info(f"K8sNode {node_name} is absent in the Cluster {self.cluster.namespace}/{self.cluster.name}")
            except exceptions.TimeoutError as e:
                LOG.error(f"K8sNode '{node_name}' was not deleted after Machine '{machine.name} was disabled'")
                k8s_node = machine.get_k8s_node()
                node_data = k8s_node.data
                if 'deletion_timestamp' not in node_data.get('metadata', {}):
                    LOG.error(f"K8sNode '{node_name}' has not been marked for deletion, it's a bug")
                    raise e
                else:
                    # check that clusterrelease < mosk-17-1-1 , W/A should not be required for the next releases
                    if self.cluster.workaround.prodx_40036():
                        LOG.warning("Apply workaround for PRODX-40036 and PRODX-40367")
                        self._apply_workaround_prodx_40036_and_40367(machine)
                    else:
                        LOG.warning("Skip workaround for PRODX-40036 and PRODX-40367")
                        raise Exception(f"K8sNode {k8s_node.name} was not deleted "
                                        f"after disabling Machine {machine.name}")

    def _apply_workaround_prodx_40036_and_40367(self, machine):
        """Check and apply a workaround for issue with openstack finalizer"""
        k8s_node = machine.get_k8s_node()
        node_data = k8s_node.data
        node_finalizers = node_data.get('metadata', {}).get('finalizers', [])
        # 1. PRODX-40036
        if 'lcm.mirantis.com/openstack-controller.node-finalizer' in node_finalizers:
            LOG.warning(f"Workaround PRODX-40036 for K8sNode {k8s_node.name}: remove openstack finalizer")
            node_finalizers = None
            try:
                k8s_node.patch({'metadata': {'finalizers': node_finalizers}})
            except (Exception, ApiException) as e:
                LOG.warning(f"The following error appeared during disabling "
                            f"the finalizer for K8sNode {k8s_node.name}: {e}")

            waiters.wait(lambda: not self.k8sclient.nodes.present(k8s_node.name),
                         interval=30, timeout=300)
        else:
            raise Exception(f"K8sNode '{k8s_node.name}' don't have an openstack finalizer but was not deleted, "
                            f"looks like a bug")

        # 2. PRODX-40367
        openstack_nwl_name = f"openstack-{k8s_node.name}"
        if self.k8sclient.nodeworkloadlocks.present_all(openstack_nwl_name):
            LOG.warning(f"Workaround PRODX-40367 for K8sNode {k8s_node.name}: "
                        f"remove openstack nwl '{openstack_nwl_name}'")
            openstack_nwl = self.k8sclient.nodeworkloadlocks.get(openstack_nwl_name)
            openstack_nwl.delete()
            waiters.wait(lambda: not self.k8sclient.nodeworkloadlocks.present_all(openstack_nwl_name),
                         interval=10, timeout=300)

    def wait_machines_enable(self, machines):
        LOG.banner("Wait until NodeDisableNotifications are removed for 'enabled' Machines", sep='-')
        for machine in machines:
            self.cluster.check.wait_evacuation_status(machine.name, "disable", timeout=7200, evacuation_expected=False)
            machine.wait_for_status_absence("Disabled")
            LOG.info("Verifying that nodedisablenotification is deleted")
            node_name = machine.get_k8s_node_name()
            ndn = self.cluster.get_nodedisablenotification(node_name)
            assert ndn is None, f"NodeDisableNotification {node_name} is not deleted but it is expected to be deleted"

    def check_machine_disabled(self, machine):
        lcmmachine = self.cluster.get_cluster_lcmmachine(name=machine.name, namespace=machine.namespace)
        evacuation_status = lcmmachine.data.get('status', {}).get('evacuation', '')
        assert evacuation_status == 'disable', \
            f"LCMMachine {lcmmachine.name} has evacuation status {evacuation_status}, expected 'disable'"
        assert lcmmachine.data.get('spec', {}).get('haltAgent', False), \
            f"agent of LCMMachine {lcmmachine.name} is not halted"
        machine_status = machine.data.get('status') or {}
        readiness_status = machine_status.get('providerStatus', {}).get('status')
        assert readiness_status == 'Disabled', \
            f"Machine {machine.name} has status {readiness_status}, expected 'Disabled'"
        LOG.info("Verifying that docker node is absent")
        node_name = machine.get_k8s_node_name()
        dashboardclient = self.cluster.mkedashboardclient
        mke_nodes = dashboardclient.get_nodes()
        for mke_node in mke_nodes:
            if mke_node['Description']['Hostname'] == node_name:
                raise Exception(f"Node {node_name} is present in MKE nodes list but it should not be present "
                                f"because LCMMachine has evacuation disable status")
        LOG.info("Verifying that nodedisablenotification is created")
        ndn = self.cluster.get_nodedisablenotification(node_name)
        assert ndn is not None, f"NodeDisableNotification {node_name} is not created but it is expected to be created"

    def make_broken_lcm_for_day2_operations(self, machines, state_names):
        """Make some LCM state broken in the LCMMachine objects"""
        for machine in machines:
            lcmmachine = self.cluster.get_cluster_lcmmachine(name=machine.name, namespace=machine.namespace)
            lcmmachine_data = lcmmachine.data
            state_items_overwr = lcmmachine_data['spec']['stateItemsOverwrites']
            for state_name in state_names:
                state_items_overwr[state_name] = {'ansible': '/bin/false'}
            body = {
                'spec': {
                    'stateItemsOverwrites': state_items_overwr
                }
            }
            LOG.info(f"Break ansible in LCMMachine {lcmmachine.namespace}/{lcmmachine.name} for tasks {state_names}")
            lcmmachine.patch(body)

    def fix_broken_lcm_for_day2_operations(self, machines):
        """Fix broken LCM states"""
        for machine in machines:
            lcmmachine = self.cluster.get_cluster_lcmmachine(name=machine.name, namespace=machine.namespace)
            lcmmachine_data = lcmmachine.data
            state_items_overwr = lcmmachine_data['spec']['stateItemsOverwrites']
            for state_name in state_items_overwr.keys():
                # Remove 'ansible' overwrites if exist
                # state_items_overwr.get(state_name, {}).pop('ansible', None)
                state_items_overwr[state_name]['ansible'] = None

            body = {
                'spec': {
                    'stateItemsOverwrites': state_items_overwr
                }
            }
            LOG.info(f"Fix 'ansible' in LCMMachine {lcmmachine.namespace}/{lcmmachine.name}")
            lcmmachine.patch(body)

    def make_broken_reboot_for_day2_operations(self, machines):
        """Make it impossible to reboot the Machine normally, by disabling some services

        SSH private key is required for this method
        """
        for machine in machines:
            LOG.info(f"Break the normal reboot for Machine {machine.namespace}/{machine.name}")
            machine.run_cmd('sudo systemctl mask containerd.service')
            machine.run_cmd('sudo systemctl mask docker.service')
            machine.run_cmd('sudo systemctl mask docker.socket')
            machine.run_cmd('sudo systemctl mask cri-dockerd-mke.service')
            machine.run_cmd('LCM_AGENT_BINARY=$(find /usr/local/bin/ -name "lcm-agent*") && '
                            'test -n "$LCM_AGENT_BINARY" && '
                            'echo "Remove executable flag from $LCM_AGENT_BINARY" && '
                            'sudo chmod 0644 $LCM_AGENT_BINARY')

    def fix_broken_reboot_for_day2_operations(self, machines, start_services=True):
        """Fix broken reboot for Machines

        SSH private key is required for this method
        """
        for machine in machines:
            LOG.info(f"Fix the normal reboot for Machine {machine.namespace}/{machine.name}")
            # Machine BMH should be 'online: true' at that moment, and Machine should be available via SSH
            machine.run_cmd('sudo systemctl unmask containerd.service')
            machine.run_cmd('sudo systemctl unmask docker.service')
            machine.run_cmd('sudo systemctl unmask docker.socket')
            machine.run_cmd('sudo systemctl unmask cri-dockerd-mke.service')
            machine.run_cmd('LCM_AGENT_BINARY=$(find /usr/local/bin/ -name "lcm-agent*") && '
                            'test -n "$LCM_AGENT_BINARY" && '
                            'echo "Set executable flag for $LCM_AGENT_BINARY" && '
                            'sudo chmod 0755 $LCM_AGENT_BINARY')
            if start_services:
                machine.run_cmd('sudo systemctl start containerd.service')
                machine.run_cmd('sudo systemctl start docker.socket')
                machine.run_cmd('sudo systemctl start docker.service')
                machine.run_cmd('sudo systemctl start cri-dockerd-mke.service')

    def _get_ceph_mon_deployments_info(self):
        rook_ceph_deployments = self.k8sclient.deployments.list(namespace='rook-ceph')
        mons = {
            'ready_num': 0,
            'ceph_daemon_ids': {},
        }
        for deploy in rook_ceph_deployments:
            try:
                deploy_data = deploy.data
                labels = deploy_data.get('metadata', {}).get('labels', {}) or {}
                if labels.get('ceph_daemon_type') == 'mon':
                    template_spec = deploy_data.get('spec', {}).get('template', {}).get('spec', {}) or {}
                    node_selector = template_spec.get('node_selector', {}) or {}
                    node_name = node_selector.get('kubernetes.io/hostname')
                    ceph_daemon_id = labels.get('ceph_daemon_id')
                    if node_name and ceph_daemon_id:
                        mons['ceph_daemon_ids'][node_name] = ceph_daemon_id
                    ready_replicas = deploy.ready_replicas or 0
                    mons['ready_num'] += bool(ready_replicas > 0)
                    LOG.info(f"Deployment '{deploy.name}' on K8sNode '{node_name}' ready replicas: {ready_replicas}")
            except ApiException as e:
                if e.status == 404:
                    LOG.info(f"Raised exception during checking deployments, skipping: {e}")
                else:
                    raise e
        return mons

    def move_ceph_monitor_during_maintenance(self, disabled_machines, new_storage_machines, ceph_k8snode_labels,
                                             interval=30, timeout=1200):
        """Perform steps from documentation to move Ceph monitor from 'disabled' Machine to another Machine"""

        # Steps from the documentation page:
        # - https://gerrit.mcp.mirantis.com/c/kaas/kaas-docs/+/194610/2/doc/source/operations-guide/operate-managed/operate-managed-bm/manage-ceph/move-mon-daemon.rst  # noqa

        # ceph-maintenance-controller must not be disabled for some time after patching MiraCeph
        # until at least two ceph-mon replicas will be available.
        # Step 1: ensure suitable cluster condition
        LOG.banner("Wait at least 2 ceph-mon 'ready' deployments before moving ceph-mon replicas "
                   "from disabled Machines", sep='-')
        waiters.wait(lambda: self._get_ceph_mon_deployments_info()['ready_num'] >= 2, interval=30, timeout=3600)

        disabled_k8s_node_names = [m.get_k8s_node_name() for m in disabled_machines]
        ceph_maintenance_controller = self.k8sclient.deployments.get(
            name='ceph-maintenance-controller', namespace='ceph-lcm-mirantis')
        rook_ceph_operator = self.k8sclient.deployments.get(
            name='rook-ceph-operator', namespace='rook-ceph')

        ceph_maintenance_controller_replicas = ceph_maintenance_controller.desired_replicas

        # Step 2: disable maintenance controller and enable operator
        LOG.banner("Disable 'ceph-maintenance-controller' and 'rook-ceph-operator'", sep='-')
        ceph_maintenance_controller.set_replicas(0)
        ceph_maintenance_controller.wait_ready()
        rook_ceph_operator.set_replicas(0)
        rook_ceph_operator.wait_ready()

        # Step 3: Ceph operator relies on the info stored in Ceph and tries to re-create outdated replicas,
        #         so we need to remove these outdated replicas from Ceph
        LOG.banner("Remove disabled ceph-mon replicas from Ceph itself", sep='-')
        ceph_mon_deployments_info = self._get_ceph_mon_deployments_info()
        LOG.info("Get rook-ceph-tools pod")
        ceph_tools_pod = self.k8sclient.pods.list(namespace='rook-ceph', name_prefix='rook-ceph-tools')[0]
        ceph_tools_pod.wait_ready()

        LOG.info("Cleanup mons from ceph")
        for node_name in disabled_k8s_node_names:
            ceph_daemon_id = ceph_mon_deployments_info['ceph_daemon_ids'].get(node_name)
            if ceph_daemon_id:
                LOG.warning(f"Remove Ceph mon '{ceph_daemon_id}'")
                cmd = ['/bin/sh', '-c', f'ceph mon rm {ceph_daemon_id}']
                ceph_tools_pod.exec(cmd)
            else:
                LOG.warning(f"Ceph mon is absent for disabled Node {node_name}")
        cmd = ['/bin/sh', '-c', 'ceph mon dump']
        ceph_dump = ceph_tools_pod.exec(cmd)
        LOG.info(f"Current ceph mons:\n{ceph_dump}")

        # Step 4: remove ceph-mon Deployment related to the outdated replicas
        LOG.banner("Delete rook-ceph deployments placed on the disabled Machines", sep='-')
        rook_ceph_deployments = self.k8sclient.deployments.list(namespace='rook-ceph')
        for rook_ceph_deployment in rook_ceph_deployments:
            template_spec = rook_ceph_deployment.data.get('spec', {}).get('template', {}).get('spec', {}) or {}
            node_selector = template_spec.get('node_selector', {}) or {}
            node_name = node_selector.get('kubernetes.io/hostname')
            if node_name and node_name in disabled_k8s_node_names:
                LOG.info(f"Delete deployment '{rook_ceph_deployment.namespace}/{rook_ceph_deployment.name}' "
                         f"that was placed on the K8sNode {node_name}")
                rook_ceph_deployment.delete()

        # TODO(ddmitriev): just double-check that maintenance controller is disabled before setting Node labels
        ceph_maintenance_controller_pods = self.k8sclient.pods.list(
            name_prefix='ceph-maintenance-controller', namespace='ceph-lcm-mirantis')
        LOG.info(f"ceph-maintenance-controller pods: {ceph_maintenance_controller_pods}\nSleep 120")
        time.sleep(120)

        # Step 5: Add labels on K8sNodes, because ceph operator will try to find suitable nodes
        #         for new ceph-mon replicas using these labels
        LOG.banner("Add ceph labels on K8sNodes for the new ceph nodes", sep='-')
        for new_storage_machine in new_storage_machines:
            if ceph_k8snode_labels[new_storage_machine.name]:
                # Add ceph labels on k8s Node
                new_storage_machine.add_k8s_node_labels(ceph_k8snode_labels[new_storage_machine.name])

        # Step 6: Enable ceph operator
        LOG.banner("Enable 'rook-ceph-operator'", sep='-')
        rook_ceph_operator.set_replicas(1)
        rook_ceph_operator.wait_ready()

        # Step 7: Wait until ceph operator create new Deployment for ceph-mon on new K8sNodes
        LOG.banner("Wait until at least one new ceph-mon Deployment is created for the new storage Machines", sep='-')
        new_k8s_node_names = [m.get_k8s_node_name() for m in new_storage_machines]

        def _check_new_deployments():
            ceph_mon_deployments_info = self._get_ceph_mon_deployments_info()
            for node_name in new_k8s_node_names:
                ceph_daemon_id = ceph_mon_deployments_info['ceph_daemon_ids'].get(node_name)
                if ceph_daemon_id:
                    LOG.info(f"Found new ceph-mon Deployment for replica '{ceph_daemon_id}' "
                             f"on K8sNode {node_name}")
                    return True
            return False
        waiters.wait(_check_new_deployments, interval=interval, timeout=timeout)

        LOG.banner("Wait until all rook-ceph pods are running", sep='-')
        self.cluster.check.check_k8s_pods(timeout=1200, interval=30, target_namespaces=["rook-ceph"])

        # Step 8: Enable maintenance controller to continue LCM operations with Ceph
        LOG.banner("Enable 'ceph-maintenance-controller'", sep='-')
        ceph_maintenance_controller.set_replicas(ceph_maintenance_controller_replicas)
        ceph_maintenance_controller.wait_ready()

        LOG.banner("DONE: Ceph roles were successfully moved on new Machines", sep='-')

    def wait_nwl_created_for_new_machines(self, new_storage_machines, interval=30, timeout=3600):

        def _check_nwl():
            for machine in new_storage_machines:
                node_name = machine.get_k8s_node_name()
                ceph_nwl_name = f"ceph-{node_name}"
                if not self.k8sclient.nodeworkloadlocks.present_all(ceph_nwl_name):
                    LOG.warning(f"NodeWorkloadLock '{ceph_nwl_name}' still not found")
                    return False
                else:
                    LOG.info((f"Found NodeWorkloadLock '{ceph_nwl_name}'"))
            LOG.info((f"*** All expected NodeWorkloadLocks present "
                      f"in the Cluster {self.cluster.namespace}/{self.cluster.name}"))
            return True

        waiters.wait(_check_nwl, interval=interval, timeout=timeout)

    def disable_ceph_for_machines(self, disabled_machines, storage_candidate_machines=None):
        if not self.cluster.is_ceph_deployed:
            LOG.warning(f"Ceph is not deployed for Cluster '{self.cluster.namespace}/{self.cluster.name}', "
                        f"skip moving ceph monitor to another Machine")
            return

        # Steps from the documentation page:
        # - https://gerrit.mcp.mirantis.com/c/kaas/kaas-docs/+/192191/17/doc/source/common/ops/ceph/ceph-node-disable.rst  # noqa

        LOG.banner("Move Ceph roles from disabled to working Machines")

        # Get ceph nodes (MCC Machine names) from KaasCephCluster
        kaascephcluster = self.cluster.get_cephcluster()
        ceph_data = kaascephcluster.data
        ceph_nodes = ceph_data.get('spec', {}).get('cephClusterSpec', {}).get('nodes', {})
        old_ceph_nodes_names = list(ceph_nodes.keys())

        storage_labels = utils.get_labels_by_type('storage')
        if not storage_candidate_machines:
            storage_candidate_machines = self.get_storage_candidate_machines(old_ceph_nodes_names)

        for m in disabled_machines:
            LOG.info(f"disabled_machines = {m.name}")
        for m in storage_candidate_machines:
            LOG.info(f"storage_candidate_machines = {m.name}")

        new_storage_machines = []
        ceph_k8snode_labels = {}
        move_ceph_mon_role = False

        for disabled_machine in disabled_machines:
            if disabled_machine.name in ceph_nodes:
                # 1. Find a new Machine without 'storage' label to move Ceph services
                if not storage_candidate_machines:
                    raise Exception(f"There are no available Machines to move Ceph roles"
                                    f"from disabled machine {disabled_machine.name}")
                storage_candidate_machine = storage_candidate_machines.pop()
                new_storage_machines.append(storage_candidate_machine)
                LOG.info(f"Ceph will be evacuated from Machine '{disabled_machine.name}' "
                         f"to Machine '{storage_candidate_machine.name}'")

                # 2. Move 'storage' label from disabled Machine to the new Machine
                LOG.info(f"Add 'storage' label to Machine '{storage_candidate_machine.name}'")
                storage_candidate_machine.add_machine_labels(storage_labels)
                LOG.info(f"Remove 'storage' label from Machine '{disabled_machine.name}' : {storage_labels.keys()}")
                disabled_machine.remove_machine_labels(list(storage_labels.keys()))

                # 3. Move roles to the new Machine
                LOG.info(f"Move KaasCephCluster roles from Machine '{disabled_machine.name}' "
                         f"to Machine '{storage_candidate_machine.name}'")
                ceph_k8snode_labels[storage_candidate_machine.name] = {}

                # ceph_nodes[storage_candidate_machine.name] = {'roles': []}
                # for role in ceph_nodes[disabled_machine.name]['roles']:
                #    ceph_k8snode_labels[storage_candidate_machine.name][f"ceph_role_{role}"] = "true"
                #    ceph_nodes[storage_candidate_machine.name]['roles'].append(role)
                #    if role == 'mon':
                #        # need to move 'mon' role to another Machine with a special procedure
                #        move_ceph_mon_role = True

                # ceph_nodes[storage_candidate_machine.name] = ceph_nodes[disabled_machine.name]
                ceph_nodes[storage_candidate_machine.name] = {'roles': ceph_nodes[disabled_machine.name]['roles']}
                if 'mon' in ceph_nodes[storage_candidate_machine.name]['roles']:
                    move_ceph_mon_role = True
                for role in ceph_nodes[disabled_machine.name]['roles']:
                    ceph_k8snode_labels[storage_candidate_machine.name][f"ceph_role_{role}"] = "true"

                if ceph_k8snode_labels[storage_candidate_machine.name]:
                    # Add ceph labels on k8s Node
                    storage_candidate_machine.add_k8s_node_labels(ceph_k8snode_labels[storage_candidate_machine.name])

                # 4. Remove old Machine from ceph nodes
                LOG.info(f"Remove Machine '{disabled_machine.name}' from kaascephcluster "
                         f"'{kaascephcluster.namespace}/{kaascephcluster.name}'")
                ceph_nodes[disabled_machine.name] = None

        LOG.info(f"old_ceph_nodes_names = {old_ceph_nodes_names}")
        LOG.info(f"ceph_nodes.keys() = {ceph_nodes.keys()}")

        if set(old_ceph_nodes_names) == set(list(ceph_nodes.keys())):
            LOG.info("Disabled Machines are not part of KaasCephCluster, nothing to fix for Ceph")
            return

        # 5. Update KaasCephCluster with new Machine names and remove disabled Machines
        body = {
            'spec': {
                'cephClusterSpec': {
                    'nodes': ceph_nodes,
                }
            }
        }
        LOG.info(f"Make changes to KaasCephCluster '{kaascephcluster.namespace}/{kaascephcluster.name}'")
        kaascephcluster.patch(body)

        # 6. Wait for updated MiraCeph
        LOG.banner("Wait for new nodes in MiraCeph", sep='-')
        self.cluster.check.wait_miraceph_nodes_updated()

        # 7. Wait for new NWLs
        LOG.banner("Wait that Ceph NodeWorkloadLocks are created for nodes added to Ceph", sep='-')
        self.wait_nwl_created_for_new_machines(new_storage_machines)

        # 8. If 'mon' role was moved
        if move_ceph_mon_role:
            LOG.banner("Move Ceph monitor", sep='-')
            self.move_ceph_monitor_during_maintenance(disabled_machines, new_storage_machines, ceph_k8snode_labels)

    def disable_stacklight_for_machines(self):
        """Relabel SL nodes and remove SL pvc and pods related to disabled machines

        1. Add spec.providerSpec.value.nodeLabels with {key: stacklight, value: enabled} to all non-SL machines
        2. Remove SL labels from spec.providerSpec.value.nodeLabels from disabled Machines
        3. Proceed with PVC as described in https://gerrit.mcp.mirantis.com/c/kaas/kaas-docs/+/194333 :
           - Remove pvc related to stacklight pods volumes on disabled machines
           - Remove pods related to stacklight on disabled machines
        """
        LOG.banner("Move StackLight from disabled to working Machines")

        cluster_machines = self.cluster.get_machines()
        disabled_machines = [m for m in cluster_machines if m.is_disabled()]
        sl_nodelabel = [{"key": "stacklight", "value": "enabled"}]
        non_sl_machines = self.get_stacklight_candidate_machines()
        # SL requires at least 3 *Ready* Machines to add labels,
        # which is impossible if one of SL Machines is Disabled and another in maintenance.
        # To proceed with this limitation, let's add labels to all available machines
        for machine in non_sl_machines:
            LOG.info(f"Add nodeLabel stacklight=enabled to Machine '{machine.namespace}/{machine.name}'")
            machine.add_labels(sl_nodelabel)

        for disabled_machine in disabled_machines:
            if disabled_machine.has_nodelabels(sl_nodelabel):
                LOG.info(f"Remove nodeLabel stacklight=enabled from Machine "
                         f"'{disabled_machine.namespace}/{disabled_machine.name}'")
                disabled_machine.remove_labels(sl_nodelabel)

        self.cleanup_pods_and_pvc_from_disabled_machines(target_namespaces=['stacklight'])

    def cleanup_pods_and_pvc_from_disabled_machines(self, target_namespaces=None):
        """Find pods with PVC which bound to the disabled nodes and remove that PVCs and PODs"""

        LOG.banner("Cleanup PODs and PVCs that are scheduled on the disabled Machines")
        target_namespaces = target_namespaces or []
        disabled_machines = [m for m in self.cluster.get_machines() if m.is_disabled()]
        pods = self.k8sclient.pods.list_all()
        node_names = [machine.get_k8s_node_name() for machine in disabled_machines]
        LOG.info(f"Pods and PVCs cleanup started for K8sNodes {node_names}")
        for pod in pods:
            if target_namespaces and pod.namespace not in target_namespaces:
                continue
            try:
                pod_data = pod.data
                pod_node = pod_data['spec'].get('node_name')
                if pod_node and pod_node in node_names:
                    pod_volumes = pod_data['spec']['volumes']
                    for volume in pod_volumes:
                        if volume.get('persistent_volume_claim'):
                            pvc_name = volume['persistent_volume_claim']['claim_name']
                            LOG.info(f"Delete PVC {pvc_name}")
                            pvc = self.k8sclient.pvolumeclaims.get(name=pvc_name, namespace=pod.namespace)
                            pvc.delete()
                    LOG.info(f"Delete Pod '{pod.namespace}/{pod.name}' from node '{pod_node}'")
                    pod.delete()
            except ApiException as e:
                if e.status == 404:
                    LOG.info(f"Skipping error: {e}")
                else:
                    raise e

        LOG.info("Pods cleanup completed")

    def check_cluster_readiness(self, exp_provider_status, expected_condition_fails=None, **kwargs):
        """Check Cluster conditions readiness in case if some Machines are in 'Disabled' state

        :param exp_provider_status: bool, if False, then ignore some Cluster conditions
                                          if True, then run cluster.check.check_cluster_readiness() without excludes
        :param expected_condition_fails: dict, additional conditions to exclude
        """
        if not exp_provider_status:
            expected_condition_fails = expected_condition_fails or {}
            node_status = self.cluster.data.get('status', {}).get('providerStatus', {}).get('nodes', {})
            expected_nodes = node_status.get('requested', 0)
            expected_ready_machines = 0
            expected_disabled_machines = 0
            machines = self.cluster.get_machines()
            for m in machines:
                if m.data.get('status', {}).get('providerStatus', {}).get('status', '') == 'Ready':
                    expected_ready_machines += 1
                elif m.data.get('status', {}).get('providerStatus', {}).get('status', '') == 'Disabled':
                    expected_disabled_machines += 1

            node_condition_msg = (f"Requested {expected_nodes} node(s), ready {expected_ready_machines}, "
                                  f"disabled {expected_disabled_machines}.")
            expected_condition_fails['Nodes'] = node_condition_msg
            expected_condition_fails['MachineDisable'] = ''
            if self.cluster.workaround.prodx_42484():
                LOG.warning("Workaround for LCMOperation condition is enabled")
                expected_condition_fails['LCMOperation'] = ''

        self.cluster.check.check_cluster_readiness(expected_condition_fails=expected_condition_fails,
                                                   exp_provider_status=exp_provider_status,
                                                   **kwargs)

    def _create_replaced_machine(self, machine, timeout=5400):
        """
        Get data from previous deleted master machine and create a new one
        Args:
            cluster: current cluster object
            machine: previous deleted master machine

        Returns: Machine object
        """

        public_key_name = f"{self.cluster.name}-key"
        machine_node_labels = machine['spec']['providerSpec']['value'].get('nodeLabels', [])
        node_labels = {item['key']: item['value'] for item in machine_node_labels}
        new_kaasmachine = self.cluster.create_baremetal_machine(
            genname=machine['metadata']['name'],
            node_pubkey_name=public_key_name,
            matchlabels=machine['spec']['providerSpec']['value']['hostSelector']['matchLabels'],
            baremetalhostprofile=machine['spec']['providerSpec']['value'].get('bareMetalHostProfile', None),
            l2TemplateSelector=machine['spec']['providerSpec']['value'].get('l2TemplateSelector', None),
            labels=machine['metadata']['labels'],
            node_labels=node_labels,
            distribution=machine['spec']['providerSpec']['value'].get('distribution', None),
        )

        LOG.info(f'Wait new machine {new_kaasmachine.name} readiness')
        # Waiting for master node become Ready
        self.cluster.check.wait_machine_status_by_name(machine_name=new_kaasmachine.name,
                                                       expected_status='Ready',
                                                       timeout=timeout)

        new_machine = self.cluster.get_machine(name=new_kaasmachine.name)
        return new_machine

    def _create_replaced_bmh(self, secret_data, bmh_data):
        """
        Create a new BMH based on deleted

        Args:
            secret_data: bmh secret cred data
            bmh_data: bmh data

        Returns: None
        """
        kaas_manager = self.cluster._manager
        managed_ns = kaas_manager.get_namespace(self.cluster.namespace)
        region = kaas_manager.get_mgmt_cluster().region_name

        new_bmh_name = bmh_data['metadata']['name']

        # For backward compatibility for secrets in older versions where bmh creds are not supported
        cred_name = bmh_data['spec']['bmc']['credentialsName']

        annotations = bmh_data['metadata'].get('annotations', {}) or {}
        if "kaas.mirantis.com/baremetalhost-credentials-name" in annotations:
            cred_name = bmh_data['metadata'].get('annotations', {}).get(
                        'kaas.mirantis.com/baremetalhost-credentials-name', cred_name)
            if not kaas_manager.api.kaas_baremetalhostscredentials.present(name=cred_name,
                                                                           namespace=self.cluster.namespace):
                managed_ns.create_baremetalhostcredential(name=cred_name, data=secret_data.data, region=region,
                                                          provider="baremetal")
            else:
                LOG.warning(f'bmhc: {cred_name} already exist, skipping')
        else:
            raise Exception("IPMI credentials supported only over baremetalhostcredentials")

        address = bmh_data['spec']['bmc']['address'].split(":")

        if len(address) == 2:
            bmh_ipmi_data = {
                "ipmi_ip": address[0],
                "port": address[1]
            }
        else:
            bmh_ipmi_data = {
                "ipmi_ip": address[0]
            }

        bootUEFI = True if bmh_data['spec'].get('bootMode', '') == 'UEFI' else False
        managed_ns.create_baremetalhost(bmh_name=new_bmh_name,
                                        bmh_secret=cred_name,
                                        bmh_mac=bmh_data['spec']['bootMACAddress'],
                                        bmh_ipmi=bmh_ipmi_data,
                                        hardwareProfile=bmh_data['spec'].get('hardwareProfile', False),
                                        labels=bmh_data['metadata']['labels'],
                                        annotations=bmh_data['metadata'].get('annotations', {}),
                                        bootUEFI=bootUEFI)

        managed_ns.wait_baremetalhosts_statuses(nodes=new_bmh_name,
                                                wait_status='ready',
                                                retries=40,
                                                interval=60)

    def replace_bm_machine(self, machine):
        """Replace Machine using the same baremetal node

          1. Collect data about BMH/secret/node
          2. Delete machine
          3. Delete BMH
          4. Create a new BMH
          5. Create new machine
        """
        ns = self.cluster._manager.get_namespace(self.cluster.namespace)

        LOG.banner("Collect data about BMH/secret/node", sep='-')
        # show_step(2)
        machine_bmh_name = machine.metadata['annotations'].get('metal3.io/BareMetalHost')
        bmh = ns.get_baremetalhost(name=machine_bmh_name.split("/")[1])
        old_bmh_data = copy.deepcopy(bmh.data)
        removed_machine = copy.deepcopy(machine.data)
        old_secret = self.cluster._manager.api.secrets.get(
            name=old_bmh_data['spec']['bmc']['credentialsName'],
            namespace=self.cluster.namespace).read()
        old_secret_data = copy.deepcopy(old_secret)
        bm_hosts_data = []
        bm_hosts_data.append({})
        bm_hosts_data[0]['name'] = machine_bmh_name.split("/")[1].split('-')[0]
        bm_hosts_data[0]['bmh_annotations'] = old_bmh_data['metadata'].get('annotations', {}) or {}

        # Use '-new' for object names to create a new BMH and a new Machine
        old_bmh_data['metadata']['name'] += '-new'
        old_bmh_data['metadata']['annotations']['kaas.mirantis.com/baremetalhost-credentials-name'] += '-new'
        old_bmh_data['metadata']['labels']['kaas.mirantis.com/baremetalhost-id'] += '-new'
        old_bmh_data['spec']['bmc']['credentialsName'] += '-new'
        removed_machine['metadata']['name'] += '-new'
        removed_machine['spec']['providerSpec']['value']['hostSelector']['matchLabels'][
            'kaas.mirantis.com/baremetalhost-id'] += '-new'
        old_bmh_data['spec']['consumerRef'] = None  # Need to unlink BMH from existing Machine
        old_bmh_data['metadata']['uid'] = None  # Need to unlink BMH from existing IpamHost

        LOG.banner("Delete BMH", sep='-')
        # Remove unique data from old BMH to allow create a new BMH with the same data
        body = {
            'spec': {
                # 'bootMACAddress': None,
                'consumerRef': None,
            },
        }
        bmh.patch(body=body)

        LOG.info(f"Deleting BMH: {bmh.name}")
        bmh.delete()
        ns.wait_baremetalhost_deletion(bmh.name, wait_bmh_cred=True, bm_hosts_data=bm_hosts_data, timeout=3600)

        LOG.banner(f"Unbind Machine {machine.name} from deleted BMH", sep='-')
        # Unbind the disabled Machine object from it's BMH,
        # so we could replace the Machine using the same baremetal node
        body = {
            'metadata': {
                'annotations': {
                    'metal3.io/BareMetalHost': 'disable-bmh',  # Use fake BMH name to avoid
                                                               # binding this Machine to new BMH
                },
                # 'finalizers': None,  # Remove finalizers to unblock deleting the Machine with fake BMH
            },
            'spec': {
                'providerSpec': {
                    'value': {
                        'hostSelector': None,
                    },
                },
            },
        }
        machine.patch(body)

        LOG.banner("Create a new BMH", sep='-')
        self._create_replaced_bmh(old_secret_data, old_bmh_data)

        LOG.banner("Create a new Machine", sep='-')
        new_machine = self._create_replaced_machine(removed_machine)
        return new_machine

    def remove_replaced_bm_machine(self, machine, timeout=1800):
        LOG.info(f"Deleting machine '{machine.name}' with 'unsafe' policy")
        body = {
            'metadata': {
                'annotations': {
                    'metal3.io/BareMetalHost': None,
                },
            },
        }
        machine.patch(body)
        machine.set_deletion_policy('unsafe')
        machine.delete(new_delete_api=False)
        self.cluster.wait_machine_deletion(machine.name, interval=30, retries=int(timeout/30))
