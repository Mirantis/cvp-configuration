import os

from functools import cached_property
from kubernetes.client.rest import ApiException

from si_tests.clients.k8s import K8sCluster
from si_tests.settings import KUBECONFIG_PATH


class OsCtlManager:
    def __init__(self, kubeconfig=KUBECONFIG_PATH):
        self.kubeconfig = kubeconfig
        self.os_helm_system_namespace = 'osh-system'
        self.client = None

    @cached_property
    def api(self) -> K8sCluster:
        """
        :rtype: cluster.K8sCluster
        """
        if not os.path.isfile(self.kubeconfig):
            raise FileNotFoundError(
                "kubeconfig file={} not found!".format(self.kubeconfig)
            )
        return K8sCluster(kubeconfig=self.kubeconfig)

    def reload_client(self):
        for pod in self.api.pods.list_starts_with(
            "openstack-controller", self.os_helm_system_namespace
        ):
            pod_obj = pod.read()
            if (
                pod_obj.metadata.labels.get("app.kubernetes.io/instance")
                == "openstack-operator"
                and pod_obj.metadata.labels.get("app.kubernetes.io/name")
                == "openstack-operator"
            ):
                self.client = pod
                break

    def exec(self, cmd, request_timeout=120):
        """
        Executes osctl command on openstack-controller pod
        """
        if self.client is None:
            self.reload_client()
        command = ["/bin/sh", "-c", cmd]
        try:
            response = self.client.exec(command, container="osdpl", _request_timeout=request_timeout)
        except ApiException as e:
            if "Not Found" in e.reason:
                self.reload_client()
                return self.client.exec(command, _request_timeout=request_timeout)
            raise e
        return response
