#    Copyright 2023 Mirantis, Inc.
#
#    Licensed under the Apache License, Version 2.0 (the "License"); you may
#    not use this file except in compliance with the License. You may obtain
#    a copy of the License at
#
#         http://www.apache.org/licenses/LICENSE-2.0
#
#    Unless required by applicable law or agreed to in writing, software
#    distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
#    WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
#    License for the specific language governing permissions and limitations

from si_tests import logger, settings
from si_tests.managers.bootstrap_manager import BootstrapManager

LOG = logger.logger


class PDNSManager:

    def __init__(self, bootstrap_manager: BootstrapManager, verbose: bool = True):
        self.verbose = verbose
        self.bootstrap_manager = bootstrap_manager
        self.remote = bootstrap_manager.remote_seed()
        self.seed_node_ip = self.bootstrap_manager.get_seed_ip()

    def install_pdns(self, local_zones=None, upstream_nameserver=settings.DNS_NAMESERVER):
        """Install PowerDNS server and recursor on the Seed node

        This turns Seed node into a DNS server which can manage own zones
        or forward requests recursively to upstream DNS

        :param local_zones: list of strings, zone names to forward to the Authoritative server
                            Do not use "local" zone because it is filtered as unsafe
                            in "systemd-resolved" service by default.
                            To check other filtered zones, please run on the node:
                                $ systemd-resolve --status
                                or
                                $ resolvectl nta
                            , and check for "DNSSEC NTA" entries (DNSSEC Negative Trust Anchor)
        :param upstream_nameserver: str, IP of upstream DNS server to forward all other queries
        """
        local_zones = local_zones or []
        if local_zones:
            forward_zones = [f"{zone}=127.0.0.1:5300" for zone in local_zones]
            forward_zones_str = "forward-zones=" + ','.join(forward_zones) + "\n"
        else:
            forward_zones_str = ""

        install_cmds = [
            # Failing to start pdns.service during apt install is expected
            "apt install -y sqlite3 net-tools pdns-backend-sqlite3 pdns-server pdns-recursor",

            "systemctl stop pdns.service",
            "systemctl stop pdns-recursor.service",
            "rm -rf /etc/powerdns/pdns.d/* || true",

            # Configure local pdns-server to use a simple SQLite3 backend
            # and default zone TTL 60 sec, to allow quick apply of the zone changes
            ("[ -f /var/lib/powerdns/pdns.sqlite3 ] || "
             "sqlite3 /var/lib/powerdns/pdns.sqlite3 < /usr/share/doc/pdns-backend-sqlite3/schema.sqlite3.sql"),
            ("cat << EOF > /etc/powerdns/pdns.d/local.conf\n"
             "launch=gsqlite3\n"
             "gsqlite3-database=/var/lib/powerdns/pdns.sqlite3\n"
             "default-ttl=60\n"
             "EOF\n"),

            # In Ubuntu 22 pdns service is working from pdns user
            #
            # ubuntu@system-phys-410-bm-seed:~$ systemctl cat pdns.service | grep -E 'User|Group'
            # User=pdns
            # Group=pdns
            # # Setting PrivateUsers=true prevents us from opening our sockets
            # ProtectControlGroups=true
            # So we need to change owner. This is backward compatible
            ("chown pdns:pdns /var/lib/powerdns/pdns.sqlite3"),

            # Listen address/port for the authoritative pdns server
            # which will keep our custom zones
            ("cat << EOF > /etc/powerdns/pdns.d/listen.conf\n"
             "local-address=127.0.0.1\n"
             "local-port=5300\n"
             "EOF\n"),

            # Which servers the Recursor should ask for the requesting zone.
            # Firstly, ask the local pdns-server on 127.0.0.1:5300,
            # then ask the upstream nameserver
            (f"cat << EOF > /etc/powerdns/recursor.d/forwards.conf\n"
             f"{forward_zones_str}"
             f"forward-zones-recurse=.={upstream_nameserver}\n"
             f"trace=on\n"
             f"EOF\n"),

            # Addresses to listen port :53 for DNS requests
            (f"cat << EOF > /etc/powerdns/recursor.d/listen.conf\n"
             f"local-address=127.0.0.1, {self.seed_node_ip}\n"
             f"EOF\n"),

            # Service 'systemd-resolved' occupies port :53 and will conflict with pdns-recursor
            "systemctl disable --now systemd-resolved",
            # Start Authoritative and Recursor servers
            "systemctl start pdns.service",
            "systemctl start pdns-recursor.service",

            'echo "nameserver 127.0.0.1" | tee /etc/resolv.conf',
            "sed -i '/127.0.1.1.*/d' /etc/hosts",
            'echo "127.0.1.1 $(hostname -s)" | tee -a /etc/hosts',
            "systemctl status pdns.service",
            "systemctl status pdns-recursor.service",
            "netstat -lpn|grep :53",
        ]

        for cmd in install_cmds:
            with self.remote.sudo(enforce=True):
                self.remote.check_call(cmd, verbose=self.verbose)

    def restart_service(self):
        with self.remote.sudo(enforce=True):
            self.remote.check_call("systemctl restart pdns.service", verbose=True)

    def create_zone(self, zone_name, recreate=True):
        with self.remote.sudo(enforce=True):
            res = self.remote.execute(f"pdnsutil list-zone {zone_name}")
            if res.exit_code == 0:
                if recreate:
                    LOG.info(f"Delete old PDNS zone {zone_name}")
                    self.remote.check_call(f"pdnsutil delete-zone {zone_name}")
                else:
                    LOG.info(f"PDNS zone {zone_name} already exists, zone recreate is disabled, using existing")

            # Create zone with SOA and NS records
            self.remote.check_call(f"pdnsutil create-zone {zone_name} ns1.{zone_name}")

        # Create A records for the nameserver and zone name
        self.add_record(zone_name, 'ns1', 'A', self.seed_node_ip)
        self.add_record(zone_name, '.', 'A', self.seed_node_ip)

    def add_record(self, zone_name, record_name, record_type, record_content):
        with self.remote.sudo(enforce=True):
            self.remote.check_call(f"pdnsutil add-record {zone_name} {record_name} {record_type} {record_content}")

    def show_zone(self, zone_name):
        with self.remote.sudo(enforce=True):
            self.remote.check_call(f"pdnsutil list-zone {zone_name}", verbose=True)
