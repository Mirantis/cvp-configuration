#    Copyright 2023 Mirantis, Inc.
#
#    Licensed under the Apache License, Version 2.0 (the "License"); you may
#    not use this file except in compliance with the License. You may obtain
#    a copy of the License at
#
#         http://www.apache.org/licenses/LICENSE-2.0
#
#    Unless required by applicable law or agreed to in writing, software
#    distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
#    WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
#    License for the specific language governing permissions and limitations

import time

import yaml

from si_tests import logger, settings
from si_tests.managers.bootstrap_manager import BootstrapManager
from si_tests.utils import packaging_version as version
from si_tests.utils import utils

LOG = logger.logger


class PDNSManager:

    def __init__(self, bootstrap_manager: BootstrapManager, verbose: bool = True):
        self.verbose = verbose
        self.bootstrap_manager = bootstrap_manager
        self.remote = bootstrap_manager.remote_seed()
        self.seed_node_ip = self.bootstrap_manager.get_seed_ip()
        self._listen_address = None

    @property
    def listen_address(self):
        """Address for the recursor to listen on, on the seed node itself

        By default this is 'seed_node_ip', the address the other hosts reach the seed node
        by, and nothing is asked of the node itself.

        That address is not necessarily configured on the node, though: on OpenStack it is a
        Neutron floating IP NATed to the port of the node, the recursor is unable to bind to
        it, and 'pdns-recursor.service' fails to start. SEED_PDNS_DETECT_LISTEN_ADDRESS turns
        on a lookup for such environments: the node is asked whether it holds the address at
        all, and the address of its default route interface is used when it does not.
        """
        if not settings.SEED_PDNS_DETECT_LISTEN_ADDRESS:
            return self.seed_node_ip
        if not self._listen_address:
            ip = self.seed_node_ip
            cmd = (rf"ip -4 -o addr show | grep -qFw {ip} && echo {ip} || "
                   r"ip -4 route get 1.1.1.1 | sed -n 's/.* src \([0-9.]*\).*/\1/p'")
            self._listen_address = self.remote.check_call(cmd, verbose=self.verbose).stdout_str.strip()
            assert self._listen_address, (
                f"Unable to determine an address of the seed node '{ip}' to listen on")
            if self._listen_address != ip:
                LOG.warning(f"Seed node address '{ip}' is not configured on the node, "
                            f"PowerDNS will listen on '{self._listen_address}' instead")
        return self._listen_address

    def prepare_repository(self, server_version='4.6', recursor_version='4.6'):
        remote_distr_codename = self.remote.check_call("lsb_release -sc").stdout_str
        server_repo_code = ''.join(server_version.split('.')[:2])
        recursor_repo_code = ''.join(recursor_version.split('.')[:2])
        stable_versions_map = {
            'authserver':
                {'repo': f'deb [signed-by=/etc/apt/keyrings/auth-{server_repo_code}-pub.asc] '
                         f'http://repo.powerdns.com/ubuntu {remote_distr_codename}-auth-{server_repo_code} main'},
            'recursor':
                {'repo': f'deb [signed-by=/etc/apt/keyrings/rec-{recursor_repo_code}-pub.asc] '
                         f'http://repo.powerdns.com/ubuntu {remote_distr_codename}-rec-{recursor_repo_code} main'}
        }

        # The suite name is built from the seed's Ubuntu codename, so the version has to be one that
        # PowerDNS publishes for that codename: 4.6 stops at jammy (22.04) and 404s on noble (24.04),
        # where the oldest builds are auth 4.9 and rec 5.0. https://repo.powerdns.com/ubuntu/dists/
        prepare_cmds = [
            (f"cat << EOF > /etc/apt/sources.list.d/pdns.list\n"
             f"{stable_versions_map['authserver']['repo']}\n"
             f"{stable_versions_map['recursor']['repo']}\n"),

            (f"cat << EOF > /etc/apt/preferences.d/auth-{server_repo_code}\n"
             "Package: auth*\n"
             "Pin: origin repo.powerdns.com\n"
             "Pin-Priority: 600\n"
             "EOF\n"),

            (f"cat << EOF > /etc/apt/preferences.d/rec-{recursor_repo_code}\n"
             "Package: rec*\n"
             "Pin: origin repo.powerdns.com\n"
             "Pin-Priority: 600\n"
             "EOF\n"),

            ("install -d /etc/apt/keyrings; curl https://repo.powerdns.com/FD380FBB-pub.asc | "
             f"tee /etc/apt/keyrings/auth-{server_repo_code}-pub.asc"),

            ("install -d /etc/apt/keyrings; curl https://repo.powerdns.com/FD380FBB-pub.asc | "
             f"tee /etc/apt/keyrings/rec-{recursor_repo_code}-pub.asc"),
            "apt update",
        ]
        for cmd_p in prepare_cmds:
            with self.remote.sudo(enforce=True):
                self.remote.check_call(cmd_p, verbose=self.verbose)

    def install_actions(self, with_recursor=True):
        # 'dnsutils' brings 'dig', used to check that the published names really resolve
        packages = "sqlite3 net-tools dnsutils pdns-backend-sqlite3 pdns-server"
        if with_recursor:
            packages += " pdns-recursor"
        actions_cmds = [
            # Failing to start pdns.service during apt install is expected
            f"apt install -y {packages}",

            "systemctl stop pdns.service"]
        if with_recursor:
            actions_cmds.append("systemctl stop pdns-recursor.service")
        actions_cmds.append("rm -rf /etc/powerdns/pdns.d/* || true")

        for action_cmd in actions_cmds:
            with self.remote.sudo(enforce=True):
                self.remote.check_call(action_cmd, verbose=self.verbose)

    def configure_server(self):
        config_server_cmds = [

            # Configure local pdns-server to use a simple SQLite3 backend
            # and default zone TTL 60 sec, to allow quick apply of the zone changes
            ("[ -f /var/lib/powerdns/pdns.sqlite3 ] || "
             "sqlite3 /var/lib/powerdns/pdns.sqlite3 < /usr/share/doc/pdns-backend-sqlite3/schema.sqlite3.sql"),

            ("cat << EOF > /etc/powerdns/pdns.d/local.conf\n"
             "launch=gsqlite3\n"
             "gsqlite3-database=/var/lib/powerdns/pdns.sqlite3\n"
             "default-ttl=60\n"
             "EOF\n"),

            # Change owner to pdns
            "chown pdns:pdns /var/lib/powerdns/pdns.sqlite3",

            # Listen address/port for the authoritative pdns server
            # which will keep our custom zones
            ("cat << EOF > /etc/powerdns/pdns.d/listen.conf\n"
             "local-address=127.0.0.1\n"
             "local-port=5300\n"
             "EOF\n")
        ]
        for config_server_cmd in config_server_cmds:
            with self.remote.sudo(enforce=True):
                self.remote.check_call(config_server_cmd, verbose=self.verbose)

    def _configure_recursor_old(self, zones, upstream_nameserver):
        if zones:
            forward_zones = [f"{zone}=127.0.0.1:5300" for zone in zones]
            forward_zones_str = "forward-zones=" + ','.join(forward_zones) + "\n"
        else:
            forward_zones_str = ""
        # Which servers the Recursor should ask for the requesting zone.
        # Firstly, ask the local pdns-server on 127.0.0.1:5300,
        # then ask the upstream nameserver
        configure_recursor_cmds = [
            # 'dnssec': the forwarded zone is not signed while the signed root proves
            # that its top-level domain does not exist, so the recursor rejects every
            # answer as "Bogus - No RRSIG" and turns it into SERVFAIL. unbound needs
            # 'domain-insecure' for the same reason, see roles/unbound.
            (f"cat << EOF > /etc/powerdns/recursor.d/forwards.conf\n"
             f"{forward_zones_str}"
             f"forward-zones-recurse=.={upstream_nameserver}\n"
             f"dnssec=process-no-validate\n"
             f"trace=on\n"
             f"EOF\n"),

            # Addresses to listen port :53 for DNS requests
            (f"cat << EOF > /etc/powerdns/recursor.d/listen.conf\n"
             f"local-address=127.0.0.1, {self.listen_address}\n"
             f"EOF\n")
        ]
        for configure_recursor_cmd in configure_recursor_cmds:
            with self.remote.sudo(enforce=True):
                self.remote.check_call(configure_recursor_cmd, verbose=self.verbose)

    def _configure_recursor_new(self, zones, upstream_nameserver):
        # Use yaml format for new versions
        recursor_conf = {
            'recursor': {
                'hint_file': '/usr/share/dns/root.hints',
                'forward_zones': [],
                'forward_zones_recurse': [
                    {'zone': '.',
                     'forwarders': [f'{upstream_nameserver}']
                     }
                ]
            },
            'incoming': {
                'listen': ['127.0.0.1', f'{self.listen_address}']
            }
        }
        zones = zones or []
        for zone in zones:
            recursor_conf['recursor']['forward_zones'].append(
                {'zone': f'{zone}',
                 'forwarders': ['127.0.0.1:5300']}
            )
        with open('recursor.conf', 'w') as file:
            yaml.dump(recursor_conf, file, default_flow_style=False)
        LOG.info(f"Uploading to /etc/powerdns/recursor.conf\n{yaml.dump(recursor_conf)}")
        with self.remote.sudo(enforce=True):
            self.remote.upload(source='recursor.conf', target='/tmp/recursor.conf')
            self.remote.check_call('mv /tmp/recursor.conf /etc/powerdns/', verbose=self.verbose)

    def configure_recursor(self, zones, upstream_nameserver):
        recursor_version = self.remote.check_call(
            "pdns_recursor --version | grep 'PowerDNS Recursor' | awk '{print $3}'",
            verbose=self.verbose).stdout_str
        is_new_config = version.parse(recursor_version) >= version.parse('5.0.0')
        if is_new_config:
            LOG.info(f"Detected {recursor_version} recursor version. New config style will be used (YAML)")
            self._configure_recursor_new(zones=zones, upstream_nameserver=upstream_nameserver)
        else:
            LOG.info(f"Detected {recursor_version} recursor version. Using old config style")
            self._configure_recursor_old(zones=zones, upstream_nameserver=upstream_nameserver)

    @staticmethod
    def _start_service_cmd(service):
        # 'systemctl start' alone reports only 'the control process exited with error
        # code' and the 'systemctl status' commands below are never reached, so dump the
        # status and the journal right away, otherwise the actual reason is lost
        return (f"systemctl start {service} || "
                f"{{ systemctl status {service} --no-pager -l; "
                f"journalctl -xeu {service} --no-pager | tail -50; false; }}")

    def start_services(self, with_recursor=True):
        start_cmds = [self._start_service_cmd("pdns.service")]
        if with_recursor:
            # The recursor owns port :53 on the node, so it also becomes the resolver
            # of the node itself
            start_cmds += [
                self._start_service_cmd("pdns-recursor.service"),

                'echo "nameserver 127.0.0.1" | tee /etc/resolv.conf',
                f'echo "nameserver {self.listen_address}" >> /etc/resolv.conf',
                "sed -i '/127.0.1.1.*/d' /etc/hosts",
                'echo "127.0.1.1 $(hostname -s)" | tee -a /etc/hosts',
                "systemctl status pdns-recursor.service",
            ]
        start_cmds += [
            "systemctl status pdns.service",
            # ':53' also matches the ':5300' of the authoritative server
            "netstat -lpn|grep :53",
        ]
        for cmd in start_cmds:
            with self.remote.sudo(enforce=True):
                self.remote.check_call(cmd, verbose=self.verbose)

    def install_pdns(self, local_zones=None, upstream_nameserver=settings.DNS_NAMESERVER,
                     use_official_repositories=settings.SEED_PDNS_USE_OFFICIAL_REPOS,
                     server_version=settings.PDNS_VERSION, recursor_version=settings.RECURSOR_VERSION):
        """Install PowerDNS server and recursor on the Seed node

        This turns Seed node into a DNS server which can manage own zones
        or forward requests recursively to upstream DNS

        :param local_zones: list of strings, zone names to forward to the Authoritative server
                            Do not use "local" zone because it is filtered as unsafe
                            in "systemd-resolved" service by default.
                            To check other filtered zones, please run on the node:
                                $ systemd-resolve --status
                                or
                                $ resolvectl nta
                            , and check for "DNSSEC NTA" entries (DNSSEC Negative Trust Anchor)
        :param upstream_nameserver: str, IP of upstream DNS server to forward all other queries
        :param use_official_repositories: bool, whether to use pdns from official repositories or not
        :param server_version: str, version of pdns server. Could be 4.6, 4.7 ... 4.9
        :param recursor_version: str, version of pdns recursor. Could be 4.3, 4.4 ... 5.2
        """

        if use_official_repositories:
            self.prepare_repository(server_version=server_version,
                                    recursor_version=recursor_version)

        LOG.info("Install packages and stop services")
        self.install_actions()
        LOG.info("Configure powerdns Authoritative Server")
        self.configure_server()
        LOG.info("Configure powerdns Recursor")
        self.configure_recursor(zones=local_zones, upstream_nameserver=upstream_nameserver)

        # Disable systemd-resolved
        # Service 'systemd-resolved' occupies port :53 and will conflict with pdns-recursor
        LOG.info("Disabling systemd-resolved because it occupies port :53")
        with self.remote.sudo(enforce=True):
            self.remote.check_call("systemctl disable --now systemd-resolved", verbose=self.verbose)

        LOG.info("Starting powerdns server and recursor")
        self.start_services()

    def install_pdns_authoritative_only(self,
                                        use_official_repositories=settings.SEED_PDNS_USE_OFFICIAL_REPOS,
                                        server_version=settings.PDNS_VERSION,
                                        recursor_version=settings.RECURSOR_VERSION):
        """Install only the PowerDNS Authoritative Server on the Seed node

        The server listens on 127.0.0.1:5300 and port :53 of the node is left alone. This
        is the mode for the virtual and half-virtual baremetal labs, where the seed node
        already runs unbound as the resolver of the lab and owns :53: there the zone is
        served to that resolver as a stub-zone, see 'stub_zone' in
        si_tests/kaas-bm-env/roles/unbound.

        Unlike 'install_pdns' this installs no recursor, hence no 'local_zones' and no
        upstream nameserver: forwarding a zone and resolving everything else is what a
        recursor does, and here both belong to the resolver of the lab.

        :param use_official_repositories: bool, whether to use pdns from official repositories or not
        :param server_version: str, version of pdns server. Could be 4.6, 4.7 ... 4.9
        :param recursor_version: str, version of pdns recursor. Could be 4.3, 4.4 ... 5.2
        """

        if use_official_repositories:
            self.prepare_repository(server_version=server_version,
                                    recursor_version=recursor_version)

        LOG.info("Install packages and stop services")
        self.install_actions(with_recursor=False)
        LOG.info("Configure powerdns Authoritative Server")
        self.configure_server()

        LOG.info("Starting powerdns server, port :53 of the seed node is left to its own resolver")
        self.start_services(with_recursor=False)

    def restart_service(self):
        with self.remote.sudo(enforce=True):
            self.remote.check_call("systemctl restart pdns.service", verbose=True)

    def create_zone(self, zone_name, recreate=True):
        with self.remote.sudo(enforce=True):
            res = self.remote.execute(f"pdnsutil list-zone {zone_name}")
            if res.exit_code == 0:
                if recreate:
                    LOG.info(f"Delete old PDNS zone {zone_name}")
                    self.remote.check_call(f"pdnsutil delete-zone {zone_name}")
                else:
                    LOG.info(f"PDNS zone {zone_name} already exists, zone recreate is disabled, using existing")
                    return

            # Create zone with SOA and NS records
            self.remote.check_call(f"pdnsutil create-zone {zone_name} ns1.{zone_name}")

        # Create A records for the nameserver and zone name
        self.add_record(zone_name, 'ns1', 'A', self.seed_node_ip)
        self.add_record(zone_name, '.', 'A', self.seed_node_ip)

    def add_record(self, zone_name, record_name, record_type, record_content):
        with self.remote.sudo(enforce=True):
            self.remote.check_call(f"pdnsutil add-record {zone_name} {record_name} {record_type} {record_content}")

    def replace_record(self, zone_name, record_name, record_type, record_content, ttl=60):
        """Set the record to exactly one value, replacing whatever it held before

        'add-record' appends, which would leave the previous address of the cluster in
        the rrset on a repeated run and resolve to it half of the time.
        """
        with self.remote.sudo(enforce=True):
            self.remote.check_call(f"pdnsutil replace-rrset {zone_name} {record_name} "
                                   f"{record_type} {ttl} {record_content}")

    def show_zone(self, zone_name):
        with self.remote.sudo(enforce=True):
            self.remote.check_call(f"pdnsutil list-zone {zone_name}", verbose=True)

    def ensure_fqdn_a_record(self, fqdn, ip, recreate_zone=False):
        """Publish an A record for a full FQDN in the seed PowerDNS.

        The FQDN's first label is the record name and the rest is the zone, e.g.
        'api.kaas-mgmt.default.sitest' -> zone 'kaas-mgmt.default.sitest', record
        'api'. The zone must be a subdomain of one of the local zones forwarded by
        the recursor (settings.SEED_PDNS_LOCAL_ZONE, e.g. 'sitest'), so it resolves
        cluster-wide once the cluster DNS points at the seed.

        Used to give a cluster API LoadBalancer VIP a real hostname instead of a
        bare IP: k0s only accepts an FQDN as the API server name, so the API cert
        (default or custom) must be issued for a hostname.

        :param fqdn: full name, e.g. 'api.kaas-mgmt.default.sitest'
        :param ip: the LoadBalancer VIP the name must resolve to
        :param recreate_zone: recreate the zone from scratch (drops existing records)
        :return: the fqdn
        """
        record_name, _, zone = fqdn.partition('.')
        assert record_name and zone, (
            f"FQDN '{fqdn}' must have a record label and a zone part")
        self.create_zone(zone, recreate=recreate_zone)
        self.add_record(zone, record_name, 'A', ip)
        self.restart_service()  # PRODX-50239
        self.show_zone(zone)
        LOG.info(f"PowerDNS A record '{fqdn}' -> {ip} published")
        return fqdn

    def wait_for_resolvable(self, fqdn, ip, tries=12, delay=5):
        """Wait until 'fqdn' returns 'ip' from the nameserver

        The zone being in the database says nothing about the name being served: 'pdnsutil'
        reads SQLite directly and succeeds with a dead pdns_server, and 'systemctl restart'
        returns success as soon as systemd accepts the command.
        """
        # Ask the resolver the cluster nodes were given: where PowerDNS brings no recursor
        # of its own that is the one already running on the lab, handed out through the
        # IPAM subnets, and the seed node address answers nothing
        if settings.IPAM_NAMESERVER:
            resolver = settings.IPAM_NAMESERVER
            port = 53
        elif self.remote.execute("systemctl is-active --quiet pdns-recursor").exit_code == 0:
            resolver = self.listen_address
            port = 53
        else:
            resolver = '127.0.0.1'
            port = 5300
        cmd = f"dig +short +time=3 +tries=1 @{resolver} -p {port} {fqdn} A"
        for attempt in range(1, tries + 1):
            answer = self.remote.execute(cmd).stdout_str.strip()
            if ip in answer.split():
                LOG.info(f"Name '{fqdn}' resolves to '{ip}' through '{resolver}'")
                return
            LOG.warning(f"Attempt {attempt}/{tries}: '{fqdn}' -> '{answer or 'no answer'}', "
                        f"expected '{ip}'")
            time.sleep(delay)
        raise AssertionError(
            f"Name '{fqdn}' does not resolve to '{ip}' through '{resolver}', the resolver "
            f"the cluster nodes use, so they would not be able to reach the API server by "
            f"the certificate name")

    def ensure_app_record(self, cluster, record, ip):
        """Publish a DNS name for the cluster application in the seed node PowerDNS

        The record goes into SEED_PDNS_LOCAL_ZONE and is a single label there. Both matter:
        a name with a zone of its own makes the authoritative server authoritative for that
        zone alone, and the intermediate levels of the forwarded namespace answer REFUSED to
        the 'DS' queries of the resolver, failing the resolution with SERVFAIL; a dotted
        name needs empty non-terminals, which the SQL backends do not maintain.

        The name is derived from the cluster and must not depend on the build: MCC keeps
        'loadBalancerHost' pointing at it, so a per-build name would break the cluster as
        soon as the next build published a different one.

        :param cluster: si_tests.managers.kaas_manager.Cluster object
        :param record: str, record name for the application, i.e. 'mke' or 'k0s'
        :param ip: str, address the name must resolve to
        :rtype str: '<record>-<cluster>-<namespace>.<SEED_PDNS_LOCAL_ZONE>'
        """
        zone_name = settings.SEED_PDNS_LOCAL_ZONE
        record_name = f"{record}-{cluster.name}-{cluster.namespace}"
        fqdn = f"{record_name}.{zone_name}"
        # Keep the zone: it is shared by every cluster of the environment, the management
        # one and the children, and each of them owns a single record in it
        self.create_zone(zone_name, recreate=False)
        LOG.info(f"Creating PDNS record '{fqdn}' with ip '{ip}'")
        self.replace_record(zone_name, record_name, 'A', ip)
        self.restart_service()  # PRODX-50239
        self.show_zone(zone_name)
        self.wait_for_resolvable(fqdn, ip)
        return fqdn


def get_app_cert_hostname(bootstrap: BootstrapManager, cluster, record):
    """Get the hostname to be used as a server name of the application certificate

    With SEED_PDNS_ENABLED a name is published in the seed node PowerDNS and returned
    instead of the load balancer IP address. Such a name is mandatory for k0s, which
    accepts only an FQDN as the API server certificate name, while 'loadBalancerHost'
    is a bare IP on OpenStack and baremetal. Without the flag the load balancer address
    is returned as is, so nothing changes for the environments without PDNS on the seed.

    :param bootstrap: si_tests.managers.bootstrap_manager.BootstrapManager object
    :param cluster: si_tests.managers.kaas_manager.Cluster object
    :param record: str, record name for the application, i.e. 'mke' or 'k0s'
    :rtype tuple: (hostname, ips, dns_names, address), where 'address' is the IP to
                  connect to when checking the served certificate: the DNS name lives
                  in the seed node PDNS only and is not resolvable from the agents
    """
    lb_address = cluster.get_load_balancer_address()

    if not settings.SEED_PDNS_ENABLED:
        LOG.info(f"SEED_PDNS_ENABLED is not set, using the load balancer address "
                 f"'{lb_address}' as the certificate server name")
        if utils.is_valid_ip(lb_address):
            return lb_address, [lb_address], None, lb_address
        return lb_address, None, [lb_address], None

    # 'loadBalancerHost' is flipped to the certificate name once one is applied, so on
    # a repeated apply only 'loadBalancerIP' still holds an address
    lb_ip = cluster.load_balancer_ip
    if not lb_ip:
        assert utils.is_valid_ip(lb_address), (
            f"Cluster '{cluster.namespace}/{cluster.name}' publishes neither "
            f"'loadBalancerIP' nor an IP address in 'loadBalancerHost' ('{lb_address}'), "
            f"unable to determine the address for the DNS record")
        lb_ip = lb_address

    # The address always comes from the cluster: on OpenStack it is a floating IP handed
    # out at deployment time and cannot be declared in advance
    pdns = PDNSManager(bootstrap_manager=bootstrap)
    hostname = pdns.ensure_app_record(cluster=cluster, record=record, ip=lb_ip)

    LOG.info(f"Using DNS name '{hostname}' -> '{lb_ip}' as the certificate server name")
    return hostname, None, [hostname], lb_ip
