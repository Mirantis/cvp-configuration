#    Copyright 2022 Mirantis, Inc.
#
#    Licensed under the Apache License, Version 2.0 (the "License"); you may
#    not use this file except in compliance with the License. You may obtain
#    a copy of the License at
#
#         http://www.apache.org/licenses/LICENSE-2.0
#
#    Unless required by applicable law or agreed to in writing, software
#    distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
#    WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
#    License for the specific language governing permissions and limitations
import csv
import io

from exec_helpers import exec_result, ExecHelperTimeoutError
from retry import retry
from urllib.parse import urlparse

from si_tests import logger, settings
from si_tests.managers.openstack_manager import OpenStackManager
from si_tests.managers.bootstrap_manager import BootstrapManager
from si_tests.utils import waiters, utils

LOG = logger.logger

# workaround to use curl on offline mode
CURL_CMD = "curl --noproxy '*' "


class LoadToolsException(Exception):

    def __init__(self, message: str, result: exec_result.ExecResult):
        msg = f"\n{message}\nCommand: {result.cmd}\nFailed with error:\n{result.stderr_str}"
        super().__init__(msg)


class LoadToolsManager:

    def __init__(self, bootstrap_manager: BootstrapManager, os_manager: OpenStackManager,
                 refapp_address: str, verbose: bool = False):
        self.__verbose = verbose
        self.__loadtools_url = None
        self.__container_name = None
        self.bootstrap_manager = bootstrap_manager
        self.os_manager = os_manager
        self.remote = bootstrap_manager.remote_seed()
        self.remote.sudo_mode = True
        self.refapp_url = refapp_address

    @property
    def refapp_url(self):
        return self.__refapp_url

    @refapp_url.setter
    def refapp_url(self, address: str):
        self.__refapp_url = "http://" + address if not address.startswith("http") else address

    @property
    def default_user_count(self):
        users = 1
        if self.os_manager.is_dns_test_record_present:
            users += 1
        if settings.SI_LOADTOOLS_CHECK_KEYSTONE_WORKLOAD:
            users += 1
        return users

    def get_dns_config(self):
        if not self.os_manager.is_dns_test_record_present:
            return (None, None)
        nameserver = self.os_manager.get_powerdns_svc_ip()
        test_record = "test-record.test-zone.test"
        return (nameserver, test_record)

    @property
    def loadtools_url(self):
        return self.__loadtools_url

    @loadtools_url.setter
    def loadtools_url(self, address: str, port="8089"):
        address = address if not address.endswith("/") else address[:-1]
        url_scheme = "http://" + address if not address.startswith("http") else address
        port = f":{port}" if ":" not in address else ""
        self.__loadtools_url = url_scheme + port

    @retry((LoadToolsException, ExecHelperTimeoutError), delay=15, tries=3, logger=LOG)
    def run_loadtools_on_seed_node(self, run_class=None):
        """
        Run loadtools docker container on seed node
        Args:
            run_class: loadtools app test class to execute
                       Details: https://gerrit.mcp.mirantis.com/plugins/gitiles/kaas/si-loadtools#writing-a-locustfile

        Returns: None

        """
        LOG.info("Start loadtools docker container on seed node")

        self.__container_name = 'kaas-si-loadtools-' + utils.gen_random_string(4)
        dns_server, dns_record = self.get_dns_config()

        env_vars = []
        locust_tags = []
        base_docker_cmd = "docker run -d "
        if run_class:
            env_vars.append(f"RUN_CLASS={run_class}")
        if dns_server:
            locust_tags.extend(['dnsquery', 'refapp'])
            env_vars.append(f"DNSQUERY_NAMESERVER={dns_server}")
            env_vars.append(f"DNSQUERY_TEST_RECORD={dns_record}")

        if settings.SI_LOADTOOLS_CHECK_KEYSTONE_WORKLOAD:
            locust_tags.append('keystone')
            endpoint_url = self.os_manager.get_service_endpoint(
                service_name='keystone', interface='public').get('URL', '')
            openstack_ingress = self.os_manager.get_ingress_svc_external_ip()
            hostname = urlparse(endpoint_url).hostname
            host_resolve_option = f"--add-host {hostname}:{openstack_ingress} "
            base_docker_cmd += host_resolve_option

        if locust_tags:
            # To get expected format like '[dnsquery,refapp,openstack]'
            locust_tags_str = f"\'[{','.join(locust_tags)}]\'"
            env_vars.append(f"LOCUST_TAGS={locust_tags_str}")

        env_var = ' -e '.join(env_vars)
        if env_var:
            env_var = f"-e {env_var}"

        cmd = base_docker_cmd + "--name {} {} {} ".format(self.__container_name, env_var,
                                                          settings.SI_LOADTOOLS_DOCKER_IMAGE_URL)
        docker_result = self.remote.execute(verbose=self.__verbose, command=cmd, timeout=300)
        if docker_result.exit_code != 0:
            raise LoadToolsException("Error while starting docker container on seed node", docker_result)

        docker_host_cmd = "docker inspect -f '{{range.NetworkSettings.Networks}}{{.IPAddress}}{{end}}' " \
                          f"{self.__container_name}"
        docker_host = self.remote.execute(verbose=self.__verbose, command=docker_host_cmd, timeout=180)
        if docker_host.exit_code != 0:
            raise LoadToolsException("Error while docker inspecting", docker_host)

        self.loadtools_url = docker_host.stdout_str

        def _wait_loadtools_init():
            cmd_healthcheck = CURL_CMD + "--request GET '{}'".format(self.loadtools_url)
            healthcheck_result = self.remote.execute(verbose=self.__verbose, command=cmd_healthcheck, timeout=180)
            return healthcheck_result.exit_code == 0

        LOG.info(f"Wait init loadtools container: {self.__container_name}")
        waiters.wait(lambda: _wait_loadtools_init(), interval=10, timeout=300)

        LOG.info(f"Loadtools container host: {self.loadtools_url}")

    @retry((LoadToolsException, ExecHelperTimeoutError), delay=15, tries=3, logger=LOG)
    def start_swarm(self, user_count=None, spawn_rate=1):
        """
        Start swarm
        Args:
            user_count: Peak number of concurrent users, should be at least
                        the same number as number of applications that we test.
                        if not set autodetect.
            spawn_rate: Rate to spawn users at (users per second)

        Returns: None

        """
        LOG.info("Start swarm")
        user_count = user_count or self.default_user_count
        LOG.info(f"Target host: {self.refapp_url} user count: {user_count} spawn rate: {spawn_rate}")
        cmd = CURL_CMD + "--request POST '{}/swarm' --header 'accept: */*' " \
                         "--form 'user_count=\"{}\"' " \
                         "--form 'spawn_rate=\"{}\"' " \
                         "--form 'host=\"{}\"'".format(self.loadtools_url, user_count, spawn_rate, self.refapp_url)

        if settings.SI_LOADTOOLS_CHECK_KEYSTONE_WORKLOAD:
            identity_username = settings.SI_LOADTOOLS_OS_ADMIN_USERNAME
            identity_password = settings.SI_LOADTOOLS_OS_ADMIN_PASSWORD
            self.os_manager.create_openstack_admin_user(username=identity_username, password=identity_password)
            endpoint_url = self.os_manager.get_service_endpoint(
                service_name='keystone', interface='public').get('URL', '') + 'v3'
            cmd += (f" --form 'os_username=\"{identity_username}\"' "
                    f"--form 'os_password=\"{identity_password}\"' "
                    f"--form 'os_auth_url=\"{endpoint_url}\"' ")

        result = self.remote.execute(verbose=self.__verbose, command=cmd, timeout=180)
        if result.exit_code != 0:
            raise LoadToolsException("Error while starting swarm", result)

    @retry((LoadToolsException, ExecHelperTimeoutError), delay=15, tries=3, logger=LOG)
    def stop_swarm(self):
        """
        Stop swarm

        Returns: None

        """
        LOG.info("Stop swarm")
        cmd = CURL_CMD + "--request GET '{}/stop'".format(self.loadtools_url)
        result = self.remote.execute(verbose=self.__verbose, command=cmd, timeout=180)
        if result.exit_code != 0:
            raise LoadToolsException("Error while stopping swarm", result)

    @retry((LoadToolsException, ExecHelperTimeoutError), delay=15, tries=3, logger=LOG)
    def get_full_history(self):
        """
        Get swarm full statistics

        Returns: yaml object

        """
        LOG.info("Get statistics")
        cmd = CURL_CMD + "--request GET '{}/stats/requests_full_history/csv'".format(self.loadtools_url)
        result = self.remote.execute(verbose=self.__verbose, command=cmd, timeout=600)
        if result.exit_code != 0:
            raise LoadToolsException("Error while receiving custom statistics", result)
        csv_reader = csv.DictReader(io.StringIO(result.stdout_str))
        data = [row for row in csv_reader]
        return data

    @retry((LoadToolsException, ExecHelperTimeoutError), delay=15, tries=3, logger=LOG)
    def save_docker_logs(self, file_name):
        """
        Get logs from the loadtools docker container and save to artifacts

        Returns: None

        """
        LOG.info("Save logs from loadtools docker container on seed node")
        logs_cmd = f"docker logs {self.__container_name} 2>&1"
        logs_str = self.remote.execute(verbose=self.__verbose, command=logs_cmd, timeout=600).stdout_str
        with open(f"{settings.ARTIFACTS_DIR}/{file_name}", 'w') as f:
            f.write(logs_str)

    @retry((LoadToolsException, ExecHelperTimeoutError), delay=15, tries=3, logger=LOG)
    def exit(self):
        """
        Shutdown container and waiting for it to disappear on seed node

        Returns: None

        """
        LOG.info("Stop loadtools docker container on seed node")
        cmd = CURL_CMD + "--request GET '{}/exit'".format(self.loadtools_url)
        result = self.remote.execute(verbose=self.__verbose, command=cmd, timeout=300)
        if result.exit_code != 0:
            raise LoadToolsException("Error while shutting down", result)

        def _is_container_delete():
            ps_cmd = "docker ps --format '{{json .Names}}'"
            existing_containers = self.remote.execute(verbose=self.__verbose, command=ps_cmd, timeout=180).stdout_str
            LOG.info(f"Existing containers: {existing_containers}")
            return self.__container_name not in existing_containers

        LOG.info(f"Wait until container '{self.__container_name}' to be removed")
        waiters.wait(_is_container_delete,
                     interval=10,
                     timeout_msg=f"Docker container {self.__container_name} delete timeout")

    @retry((LoadToolsException, ExecHelperTimeoutError), delay=15, tries=3, logger=LOG)
    def receive_report(self, file_name='locust_report.html'):
        """
        Receive swarm report in HTML format
        Args:
            file_name: the report file name to store in artifacts

        Returns: None

        """
        LOG.info("Get load html report")
        cmd = CURL_CMD + "--request GET '{}/stats/report?download=1'".format(self.loadtools_url)
        result = self.remote.execute(verbose=self.__verbose, command=cmd, timeout=300)
        if result.exit_code != 0:
            raise LoadToolsException("Error while receiving report", result)
        with open(f"{settings.ARTIFACTS_DIR}/{file_name}", 'w') as f:
            f.write(result.stdout_str)

    @retry((LoadToolsException, ExecHelperTimeoutError), delay=15, tries=3, logger=LOG)
    def run_smoke(self):
        """
        Simple curl call to RefApp to verify is it accessible from host and alive

        Returns: None

        """
        LOG.info("Smoke call to RefApp to verify is it accessible and alive")
        cmd = CURL_CMD + '--request GET -s -o /dev/null -I -w "%{http_code}" ' + self.refapp_url
        result = self.remote.execute(verbose=self.__verbose, command=cmd, timeout=60)
        if result.exit_code != 0:
            raise LoadToolsException("Error while receiving response", result)
        elif result.stdout_str != "200":
            raise LoadToolsException(f"Status code '{result.stdout_str}' not as expected '200'. Smoke test failed",
                                     result)
