# Known Issues

The article describes known issues with MOSK and Equinix provider.

- [PRODX-29296]: Do not use c3.medium.x86. Issue with ipxe binary provided by BM team