Reserved top-level keys for SI scenarios, which will be available in si-config.yaml:

    management_cluster_params: Jenkins parameters dict for management cluster
    region_cluster_params: list of Jenkins parameters dicts for region clusters
    child_cluster_params: list of Jenkins parameters dicts for child clusters

Reserved Jenkins parameter names:

    CLUSTER_NAME: name of the creating management cluster

    REGIONAL_CLUSTER_NAME: name of the creating regional cluster

    KAAS_CHILD_CLUSTER_NAME: name of the creating child cluster
    KAAS_NAMESPACE: namespace of the creating child cluster

    EQUINIXMETALV2_REGION: name of the MCC region to deploy regional/child clusters. Default: 'region-one'

    EQUINIXMETALV2_MGMT_METRO: for network config generation in multimetro case only
                               (management cluster in one metro, child cluster in another metro, no region cluster)
                               If True - child cluster will be configured to deploy in the same metro as management cluster.
                               If False - child cluster will be configured in any other metro which don't have own region cluster.
