# Bootstrap MKE clusters on OpenStack

This directory provides an example flow with Mirantis Launchpad together with Terraform and OpenStack.

## Prerequisites

* You need an account and credentials for an OpenStack Tenant.
* Terraform [installed](https://learn.hashicorp.com/terraform/getting-started/install)

## Steps

1. `terraform init`
2`terraform apply`
3`terraform output mke_cluster | launchpad apply --config -`

## Related topics

Configure [OpenStack Cloud Provider](https://github.com/kubernetes/cloud-provider-openstack/blob/master/docs/getting-started-provider-dev.md) config

Based on https://docs.mirantis.com/mke/3.5/install/install-aws/aws-prerequisites.html
