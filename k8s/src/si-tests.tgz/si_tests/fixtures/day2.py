import pytest
from si_tests import logger
from si_tests import settings
from si_tests.utils import waiters

LOG = logger.logger


@pytest.fixture(scope='module')
def cleanup_hoc_and_machine_labels(kaas_manager, request):
    """Delete HostOSConfiguration object and machine labels before or after test starts"""
    # Run on tear-down (after test execution)
    if request.param != 'run_on_setup':
        yield
    cluster_name = settings.TARGET_CLUSTER
    namespace_name = settings.TARGET_NAMESPACE
    ns = kaas_manager.get_namespace(namespace_name)
    cluster = ns.get_cluster(cluster_name)

    if ns.hostosconfiguration_is_present(name=settings.HOC_CPUSHIELD_TEST_HOC_NAME):
        delete_timeout = 600
        delete_interval = 10

        existing_config = ns.get_hostosconfiguration(name=settings.HOC_CPUSHIELD_TEST_HOC_NAME)
        LOG.info(f"Deleting HostOSConfiguration '{existing_config.name}'")
        existing_config.delete(async_req=True)
        timeout_msg = (f"HostOSConfiguration {settings.HOC_CPUSHIELD_TEST_HOC_NAME} "
                       f"was not deleted in {delete_timeout}s")
        waiters.wait(lambda: not bool(ns.hostosconfiguration_is_present(name=settings.HOC_CPUSHIELD_TEST_HOC_NAME)),
                     timeout=delete_timeout,
                     interval=delete_interval,
                     timeout_msg=timeout_msg)

    machines = cluster.get_machines()
    for machine in machines:
        machine.remove_machine_labels(list(settings.HOC_CPUSHIELD_REBOOT_LABEL.keys()))
    # Run on setup (prior test execution)
    if request.param == 'run_on_setup':
        yield
