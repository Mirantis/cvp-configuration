import pytest

from si_tests.managers.ipmi_manager import IpmiManager


@pytest.fixture(scope='session')
def ipmi_client():
    return IpmiManager()
