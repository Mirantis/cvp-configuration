#    Copyright 2025 Mirantis, Inc.
#
#    Licensed under the Apache License, Version 2.0 (the "License"); you may
#    not use this file except in compliance with the License. You may obtain
#    a copy of the License at
#
#         http://www.apache.org/licenses/LICENSE-2.0
#
#    Unless required by applicable law or agreed to in writing, software
#    distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
#    WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
#    License for the specific language governing permissions and limitations
#    under the License.

import http

import pytest
import yaml

from kubernetes.client import ApiException

from si_tests import logger
from si_tests import settings
from si_tests.managers.cluster_backups_manager import ClusterBackupManager
from si_tests.utils import templates, mcc_clusterbackup_utils, waiters

LOG = logger.logger


def create_resources(cluster, share_type="s3"):
    cb_manager = ClusterBackupManager(cluster)
    # Create keyencryptionkey for backup encryption
    existed_keks = cb_manager.keyencryptionkeys.list(namespace=cluster.namespace)
    for kek in existed_keks:
        if kek.name == cb_manager.kek_name:
            LOG.info(f"keyencryptionkey with name {cb_manager.kek_name} already existed. "
                     f"Skipping creation")
            break
    else:
        data = yaml.safe_load(templates.render_template(cb_manager.cluster_backup_kek_file_path))
        data['spec']['secret']['value'] = cb_manager.kek_value
        data['metadata']['namespace'] = cluster.namespace
        cb_manager.create_keyencryptionkey(data=data)
    if share_type == "s3":
        existed_rclone = cb_manager.rclonecredentials.list(namespace=cluster.namespace)
        for rclone in existed_rclone:
            if rclone.name == cb_manager.rclone_cred_name:
                LOG.info(f"rclone credentials with name {cb_manager.rclone_cred_name} already existed. "
                         f"Skipping creation")
                break
        else:
            data = yaml.safe_load(templates.render_template(
                cb_manager.cluster_backup_rclone_cred_file_path))
            data['spec']['remoteConfig']['access_key_id'] = cb_manager.s3_access_key_id
            data['spec']['remoteSecret']['value'] = cb_manager.s3_access_secret_key
            data['metadata']['namespace'] = cluster.namespace
            cb_manager.create_rclonecredential(data=data)
    LOG.info(f"Configuring cluster {cluster.name} in namespace {cluster.namespace} for backups "
             f"with {share_type} share type.")
    cb_manager.configure_cluster(share_type=share_type)


def wait_deleted(objects_manager, name, namespace, kind, timeout=300, interval=5):
    """Wait until a k8s object is really gone from the API.

    `obj.delete()` only sends the DELETE request and returns. An object that has
    a finalizer (clusterbackup does) stays in the API with a deletionTimestamp
    until its controller releases it, so a LIST right after the delete still
    returns it. Waiting for the actual disappearance keeps the teardown of one
    test from racing with the setup of the next one, which otherwise gets either
    a 404 on delete or an AlreadyExists on create.

    :param objects_manager: resource manager to list objects with,
                            e.g. ClusterBackupManager.clusterbackups
    :param name: name of the object to wait for
    :param namespace: namespace of the object
    :param kind: human readable resource kind, used in log messages only
    :param timeout: raise TimeoutError if the object is still there after
                    this amount of seconds
    :param interval: seconds between checks
    """

    def _is_deleted():
        return not any(obj.name == name
                       for obj in objects_manager.list(namespace=namespace))

    def _status_message():
        return (f"{kind.capitalize()} object with name {name} in namespace "
                f"{namespace} is still present in the API.")

    err_msg = (f"{kind.capitalize()} object with name {name} in namespace {namespace} "
               f"was not deleted in {timeout} sec.")
    LOG.info(f"Waiting for {kind} object {name} to be deleted")
    waiters.wait(_is_deleted,
                 timeout=timeout,
                 interval=interval,
                 status_msg_function=_status_message,
                 timeout_msg=err_msg)


@pytest.fixture(scope="function")
def clusterbackup_cleanup_actions(request, kaas_manager):
    share_type = getattr(request, "param", None)
    cluster_name = settings.TARGET_CLUSTER
    namespace_name = settings.TARGET_NAMESPACE
    ns = kaas_manager.get_namespace(namespace_name)
    target_cluster = ns.get_cluster(cluster_name)
    patch_data = {
        "spec": {
            "providerSpec": {
                "value": {
                    "backup": None
                }
            }
        }
    }

    manager = ClusterBackupManager(target_cluster)

    def delete_by_name(objects_manager, expected_name, kind):
        for obj in objects_manager.list(namespace=target_cluster.namespace):
            if obj.name != expected_name:
                continue
            LOG.info(f"Remove {kind} object with name {expected_name}")
            try:
                obj.delete()
            except ApiException as e:
                if e.status == http.HTTPStatus.NOT_FOUND:
                    LOG.info(f"{kind.capitalize()} object with name {expected_name} is already deleted")
                    return
                if e.body and "used by backups" in e.body and "ucp-backup-" in e.body:
                    LOG.info(f"{kind.capitalize()} object with name {expected_name} is used by auto backups. "
                             f"Will not remove")
                    return
                raise
            wait_deleted(objects_manager, expected_name, target_cluster.namespace, kind)
            return
        LOG.info(f"{kind.capitalize()} object with name {expected_name} is not found. No cleanup required")

    def cleanup():
        LOG.info("Cleanup clusterbackups related resources")

        delete_by_name(manager.clusterbackups, manager.clusterbackup_name, "clusterbackup")

        LOG.info(f"Cleanup cluster {target_cluster.name} spec from backup section")
        target_cluster.patch(patch_data)

        delete_by_name(manager.keyencryptionkeys, manager.kek_name, "keyencryptionkey")

        delete_by_name(manager.rclonecredentials, manager.rclone_cred_name, "rclonecredential")

    def cleanup_s3():
        bucket = manager.s3_bucket_name
        s3 = manager.s3_client
        paginator = s3.get_paginator("list_objects_v2")
        prefix = settings.ENV_NAME + '/'
        for page in paginator.paginate(Bucket=bucket, Prefix=prefix):
            objects = [{"Key": obj["Key"]} for obj in page.get(
                "Contents", []) if obj["Key"] != prefix and "ucp-backup" not in obj["Key"]]

            if objects:
                LOG.info(f"Cleanup next objects from s3 bucket:\n{yaml.dump(objects)}")
                s3.delete_objects(
                    Bucket=bucket,
                    Delete={"Objects": objects}
                )

    cleanup()
    yield
    cleanup()
    if share_type == "s3":
        cleanup_s3()


def _check_backup_files_locally(clusterbackup_manager, target_cluster, files_map):
    files_nodes_map = {}
    for _, value in files_map.items():
        if value:
            node_name, file_name = value.split(":")
            files_nodes_map[file_name] = node_name
    LOG.info(f"Backups nodes<->names map:\n{yaml.dump(files_nodes_map)}")

    mgmt_cluster = target_cluster.get_parent_cluster() if target_cluster.is_child else target_cluster
    node_to_cluster = {node: mgmt_cluster for node in mgmt_cluster.get_k8s_node_names()}
    if target_cluster.is_child:
        node_to_cluster.update({node: target_cluster for node in target_cluster.get_k8s_node_names()})

    for file_name, node_name in files_nodes_map.items():
        cluster = node_to_cluster.get(node_name)
        if cluster is None:
            # A local backup value is "<node>:<file>"; a remote one (S3/NFS) is
            # "<bucket>/<path>:<file>", so node_name is not a cluster node. Such
            # entries are stored remotely, not on a node, and must not be checked
            # as local files (see _check_backup_files_on_remote).
            LOG.info(f"Skipping non-local backup entry for {file_name}: "
                     f"'{node_name}' is not a cluster node (remote storage)")
            continue
        clusterbackup_manager.wait_object_exists_locally(
            file_name=file_name,
            target_node_name=node_name,
            cluster=cluster
        )


def _check_backup_files_on_remote(clusterbackup_manager, files_map, share_type, is_encrypted):
    if share_type == "s3":
        files_names = [f.split(":")[-1] for _, f in files_map.items() if f]
    elif share_type == "nfs":
        files_names = [f.split("/")[-1] for _, f in files_map.items() if f]
    else:
        raise NotImplementedError(f"Unsupported share type {share_type}")

    if is_encrypted:
        files_names += [f.replace('.encrypted', '.dek') for f in files_names]

    clusterbackup_manager.wait_objects_exist_on_remote(files_list=files_names, share_type=share_type)
    LOG.info("All files are existed on remote")

    if share_type == "s3":
        LOG.info("Cleanup s3 bucket")
        for file in files_names:
            key = f"{settings.ENV_NAME}/{file}"
            LOG.info(f"Removing file {key}")
            clusterbackup_manager.s3_client.delete_object(
                Bucket=clusterbackup_manager.s3_bucket_name,
                Key=key
            )


@pytest.fixture(scope="function")
def verify_auto_backups_on_upgrade(kaas_manager):
    """
        1. Configure backup section for cluster before update
        2. Check backup files are existed after update
    """

    if not settings.MCC_CLUSTER_BACKUP_VERIFY_ON_UPGRADE:
        LOG.info("MCC_CLUSTER_BACKUP_VERIFY_ON_UPGRADE parameter is set to False. "
                 "Will skip backups check")
        yield
        return

    cluster_name = settings.TARGET_CLUSTER
    namespace_name = settings.TARGET_NAMESPACE
    ns = kaas_manager.get_namespace(namespace_name)
    target_cluster = ns.get_cluster(cluster_name)
    clusterbackup_manager = ClusterBackupManager(target_cluster)

    is_supported_before = target_cluster.workaround.cluster_supports_backups()
    is_encrypted = settings.MCC_CLUSTER_BACKUP_ENCRYPT_BACKUPS
    share_type = settings.MCC_CLUSTER_BACKUP_SHARE_TYPE_FOR_UPDATE

    if target_cluster.is_management and not is_supported_before:
        LOG.info(f"Auto backups is not supported on cluster version {target_cluster.clusterrelease_version}. "
                 f"Skipping check")
        yield
        return

    # Case 3: supported before update — configure remote resources now so backups land on remote
    if is_supported_before:
        if not share_type:
            LOG.info("Share type is not specified. Will check local file existence on node")
        else:
            create_resources(target_cluster, share_type=share_type)
            if target_cluster.is_child:
                create_resources(target_cluster.get_parent_cluster(), share_type=share_type)
    else:
        # Case 1 or 2: not supported before update — remote resources are not configured,
        # backups during update go to local storage
        LOG.info(f"Auto backups not supported before update for cluster version "
                 f"{target_cluster.clusterrelease_version}. "
                 f"Will check support after update.")
    if target_cluster.lcm_type_is_ucp:
        tag_before = kaas_manager.get_ucp_tag(target_cluster.clusterrelease_version)
    else:
        tag_before = kaas_manager.get_k0s_tag(target_cluster.clusterrelease_version)
    release_before = target_cluster.clusterrelease_actual_version.split('+')[0]
    lcm_type_before = target_cluster.lcm_type
    yield

    is_supported_after = target_cluster.workaround.cluster_supports_backups()
    if target_cluster.lcm_type_is_ucp:
        tag_after = kaas_manager.get_ucp_tag(target_cluster.clusterrelease_version)
    else:
        tag_after = kaas_manager.get_k0s_tag(target_cluster.clusterrelease_version)
    release_after = target_cluster.clusterrelease_actual_version.split('+')[0]
    LOG.info(f"Backup tag after update {tag_after}")
    # Case 1: not supported before or after — skip entirely
    if not is_supported_before and not is_supported_after:
        LOG.info(f"Auto backups not supported before or after update for cluster version "
                 f"{target_cluster.clusterrelease_version}. Skipping check")
        return

    files_map = mcc_clusterbackup_utils.get_clusterbackup_autogenerated_files_names(
        cluster=target_cluster,
        tag_before=tag_before,
        tag_after=tag_after,
        release_before=release_before,
        release_after=release_after,
        lcm_type_before=lcm_type_before)

    # Case 2: not supported before but supported after — check only post-update backup files.
    # Remote resources were not configured before update, so backup went to local storage.
    if not is_supported_before and is_supported_after:
        LOG.info("Auto backups became supported after update. "
                 "Checking only post-update backup files on local storage.")
        after_update_files_map = {k: v for k, v in files_map.items() if '_after_' in k}
        _check_backup_files_locally(clusterbackup_manager, target_cluster, after_update_files_map)
        return

    # Case 3: supported before update — check both pre- and post-update backup files
    if not share_type:
        LOG.info("Backups are stored locally on node. Get node name and backup name")
        _check_backup_files_locally(clusterbackup_manager, target_cluster, files_map)
    elif target_cluster.workaround.prodx_59965() or settings.CHECK_BACKUP_ONLY_LOCALLY:
        # PRODX-59965: on MCC < 2.32.x the pre-update backup is triggered before the freshly
        # configured remote backup section propagates to the backup parameters, so it lands on
        # local node storage instead of the remote share. Only the post-update backup reaches the
        # remote share. Verify the pre-update backup locally and the post-update backup on remote.
        LOG.info("PRODX-59965 workaround (MCC < 2.32.x): pre-update backup is stored locally on "
                 "node, only post-update backup is uploaded to the remote share. Checking "
                 "pre-update backup locally and post-update backup on remote.")
        before_update_files_map = {k: v for k, v in files_map.items() if '_before_' in k}
        after_update_files_map = {k: v for k, v in files_map.items() if '_after_' in k}
        _check_backup_files_locally(clusterbackup_manager, target_cluster, before_update_files_map)
        _check_backup_files_on_remote(clusterbackup_manager, after_update_files_map, share_type, is_encrypted)
    else:
        _check_backup_files_on_remote(clusterbackup_manager, files_map, share_type, is_encrypted)
