#    Copyright 2026 Mirantis, Inc.
#
#    Licensed under the Apache License, Version 2.0 (the "License"); you may
#    not use this file except in compliance with the License. You may obtain
#    a copy of the License at
#
#         http://www.apache.org/licenses/LICENSE-2.0
#
#    Unless required by applicable law or agreed to in writing, software
#    distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
#    WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
#    License for the specific language governing permissions and limitations
#    under the License.

import os

import pytest

from si_tests import logger, settings
from si_tests.utils import waiters, exceptions
from si_tests.utils import packaging_version as version

LOG = logger.logger


def delete_supportdump(kaas_manager, name, namespace):
    """Delete the SupportDump and wait until it disappears."""
    if not kaas_manager.api.mcc_supportdumps.present_all(name=name):
        LOG.info(f"SupportDump object {name} is not present, nothing to clean up")
        return

    sd = kaas_manager.api.mcc_supportdumps.get(name=name, namespace=namespace)
    LOG.info(f"Deleting SupportDump {name}")
    sd.delete(async_req=True)

    deletion_timeout = 300
    deletion_interval = 10
    deletion_timeout_msg = (
        f"Deletion failed, SupportDump with name '{name}' still exists "
        f"after {deletion_timeout} sec"
    )
    waiters.wait(lambda: not bool(kaas_manager.api.mcc_supportdumps.present_all(name=name)),
                 timeout=deletion_timeout,
                 interval=deletion_interval,
                 timeout_msg=deletion_timeout_msg)
    LOG.info(f"SupportDump {name} has been deleted")


def ensure_supportdump_is_not_present(kaas_manager, name, namespace):
    """Remove any leftover SupportDump with this name (e.g. from a previous failed run) before creating a new one."""
    if not kaas_manager.api.mcc_supportdumps.present_all(name=name):
        return
    LOG.warning(f"Found leftover SupportDump '{name}' from a previous run, removing it before creating a new one")
    sd = kaas_manager.api.mcc_supportdumps.get(name=name, namespace=namespace)
    sd.delete(async_req=True)
    try:
        waiters.wait(lambda: not bool(kaas_manager.api.mcc_supportdumps.present_all(name=name)),
                     timeout=300, interval=10,
                     timeout_msg=f"Leftover SupportDump '{name}' did not disappear in 300 sec")
    except exceptions.TimeoutError:
        LOG.warning(f"SupportDump '{name}' stuck (likely finalizer never released by the controller); "
                    f"forcing removal by clearing its finalizers")
        sd.patch({'metadata': {'finalizers': []}})
        waiters.wait(lambda: not bool(kaas_manager.api.mcc_supportdumps.present_all(name=name)), timeout=60, interval=5,
                     timeout_msg=f"SupportDump '{name}' still present after clearing finalizers")


@pytest.fixture(scope="function")
def supportdump_cleanup(kaas_manager):
    """Cleanup of the SupportDump CR created by the test."""

    if version.parse(kaas_manager.get_mgmt_cluster().get_kaasrelease_version()) < version.parse("kaas-2-32-0-rc"):
        pytest.skip(f"SupportDump is not supported on {kaas_manager.get_mgmt_cluster().get_kaasrelease_version()}")

    namespace = settings.TARGET_NAMESPACE
    cluster_name = settings.TARGET_CLUSTER
    name = f"{settings.MCC_SUPPORTDUMP_NAME}-{namespace}-{cluster_name}"
    ensure_supportdump_is_not_present(kaas_manager, name, namespace)

    yield

    if settings.MCC_SUPPORTDUMP_POSTCLEANUP:
        delete_supportdump(kaas_manager, name, namespace)


def _get_supportdump_pod(kaas_manager, sd):
    """Resolve the supportdump-controller pod that collected a given SupportDump.

    supportdump-controller runs with multiple replicas (HA by default), so the pod that
    owns a particular dump is reported per-object via status.podName rather than being
    a fixed, well-known pod name.
    """
    sd_status = sd.data.get('status', {}) or {}
    pod_name = sd_status.get('podName')
    assert pod_name, f"SupportDump status has no podName: {sd_status}"
    pod = kaas_manager.api.pods.get(name=pod_name, namespace='kaas')
    assert pod, f"Support-dump controller pod {pod_name} not found"
    return pod


def check_supportdump_dump_in_pod(kaas_manager, sd, timeout=300, interval=15):
    """
    Wait until the dump path from SupportDump status exists in the controller pod.
    Print dump directory structure.
    """

    pod = _get_supportdump_pod(kaas_manager, sd)

    sd_status = sd.data.get('status', {}) or {}
    path_to_dump_from_status = sd_status.get('fileName')
    assert path_to_dump_from_status, f"SupportDump status has no fileName: {sd_status}"

    LOG.info(f"Wait until support dump exists at {path_to_dump_from_status} in controller pod")

    def _dump_ready():
        listing = pod.exec(
            ['/bin/sh', '-c', f'ls -1td {path_to_dump_from_status} 2>/dev/null || true']).strip()
        if not listing:
            return False
        paths = [line.strip() for line in listing.splitlines() if line.strip()]
        dump_path = paths[0] if paths else None
        if not dump_path:
            LOG.warning(f"No support dump yet at {path_to_dump_from_status}")
            return False
        if not (pod.check_folder_exists(dump_path) or pod.check_file_exists(dump_path)):
            LOG.warning(f"Support dump path {dump_path} is not ready yet")
            return False
        return dump_path

    dump_path = waiters.wait(_dump_ready, timeout=timeout, interval=interval,
                             timeout_msg=f"Support dump {path_to_dump_from_status} was not found "
                                         f"in supportdump-controller pod within {timeout} sec")

    dump_tree = pod.exec(
        ['/bin/sh', '-c', f'du -h -d4 {dump_path} 2>/dev/null || true']).strip()

    LOG.info(f"Support dump found at {dump_path}. Dump structure: \n{dump_tree}")
    return dump_path


def copy_supportdump_from_pod(kaas_manager, sd, dump_path):
    """
          * Get supportdump controller pod that collected this SupportDump
          * If dump path is already a file, copy it to the local artifact directory as is
          * If dump path is a folder:
              * Create archive /tmp/<-supportdump-name->.tar.gz from it
              * Copy /tmp/<-supportdump-name->tar.gz from pod to the local artifact directory
              * Delete archive file from pod
    """

    if not settings.MCC_SUPPORTDUMP_COPY_FROM_POD_TO_LOCAL:
        LOG.info("Skip copying dumps from pod to the local, flag MCC_SUPPORTDUMP_COPY_FROM_POD_TO_LOCAL is not set")
        return

    pod = _get_supportdump_pod(kaas_manager, sd)

    dump_name = os.path.basename(dump_path.rstrip('/'))

    if pod.check_file_exists(dump_path):
        LOG.info(f"Support dump {dump_path} is a file, skip archiving and copy it as is")
        pod.cp_from_pod(source_dir=os.path.dirname(dump_path), source_file=dump_name)
        LOG.info(f"Support dump file saved to {dump_name}")
        return dump_name

    assert pod.check_folder_exists(dump_path), f"Support dump path {dump_path} is neither a file nor a folder"

    remote_archive = f"/tmp/{dump_name}.tar.gz"
    remote_archive_dir = os.path.dirname(remote_archive)
    remote_archive_file = os.path.basename(remote_archive)
    local_archive = f"{dump_name}.tar.gz"

    try:
        LOG.info(f"Support dump {dump_path} is a folder, archiving it in pod to {remote_archive}")
        pod.run_exec([
            '/bin/sh', '-c',
            f'tar -czf {remote_archive} {dump_path} && sync',
        ], keepalive_session=True, timeout=1200)

        LOG.info(f"Copy support dump from pod path {remote_archive} to {local_archive}")
        pod.cp_from_pod(source_dir=remote_archive_dir, source_file=remote_archive_file)

        LOG.info(f"Support dump archive saved to {local_archive}")
        return local_archive
    finally:
        pod.run_exec(['/bin/sh', '-c', f'rm -f {remote_archive}'])


def check_systemlogs_filtered_by_machine(kaas_manager, sd, dump_path, included_machines, excluded_machines):
    """Verify a SupportDump's systemLogs collector only gathered data for `included_machines`.

    systemLogs output is laid out as '<targetCluster>/system/<machine-name>/...' inside the dump
    (confirmed against a real dump on lab 1460), so machine names are read from that path segment.
    """
    pod = _get_supportdump_pod(kaas_manager, sd)

    if pod.check_file_exists(dump_path):
        listing = pod.exec(['/bin/sh', '-c', f'tar -tzf {dump_path}']).strip()
    else:
        assert pod.check_folder_exists(dump_path), f"Support dump path {dump_path} is neither a file nor a folder"
        listing = pod.exec(['/bin/sh', '-c', f'find {dump_path} -mindepth 1']).strip()

    entries = [line.strip() for line in listing.splitlines() if line.strip()]
    system_machine_names = {
        entry.split('/system/', 1)[1].split('/', 1)[0]
        for entry in entries if '/system/' in entry
    }

    LOG.info(f"Machines found under systemLogs in the dump: {sorted(system_machine_names)}")
    missing = set(included_machines) - system_machine_names
    assert not missing, (
        f"Expected systemLogs for machine(s) {sorted(included_machines)} in the dump, "
        f"but machine(s) {sorted(missing)} are missing. Found machines: {sorted(system_machine_names)}"
    )
    unexpected = system_machine_names & set(excluded_machines)
    assert not unexpected, (
        f"SystemLogs collector was filtered to machine(s) {sorted(included_machines)}, but the dump also "
        f"contains logs for unexpected machine(s): {sorted(unexpected)}"
    )


@pytest.fixture(scope="function")
def supportdump_copy_from_pod(kaas_manager, request, supportdump_cleanup):
    """Copy the collected SupportDump from the controller pod to artifacts, only if the test passed.

    Runs as teardown so it happens after the test's own verification but before supportdump_cleanup
    removes the SupportDump CR.
    """
    yield
    rep_call = getattr(request.node, "rep_call", None)
    if not rep_call or not rep_call.passed:
        LOG.info("Skip copying supportdump from pod due to test is not Passed")
        return

    namespace = settings.TARGET_NAMESPACE
    cluster_name = settings.TARGET_CLUSTER
    sd_name = f"{settings.MCC_SUPPORTDUMP_NAME}-{namespace}-{cluster_name}"
    sd = kaas_manager.api.mcc_supportdumps.get(name=sd_name, namespace=namespace)
    dump_path = check_supportdump_dump_in_pod(kaas_manager, sd)
    copy_supportdump_from_pod(kaas_manager, sd, dump_path)
