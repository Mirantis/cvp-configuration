import pytest

from si_tests.managers.aws_manager import AwsManager
from si_tests import settings


@pytest.fixture(scope='session')
def aws_ec2_client():
    return AwsManager(aws_access_key_id=settings.AWS_ACCESS_KEY_ID,
                      aws_secret_access_key=settings.AWS_SECRET_ACCESS_KEY,
                      region_name=settings.AWS_DEFAULT_REGION)
