#    Copyright 2024 Mirantis, Inc.
#
#    Licensed under the Apache License, Version 2.0 (the "License"); you may
#    not use this file except in compliance with the License. You may obtain
#    a copy of the License at
#
#         http://www.apache.org/licenses/LICENSE-2.0
#
#    Unless required by applicable law or agreed to in writing, software
#    distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
#    WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
#    License for the specific language governing permissions and limitations

import pytest

from si_tests import logger, settings
from si_tests.deployments.mcc_deploy.restart_daemonset import RestartChecker

LOG = logger.logger


@pytest.fixture(scope='function')
def runtime_restart_checker(target_cluster):
    """Create simple daemonset workload and hold it during cluster upgrade. Check logs after."""
    if not settings.KAAS_RESTART_CHECKER_ENABLED:
        LOG.info('MCC restart checker not enabled. Daemonset will not be deployed.'
                 'To enable - set KAAS_RESTART_CHECKER_ENABLED to True.')
        yield
        return

    checker = RestartChecker(target_cluster)
    LOG.banner('Restart DS: Deploying checker daemonset')
    checker.deploy()
    checker.save_timestamps()
    LOG.banner('Restart DS: DS ready')
    yield
    LOG.banner('Restart DS: Check phase')
    LOG.info('Check daemonset timestamp logs to detect restarts')
    new_stamps = checker.get_timestamps()
    LOG.banner('Restart DS: Cleanup phase')
    checker.cleanup()
    assert checker.timestamps == new_stamps, (f"Runtime restart found. DS Timestamps "
                                              f"before update and after are different.\n"
                                              f"Old raw timestamps: {checker.timestamps}\n"
                                              f"New raw timestamps: {new_stamps}")
    LOG.banner('Restart DS: No restarts found. Check finished')
