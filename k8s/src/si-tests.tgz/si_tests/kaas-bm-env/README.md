---

# List of awesome modificators, which change ansible logic in madness way
# I hope some day, we document them..
deployment_modes:
  - virtual #

KaaS epoch (kaas_binary_version):
- Add preflight
  >=1.2.0
- Drop HostNetwork
  >=1.3.0
- MultiRegion, release controller moved to mgmt
  >=1.10.0
