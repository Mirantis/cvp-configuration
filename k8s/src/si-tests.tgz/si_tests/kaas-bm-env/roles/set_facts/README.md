Possible opts
-------------

cat bootstrap/ansible_env_override.yaml

---
  KAAS_CORE_REFSPEC: 'refs/changes/83/46983/29'
  BOOTSTRAP_ENV: {}
  ## kubeadm setup aka single aka without KaaS
  KAAS_BM_CHARTS_REPO: https://artifactory.mcp.mirantis.net/artifactory/binary-dev-kaas-local/bm/helm
  KAAS_BM_PUBLIC_API_CHART_URL: https://
  KAAS_BM_PUBLIC_API_CHART_VERSION: 0.1.0-mcp-85
  KAAS_BM_OPERATOR_CHART_URL: https://artifactory.mcp.mirantis.net/artifactory/binary-dev-kaas-local/bm/helm/baremetal-provider-0.1.0-mcp-85.tgz
  KAAS_BM_OPERATOR_CHART_VERSION: 0.1.0-mcp-85
  KAAS_BM_OPERATOR_DOCKER_IMAGE: "docker-dev-virtual.docker.mirantis.net/review/bm/baremetal-operator:cr-49916"
  KAAS_BM_KAAS_IPAM_DOCKER_IMAGE: ""
  KAAS_BM_KAAS_ANSIBLE_TAR_GZ: 'http://'
  KAAS_BM_KAAS_ANSIBLE_TAR_GZ_MD5: 'http://'
  KAAS_BM_IRONIC_OPERATOR_DOCKER_IMAGE: "docker-dev-local.docker.mirantis.net/review/bm/ironic-operator:cr-67797"
