dump-configuration dumps content of `generated_configuration` variable to
`~/.ansible_state/l2layout/generated_configuration.yaml` file located on
seed node only.

`generate-configuration` role has detailed explanation of this data.
