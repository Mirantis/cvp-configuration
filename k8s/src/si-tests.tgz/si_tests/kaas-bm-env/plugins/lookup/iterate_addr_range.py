from ansible.plugins.lookup import LookupBase
from ansible.errors import AnsibleError
import ipaddress

DOCUMENTATION = """
    name: iterate_addr_range
    author: dev@mirantis.com
    short_description: return list from ip-range
    description:
      - The 'iterate_addr_range'
"""

EXAMPLES = """
ansible localhost -m debug -a "msg={{ lookup('iterate_addr_range', '10.0.0.100,10.0.0.120,255.255.252.0') }}" -v
"""

RETURN = """
  _list:
    description: todo
    type: list
    elements: raw
"""


class LookupModule(LookupBase):
    """ Custom module, to correctly get list of ip from
    10.0.0.100,10.0.0.200,255.255.252.0
    start-ip,end-ip,mask
    """

    def run(self, terms, variables=None, **kwargs):
        try:
            start_ip, end_ip, netmask = terms[0].split(',')

            start = ipaddress.IPv4Address(start_ip.strip())
            end = ipaddress.IPv4Address(end_ip.strip())
            net = ipaddress.IPv4Network(f"{start_ip}/{netmask.strip()}", strict=False)
            result = []
            for ip_addr in list(net):
                if ip_addr <= end and ip_addr >= start:
                    result.append(str(ip_addr))
            return result

        except Exception as e:
            raise AnsibleError(f"Failed to parse IP range: {e}")
