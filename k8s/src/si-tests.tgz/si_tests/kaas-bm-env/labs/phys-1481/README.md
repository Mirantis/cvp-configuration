https://mirantis.jira.com/wiki/spaces/NG/pages/5084545108/phys-1481+Frankenstein
