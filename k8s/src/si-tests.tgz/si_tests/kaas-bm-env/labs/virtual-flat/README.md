https://mirantis.jira.com/wiki/spaces/NG/pages/6277202006/virtual-flat
