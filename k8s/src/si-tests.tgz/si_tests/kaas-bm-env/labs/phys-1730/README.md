https://mirantis.jira.com/wiki/spaces/NG/pages/6247710721/phys-1730-scale-lab
