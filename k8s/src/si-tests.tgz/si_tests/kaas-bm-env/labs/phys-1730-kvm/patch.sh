#!/usr/bin/env bash

echo 'set_power'
#phys-1730	KaaS Management cluster
#	Managed cluster - control plane
#	Managed cluster - worker/storage

declare -A nodes_pw
nodes_pw=(\
[default]='LJN$jG4dmY4Ed@ef' \
)

function set_power(){
  local action="${1:-'chassis power status'}"
  local nset=${2:-'all'}
  declare -A nodes=();
  declare -A nodes_child=();
  declare -A nodes_mgmt=();
  declare -A nodes_kvm=();

  nodes_kvm=(
             [cz1000]='188.124.60.20' \
             [cz1001]='188.124.60.21' \
             [cz1002]='188.124.60.33' \
             [cz1003]='188.124.60.64' \
             [cz1004]='188.124.60.75' \
             [cz1005]='188.124.60.76' \
             [cz1006]='188.124.60.77' \
             [cz1007]='188.124.60.82' \
             [cz1008]='188.124.60.83' \
             [cz1009]='188.124.60.86' \
             [cz1010]='188.124.60.87' \
             [cz1011]='188.124.60.88' \
             [cz1012]='188.124.60.89' \
             [cz1013]='188.124.60.90' \
             [cz1014]='188.124.60.14' \
             [cz1015]='188.124.60.91' \
             [cz1016]='188.124.60.92' \
             [cz1017]='188.124.60.93' \
             [cz1018]='188.124.60.97' \
             [cz1019]='188.124.60.98' \
             )
  nodes_child=(
               [cz1024]='188.124.60.34' \
               [cz1025]='188.124.60.37' \
               [cz1026]='188.124.60.78' \
               [cz1027]='188.124.60.79' \
               [cz1028]='188.124.60.84' \
               [cz1029]='188.124.60.85' \
               [cz1033]='188.124.60.106' \
               [cz1034]='188.124.60.107' \
               [cz1035]='188.124.60.108' \
               [cz1036]='188.124.60.112' \
               [cz1037]='188.124.60.113' \
               [cz1038]='188.124.60.114'
               )

  nodes_mgmt=( [cz1044]='188.124.60.120' [cz1045]='188.124.60.121' \
               [cz1046]='188.124.60.122' )
  # awesome merge event...
  case "$nset" in
      'mgmt')
        for i in ${!nodes_mgmt[@]}; do
            nodes[$i]="${nodes_mgmt[$i]}"
        done
      ;;
      'child')
        for i in ${!nodes_child[@]}; do
            nodes[$i]="${nodes_child[$i]}"
        done
      ;;
      'kvm')
        for i in ${!nodes_kvm[@]}; do
            nodes[$i]="${nodes_kvm[$i]}"
        done
      ;;
      'all_with_kvm')
        for i in ${!nodes_kvm[@]}; do
            nodes[$i]="${nodes_kvm[$i]}"
        done
        for i in ${!nodes_child[@]}; do
            nodes[$i]="${nodes_child[$i]}"
        done
        for i in ${!nodes_mgmt[@]}; do
            nodes[$i]="${nodes_mgmt[$i]}"
        done
      ;;
      'all')
        for i in ${!nodes_child[@]}; do
            nodes[$i]="${nodes_child[$i]}"
        done
        for i in ${!nodes_mgmt[@]}; do
            nodes[$i]="${nodes_mgmt[$i]}"
        done
      ;;
  esac

  for i in "${!nodes[@]}"; do
    echo "node: $i"
    if [[ -n "${nodes_pw[$i]+_}" ]]; then
      export IPMITOOL_PASSWORD="${nodes_pw[$i]}"
    else
      export IPMITOOL_PASSWORD="${nodes_pw[default]}"
    fi
    set -xe
    until ipmitool -I lanplus -H ${nodes[$i]} -U engineer -E $action ; do
      echo "$(date): retry.."
    done
    set +xe
  done
 }

