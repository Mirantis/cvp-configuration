cz7798
======

Node name: cz7798
Cluster: Management Cluster
Role: Hypervisor
BMC Address: 5.43.225.111
IPMI Username:
IPMI Password:

LAB VLAN IP: 10.0.10.11/24

RAM: 256 Gb
CPU: E5-2650v4 x1

| Interface | PXE   | MAC               | Device                      | Bus Info         |
|-----------|-------|-------------------|-----------------------------|------------------|
| eno1      | false | 0c:c4:7a:58:43:b2 | 82599ES 10-Gigabit SFI/SFP+ | pci@0000:03:00.0 |
| ens3f1    | false | 0c:c4:7a:58:43:b3 | 82599ES 10-Gigabit SFI/SFP+ | pci@0000:03:00.1 |
| enp9s0f0  | true  | 0c:c4:7a:6c:5a:3c | I350 Gigabit                | pci@0000:09:00.0 |
| enp9s0f1  | true  | 0c:c4:7a:6c:5a:3d | I350 Gigabit                | pci@0000:09:00.1 |

| Device   | Model            | Size         | Serial             | Bus Info     |
|----------|------------------|--------------|--------------------|--------------|
| /dev/sda | INTEL SSDSC2BB08 | 74GiB (80GB) | CVWL424502D0080KGN | scsi@4:0.0.0 |
| /dev/sdb | MICRON           | (2TB)        | 20302955693F       | scsi@5:0.0.0 |


cz7812
======

Node name: cz7812
Cluster: Child Cluster (Control plane)
Role: Hypervisor
BMC Address: 185.8.58.181
IPMI Username:
IPMI Password:

LAB VLAN IP: 10.0.10.12/24

RAM: 256 Gb
CPU: E5-2650v4 x1

| Interface | PXE   | MAC               | Device                      | Bus Info         |
|-----------|-------|-------------------|-----------------------------|------------------|
| eno1      | false | 0c:c4:7a:59:54:9a | 82599ES 10-Gigabit SFI/SFP+ | pci@0000:03:00.0 |
| ens3f1    | false | 0c:c4:7a:59:54:9b | 82599ES 10-Gigabit SFI/SFP+ | pci@0000:03:00.1 |
| enp9s0f0  | true  | 0c:c4:7a:6c:83:52 | I350 Gigabit                | pci@0000:09:00.0 |
| enp9s0f1  | true  | 0c:c4:7a:6c:83:53 | I350 Gigabit                | pci@0000:09:00.1 |

| Device   | Model            | Size         | Serial             | Bus Info     |
|----------|------------------|--------------|--------------------|--------------|
| /dev/sda | INTEL SSDSC2BB08 | 74GiB (80GB) | CVWL411302CL080KGN | scsi@4:0.0.0 |
| /dev/sdb | MICRON           | (2TB)        | 203029556898       | scsi@5:0.0.0 |


cz9051
======

Node name: cz9051
Cluster: child
Role: worker node
BMC Address: 5.43.225.221
IPMI Username:
IPMI Password:

LAB VLAN IP: 10.0.10.13/24

RAM: 256 Gb
CPU: E5-2650v4 x1

| Interface | PXE   | MAC               | Device                      | Bus Info         |
|-----------|-------|-------------------|-----------------------------|------------------|
| eno1      | false | 0c:c4:7a:1e:03:d0 | 82599ES 10-Gigabit SFI/SFP+ | pci@0000:03:00.0 |
| ens3f1    | false | 0c:c4:7a:1e:03:d1 | 82599ES 10-Gigabit SFI/SFP+ | pci@0000:03:00.1 |
| enp9s0f0  | true  | 0c:c4:7a:aa:d5:88 | I350 Gigabit                | pci@0000:09:00.0 |
| enp9s0f1  | true  | 0c:c4:7a:aa:d5:89 | I350 Gigabit                | pci@0000:09:00.1 |

| Device   | Model            | Size         | Serial             | Bus Info     |
|----------|------------------|--------------|--------------------|--------------|
| /dev/sda | INTEL SSDSC2BB08 | 74GiB (80GB) | CVWL431201QN080KGN | scsi@4:0.0.0 |
| /dev/sdb | MICRON           | (2TB)        | 20302955626F       | scsi@5:0.0.0 |


cz9052
======

Node name: cz9052
Cluster: child
Role: worker node
BMC Address: 176.74.219.20
IPMI Username:
IPMI Password:

LAB VLAN IP: 10.0.10.14/24

RAM: 256 Gb
CPU: E5-2650v4 x1

| Interface | PXE   | MAC               | Device                      | Bus Info         |
|-----------|-------|-------------------|-----------------------------|------------------|
| eno1      | false | 0c:c4:7a:1e:3e:ee | 82599ES 10-Gigabit SFI/SFP+ | pci@0000:03:00.0 |
| ens3f1    | false | 0c:c4:7a:1e:3e:ef | 82599ES 10-Gigabit SFI/SFP+ | pci@0000:03:00.1 |
| enp9s0f0  | true  | 0c:c4:7a:aa:d6:de | I350 Gigabit                | pci@0000:09:00.0 |
| enp9s0f1  | true  | 0c:c4:7a:aa:d6:df | I350 Gigabit                | pci@0000:09:00.1 |

| Device   | Model            | Size         | Serial             | Bus Info     |
|----------|------------------|--------------|--------------------|--------------|
| /dev/sda | INTEL SSDSC2BB08 | 74GiB (80GB) | CVWL430401Z2080KGN | scsi@4:0.0.0 |
| /dev/sdb | Samsung SSD 860  | 931GiB (1TB) | S4CSNX0N714409H    | scsi@5:0.0.0 |


cz9054
======

Node name: cz9054
Cluster: child
Role: control node
BMC Address: 5.43.226.58
IPMI Username:
IPMI Password:

LAB VLAN IP: 10.0.10.15/24

RAM: 256 Gb
CPU: E5-2650v4 x1

| Interface | PXE   | MAC               | Device                      | Bus Info         |
|-----------|-------|-------------------|-----------------------------|------------------|
| eno1      | false | 0c:c4:7a:1d:92:da | 82599ES 10-Gigabit SFI/SFP+ | pci@0000:03:00.0 |
| ens3f1    | false | 0c:c4:7a:1d:92:db | 82599ES 10-Gigabit SFI/SFP+ | pci@0000:03:00.1 |
| enp9s0f0  | true  | 0c:c4:7a:aa:d6:90 | I350 Gigabit                | pci@0000:09:00.0 |
| enp9s0f1  | true  | 0c:c4:7a:aa:d6:91 | I350 Gigabit                | pci@0000:09:00.1 |

| Device   | Model            | Size         | Serial             | Bus Info     |
|----------|------------------|--------------|--------------------|--------------|
| /dev/sda | INTEL SSDSC2BB08 | 74GiB (80GB) | CVWL4312011Q080KGN | scsi@4:0.0.0 |
| /dev/sdb | MICRON           | (2TB)        | 20302955683C       | scsi@5:0.0.0 |
