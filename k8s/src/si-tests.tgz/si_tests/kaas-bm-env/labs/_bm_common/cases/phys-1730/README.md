https://mirantis.jira.com/wiki/spaces/NG/pages/6247710721/phys-1730-scale-lab

# Openstack networks:
| ae74a850-97de-4f96-90be-bd94ad87d092 | system-phys-1730                                                               |                                                                            |
| 1636f1ed-06ef-4b03-b4b4-117238cddf0f | system-phys-1731                                                               |                                                                            |
| c5537c80-828b-4152-bd8a-0a85b8ff2401 | system-phys-1737                                                               |                                                                            |
| c8b6ae11-d56c-4550-8c8a-194e26ba7e88 | system-phys-1735                                                               |                                                                            |

# hot stack data
openstack subnet create system-phys-1730-subnet1 --network ae74a850-97de-4f96-90be-bd94ad87d092 --no-dhcp --subnet-range 192.0.2.0/24 --allocation-pool start=192.0.2.5,end=192.0.2.10
| id                   | b2b058fd-a666-4196-b2f4-d9028e8955ff |
| name                 | system-phys-1730-subnet1             |
#
openstack subnet create system-phys-1731-subnet1 --network 1636f1ed-06ef-4b03-b4b4-117238cddf0f --no-dhcp --subnet-range 192.0.2.0/24 --allocation-pool start=192.0.2.5,end=192.0.2.10
| id                   | 7162d2d2-c970-428f-ac1e-d858c9d1e9e5 |
| name                 | system-phys-1731-subnet1             |

# IT data:
pxe untag vlan - 1730  - 10.0.0.0/22
  10.0.0.1/22 - phys seed
  10.0.0.5/22 - virtual seed
  10.0.0.7/22 - bootstrap veth
vlan 1731 - 172.16.176.0/22 gw 172.16.176.1
  172.16.176.4/22 - phys seed
  172.16.176.5/22 - virtual seed
vlan 1735 -  10.4.0.0/18
vlan 1737 - 172.16.163.0/25 - no gw?
  172.16.163.1/25 - phys seed


HW Seed node: cz7695
 TenGigabitEthernet 0/22
Description: cz7695:1 (seed)
802.1QTagged: Hybrid
Vlan membership:
Q       Vlans
U       1730
T       1731

Native VlanId:    1730.

TenGigabitEthernet 0/23
Description: cz7695:2 (seed)
802.1QTagged: Hybrid
Vlan membership:
Q       Vlans
U       1
T       1735,1737

Native VlanId:    1.

# Hw seed netplan:

network:
    version: 2
    ethernets:
        eno1:
          link-local: []
        ens3f1:
          link-local: []
    vlans:
        lcm:
            id: 1731
            link: eno1
            link-local: []
            dhcp4: false
            dhcp6: false
            addresses:
            - 172.16.176.4/22
            nameservers:
                addresses:
                - 172.18.176.6
            routes:
            -   to: default
                via: 172.16.176.1
        tenant:
            id: 1735
            link: ens3f1
            link-local: []
            dhcp4: false
            dhcp6: false
            addresses:
            - 10.4.0.1/22
        floating:
            id: 1737
            link: ens3f1
            link-local: []
            dhcp4: false
            dhcp6: false
            addresses:
            - 172.16.163.1/25
            - 10.100.0.1/16
    bridges:
        br-pxe:
            interfaces:
            - eno1
            dhcp4: false
            dhcp6: false
            link-local: []
            addresses:
            - 10.0.0.1/22
#        br-virt:
#            interfaces: []
#            dhcp4: false
#            dhcp6: false
#            link-local: []
#            addresses:
#            - 10.255.255.1/24


