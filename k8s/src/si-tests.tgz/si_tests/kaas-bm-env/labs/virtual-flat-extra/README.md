https://mirantis.jira.com/wiki/spaces/NG/pages/6277202006/virtual-flat
plus more resources in Openstack (larger flavors)
