cz808-child-cluster-storage-worker-efi
======================================

Node name: cz808
Cluster: child
Role: worker node
BMC Address: 176.74.219.187
IPMI Username: engineer
IPMI Password: cWuaU8gRXVKA

| Note                                                                |
|---------------------------------------------------------------------|
| NVME disk has been moved from cz808 to cz809 as part of PRODX-18709 |

| No  | Device         | Size           |
|-----|----------------|----------------|
| 1   | /dev/sda       | 120034123776   |
| 2   | /dev/sdb       | 800166076416   |
| 3   | /dev/sdc       | 2000398934016  |
| 4   | /dev/sdd       | 2000398934016  |
| 5   | /dev/sde       | 2000398934016  |
| 6   | /dev/sdf       | 2000398934016  |

| Interface | PXE   | MAC               |
|-----------|-------|-------------------|
| eno1      | true  | 0c:c4:7a:bd:0e:9a |
| eno2      | false | 0c:c4:7a:bd:0e:9b |
| ens7f0    | false | 0c:c4:7a:8e:7d:4a |
| ens7f1    | false | 0c:c4:7a:8e:7d:4b |


cz809-child-cluster-storage-worker-efi
======================================

Node name: cz809
Cluster: child
Role: worker node
BMC Address: 176.74.219.189
IPMI Username: engineer
IPMI Password: cWuaU8gRXVKA

| Note                                                                |
|---------------------------------------------------------------------|
| NVME disk has been moved from cz808 to cz809 as part of PRODX-18709 |

| No  | Device       | Size          |
|-----|--------------|---------------|
| 1   | /dev/sda     | 120034123776  |
| 2   | /dev/sdb     | 800166076416  |
| 3   | /dev/sdc     | 2000398934016 |
| 4   | /dev/sdd     | 2000398934016 |
| 5   | /dev/sde     | 2000398934016 |
| 6   | /dev/sdf     | 2000398934016 |
| 7   | /dev/nvme0n1 | 800166076416  |
| 8   | /dev/nvme1n1 | 800166076416  |

| Interface | PXE   | MAC               |
|-----------|-------|-------------------|
| eno1      | true  | 0c:c4:7a:bc:fc:b4 |
| eno2      | false | 0c:c4:7a:bc:fc:b5 |
| ens1f0    | false | 0c:c4:7a:8e:7d:5e |
| ens1f1    | false | 0c:c4:7a:8e:7d:5f |


cz810-child-cluster-storage-worker-efi
======================================

Node name: cz810
Cluster: child
Role: worker node
BMC Address: 176.74.219.190
IPMI Username: engineer
IPMI Password: cWuaU8gRXVKA

| No  | Device       | Size           |
|-----|--------------|----------------|
| 1   | /dev/sda     | 120034123776   |
| 2   | /dev/sdb     | 800166076416   |
| 3   | /dev/sdc     | 2000398934016  |
| 4   | /dev/sdd     | 2000398934016  |
| 5   | /dev/sde     | 2000398934016  |
| 6   | /dev/sdf     | 2000398934016  |
| 7   | /dev/nvme0n1 | 800166076416   |

| Interface | PXE   | MAC               |
|-----------|-------|-------------------|
| eno1      | true  | 0c:c4:7a:bc:fa:96 |
| eno2      | false | 0c:c4:7a:bc:fa:97 |
| ens7f0    | false | 0c:c4:7a:8e:7c:c4 |
| ens7f1    | false | 0c:c4:7a:8e:7c:c5 |


cz811-child-cluster-storage-worker-efi
======================================

Node name: cz811
Cluster: child
Role: worker node
BMC Address: 176.74.219.207
IPMI Username: engineer
IPMI Password: cWuaU8gRXVKA

| No  | Device       | Size          |
|-----|--------------|---------------|
| 1   | /dev/sda     | 120034123776  |
| 2   | /dev/sdb     | 800166076416  |
| 3   | /dev/sdc     | 2000398934016 |
| 4   | /dev/sdd     | 2000398934016 |
| 5   | /dev/sde     | 2000398934016 |
| 6   | /dev/sdf     | 800166076416  |

| Interface | PXE   | MAC               |
|-----------|-------|-------------------|
| eno1      | true  | 0c:c4:7a:bc:1b:b0 |
| eno2      | false | 0c:c4:7a:bc:1b:b1 |
| ens1f0    | false | 0c:c4:7a:8e:7c:fa |
| ens1f1    | false | 0c:c4:7a:8e:7c:fb |


cz7788-child-cluster-controlplane-efi
=====================================

Node name: cz7788
Cluster: child
Role: control node
BMC Address: 5.43.225.124
IPMI Username: engineer
IPMI Password: PM3dqFFwe3fe

| No  | Device    | Size          |
|-----|-----------|---------------|
| 1   | /dev/sda  | 500107862016  |
| 2   | /dev/sdb  | 500107862016  |
| 3   | /dev/sdc  | 2000398934016 |
| 4   | /dev/sdd  | 2000398934016 |

| Interface | PXE   | MAC               |
|-----------|-------|-------------------|
| eno1      | true  | 0c:c4:7a:6c:69:a8 |
| eno2      | false | 0c:c4:7a:6c:69:a9 |
| ens1f0    | false | 0c:c4:7a:1f:7d:c2 |
| ens1f1    | false | 0c:c4:7a:1f:7d:c3 |


cz10147-child-cluster-controlplane-efi
======================================

Node name: cz10147
Cluster: child
Role: control node
BMC Address: 5.43.229.155
IPMI Username: engineer
IPMI Password: PM3dqFFwe3fe

| No  | Device       | Size          |
|-----|--------------|---------------|
| 1   | /dev/sda     | 500107862016  |
| 2   | /dev/sdb     | 500107862016  |
| 3   | /dev/sdc     | 2000398934016 |
| 4   | /dev/sdd     | 2000398934016 |

| Interface | PXE   | MAC               |
|-----------|-------|-------------------|
| eno1      | true  | ac:1f:6b:02:81:1a |
| eno2      | false | ac:1f:6b:02:81:1b |
| ens1f0    | false | 00:25:90:33:d5:ac |
| ens1f1    | false | 00:25:90:33:d5:ad |


cz10148-child-cluster-controlplane-efi
======================================

Node name: cz10148
Cluster: child
Role: control node
BMC Address: 5.43.229.156
IPMI Username: engineer
IPMI Password: PM3dqFFwe3fe

| No  | Device   | Size          |
|-----|----------|---------------|
| 1   | /dev/sda | 500107862016  |
| 2   | /dev/sdb | 500107862016  |
| 3   | /dev/sdc | 2000398934016 |
| 4   | /dev/sdd | 2000398934016 |

| Interface | PXE   | MAC               |
|-----------|-------|-------------------|
| eno1      | true  | ac:1f:6b:02:82:02 |
| eno2      | false | ac:1f:6b:02:82:03 |
| ens1f0    | false | 0c:c4:7a:1e:aa:8e |
| ens1f1    | false | 0c:c4:7a:1e:aa:8f |


cz10149
=======

Node name: cz10149
Cluster: management
Role: control node
BMC Address: 5.43.229.157
IPMI Username: engineer
IPMI Password: PM3dqFFwe3fe


cz10150
=======

Node name: cz10150
Cluster: management
Role: control node
BMC Address: 5.43.229.158
IPMI Username: engineer
IPMI Password: PM3dqFFwe3fe


cz10151
=======

Node name: cz10151
Cluster: management
Role: control node
BMC Address: 5.43.229.159
IPMI Username: engineer
IPMI Password: PM3dqFFwe3fe
