```shell
alias birdctl='function f(){ local n=$1; shift; sudo birdc -s /var/run/bird/$n.ctl $@; }; f'
```

https://mirantis.jira.com/wiki/spaces/NG/pages/5085429782/phys-429
