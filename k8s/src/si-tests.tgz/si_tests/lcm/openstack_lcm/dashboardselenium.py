def get_run_command(*args):
    return 'pytest /opt/horizon/openstack_dashboard/test/integration_tests ' \
           '--ds=openstack_dashboard.test.settings -v ' \
           '--junitxml="/opt/horizon/test_reports/integration_test_' \
           'results.xml" --html="/opt/horizon/test_reports/integration_test_' \
           'results.html" --self-contained-html || true'
