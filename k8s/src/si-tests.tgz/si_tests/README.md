# SI global labels, for test-function-search:

Labels must be stored example in object itself

bmh + machine:
For test case, must be configured in both objects
"si-role/node-for-delete": "true"
"si-roles/child-scale-controller" : "true"

Bmhp extra labels:
# def check_bmhp_mapping
"si-test/test-bmhp-mapping{DISKXX}": "{method}-si-separator-{value}-si-separator-{PARTLABEL}"
'si-test/test-bmhp-mapping-DISK0': 'wwn-si-separator-0x5002538d409aeeb4-si-separator-lvm_root_part'
