# Copyright 2026 Mirantis, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License"); you may
# not use this file except in compliance with the License. You may obtain
# a copy of the License at
#
#      http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
# WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
# License for the specific language governing permissions and limitations
# under the License.
import pytest
from exec_helpers import ExecHelperTimeoutError

from si_tests import settings
from si_tests.deployments.utils import commons
from si_tests.managers.clustercheck_mos_manager import ClusterCheckMosManager
from si_tests.tests.ha.test_octavia_amphora_tf_ha import _nodes_of_pods
from si_tests.utils import utils, waiters

LOG = commons.LOG

VROUTER_AGENT = "/usr/bin/contrail-vrouter-agent"
REBOOT_CMD = 'sudo systemctl reboot'
SHUTDOWN_CMD = 'sudo shutdown -h +1'  # shutdown after 1 minute


@pytest.fixture(scope='module')
def gateway_nodes(os_manager):
    """Gateway computes (openstack-gateway=enabled + tfvrouter=enabled)."""
    nodes = [n.name for n in os_manager.tf_manager.get_vgw_nodes()]
    LOG.info(f"Discovered gateway computes: {nodes}")
    if len(nodes) < 2:
        pytest.skip("PRODX-61681 node-level HA requires at least 2 "
                    f"openstack-gateway computes, found {len(nodes)}: {nodes}")
    return nodes


def _create_probe_lb(request, openstack_client_manager):
    """Create an amphorav2 LB and confirm it is ONLINE + functional."""
    stack = ClusterCheckMosManager.created_stack_tf_lb(
        request, openstack_client_manager,
        custom_params={"lb_provider": "amphorav2"})
    lb = {
        "id": ClusterCheckMosManager.get_stack_output(stack, 'lb_id'),
        "url": ClusterCheckMosManager.get_stack_output(stack, 'lb_url'),
        "net": ClusterCheckMosManager.get_stack_output(stack, 'network_name'),
    }
    ClusterCheckMosManager.wait_lb_online(openstack_client_manager, lb["id"])
    assert ClusterCheckMosManager.is_lb_functional(
        openstack_client_manager, 2, lb["url"])
    return lb


def _process_pids(ssh, name):
    result = ssh.execute(f"pgrep -fa {name}")
    return sorted(line.split()[0] for line in result.stdout_str.splitlines()
                  if line.strip())


def _gateway_machines(kaas_manager):
    """Return (cluster, [gateway machines]) from the management cluster."""
    ns = kaas_manager.get_namespace(settings.TARGET_NAMESPACE)
    cluster = ns.get_cluster(settings.TARGET_CLUSTER)
    gw_label = {'key': 'openstack-gateway', 'value': 'enabled'}
    machines = [m for m in cluster.get_machines()
                if m.has_nodelabels([gw_label])]
    return cluster, machines


def _wait_gateway_recovered(os_manager, node):
    """Wait until a gateway compute is Ready and its VGW routing + tf-vrouter
    -vgw pod are back."""
    tf_manager = os_manager.tf_manager
    waiters.wait(
        lambda: os_manager.api.nodes.node_status(node, 'Ready'),
        timeout=1200, interval=30,
        timeout_msg=f"{node} did not return Ready")
    tf_manager.wait_all_pods_on_node(node, timeout=1200)
    waiters.wait(
        lambda: node in _nodes_of_pods(tf_manager.get_vgw_daemonset_pods()),
        timeout=600, interval=20,
        timeout_msg=f"tf-vrouter-vgw not rescheduled on {node}")
    waiters.wait(
        lambda: tf_manager.check_vgw_routing(node),
        timeout=600, interval=20,
        timeout_msg=f"vgw routing not re-provisioned on {node}")


@pytest.mark.usefixtures('skip_by_network_backend')
@pytest.mark.network_backend('tf')
def test_ha_restart_containerd_on_gateway(request, os_manager,
                                          openstack_client_manager,
                                          gateway_nodes, show_step):
    """Restarting containerd on a gateway compute must not disrupt the LB.

    Scenario:
        1. Deploy an amphora LB and confirm ACTIVE/ONLINE + functional.
        2. Restart containerd on a gateway compute.
        3. The node returns Ready, the vRouter agent is NOT restarted and the
           vgw route + SNAT survive.
        4. The LB is still functional.
    """
    tf_manager = os_manager.tf_manager
    show_step(1)
    lb = _create_probe_lb(request, openstack_client_manager)

    node = gateway_nodes[0]
    ssh = utils.ssh_k8s_node(node)
    pids_before = _process_pids(ssh, VROUTER_AGENT)
    LOG.info(f"vRouter agent pids before on {node}: {pids_before}")

    show_step(2)
    ssh.check_call("sudo systemctl restart containerd")

    show_step(3)
    waiters.wait(
        lambda: os_manager.api.nodes.node_status(node, 'Ready'),
        timeout=300, interval=10,
        timeout_msg=f"{node} not Ready after containerd restart")
    tf_manager.wait_all_pods_on_node(node, timeout=600)
    pids_after = _process_pids(ssh, VROUTER_AGENT)
    LOG.info(f"vRouter agent pids after on {node}: {pids_after}")
    assert pids_after == pids_before, (
        f"vRouter agent restarted by containerd restart on {node}: "
        f"{pids_before} -> {pids_after}")
    tf_manager.check_vgw_routing(node)

    show_step(4)
    assert ClusterCheckMosManager.is_lb_functional(
        openstack_client_manager, 2, lb["url"])


@pytest.mark.usefixtures('skip_by_network_backend')
@pytest.mark.network_backend('tf')
def test_ha_gateway_compute_reboot(request, kaas_manager, os_manager,
                                   openstack_client_manager, gateway_nodes,
                                   show_step):
    """Soft reboot of a gateway compute; the LB fully recovers.
    Same mechanics as the MOSK reboot tests (in-guest ``systemctl reboot`` +
    ICMP / k8s node-status transitions), not a REST/IPMI power op.

    Scenario:
        1. Deploy an amphora LB and confirm ACTIVE/ONLINE + functional.
        2. Soft-reboot one gateway compute; it goes NotReady then Ready.
        3. tf-vrouter-vgw + the per-node SNAT are re-provisioned there.
        4. The LB returns to ACTIVE/ONLINE and is functional.
    """
    cluster, machines = _gateway_machines(kaas_manager)
    if not machines:
        pytest.skip("No gateway machines available (management cluster)")
    machine = machines[0]
    node = machine.get_k8s_node_name()
    machine_ip = machine.public_ip

    show_step(1)
    lb = _create_probe_lb(request, openstack_client_manager)

    show_step(2)
    LOG.info(f"Soft-reboot gateway compute {node} (machine {machine.name})")
    try:
        machine.run_cmd(REBOOT_CMD, check_exit_code=False, timeout=10)
    except ExecHelperTimeoutError:
        LOG.debug("SSH connection closed by the reboot, as expected")
    waiters.wait(lambda: not waiters.icmp_ping(machine_ip),
                 interval=5, timeout=1200)
    cluster.check.wait_k8s_node_status(node, expected_status='NotReady',
                                       timeout=900)
    waiters.wait(lambda: waiters.icmp_ping(machine_ip),
                 interval=5, timeout=1800)
    cluster.check.wait_k8s_node_status(node, expected_status='Ready',
                                       timeout=1800)

    show_step(3)
    _wait_gateway_recovered(os_manager, node)

    show_step(4)
    ClusterCheckMosManager.wait_lb_online(openstack_client_manager, lb["id"],
                                          timeout=1200)
    assert ClusterCheckMosManager.is_lb_functional(
        openstack_client_manager, 2, lb["url"])


@pytest.mark.usefixtures('skip_by_network_backend')
@pytest.mark.network_backend('tf')
def test_ha_gateway_compute_shutdown(request, kaas_manager, os_manager,
                                     openstack_client_manager, gateway_nodes,
                                     show_step):
    """Soft shutdown of a gateway compute; the LB survives on the surviving
    gateway and fully recovers when the node is powered back on.
    Same mechanics as the MOSK shutdown tests (in-guest ``shutdown -h`` then
    power-on via the BareMetalHost), not a REST/IPMI power op.

    Scenario:
        1. Deploy an amphora LB, preferring its amphora on the target gateway.
        2. Soft-shut-down that gateway compute; it goes NotReady and the LB
           recovers to ACTIVE/ONLINE + functional on the surviving gateway.
        3. Power the compute back on via its BareMetalHost; it returns Ready
           and tf-vrouter-vgw + SNAT are re-provisioned.
        4. The LB stays ACTIVE/ONLINE and functional.
    """
    cluster, machines = _gateway_machines(kaas_manager)
    if len(machines) < 2:
        pytest.skip("Need >= 2 gateway machines to survive a shutdown")

    show_step(1)
    lb = _create_probe_lb(request, openstack_client_manager)
    amphora_host = ClusterCheckMosManager.get_amphora_host(
        openstack_client_manager, lb["net"])
    machine_by_node = {m.get_k8s_node_name(): m for m in machines}
    target_node = amphora_host if amphora_host in machine_by_node \
        else list(machine_by_node)[0]
    machine = machine_by_node[target_node]
    machine_ip = machine.public_ip
    survivors = [n for n in machine_by_node if n != target_node]

    powered_off = {"state": False}

    def _ensure_power_on():
        if powered_off["state"]:
            LOG.info(f"Finalizer: power on {target_node}")
            machine.set_baremetalhost_power(online=True)
    request.addfinalizer(_ensure_power_on)

    show_step(2)
    LOG.info(f"Soft-shutdown gateway compute {target_node} "
             f"(amphora host: {amphora_host})")
    try:
        machine.exec_pod_cmd(SHUTDOWN_CMD, verbose=False, timeout=10)
    except Exception:
        LOG.debug("SSH connection closed by the shutdown, as expected")
    powered_off["state"] = True
    waiters.wait(lambda: not waiters.icmp_ping(machine_ip),
                 interval=5, timeout=1200)
    cluster.check.wait_k8s_node_status(target_node,
                                       expected_status='NotReady', timeout=900)
    for node in survivors:
        os_manager.tf_manager.check_vgw_routing(node)
    ClusterCheckMosManager.wait_lb_online(openstack_client_manager, lb["id"],
                                          timeout=1500)
    assert ClusterCheckMosManager.is_lb_functional(
        openstack_client_manager, 2, lb["url"]), (
        "LB not functional after a gateway compute shutdown")

    show_step(3)
    machine.set_baremetalhost_power(online=True)
    powered_off["state"] = False
    waiters.wait(lambda: waiters.icmp_ping(machine_ip),
                 interval=5, timeout=1800)
    cluster.check.wait_k8s_node_status(target_node, expected_status='Ready',
                                       timeout=1800)
    _wait_gateway_recovered(os_manager, target_node)

    show_step(4)
    ClusterCheckMosManager.wait_lb_online(openstack_client_manager, lb["id"],
                                          timeout=1200)
    assert ClusterCheckMosManager.is_lb_functional(
        openstack_client_manager, 2, lb["url"])
