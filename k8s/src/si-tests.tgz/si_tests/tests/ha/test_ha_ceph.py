import pytest

from si_tests import logger
from si_tests import settings
from si_tests.clients.k8s.pods import K8sPod
from si_tests.utils import utils, waiters
from si_tests.utils.ha_helpers import collect_ceph_role_machines

LOG = logger.logger
CEPH_MACHINES = collect_ceph_role_machines()

SKIP_MSG = "Damage multiple Ceph components may make recovery impossible. Please investigate previous failure."


def id_label_node(param):
    if hasattr(param, 'role'):
        return 'MODULE={};MACHINE={}'.format(param.role, param.machine.name)
    else:
        return ""


def collect_modules():
    return [m for m in CEPH_MACHINES if ('csi' not in m.role and 'mon' not in m.role)]


def select_mon():
    return [m for m in CEPH_MACHINES if 'mon' in m.role]


ERRORS = {
    "mgr": {"ceph": "HEALTH_OK", "miracephhealth": "Failed", "cephdeploymenthealth": "Failed",
            "cluster": {'Ceph': 'not all mgrs'}},
    "mon": {"ceph": "HEALTH_WARN", "miracephhealth": "Failed", "cephdeploymenthealth": "Failed",
            "cluster": {'Ceph': 'not all mons'}},
    "osd": {"ceph": "HEALTH_WARN", "miracephhealth": "Failed", "cephdeploymenthealth": "Failed",
            "cluster": {'Ceph': 'not all osds'}}
}


@pytest.mark.parametrize("target_data", collect_modules(), ids=id_label_node)
@pytest.mark.usefixtures('log_step_time')
@pytest.mark.usefixtures("check_ceph_keyrings")
def test_ceph_component_down(request, target_cluster, target_data, kaas_manager, show_step):
    """Emulate Ceph components failure/freezing and check that Ceph is available

    Scenario:
        1. Emulate Ceph component failure/freezing
        2. Check Ceph cluster status
        3. Spawn test pod and check PV i/o
        4. Delete pod
        5. Check Ceph cluster and MCC cluster statuses
        6. Check PV i/o
        7. Delete test pod and claim
        8. Check cluster readiness

    """
    if request.session.testsfailed:
        LOG.error(SKIP_MSG)
        pytest.skip(SKIP_MSG)

    rnd = utils.gen_random_string(6)
    namespace = f'test-ns-{rnd}'
    claim_name = f"test-pv-claim-{rnd}"
    mount_path = '/data/test'

    machine = target_data.machine
    container_id = target_data.container_id
    pod = target_data.pod
    node = target_data.k8s_node_name
    role = target_data.role

    LOG.info(f'Create "{namespace}" namespace')
    test_ns = target_cluster.k8sclient.namespaces.create(name=namespace, body={'metadata': {'name': namespace}})

    show_step(1)
    LOG.info("Pause container {} for pod {} on {} machine ({})".format(container_id, pod.name, machine.name, node))

    machine._run_cmd("sudo ctr --namespace k8s.io tasks pause {}".format(container_id),
                     ssh_key=settings.KAAS_CLUSTER_PRIVATE_KEY_FILE,
                     verbose_info=True, timeout=10)

    show_step(2)
    error = ERRORS[role]
    if target_cluster.workaround.child_with_cephdeployment():
        LOG.info("Check CephDeploymentHealth status")
        target_cluster.check.wait_cephdeploymenthealth_state(expected_phase=error['cephdeploymenthealth'])
    else:
        LOG.info("Check MiraCephHealth status")
        target_cluster.check.wait_miracephhealth_state(expected_phase=error['miracephhealth'])
    LOG.info("Check Ceph health status")
    try:
        health_info = target_cluster.check.get_ceph_health_detail()
        assert health_info['status'] == error['ceph'], f'Health is not OK. Will not proceed. ' \
                                                       f'Current ceph health status: {health_info}'
    except AssertionError:
        target_cluster.check.wait_ceph_health_status(error['ceph'])
    LOG.info("Check MCC cluster status")
    assert target_cluster.is_ready(exp_provider_status=False,
                                   expected_fails=['Ceph']), "MCC cluster status not as expected"
    expected_condition_fails = {**error['cluster'], **target_cluster.workaround.prodx_60827()}
    assert target_cluster.are_conditions_ready(
        expected_fails=expected_condition_fails), "MCC cluster error message not as expected"

    show_step(3)
    storage_classes = target_cluster.k8sclient.api_storage.list_storage_class().to_dict()['items']
    storage_class_name = [storageclass for storageclass in storage_classes
                          if storageclass['provisioner'] == 'rook-ceph.rbd.csi.ceph.com'
                          and storageclass['metadata']['annotations']
                          ['storageclass.kubernetes.io/is-default-class'] == 'true'][0]['metadata']['name']
    test_pvc = target_cluster.check.create_pvc(ns=namespace, pvc_name=claim_name, storage_class=storage_class_name)
    test_pod = target_cluster.check.create_pod(pvc_name=test_pvc.name, ns=namespace, mount_path=mount_path)
    target_cluster.check.check_pod_filesystem(mount_path=mount_path, pod=test_pod)

    show_step(4)
    pod.delete(async_del=True)

    show_step(5)
    LOG.info("Check Ceph health status")
    try:
        health_info = target_cluster.check.get_ceph_health_detail()
        assert health_info['status'] == "HEALTH_OK", f'Health is not OK. Will not proceed. ' \
                                                     f'Current ceph health status: {health_info}'
    except AssertionError:
        target_cluster.check.wait_ceph_health_status(timeout=1800)
    if target_cluster.workaround.child_with_cephdeployment():
        LOG.info("Check CephDeploymentHealth status")
        target_cluster.check.wait_cephdeploymenthealth_state()
    else:
        LOG.info("Check MiraCephHealth status")
        target_cluster.check.wait_miracephhealth_state()

    show_step(6)
    target_cluster.check.check_pod_filesystem(mount_path=mount_path, pod=test_pod)

    show_step(7)
    test_pod.delete(async_del=True)
    test_pvc.delete()
    test_ns.delete()

    show_step(8)
    target_cluster.check.check_cluster_readiness(
        expected_condition_fails=target_cluster.workaround.prodx_60827())


@pytest.mark.parametrize("target_data", select_mon(), ids=id_label_node)
@pytest.mark.usefixtures('log_step_time')
@pytest.mark.usefixtures("check_ceph_keyrings")
def test_restart_mon(request, target_cluster, target_data, kaas_manager, show_step):
    """Emulate Ceph MON failure and check that Ceph recovers

    Scenario:
        1. Check Ceph cluster
        2. Kill the Ceph MON container (SIGKILL)
        3. Check Ceph cluster status (best-effort degraded state)
        4. Spawn test pod and check PV i/o
        5. Wait until the Ceph mon container is restarted and pods are healthy
        6. Check Ceph cluster
        7. Check PV i/o
        8. Delete test pod and claim
        9. Check cluster readiness

    """

    if request.session.testsfailed:
        LOG.error(SKIP_MSG)
        pytest.skip(SKIP_MSG)

    rnd = utils.gen_random_string(6)
    namespace = f'test-ns-{rnd}'
    claim_name = f"test-pv-claim-{rnd}"
    mount_path = '/data/test'
    role = target_data.role

    machine = target_data.machine
    container_id = target_data.container_id
    pod: K8sPod = target_data.pod
    node = target_data.k8s_node_name
    pod_name_prefix = f"rook-ceph-{role}"

    LOG.info(f'Create "{namespace}" namespace')
    test_ns = target_cluster.k8sclient.namespaces.create(name=namespace, body={'metadata': {'name': namespace}})
    restarts_before = pod.get_restarts_number()
    LOG.info(f"Initial restart count for pod '{pod.name}': {restarts_before}")

    show_step(1)
    LOG.info("Check Ceph health status")
    try:
        health_info = target_cluster.check.get_ceph_health_detail()
        assert health_info['status'] == "HEALTH_OK", f'Health is not OK. Will not proceed. ' \
                                                     f'Current ceph health status: {health_info}'
    except AssertionError:
        target_cluster.check.wait_ceph_health_status()
    if target_cluster.workaround.child_with_cephdeployment():
        LOG.info("Check CephDeploymentHealth status")
        target_cluster.check.wait_cephdeploymenthealth_state()
    else:
        LOG.info("Check MiraCephHealth status")
        target_cluster.check.wait_miracephhealth_state()

    show_step(2)
    LOG.info("Kill container {} for pod {} on {} machine ({})".format(container_id, pod.name, machine.name, node))
    # SIGKILL terminates the mon process so the container exits and kubelet restarts it
    # in-place (restart count increments), after which the mon rejoins quorum.
    # Note: neither `ctr tasks pause` (liveness probe errors with "cannot exec in a paused
    # state") nor SIGSTOP work here -- a frozen mon makes the liveness probe hang instead of
    # failing cleanly, so kubelet never restarts it, and on compact/host-networking clusters
    # rook cannot fail the mon over (no node to schedule a replacement mon on).
    machine._run_cmd("sudo ctr --namespace k8s.io tasks kill --signal SIGKILL {}".format(container_id),
                     ssh_key=settings.KAAS_CLUSTER_PRIVATE_KEY_FILE,
                     verbose_info=True, timeout=10)

    show_step(3)
    error = ERRORS[role]
    LOG.info("Check KaaS Ceph cluster status")
    # NOTE: SIGKILL makes kubelet restart the mon container in-place within seconds,
    # so the degraded window ('Failed'/HEALTH_WARN, "not all mons") is short and may
    # be missed by polling. The degraded-state checks below are therefore best-effort;
    # the hard recovery assertions are in step 6.
    try:
        if target_cluster.workaround.child_with_cephdeployment():
            LOG.info("Check CephDeploymentHealth status")
            target_cluster.check.wait_cephdeploymenthealth_state(
                expected_phase=error['cephdeploymenthealth'], timeout=120, interval=5)
        else:
            LOG.info("Check MiraCephHealth status")
            target_cluster.check.wait_miracephhealth_state(
                expected_phase=error['miracephhealth'], timeout=120, interval=5)
        LOG.info("Check Ceph cluster status")
        target_cluster.check.wait_ceph_health_status(error['ceph'], timeout=120)
    except Exception as e:
        LOG.warning(f"Degraded Ceph state '{error['ceph']}' was not observed, "
                    f"likely due to fast mon container restart: {e}")

    show_step(4)
    storage_classes = target_cluster.k8sclient.api_storage.list_storage_class().to_dict()['items']
    storage_class_name = [storageclass for storageclass in storage_classes
                          if storageclass['provisioner'] == 'rook-ceph.rbd.csi.ceph.com'
                          and storageclass['metadata']['annotations']
                          ['storageclass.kubernetes.io/is-default-class'] == 'true'][0]['metadata']['name']
    test_pvc = target_cluster.check.create_pvc(ns=namespace, pvc_name=claim_name, storage_class=storage_class_name)
    test_pod = target_cluster.check.create_pod(pvc_name=test_pvc.name, ns=namespace, mount_path=mount_path)
    target_cluster.check.check_pod_filesystem(mount_path=mount_path, pod=test_pod)

    show_step(5)
    LOG.info(f"Wait for the mon container in pod '{pod.name}' to be restarted by kubelet")
    waiters.wait(lambda: pod.get_restarts_number() > restarts_before, timeout=900, interval=15,
                 timeout_msg=f"Container in pod {pod.name} was not restarted "
                             f"(restart count still {restarts_before})")

    LOG.info("Wait for all rook-ceph mon pods to become healthy")
    waiters.wait(lambda: target_cluster.k8sclient.pods.check_pods_statuses(target_namespaces=settings.ROOK_CEPH_NS,
                                                                           pods_prefix=pod_name_prefix), timeout=240,
                 interval=10, timeout_msg="Some pods are not in correct status/phase")

    show_step(6)
    LOG.info("Check Ceph health status")
    try:
        health_info = target_cluster.check.get_ceph_health_detail()
        assert health_info['status'] == "HEALTH_OK", f'Health is not OK. Will not proceed. ' \
                                                     f'Current ceph health status: {health_info}'
    except AssertionError:
        target_cluster.check.wait_ceph_health_status(timeout=3600)
    if target_cluster.workaround.child_with_cephdeployment():
        LOG.info("Check CephDeploymentHealth status")
        target_cluster.check.wait_cephdeploymenthealth_state()
    else:
        LOG.info("Check MiraCephHealth status")
        target_cluster.check.wait_miracephhealth_state()

    show_step(7)
    target_cluster.check.check_pod_filesystem(mount_path=mount_path, pod=test_pod)

    show_step(8)
    test_pod.delete(async_del=True)
    test_pvc.delete()
    test_ns.delete()

    show_step(9)
    target_cluster.check.check_cluster_readiness(
        expected_condition_fails=target_cluster.workaround.prodx_60827())


@pytest.mark.parametrize("_", ["CLUSTER_NAME={0}"
                         .format(settings.TARGET_CLUSTER)])
@pytest.mark.usefixtures("check_ceph_keyrings")
def test_ha_ceph_mgr(request, target_cluster, cluster_condition_check, _):
    """Check that Ceph HA move active mgr to second node

    Scenario:
        1. Check ceph cluster state and readiness
        2. Check on which node we have active ceph mgr and on which it in stand by
        3. Reboot node with active ceph mgr
        4. Check that all pods are Running and Ready
        5. Check ceph cluster state and readiness
        6. Check that ceph mgrs swapped

    Expected result - Ceph active mgr should migrate to node on which it was
    in stand by state
    """
    if request.session.testsfailed:
        LOG.error(SKIP_MSG)
        pytest.skip(SKIP_MSG)

    target_cluster.check.check_ha_ceph_mgr()
