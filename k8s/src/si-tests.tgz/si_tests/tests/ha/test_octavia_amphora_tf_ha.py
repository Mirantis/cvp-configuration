# Copyright 2026 Mirantis, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License"); you may
# not use this file except in compliance with the License. You may obtain
# a copy of the License at
#
#      http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
# WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
# License for the specific language governing permissions and limitations
# under the License.
"""Multi-node Octavia Amphora control-plane HA on OpenSDN/TF.

Coverage for PRODX-61681 (GA of multi-compute Octavia HA on OpenSDN/TF):

  * Multi-gateway topology: 2+ computes labeled ``openstack-gateway=enabled``
    each running its own ``tf-vrouter-vgw`` and per-compute selective overlay
    routing + SNAT into ``lb-mgmt-net`` (no obsolete ``0.0.0.0/0`` injection).
  * Redundant Octavia worker / health-manager / housekeeping placement.
  * Amphora LB reaches ACTIVE/ONLINE across the multi-gateway topology and is
    functional regardless of amphora vs control-pod co-location -- covering
    the IDEA-2487 scenarios (same-host / cross-host control path)
    observationally (Nova forbids moving a compute with running instances
    between AZs, so amphora placement cannot be pinned deterministically on a
    live cluster).
  * Loss of one gateway compute does not permanently break LB operations.
  * Adding / removing the ``openstack-gateway`` label reschedules
    ``tf-vrouter-vgw`` and the Octavia control pods (PRODX-38931).

Test runs with a minimum of 2 gateway computes.
"""
import pytest

from si_tests.deployments.utils import commons
from si_tests.managers.clustercheck_mos_manager import ClusterCheckMosManager
from si_tests.tests.lcm.test_node_controller import check_node_controller
from si_tests.utils import waiters

LOG = commons.LOG

# Octavia control services that must be redundant across gateway computes.
OCTAVIA_CONTROL_ROLES = ("octavia-worker",
                         "octavia-health-manager",
                         "octavia-housekeeping")

# Number of load balancers created by the scale scenario.
SCALE_LB_COUNT = 3


def _wait_role_pods_running(os_manager, role, count, timeout=480,
                            interval=15):
    """Wait until at least ``count`` pods of an Octavia control ``role`` are
    Running (used to confirm a killed control pod rescheduled)."""
    waiters.wait(
        lambda: len(_octavia_pods_by_role(os_manager, role)) >= count,
        timeout=timeout, interval=interval,
        timeout_msg=f"{role}: fewer than {count} Running pods after reschedule")


def _octavia_pods_by_role(os_manager, role):
    """Return Octavia control pods for a given role (running only)."""
    pods = os_manager.api.pods.list(namespace=os_manager.openstack_namespace,
                                    name_prefix=role)
    return [p for p in pods
            if p.data.get('status', {}).get('phase') == 'Running']


def _nodes_of_pods(pods):
    """Return the set of node names hosting the given pods."""
    return {p.data['spec'].get('node_name') for p in pods
            if p.data['spec'].get('node_name')}


def _short(name):
    """Short hostname (strip domain) for comparing k8s node names with Nova
    hypervisor hostnames."""
    return name.split('.')[0] if name else name


@pytest.fixture(scope='module')
def gateway_nodes(os_manager):
    """Gateway computes (openstack-gateway=enabled + tfvrouter=enabled)."""
    nodes = os_manager.tf_manager.get_vgw_nodes()
    node_names = [n.name for n in nodes]
    LOG.info(f"Discovered gateway computes: {node_names}")
    if len(node_names) < 2:
        pytest.skip("PRODX-61681 multi-node Octavia HA requires at least 2 "
                    f"openstack-gateway computes, found {len(node_names)}: "
                    f"{node_names}")
    return node_names


@pytest.mark.usefixtures('skip_by_network_backend')
@pytest.mark.network_backend('tf')
class TestOctaviaAmphoraTFHA(object):

    def test_multi_gateway_topology(self, os_manager, gateway_nodes,
                                    show_step):
        """Validate the multi-gateway topology and per-node Simple VGW routing.

        Scenario:
            1. At least 2 computes carry openstack-gateway=enabled.
            2. tf-vrouter-vgw DaemonSet runs one pod per gateway compute.
            3. Each gateway compute injects a selective /32 route + SNAT into
               the lb-mgmt-net overlay and does NOT re-add 0.0.0.0/0.
        """
        tf_manager = os_manager.tf_manager

        show_step(1)
        assert not tf_manager.is_vgw_disabled(), (
            "Virtual Gateway is disabled; multi-node Octavia Amphora HA on "
            "OpenSDN/TF is not applicable")

        show_step(2)
        vgw_pods = tf_manager.get_vgw_daemonset_pods()
        vgw_pod_nodes = _nodes_of_pods(vgw_pods)
        LOG.info(f"tf-vrouter-vgw pods run on: {sorted(vgw_pod_nodes)}")
        assert vgw_pod_nodes == set(gateway_nodes), (
            f"tf-vrouter-vgw is expected on every gateway compute "
            f"{sorted(gateway_nodes)}, but runs on {sorted(vgw_pod_nodes)}")

        show_step(3)
        for node in gateway_nodes:
            LOG.info(f"Validate Simple VGW routing on gateway node {node}")
            tf_manager.check_vgw_routing(node)

    def test_octavia_control_redundancy(self, os_manager, gateway_nodes,
                                        show_step):
        """Octavia control services are redundant and follow gateway computes.

        Scenario:
            1. Octavia worker/health-manager/housekeeping each run >= 2 pods.
            2. Health-manager runs on every gateway compute and worker /
               housekeeping are co-located with it (PRODX-38931 affinity).
        """
        show_step(1)
        placement = {}
        for role in OCTAVIA_CONTROL_ROLES:
            pods = _octavia_pods_by_role(os_manager, role)
            nodes = _nodes_of_pods(pods)
            placement[role] = nodes
            LOG.info(f"{role}: {len(pods)} pod(s) on {sorted(nodes)}")
            assert len(pods) >= 2, (
                f"{role} is not redundant: {len(pods)} pod(s) running, "
                f"expected >= 2 for multi-node Octavia HA")

        show_step(2)
        # health-manager must be present on every gateway compute; worker and
        # housekeeping follow health-manager placement (pod affinity).
        hm_nodes = placement["octavia-health-manager"]
        assert set(gateway_nodes).issubset(hm_nodes), (
            f"octavia-health-manager is expected on all gateway computes "
            f"{sorted(gateway_nodes)}, found on {sorted(hm_nodes)}")
        for role in ("octavia-worker", "octavia-housekeeping"):
            assert placement[role] & hm_nodes, (
                f"{role} is not co-located with any octavia-health-manager "
                f"node (affinity broken): {sorted(placement[role])} vs "
                f"{sorted(hm_nodes)}")

    def test_amphora_lb_online_multi_gateway(self, openstack_client_manager,
                                             os_manager, gateway_nodes, request,
                                             show_step):
        """Amphora LB reaches ACTIVE/ONLINE and is functional (multi-gateway).

        Scenario:
            1. Deploy an amphorav2 LB via Heat.
            2. LB reaches provisioning_status=ACTIVE and operating_status=ONLINE.
            3. Log which IDEA-2487 placement scenario the topology exercised.
            4. LB is functional (round-robin across members).
        """
        show_step(1)
        stack = ClusterCheckMosManager.created_stack_tf_lb(
            request, openstack_client_manager,
            custom_params={"lb_provider": "amphorav2"})
        lb_id = ClusterCheckMosManager.get_stack_output(stack, 'lb_id')
        lb_url = ClusterCheckMosManager.get_stack_output(stack, 'lb_url')
        net_name = ClusterCheckMosManager.get_stack_output(stack,
                                                           'network_name')
        assert lb_id, "Heat stack did not expose lb_id output"

        show_step(2)
        ClusterCheckMosManager.wait_lb_online(openstack_client_manager, lb_id)

        show_step(3)
        # Log the placement matrix to document which IDEA-2487 scenario the
        # observed topology exercised (amphora host vs worker hosts).
        amphora_host = ClusterCheckMosManager.get_amphora_host(
            openstack_client_manager, net_name)
        worker_nodes = {_short(n) for n in _nodes_of_pods(
            _octavia_pods_by_role(os_manager, "octavia-worker"))}
        LOG.info(f"Amphora host: {amphora_host}; octavia-worker nodes: "
                 f"{sorted(worker_nodes)}; gateway nodes: "
                 f"{sorted(gateway_nodes)}")
        if amphora_host and _short(amphora_host) not in worker_nodes:
            LOG.info("IDEA-2487 scenario: amphora runs on a compute without a "
                     "local Octavia worker (cross-host control path)")
        else:
            LOG.info("IDEA-2487 scenario: amphora co-located with an Octavia "
                     "worker")

        show_step(4)
        assert ClusterCheckMosManager.is_lb_functional(
            openstack_client_manager, 2, lb_url), (
            "LB is ONLINE but not functional (round-robin check failed)")

    def test_octavia_gateway_compute_failover(self, openstack_client_manager,
                                              os_manager, gateway_nodes,
                                              request, show_step):
        """Loss of one gateway compute does not permanently break Octavia LB.

        Scenario:
            1. Deploy an Amphora LB and confirm ACTIVE/ONLINE + functional.
            2. Put one gateway compute into maintenance (drain/evacuate).
            3. Surviving gateway computes still provide VGW routing and run
               tf-vrouter-vgw.
            4. LB recovers to ACTIVE/ONLINE and stays functional.
        """
        show_step(1)
        stack = ClusterCheckMosManager.created_stack_tf_lb(
            request, openstack_client_manager,
            custom_params={"lb_provider": "amphorav2"})
        lb_id = ClusterCheckMosManager.get_stack_output(stack, 'lb_id')
        lb_url = ClusterCheckMosManager.get_stack_output(stack, 'lb_url')
        net_name = ClusterCheckMosManager.get_stack_output(stack,
                                                           'network_name')
        ClusterCheckMosManager.wait_lb_online(openstack_client_manager, lb_id)
        assert ClusterCheckMosManager.is_lb_functional(
            openstack_client_manager, 2, lb_url)

        show_step(2)
        # Prefer taking down the gateway compute that hosts the amphora VM to
        # exercise the worst case; fall back to the first gateway compute.
        amphora_host = ClusterCheckMosManager.get_amphora_host(
            openstack_client_manager, net_name)
        victim = amphora_host if amphora_host in gateway_nodes \
            else gateway_nodes[0]
        LOG.info(f"Draining gateway compute {victim} "
                 f"(amphora host: {amphora_host})")
        check_node_controller(openstack_client_manager, os_manager,
                              hosts=[victim])

        show_step(3)
        survivors = [n for n in gateway_nodes if n != victim]
        assert survivors, "No surviving gateway compute to validate"
        for node in survivors:
            os_manager.tf_manager.check_vgw_routing(node)

        show_step(4)
        ClusterCheckMosManager.wait_lb_online(openstack_client_manager, lb_id)
        assert ClusterCheckMosManager.is_lb_functional(
            openstack_client_manager, 2, lb_url), (
            "LB not functional after gateway compute failover")

    def test_vgw_snat_per_node_own_ip(self, os_manager, gateway_nodes,
                                      show_step):
        """Each gateway compute SNATs overlay control traffic to its OWN
        LCM IP (per-node /32 model of PRODX-61108, not a shared route).

        Scenario:
            1. Collect the LCM (InternalIP) of each gateway compute.
            2. The vgw SNAT --to-source on each gateway equals that node's
               own LCM IP and nothing else.
        """
        show_step(1)
        node_ips = {}
        for node in gateway_nodes:
            k8s_node = os_manager.api.nodes.get(name=node)
            addrs = k8s_node.data.get('status', {}).get('addresses', [])
            internal = [a['address'] for a in addrs
                        if a.get('type') == 'InternalIP']
            assert internal, f"No InternalIP for gateway node {node}"
            node_ips[node] = internal[0]
        LOG.info(f"Gateway node LCM IPs: {node_ips}")

        show_step(2)
        for node, ip in node_ips.items():
            sources = os_manager.tf_manager.get_node_vgw_snat_sources(node)
            assert sources == {ip}, (
                f"Gateway {node} vgw SNAT sources {sources} != its own LCM IP "
                f"{{{ip}}} (per-node SNAT is incorrect)")


@pytest.mark.usefixtures('skip_by_network_backend')
@pytest.mark.network_backend('tf')
def test_octavia_gateway_label_move(os_manager, show_step):
    """Adding/removing openstack-gateway reschedules the tf-vrouter-vgw pod.

    Scenario:
        1. Pick a spare tfvrouter compute without the openstack-gateway label.
        2. Add openstack-gateway=enabled to its k8s Node.
        3. tf-vrouter-vgw is scheduled there and VGW routing is provisioned.
        4. Remove the label and confirm tf-vrouter-vgw drains from the node.

    The label is restored/removed by a finalizer regardless of outcome.
    """
    tf_manager = os_manager.tf_manager
    gw_key = 'openstack-gateway'

    show_step(1)
    spare = None
    for node in os_manager.api.nodes.list(label_selector="tfvrouter=enabled"):
        labels = node.data.get('metadata', {}).get('labels', {})
        if gw_key not in labels:
            spare = node
            break
    if spare is None:
        pytest.skip("No spare tfvrouter compute without openstack-gateway "
                    "label available for the label-move scenario")
    node_name = spare.name
    LOG.info(f"Spare compute for label move: {node_name}")

    def _restore():
        node = os_manager.api.nodes.get(name=node_name)
        if gw_key in node.data.get('metadata', {}).get('labels', {}):
            LOG.info(f"Finalizer: remove {gw_key} label from {node_name}")
            node.patch({"metadata": {"labels": {gw_key: None}}})

    show_step(2)
    spare.add_label({gw_key: 'enabled'})
    try:
        show_step(3)
        waiters.wait(
            lambda: node_name in _nodes_of_pods(
                tf_manager.get_vgw_daemonset_pods()),
            timeout=900, interval=30,
            timeout_msg=f"tf-vrouter-vgw was not scheduled on {node_name} "
                        f"after adding openstack-gateway label")
        tf_manager.wait_all_pods_on_node(node_name, timeout=900)
        waiters.wait(
            lambda: tf_manager.check_vgw_routing(node_name),
            timeout=600, interval=30,
            timeout_msg=f"Simple VGW routing not provisioned on {node_name}")

        show_step(4)
        os_manager.api.nodes.get(name=node_name).patch(
            {"metadata": {"labels": {gw_key: None}}})
        waiters.wait(
            lambda: node_name not in _nodes_of_pods(
                tf_manager.get_vgw_daemonset_pods()),
            timeout=900, interval=30,
            timeout_msg=f"tf-vrouter-vgw was not removed from {node_name} "
                        f"after removing openstack-gateway label")
    finally:
        _restore()


@pytest.mark.usefixtures('skip_by_network_backend')
@pytest.mark.network_backend('tf')
class TestOctaviaAmphoraControlHA(object):
    """Tier 1: control-plane and LB-lifecycle resilience under single
    component failures on a multi-gateway OpenSDN/TF topology (PRODX-61681).

    A shared amphorav2 LB is created once per class and reused as the
    data-plane probe across the failure scenarios.
    """

    @pytest.fixture(scope='class')
    def lb(self, request, openstack_client_manager, gateway_nodes):
        stack = ClusterCheckMosManager.created_stack_tf_lb(
            request, openstack_client_manager,
            custom_params={"lb_provider": "amphorav2"})
        lb_id = ClusterCheckMosManager.get_stack_output(stack, 'lb_id')
        lb_url = ClusterCheckMosManager.get_stack_output(stack, 'lb_url')
        net_name = ClusterCheckMosManager.get_stack_output(stack,
                                                           'network_name')
        ClusterCheckMosManager.wait_lb_online(openstack_client_manager, lb_id)
        assert ClusterCheckMosManager.is_lb_functional(
            openstack_client_manager, 2, lb_url)
        return {"id": lb_id, "url": lb_url, "net": net_name}

    def test_ha_delete_octavia_worker_pod(self, request, os_manager,
                                          openstack_client_manager,
                                          gateway_nodes, lb, show_step):
        """Losing an octavia-worker pod does not stop LB control operations.

        Scenario:
            1. Delete one octavia-worker pod.
            2. It reschedules (worker count restored, all on gateway nodes).
            3. A brand-new LB still reaches ACTIVE/ONLINE (ops continue).
            4. The pre-existing LB stays functional.
        """
        show_step(1)
        # Wait for a healthy baseline in case a previous test left the control
        # plane still recovering, then capture the current worker count.
        _wait_role_pods_running(os_manager, "octavia-worker", 2)
        workers = _octavia_pods_by_role(os_manager, "octavia-worker")
        count = len(workers)
        victim = workers[0]
        LOG.info(f"Deleting octavia-worker pod {victim.name} on "
                 f"{victim.data['spec'].get('node_name')}")
        victim.delete()

        show_step(2)
        _wait_role_pods_running(os_manager, "octavia-worker", count)
        worker_nodes = _nodes_of_pods(
            _octavia_pods_by_role(os_manager, "octavia-worker"))
        assert worker_nodes.issubset(set(gateway_nodes)), (
            f"octavia-worker rescheduled off gateway nodes: {worker_nodes}")

        show_step(3)
        stack = ClusterCheckMosManager.created_stack_tf_lb(
            request, openstack_client_manager,
            custom_params={"lb_provider": "amphorav2"})
        new_lb_id = ClusterCheckMosManager.get_stack_output(stack, 'lb_id')
        new_lb_url = ClusterCheckMosManager.get_stack_output(stack, 'lb_url')
        ClusterCheckMosManager.wait_lb_online(openstack_client_manager,
                                              new_lb_id)
        assert ClusterCheckMosManager.is_lb_functional(
            openstack_client_manager, 2, new_lb_url)

        show_step(4)
        assert ClusterCheckMosManager.is_lb_functional(
            openstack_client_manager, 2, lb["url"])

    def test_ha_delete_octavia_health_manager_pod(self, os_manager,
                                                  openstack_client_manager,
                                                  gateway_nodes, lb, show_step):
        """Losing an octavia-health-manager pod is self-healing.

        Scenario:
            1. Delete one octavia-health-manager pod.
            2. It reschedules on a gateway compute (count restored).
            3. The LB stays ACTIVE/ONLINE and functional.
        """
        show_step(1)
        # Wait for a healthy baseline (one health-manager per gateway compute)
        # in case a previous test left the control plane still recovering.
        count = len(gateway_nodes)
        _wait_role_pods_running(os_manager, "octavia-health-manager", count)
        hms = _octavia_pods_by_role(os_manager, "octavia-health-manager")
        victim = hms[0]
        LOG.info(f"Deleting octavia-health-manager pod {victim.name}")
        victim.delete()

        show_step(2)
        _wait_role_pods_running(os_manager, "octavia-health-manager", count)
        hm_nodes = _nodes_of_pods(
            _octavia_pods_by_role(os_manager, "octavia-health-manager"))
        assert set(gateway_nodes).issubset(hm_nodes), (
            f"health-manager not present on all gateway nodes: {hm_nodes}")

        show_step(3)
        ClusterCheckMosManager.wait_lb_online(openstack_client_manager,
                                              lb["id"])
        assert ClusterCheckMosManager.is_lb_functional(
            openstack_client_manager, 2, lb["url"])

    def test_ha_delete_tf_vrouter_vgw_pod(self, os_manager,
                                          openstack_client_manager,
                                          gateway_nodes, lb, show_step):
        """Losing a tf-vrouter-vgw pod re-provisions the overlay routing.

        Scenario:
            1. Delete one tf-vrouter-vgw pod on a gateway compute.
            2. It reschedules on the same gateway compute.
            3. The vgw selective route + SNAT are re-provisioned there.
            4. The LB stays functional.
        """
        tf_manager = os_manager.tf_manager
        show_step(1)
        # Wait for a healthy baseline (one tf-vrouter-vgw per gateway compute)
        # in case a previous test left a node still recovering.
        waiters.wait(
            lambda: len(tf_manager.get_vgw_daemonset_pods()) >= len(
                gateway_nodes),
            timeout=480, interval=15,
            timeout_msg="tf-vrouter-vgw did not reach one pod per gateway node")
        vgw_pods = tf_manager.get_vgw_daemonset_pods()
        count = len(vgw_pods)
        victim = vgw_pods[0]
        node = victim.data['spec'].get('node_name')
        LOG.info(f"Deleting tf-vrouter-vgw pod {victim.name} on {node}")
        victim.delete()

        show_step(2)
        waiters.wait(
            lambda: node in _nodes_of_pods(tf_manager.get_vgw_daemonset_pods())
            and len(tf_manager.get_vgw_daemonset_pods()) >= count,
            timeout=600, interval=15,
            timeout_msg=f"tf-vrouter-vgw did not reschedule on {node}")
        tf_manager.wait_all_pods_on_node(node, timeout=600)

        show_step(3)
        waiters.wait(
            lambda: tf_manager.check_vgw_routing(node),
            timeout=600, interval=20,
            timeout_msg=f"vgw routing not re-provisioned on {node}")

        show_step(4)
        assert ClusterCheckMosManager.is_lb_functional(
            openstack_client_manager, 2, lb["url"])

    def test_octavia_amphora_failover(self, openstack_client_manager,
                                      gateway_nodes, lb, show_step):
        """Amphora failover rebuilds the VM and restores the LB.

        Scenario:
            1. Record the current amphora(e) of the LB.
            2. Trigger `openstack loadbalancer failover`.
            3. The LB returns to ACTIVE/ONLINE with a new amphora.
            4. The LB is functional again.
        """
        show_step(1)
        before = openstack_client_manager.loadbalancer.amphora_list(
            ['--loadbalancer', lb["id"]], yaml_output=True)
        before_ids = {a.get('id') for a in before}
        LOG.info(f"Amphora(e) before failover: {before_ids}")

        show_step(2)
        openstack_client_manager.loadbalancer.failover([lb["id"]])

        show_step(3)
        ClusterCheckMosManager.wait_lb_online(openstack_client_manager,
                                              lb["id"])
        after = openstack_client_manager.loadbalancer.amphora_list(
            ['--loadbalancer', lb["id"]], yaml_output=True)
        after_ids = {a.get('id') for a in after}
        LOG.info(f"Amphora(e) after failover: {after_ids}")
        assert after_ids and after_ids != before_ids, (
            f"Amphora was not rebuilt by failover: {before_ids} -> {after_ids}")

        show_step(4)
        assert ClusterCheckMosManager.is_lb_functional(
            openstack_client_manager, 2, lb["url"])

    def test_octavia_multi_lb_scale(self, request, openstack_client_manager,
                                    os_manager, gateway_nodes, show_step):
        """Multiple amphora LBs are provisioned concurrently and all work.

        Scenario:
            1. Create several amphorav2 LBs.
            2. Every LB reaches ACTIVE/ONLINE.
            3. Every LB is functional (round-robin across members).
            4. Log the amphora spread across gateway computes.
        """
        show_step(1)
        lbs = []
        for _ in range(SCALE_LB_COUNT):
            stack = ClusterCheckMosManager.created_stack_tf_lb(
                request, openstack_client_manager,
                custom_params={"lb_provider": "amphorav2"})
            lbs.append({
                "id": ClusterCheckMosManager.get_stack_output(stack, 'lb_id'),
                "url": ClusterCheckMosManager.get_stack_output(stack, 'lb_url'),
                "net": ClusterCheckMosManager.get_stack_output(
                    stack, 'network_name'),
            })

        show_step(2)
        for entry in lbs:
            ClusterCheckMosManager.wait_lb_online(openstack_client_manager,
                                                  entry["id"])

        show_step(3)
        for entry in lbs:
            assert ClusterCheckMosManager.is_lb_functional(
                openstack_client_manager, 2, entry["url"]), (
                f"LB {entry['id']} is not functional")

        show_step(4)
        hosts = [ClusterCheckMosManager.get_amphora_host(
            openstack_client_manager, e["net"]) for e in lbs]
        LOG.info(f"Amphora spread across computes: "
                 f"{[_short(h) for h in hosts if h]}")

    def test_octavia_member_crud_under_load(self, openstack_client_manager,
                                            lb, show_step):
        """Pool member enable/disable is reflected in the data plane.

        Scenario:
            1. LB is functional across both pool members.
            2. Disabling one member routes traffic to a single member.
            3. Re-enabling the member restores round-robin across both.
        """
        show_step(1)
        pool = openstack_client_manager.loadbalancer.pool_list(
            ['--loadbalancer', lb["id"]])[0]
        members = openstack_client_manager.loadbalancer.member_list(
            [pool['id']])
        assert len(members) == 2, f"Expected 2 pool members, got {members}"
        assert ClusterCheckMosManager.is_lb_functional(
            openstack_client_manager, 2, lb["url"])

        show_step(2)
        openstack_client_manager.loadbalancer.member_set(
            [pool['id'], members[0]['id'], "--disable"])
        ClusterCheckMosManager.wait_lb_online(openstack_client_manager,
                                              lb["id"])
        assert ClusterCheckMosManager.is_lb_functional(
            openstack_client_manager, 1, lb["url"]), (
            "Traffic not restricted to the single enabled member")

        show_step(3)
        openstack_client_manager.loadbalancer.member_set(
            [pool['id'], members[0]['id'], "--enable"])
        ClusterCheckMosManager.wait_lb_online(openstack_client_manager,
                                              lb["id"])
        assert ClusterCheckMosManager.is_lb_functional(
            openstack_client_manager, 2, lb["url"]), (
            "Round-robin across both members not restored")

    def test_octavia_degrade_to_single_gateway(self, openstack_client_manager,
                                               os_manager, gateway_nodes, lb,
                                               request, show_step):
        """The LB survives with only a single gateway compute remaining.

        Scenario:
            1. Gracefully drain every gateway compute except one.
            2. Only one gateway compute stays active with its VGW routing.
            3. The LB stays ACTIVE/ONLINE and functional via that VGW path.
            4. Restore the drained gateway computes.
        """
        nmr_api = os_manager.api.nodemaintenancerequests
        nwl_api = os_manager.api.nodeworkloadlocks
        drained = [n for n in gateway_nodes[1:]]
        survivor = gateway_nodes[0]
        created = []

        def _restore():
            for host in created:
                try:
                    nmr_api.delete_node_maintenance_request(
                        f"nmr-si-octavia-{host}")
                    nwl_api.wait_nwl_state(f"openstack-{host.split('.')[0]}",
                                           "active", timeout=1800, interval=30)
                except Exception as e:
                    LOG.warning(f"Failed to restore {host}: {e}")
        request.addfinalizer(_restore)

        show_step(1)
        for host in drained:
            nmr_api.create_node_maintenance_request(
                host, f"nmr-si-octavia-{host}", scope="drain")
            created.append(host)
        for host in drained:
            nwl_api.wait_nwl_state(f"openstack-{host.split('.')[0]}",
                                   "inactive", timeout=2760, interval=30)

        show_step(2)
        LOG.info(f"Only gateway {survivor} should remain active")
        os_manager.tf_manager.check_vgw_routing(survivor)

        show_step(3)
        ClusterCheckMosManager.wait_lb_online(openstack_client_manager,
                                              lb["id"])
        assert ClusterCheckMosManager.is_lb_functional(
            openstack_client_manager, 2, lb["url"]), (
            "LB not functional when degraded to a single gateway compute")

        show_step(4)
        _restore()
        created.clear()
        # Wait for the Octavia control pods to fully recover on the restored
        # gateway computes so the next test starts from a healthy baseline.
        _wait_role_pods_running(os_manager, "octavia-health-manager",
                                len(gateway_nodes))
        for role in ("octavia-worker", "octavia-housekeeping"):
            _wait_role_pods_running(os_manager, role, 2)
