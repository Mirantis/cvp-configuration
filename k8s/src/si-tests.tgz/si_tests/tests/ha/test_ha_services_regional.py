import pytest
from si_tests import settings


@pytest.mark.parametrize("_", ["CLUSTER_NAME={0}"
                               .format(settings.TARGET_CLUSTER)])
@pytest.mark.skip(reason="PRODX-14150, PRODX-5376")
def test_ha_kill_proc_pods(target_cluster, command,
                           pod_group, cluster_condition_check, _):
    """Kill processed in every container in all cluster pods
    Precondition - all expected pods and their replicas must be presented
    The following scenario is executed for every namespace and
    expected pod entry in get_expected_pods
    Note: 'kill -- - 1' will kill all processes except pid 1

    Scenario:
        1. Iterate by each pod in a group
        2. Iterate by each container in a pod and
           kill processes in the container
        3. Wait till number of replicas will be restored
        4. Check pods and container statuses in this group
           (Running and Ready)
        5. Check all pods phases (must be Running or Completed)
           (in fixture)

    Expected result - pods are recreated, number of replicas is restored.
    """
    target_cluster.check.check_ha_kill_proc_pods(pod_group, command)


@pytest.mark.parametrize("_", ["CLUSTER_NAME={0}"
                               .format(settings.TARGET_CLUSTER)])
@pytest.mark.skip()
def test_ha_delete_pods(target_cluster, pod_group,
                        cluster_condition_check, _):
    """Delete all pods in any cluster one by one
     Precondition - all expected pods and their replicas must be presented
     The following scenario is executed for every namespace and
     expected pod entry in get_expected_pods

     Scenario:
         1. Compare actual number of replicas for pod with expected
         2. Iterate by each replica
         3. Delete pod (1 replica)
         4. Wait till number of replicas will be restored
         5. Check pods statuses in this group (Running and Ready)

     Expected result - pods are recreated, number of replicas is restored.
     """
    target_cluster.check.check_ha_delete_pods(pod_group)


@pytest.mark.parametrize("_", ["CLUSTER_NAME={0}"
                               .format(settings.TARGET_CLUSTER)])
@pytest.mark.skip(reason="ENGORC-7836")
def test_ha_kill_containerd_shim(target_cluster, cluster_condition_check, _):
    """Kill all containerd-shim processes on every cluster node
    Precondition - all expected pods and their replicas must be presented
    The following scenario is executed for every node

    Scenario:
        1. SSH to node and run kill command for containerd-shim processes
        2. Wait
        3. Check that all pods are Running and Ready

    Expected result - pods and their containers are Running and Ready.
    Number of replicas are the same.
    """
    target_cluster.check.check_ha_kill_containerd_shim()


@pytest.mark.parametrize("_", ["CLUSTER_NAME={0}"
                               .format(settings.TARGET_CLUSTER)])
@pytest.mark.skip(reason="ENGORC-7837")
def test_ha_stop_containerd(target_cluster, cluster_condition_check, _):
    """Stop containerd service on every cluster node (one at a time)
    Precondition - all expected pods and their replicas must be presented
    The following scenario is executed for every node

    Scenario:
        1. SSH to node
        2. Get number of containerd-shim processes
        3. Stop containerd service and make sure it is stopped
        4. Get number of containerd-shim processes and
           compare with previous value (must be the same)
        5. Check that all pods are Running and Ready
        6. Start containerd service

    Expected result - containerd-shim processes are running independently
    from containerd service and all containers in the pods are
    still operational even if containerd is down.
    """
    target_cluster.check.check_ha_stop_containerd()


@pytest.mark.parametrize("_", ["CLUSTER_NAME={0}"
                               .format(settings.TARGET_CLUSTER)])
def test_ha_haproxy(target_cluster, cluster_condition_check, _):
    """Check that HAProxy balance load between api

    Scenario:
        1. Left keepalived on one node by one
        2. Stop api service on two of tree nodes for each node
        3. Check health of api
        4. Restore api service
        5. Resore keepalived

    Expected result - HAProxy will catch service degradation and api should
    be operational.
    """
    target_cluster.check.check_ha_haproxy_lb()
