import pytest
from si_tests import settings

from si_tests.managers.kaas_manager import Cluster


@pytest.mark.parametrize("_", ["CLUSTER_NAME={0}"
                               .format(settings.TARGET_CLUSTER)])
@pytest.mark.usefixtures("collect_downtime_statistics")     # Should be used if ALLOW_WORKLOAD == True
@pytest.mark.usefixtures("check_heat_stacks_after_test")
def test_ha_kill_mariadb(target_cluster: Cluster, cluster_condition_check, _):
    """Kill mysqld service on every cluster node (one at a time)

    Precondition - all expected pods and their replicas must be presented
    The following scenario is executed for every node

    Scenario:
        1. SSH to node
        2. Kill mysqld service
        3. Check mariadb become ready
        4. Check that all pods are Running and Ready

    Expected result - all mysqld services restored successfully.
    """
    target_cluster.check.check_ha_kill_mariadb_cluster()


@pytest.mark.parametrize("_", ["CLUSTER_NAME={0}"
                               .format(settings.TARGET_CLUSTER)])
@pytest.mark.usefixtures("collect_downtime_statistics")     # Should be used if ALLOW_WORKLOAD == True
@pytest.mark.usefixtures("check_heat_stacks_after_test")
def test_ha_kill_memcached(target_cluster: Cluster, cluster_condition_check, _):
    """Kill memcached service on every cluster node (one at a time)

    Executed only on MOSK cluster

    Precondition - all expected pods and their replicas must be presented
    The following scenario is executed for every node

    Scenario:
        1. SSH to node
        2. Kill memcached service
        3. Check memcached become ready
        4. Check that all pods are Running and Ready

    Expected result - all memcached services restored successfully.
    """
    target_cluster.check.check_ha_kill_memcached_cluster()


@pytest.mark.parametrize("_", ["CLUSTER_NAME={0}"
                               .format(settings.TARGET_CLUSTER)])
@pytest.mark.usefixtures("collect_downtime_statistics")     # Should be used if ALLOW_WORKLOAD == True
@pytest.mark.usefixtures("check_heat_stacks_after_test")
def test_ha_kill_etcd(target_cluster: Cluster, cluster_condition_check, _):
    """Kill etcd service on every cluster node (one at a time)

    Executed only on MOSK cluster

    Precondition - all expected pods and their replicas must be presented
    The following scenario is executed for every node

    Scenario:
        1. SSH to node
        2. Kill etcd service
        3. Check etcd become ready
        4. Check that all pods are Running and Ready

    Expected result - all etcd services restored successfully.
    """
    target_cluster.check.check_ha_kill_etcd_cluster()


@pytest.mark.parametrize("_", ["CLUSTER_NAME={0}"
                               .format(settings.TARGET_CLUSTER)])
@pytest.mark.usefixtures("collect_downtime_statistics")     # Should be used if ALLOW_WORKLOAD == True
@pytest.mark.usefixtures("check_heat_stacks_after_test")
def test_ha_kill_rabbitmq(target_cluster: Cluster, cluster_condition_check, _):
    """Kill rabbitmq service

    Executed only on MOSK cluster

    Precondition - all expected pods and their replicas must be presented
    The following scenario is executed for every node

    Scenario:
        1. Found node where rabbitmq is running
        2. SSH to node
        3. Kill rabbitmq service
        4. Check rabbitmq become ready
        5. Check that all pods are Running and Ready

    Expected result - rabbitmq services restored successfully.
    """
    target_cluster.check.check_ha_kill_rabbitmq()


@pytest.mark.parametrize("_", ["CLUSTER_NAME={0}"
                               .format(settings.TARGET_CLUSTER)])
@pytest.mark.usefixtures("collect_downtime_statistics")     # Should be used if ALLOW_WORKLOAD == True
@pytest.mark.usefixtures("check_heat_stacks_after_test")
def test_ha_kill_neutron_rabbitmq(target_cluster: Cluster, cluster_condition_check, _):
    """Kill neutron rabbitmq service

    Executed only on MOSK cluster

    Precondition - all expected pods and their replicas must be presented
    The following scenario is executed for every node

    Scenario:
        1. Found node where rabbitmq is running
        2. SSH to node
        3. Kill rabbitmq service
        4. Check rabbitmq become ready
        5. Check that all pods are Running and Ready

    Expected result - rabbitmq services restored successfully.
    """
    target_cluster.check.check_ha_kill_neutron_rabbitmq()


@pytest.mark.parametrize("_", ["CLUSTER_NAME={0}"
                               .format(settings.TARGET_CLUSTER)])
@pytest.mark.usefixtures("collect_downtime_statistics")     # Should be used if ALLOW_WORKLOAD == True
@pytest.mark.usefixtures("check_heat_stacks_after_test")
def test_ha_kill_neutron_ovs_agent(target_cluster: Cluster, cluster_condition_check, _):
    """Kill neutron osv service

    Executed only on MOSK cluster

    Precondition - all expected pods and their replicas must be presented
    The following scenario is executed for every node

    Scenario:
        1. Found node where ovs-agent is running
        2. SSH to node
        3. Kill ovs-agent service
        4. Check ovs-agent become ready
        5. Check that all pods are Running and Ready

    Expected result - ovs-agent services restored successfully.
    """
    target_cluster.check.check_ha_kill_neutron_ovs_agent()


@pytest.mark.parametrize("_", ["CLUSTER_NAME={0}"
                               .format(settings.TARGET_CLUSTER)])
@pytest.mark.usefixtures("collect_downtime_statistics")     # Should be used if ALLOW_WORKLOAD == True
@pytest.mark.usefixtures("check_heat_stacks_after_test")
def test_ha_kill_neutron_l3_agent(target_cluster: Cluster, cluster_condition_check, _):
    """Kill neutron l3 service

    Executed only on MOSK cluster

    Precondition - all expected pods and their replicas must be presented
    The following scenario is executed for every node

    Scenario:
        1. Found node where l3-agent is running
        2. SSH to node
        3. Kill l3-agent service
        4. Check l3-agent become ready
        5. Check that all pods are Running and Ready

    Expected result - l3-agent services restored successfully.
    """
    target_cluster.check.check_ha_kill_neutron_l3_agent()


@pytest.mark.parametrize("_", ["CLUSTER_NAME={0}"
                               .format(settings.TARGET_CLUSTER)])
@pytest.mark.usefixtures("collect_downtime_statistics")     # Should be used if ALLOW_WORKLOAD == True
@pytest.mark.usefixtures("check_heat_stacks_after_test")
def test_ha_kill_neutron_dhcp_agent(target_cluster: Cluster, cluster_condition_check, _):
    """Kill neutron dhcp service

    Executed only on MOSK cluster

    Precondition - all expected pods and their replicas must be presented
    The following scenario is executed for every node

    Scenario:
        1. Found node where dhcp-agent is running
        2. SSH to node
        3. Kill dhcp-agent service
        4. Check dhcp-agent become ready
        5. Check that all pods are Running and Ready

    Expected result - dhcp-agent services restored successfully.
    """
    target_cluster.check.check_ha_kill_neutron_dhcp_agent()


@pytest.mark.parametrize("_", ["CLUSTER_NAME={0}"
                               .format(settings.TARGET_CLUSTER)])
@pytest.mark.usefixtures("collect_downtime_statistics")     # Should be used if ALLOW_WORKLOAD == True
@pytest.mark.usefixtures("check_heat_stacks_after_test")
def test_ha_kill_tf_control(target_cluster: Cluster, cluster_condition_check, _):
    """Kill contrail-control

    Executed only on MOSK cluster with TF

    Precondition - all expected pods and their replicas must be presented
    The following scenario is executed for every node

    Scenario:
        1. Found nodes where contrail-control is running
        2. SSH to node
        3. Kill contrail-control service
        4. Check contrail-control become ready
        5. Check that all pods are Running and Ready

    Expected result - contrail-control services restored successfully.
    """
    target_cluster.check.check_ha_kill_tf_control()


@pytest.mark.parametrize("_", ["CLUSTER_NAME={0}"
                               .format(settings.TARGET_CLUSTER)])
@pytest.mark.usefixtures("collect_downtime_statistics")     # Should be used if ALLOW_WORKLOAD == True
@pytest.mark.usefixtures("check_heat_stacks_after_test")
def test_ha_kill_tf_kafka(target_cluster: Cluster, cluster_condition_check, _):
    """Kill tf kafka

    Executed only on MOSK cluster with TF

    Precondition - all expected pods and their replicas must be presented
    The following scenario is executed for every node

    Scenario:
        1. Found nodes where tf kafka is running
        2. SSH to node
        3. Kill tf kafka service
        4. Check tf kafka become ready
        5. Check that all pods are Running and Ready

    Expected result - tf kafka services restored successfully.
    """
    target_cluster.check.check_ha_kill_tf_kafka()


@pytest.mark.parametrize("_", ["CLUSTER_NAME={0}"
                               .format(settings.TARGET_CLUSTER)])
@pytest.mark.usefixtures("collect_downtime_statistics")     # Should be used if ALLOW_WORKLOAD == True
@pytest.mark.usefixtures("check_heat_stacks_after_test")
def test_ha_kill_tf_zookeeper(target_cluster: Cluster, cluster_condition_check, _):
    """Kill tf zookeeper

    Executed only on MOSK cluster with TF

    Precondition - all expected pods and their replicas must be presented
    The following scenario is executed for every node

    Scenario:
        1. Found nodes where tf zookeeper is running
        2. SSH to node
        3. Kill tf zookeeper service
        4. Check tf zookeeper become ready
        5. Check that all pods are Running and Ready

    Expected result - tf zookeeper services restored successfully.
    """
    target_cluster.check.check_ha_kill_tf_zookeeper()


@pytest.mark.parametrize("_", ["CLUSTER_NAME={0}"
                               .format(settings.TARGET_CLUSTER)])
@pytest.mark.usefixtures("collect_downtime_statistics")     # Should be used if ALLOW_WORKLOAD == True
@pytest.mark.usefixtures("check_heat_stacks_after_test")
def test_ha_kill_tf_zookeeper_nal(target_cluster: Cluster, cluster_condition_check, _):
    """Kill tf zookeeper nal

    Executed only on MOSK cluster with TF

    Precondition - all expected pods and their replicas must be presented
    The following scenario is executed for every node

    Scenario:
        1. Found nodes where tf zookeeper nal is running
        2. SSH to node
        3. Kill tf zookeeper nal service
        4. Check tf zookeeper nal become ready
        5. Check that all pods are Running and Ready

    Expected result - tf zookeeper nal services restored successfully.
    """
    target_cluster.check.check_ha_kill_tf_zookeeper_nal()


@pytest.mark.parametrize("_", ["CLUSTER_NAME={0}"
                               .format(settings.TARGET_CLUSTER)])
@pytest.mark.usefixtures("collect_downtime_statistics")     # Should be used if ALLOW_WORKLOAD == True
@pytest.mark.usefixtures("check_heat_stacks_after_test")
def test_ha_kill_tf_rabbitmq(target_cluster: Cluster, cluster_condition_check, _):
    """Kill tf rabbitmq nal

    Executed only on MOSK cluster with TF

    Precondition - all expected pods and their replicas must be presented
    The following scenario is executed for every node

    Scenario:
        1. Found nodes where tf rabbitmq nal is running
        2. SSH to node
        3. Kill tf rabbitmq nal service
        4. Check tf rabbitmq nal become ready
        5. Check that all pods are Running and Ready

    Expected result - tf rabbitmq nal services restored successfully.
    """
    target_cluster.check.check_ha_kill_tf_rabbitmq()


@pytest.mark.parametrize("_", ["CLUSTER_NAME={0}"
                               .format(settings.TARGET_CLUSTER)])
@pytest.mark.usefixtures("collect_downtime_statistics")     # Should be used if ALLOW_WORKLOAD == True
@pytest.mark.usefixtures("check_heat_stacks_after_test")
def test_ha_kill_tf_redis(target_cluster: Cluster, cluster_condition_check, _):
    """Kill tf redis

    Executed only on MOSK cluster with TF

    Precondition - all expected pods and their replicas must be presented
    The following scenario is executed for every node

    Scenario:
        1. Found nodes where tf redis is running
        2. SSH to node
        3. Kill tf redis service
        4. Check tf redis become ready
        5. Check that all pods are Running and Ready

    Expected result - tf redis services restored successfully.
    """
    target_cluster.check.check_ha_kill_tf_redis()


@pytest.mark.parametrize("_", ["CLUSTER_NAME={0}"
                               .format(settings.TARGET_CLUSTER)])
@pytest.mark.usefixtures("collect_downtime_statistics")     # Should be used if ALLOW_WORKLOAD == True
@pytest.mark.usefixtures("check_heat_stacks_after_test")
def test_ha_kill_libvirt(target_cluster: Cluster, cluster_condition_check, _):
    """Kill libvirt

    Executed only on MOSK cluster with

    Precondition - all expected pods and their replicas must be presented
    The following scenario is executed for every node

    Scenario:
        1. Found nodes where libvirt is running
        2. SSH to node
        3. Kill libvirt service
        4. Check libvirt become ready
        5. Check that all pods are Running and Ready

    Expected result - libvirt services restored successfully.
    """
    target_cluster.check.check_ha_kill_libvirt()
