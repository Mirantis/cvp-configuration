from collections import Counter

import pytest
from kubernetes.client.rest import ApiException

from si_tests import logger
from si_tests import settings
from si_tests.managers.kaas_manager import Namespace, Cluster
from si_tests.utils import waiters, utils

LOG = logger.logger


def check_cluster_readiness(cluster: Cluster):
    LOG.info(f"Check cluster '{cluster.name}' readiness")
    cluster.check.check_machines_status()
    cluster.check.check_k8s_nodes()
    cluster.check.check_k8s_pods()
    cluster.check.check_actual_expected_pods()
    cluster.check.check_cluster_readiness()
    LOG.info(f"Cluster '{cluster.name}' readiness checked\n")


def check_svc_host(cluster, times=5, failure_threshold=1):
    """
    Check SVC host external IP is available
    Args:
        cluster: current cluster
        times: num attempts to check
        failure_threshold: allowed value of error answers

    Returns:

    """
    services = {}
    status_ok = "OK"
    status_err = "Err"
    for service in cluster.k8sclient.services.list_all():
        if ip := service.get_external_ip():
            for port in service.get_ports():
                if port.target_port in ['http', 'https']:
                    services.update({service.name: {ip: port.port}})
    LOG.info("Check services:\n{}".format("\n".join(services.keys())))

    def _check_svc():
        failed_svc = []
        for service_name, service_url in services.items():
            (host, port), = service_url.items()
            result = []
            for i in range(times):
                res = waiters.tcp_ping(host, port)
                result.append(status_ok) if res else result.append(status_err)
            LOG.debug("Connect to {}:{} Result: {}".format(host, port, ", ".join(result)))
            statuses = Counter(result)
            if status_err in statuses and statuses[status_err] > failure_threshold:
                failed_svc.append(service_name)

        if failed_svc:
            LOG.info(f"The following services are not available over tcp: {failed_svc}")
        return not bool(failed_svc)

    # TODO decrease interval and timeout after implement https://mirantis.jira.com/browse/PRODX-28494
    waiters.wait(lambda: _check_svc(), interval=30, timeout=settings.HA_SVC_TIMEOUT,
                 timeout_msg=f"Downtime of some services is longer than expected {settings.HA_SVC_TIMEOUT} seconds")


def check_admission_controller(kaas_manager):
    rnd_string = utils.gen_random_string(4)
    cluster_name = f'test-ha-cl-{rnd_string}'
    namespace_name = f'test-ha-ns-{rnd_string}'
    LOG.info("Namespace name - %s", namespace_name)
    ns = kaas_manager.create_namespace(namespace_name)
    mgmt_cluster = kaas_manager.get_mgmt_cluster()
    release_name = mgmt_cluster.clusterrelease_version
    region = mgmt_cluster.region_name
    try:
        ns.create_cluster(
            cluster_name,
            release_name,
            region=region,
            credentials_name=f"fake_creds_{rnd_string}",
            provider="baremetal",
            public_key_name=f"fake_public_key_{rnd_string}")

    except ApiException as e:
        if 'admission webhook \\"validations.kaas.mirantis.com\\" denied the request' in e.body:
            LOG.info("Admission Controller checked")
        else:
            LOG.error(e)
            raise e
    finally:
        ns.delete()
        ns.wait_for_deletion()


@pytest.mark.usefixtures("collect_downtime_statistics")     # Should be used if ALLOW_WORKLOAD == True
@pytest.mark.usefixtures('log_method_time')
@pytest.mark.usefixtures("check_stacklight_svc_downtime")
def test_ha_abnormal_shutdown_mgmt_vip(kaas_manager, show_step):
    """Abnormal shutdown of VIP nodes in mgmt cluster.
    Check on each unique node where VIP migrates.

    Scenario:
            1. Shutdown node that is VIP
            2. Check services external IP availability
            3. Check that leader pods migrate from powered off node
            4. Check admission controller
            5. Check child cluster(s)
            6. Power on node
            7. Check that VIP migrated
            8. Check mgmt cluster
            9. Check child cluster(s)

    """

    managed_ns: Namespace = kaas_manager.get_namespace(settings.TARGET_NAMESPACE)
    mgmt_cluster: Cluster = managed_ns.get_cluster(settings.TARGET_CLUSTER)

    control_machines = mgmt_cluster.get_machines(machine_type='control')
    checked_machines = []
    child_clusters = kaas_manager.get_child_clusters()

    for i in range(len(control_machines)):
        current_keepalive = mgmt_cluster.get_keepalive_master_machine()
        current_keepalive_k8s_node_name = current_keepalive.get_k8s_node_name()

        if current_keepalive.name in checked_machines:
            LOG.info("Keepalive migrated to already checked machine")
            break
        else:
            LOG.info(f"Keepalive assigned to a not checked machine {current_keepalive.name}")
            checked_machines.append(current_keepalive.name)

        machine_ip = current_keepalive.public_ip or current_keepalive.internal_ip

        show_step(1)
        current_keepalive.set_baremetalhost_power(online=False)

        LOG.info("Wait until machine is no longer available via ICMP")
        waiters.wait(lambda: not waiters.icmp_ping(machine_ip), interval=5, timeout=600)

        LOG.info("Wait until k8s node status to be Not Ready")
        mgmt_cluster.check.wait_k8s_node_status(current_keepalive_k8s_node_name, expected_status='NotReady',
                                                timeout=1800)

        show_step(2)
        check_svc_host(mgmt_cluster)

        show_step(3)
        mgmt_cluster.check.wait_leader_migrate_from_node(node_name=current_keepalive_k8s_node_name)

        show_step(4)
        check_admission_controller(kaas_manager)

        show_step(5)
        for child_cluster in child_clusters:
            check_cluster_readiness(child_cluster)

        show_step(6)
        current_keepalive.set_baremetalhost_power(online=True)

        LOG.info("Wait until machine is available via ICMP")
        waiters.wait(lambda: waiters.icmp_ping(machine_ip), interval=5, timeout=600)

        LOG.info("Wait until k8s node status to be Ready")
        mgmt_cluster.check.wait_k8s_node_status(current_keepalive_k8s_node_name, expected_status='Ready',
                                                timeout=1800)

        show_step(7)
        new_keepalive = mgmt_cluster.get_keepalive_master_machine()
        assert new_keepalive is not current_keepalive, "Keepalive machine has not been changed"

        show_step(8)
        check_cluster_readiness(mgmt_cluster)

        show_step(9)
        for child_cluster in child_clusters:
            check_cluster_readiness(child_cluster)
