"""Engine-agnostic HA tests for the management cluster.

These run the same scenario on both LCM engines (MKE / k0s) via the
``cluster.lcm_engine`` abstraction, instead of talking to Docker directly.
Verified against management cluster on lab system-phys-1460 (k0s,
v1.33.13+k0s, 3 control nodes).
"""
import pytest

from si_tests import logger
from si_tests import settings

LOG = logger.logger


@pytest.mark.lcm_agnostic
@pytest.mark.parametrize("_", [f"CLUSTER_NAME={settings.TARGET_CLUSTER}"])
@pytest.mark.usefixtures("collect_downtime_statistics")
@pytest.mark.usefixtures("mcc_loadtest_mke_api")
def test_ha_restart_lcm_engine(target_cluster, cluster_condition_check, _):
    """Restart the node LCM engine on each control node (MKE: docker.service,
    k0s: k0scontroller.service) and verify the control plane recovers.

    Precondition - all expected pods and their replicas are present.

    Scenario:
        1. For every control node, one at a time:
        2. Restart the LCM engine daemon
        3. Wait until the engine reports a healthy control plane
        4. Wait until all pods are Running and Ready

    Expected result - the LCM engine and control plane recover on every node.
    """
    target_cluster.check.check_ha_restart_lcm_engine()


@pytest.mark.lcm_agnostic
@pytest.mark.parametrize("_", [f"CLUSTER_NAME={settings.TARGET_CLUSTER}"])
@pytest.mark.usefixtures("collect_downtime_statistics")
@pytest.mark.usefixtures("mcc_loadtest_mke_api")
def test_ha_kill_control_components(target_cluster, cluster_condition_check, _):
    """Kill control-plane components on each control node and verify the
    engine supervisor restarts them.

    On MKE the ``ucp-*`` containers are killed; on k0s the host processes
    supervised by k0s (kube-apiserver, kube-scheduler, kube-controller-manager,
    etcd) are killed.

    Precondition - all expected pods and their replicas are present.

    Scenario:
        1. For every control node, one at a time:
        2. SIGKILL each control-plane component
        3. Wait until the supervisor restarts it
        4. Wait until all pods are Running and Ready

    Expected result - every component is auto-restarted; control plane healthy.
    """
    target_cluster.check.check_ha_kill_control_components()
