import pytest

from si_tests import logger
from si_tests.managers.kaas_manager import Cluster
from si_tests import settings

LOG = logger.logger


@pytest.mark.parametrize("_", ["CLUSTER_NAME={0}"
                               .format(settings.TARGET_CLUSTER)])
def test_ha_kill_mariadb(target_cluster: Cluster, cluster_condition_check, _):
    """Kill mysqld service on every cluster node (one at a time)

    Precondition - all expected pods and their replicas must be presented
    The following scenario is executed for every node

    Scenario:
        1. SSH to node
        2. Kill patroni-13 service
        3. Check patroni-13 become ready
        4. Check that all pods are Running and Ready

    Expected result - all mysqld services restored successfully.
    """
    target_cluster.check.check_ha_kill_patroni_cluster()


@pytest.mark.parametrize("_", ["CLUSTER_NAME={0}"
                               .format(settings.TARGET_CLUSTER)])
def test_ha_fluentd_logs(target_cluster: Cluster, cluster_condition_check, _):
    """Check fluentd logs

    Precondition - all expected pods and their replicas must be presented
    The following scenario is executed for every node

        Scenario:
            1. SSH to node
            2. Kill fluentd logs service
            3. Check fluentd logs become ready
            4. Check that all pods are Running and Ready

    Expected result - fluentd logs are empty.
    """
    target_cluster.check.check_ha_klll_fluentd_logs()


@pytest.mark.parametrize("_", ["CLUSTER_NAME={0}"
                               .format(settings.TARGET_CLUSTER)])
def test_ha_cadvisor(target_cluster: Cluster, cluster_condition_check, _):
    """Kill cadvisor service on every cluster node (one at a time)

    Precondition - all expected pods and their replicas must be presented
    The following scenario is executed for every node

    Scenario:
        1. SSH to node
        2. Kill cadvisor service
        3. Check cadvisor become ready
        4. Check that all pods are Running and Ready

    Expected result - all cadvisor services restored successfully.
    """
    target_cluster.check.check_ha_kill_cadvisor()


@pytest.mark.parametrize("_", ["CLUSTER_NAME={0}"
                               .format(settings.TARGET_CLUSTER)])
def test_ha_alerta(target_cluster: Cluster, cluster_condition_check, _):
    """Kill alerta service on every cluster node (one at a time)

    Precondition - all expected pods and their replicas must be presented
    The following scenario is executed for every node

    Scenario:
        1. SSH to node
        2. Kill alerta service
        3. Check alerta become ready
        4. Check that all pods are Running and Ready

    Expected result - all alerta services restored successfully.
    """
    target_cluster.check.check_ha_kill_alerta()


@pytest.mark.parametrize("_", ["CLUSTER_NAME={0}"
                               .format(settings.TARGET_CLUSTER)])
def test_ha_opensearch_master(target_cluster: Cluster, cluster_condition_check, _):
    """Kill opensearch master service on every cluster node (one at a time)

    Precondition - all expected pods and their replicas must be presented
    The following scenario is executed for every node

    Scenario:
        1. SSH to node
        2. Kill opensearch master service
        3. Check opensearch master become ready
        4. Check that all pods are Running and Ready

    Expected result - all opensearch master services restored successfully.
    """
    target_cluster.check.check_ha_kill_opensearch_master()


@pytest.mark.parametrize("_", ["CLUSTER_NAME={0}"
                               .format(settings.TARGET_CLUSTER)])
def test_ha_node_exporter(target_cluster: Cluster, cluster_condition_check, _):
    """Kill prometheus node exporter service on every cluster node (one at a time)

    Precondition - all expected pods and their replicas must be presented
    The following scenario is executed for every node

    Scenario:
        1. SSH to node
        2. Kill prometheus node exporter service
        3. Check prometheus node exporter become ready
        4. Check that all pods are Running and Ready

    Expected result - all prometheus node exporter services restored successfully.
    """
    target_cluster.check.check_ha_kill_prometheus_node_exporter()


# telegraf-ds-smart - checker done
@pytest.mark.parametrize("_", ["CLUSTER_NAME={0}"
                               .format(settings.TARGET_CLUSTER)])
def test_ha_telegraf_ds_smart(target_cluster: Cluster, cluster_condition_check, _):
    """Kill telegraf ds smart service on every cluster node (one at a time)

    Precondition - all expected pods and their replicas must be presented
    The following scenario is executed for every node

    Scenario:
        1. SSH to node
        2. Kill telegraf ds smart service
        3. Check telegraf ds smart become ready
        4. Check that all pods are Running and Ready

    Expected result - all telegraf ds smart services restored successfully.
    """
    target_cluster.check.check_ha_kill_telegraf_ds_smart()


@pytest.mark.parametrize("_", ["CLUSTER_NAME={0}"
                               .format(settings.TARGET_CLUSTER)])
def test_ha_telemeter_server(target_cluster: Cluster, cluster_condition_check, _):
    """Kill telemeter server service on every cluster node (one at a time)

    Precondition - all expected pods and their replicas must be presented
    The following scenario is executed for every node

    Scenario:
        1. SSH to node
        2. Kill telemeter server service
        3. Check telemeter server become ready
        4. Check that all pods are Running and Ready

    Expected result - all telemeter server services restored successfully.
    """
    target_cluster.check.check_ha_kill_telemeter_server()


@pytest.mark.parametrize("_", ["CLUSTER_NAME={0}"
                               .format(settings.TARGET_CLUSTER)])
def test_ha_telegraf_docker_swarm(target_cluster: Cluster, cluster_condition_check, _):
    """Kill telegraf docker swarm service on every cluster node (one at a time)

    Precondition - all expected pods and their replicas must be presented
    The following scenario is executed for every node

    Scenario:
        1. SSH to node
        2. Kill telegraf docker swarm service
        3. Check telegraf docker swarm become ready
        4. Check that all pods are Running and Ready

    Expected result - all telegraf docker swarm services restored successfully.
    """
    target_cluster.check.check_ha_kill_telegraf_docker_swarm()


@pytest.mark.parametrize("_", ["CLUSTER_NAME={0}"
                               .format(settings.TARGET_CLUSTER)])
def test_ha_prometheus_relay(target_cluster: Cluster, cluster_condition_check, _):
    """Kill prometheus relay service on every cluster node (one at a time)

    Precondition - all expected pods and their replicas must be presented
    The following scenario is executed for every node

    Scenario:
        1. SSH to node
        2. Kill prometheus relay service
        3. Check prometheus relay become ready
        4. Check that all pods are Running and Ready

    Expected result - all prometheus relay services restored successfully.
    """
    target_cluster.check.check_ha_kill_prometheus_relay()


@pytest.mark.parametrize("_", ["CLUSTER_NAME={0}"
                               .format(settings.TARGET_CLUSTER)])
def test_ha_prometheus_kube_state_metrics(target_cluster: Cluster, cluster_condition_check, _):
    """Kill prometheus kube state metrics service on every cluster node (one at a time)

    Precondition - all expected pods and their replicas must be presented
    The following scenario is executed for every node

    Scenario:
        1. SSH to node
        2. Kill prometheus kube state metrics service
        3. Check prometheus kube state metrics become ready
        4. Check that all pods are Running and Ready

    Expected result - all prometheus kube state metrics services restored successfully.
    """
    target_cluster.check.check_ha_kill_prometheus_kube_state_metrics()


@pytest.mark.parametrize("_", ["CLUSTER_NAME={0}"
                               .format(settings.TARGET_CLUSTER)])
def test_ha_prometheus_es_exporter(target_cluster: Cluster, cluster_condition_check, _):
    """Kill prometheus es exporter service on every cluster node (one at a time)

    Precondition - all expected pods and their replicas must be presented
    The following scenario is executed for every node

    Scenario:
        1. SSH to node
        2. Kill prometheus es exporter service
        3. Check prometheus es exporter become ready
        4. Check that all pods are Running and Ready

    Expected result - all prometheus es exporter services restored successfully.
    """
    target_cluster.check.check_ha_kill_prometheus_es_exporter()


@pytest.mark.parametrize("_", ["CLUSTER_NAME={0}"
                               .format(settings.TARGET_CLUSTER)])
def test_ha_prometheus_blackbox_exporter(target_cluster: Cluster, cluster_condition_check, _):
    """Kill prometheus blackbox exporter service on every cluster node (one at a time)

    Precondition - all expected pods and their replicas must be presented
    The following scenario is executed for every node

    Scenario:
        1. SSH to node
        2. Kill prometheus blackbox exporter service
        3. Check prometheus blackbox exporter become ready
        4. Check that all pods are Running and Ready

    Expected result - all prometheus blackbox exporter services restored successfully.
    """
    target_cluster.check.check_ha_kill_prometheus_blackbox_exporter()


@pytest.mark.parametrize("_", ["CLUSTER_NAME={0}"
                               .format(settings.TARGET_CLUSTER)])
def test_ha_elasticsearch_exporter(target_cluster: Cluster, cluster_condition_check, _):
    """Kill elasticsearch exporter service on every cluster node (one at a time)

    Precondition - all expected pods and their replicas must be presented
    The following scenario is executed for every node

    Scenario:
        1. SSH to node
        2. Kill elasticsearch exporter service
        3. Check elasticsearch exporter become ready
        4. Check that all pods are Running and Ready

    Expected result - all elasticsearch exporter services restored successfully.
    """
    target_cluster.check.check_ha_kill_elasticsearch_exporter()


@pytest.mark.parametrize("_", ["CLUSTER_NAME={0}"
                               .format(settings.TARGET_CLUSTER)])
def test_ha_opensearch_dashboards(target_cluster: Cluster, cluster_condition_check, _):
    """Kill opensearch dashboards service on every cluster node (one at a time)

    Precondition - all expected pods and their replicas must be presented
    The following scenario is executed for every node

    Scenario:
        1. SSH to node
        2. Kill opensearch dashboards service
        3. Check opensearch dashboards become ready
        4. Check that all pods are Running and Ready

    Expected result - all opensearch dashboards services restored successfully.
    """
    target_cluster.check.check_ha_kill_opensearch_dashboards()


@pytest.mark.parametrize("_", ["CLUSTER_NAME={0}"
                               .format(settings.TARGET_CLUSTER)])
def test_ha_metricbeat(target_cluster: Cluster, cluster_condition_check, _):
    """Kill metricbeat service on every cluster node (one at a time)

    Precondition - all expected pods and their replicas must be presented
    The following scenario is executed for every node

    Scenario:
        1. SSH to node
        2. Kill metricbeat service
        3. Check metricbeat become ready
        4. Check that all pods are Running and Ready

    Expected result - all metricbeat services restored successfully.
    """
    target_cluster.check.check_ha_kill_metricbeat()


@pytest.mark.parametrize("_", ["CLUSTER_NAME={0}"
                               .format(settings.TARGET_CLUSTER)])
def test_ha_metric_collector(target_cluster: Cluster, cluster_condition_check, _):
    """Kill metric collector service on every cluster node (one at a time)

    Precondition - all expected pods and their replicas must be presented
    The following scenario is executed for every node
    Scenario:
        1. SSH to node
        2. Kill metric collector service
        3. Check metric collector become ready
        4. Check that all pods are Running and Ready
    Expected result - all metric collector services restored successfully.
    """
    target_cluster.check.check_ha_kill_metric_collector()


@pytest.mark.parametrize("_", ["CLUSTER_NAME={0}"
                               .format(settings.TARGET_CLUSTER)])
def test_ha_grafana(target_cluster: Cluster, cluster_condition_check, _):
    """Kill grafana service on every cluster node (one at a time)

    Precondition - all expected pods and their replicas must be presented
    The following scenario is executed for every node
    Scenario:
        1. SSH to node
        2. Kill grafana service
        3. Check grafana become ready
        4. Check that all pods are Running and Ready
    Expected result - all grafana services restored successfully.
    """
    target_cluster.check.check_ha_kill_grafana()


@pytest.mark.parametrize("_", ["CLUSTER_NAME={0}"
                               .format(settings.TARGET_CLUSTER)])
def test_ha_prometheus_alertmanager(target_cluster: Cluster, cluster_condition_check, _):
    """Kill prometheus alertmanager service on every cluster node (one at a time)

    Precondition - all expected pods and their replicas must be presented
    The following scenario is executed for every node
    Scenario:
        1. SSH to node
        2. Kill prometheus alertmanager service
        3. Check prometheus alertmanager become ready
        4. Check that all pods are Running and Ready
    Expected result - all prometheus alertmanager services restored successfully.
    """
    target_cluster.check.check_ha_kill_prometheus_alertmanager()


@pytest.mark.parametrize("_", ["CLUSTER_NAME={0}"
                               .format(settings.TARGET_CLUSTER)])
def test_ha_prometheus_server(target_cluster: Cluster, cluster_condition_check, _):
    """Kill prometheus server service on every cluster node (one at a time)

    Precondition - all expected pods and their replicas must be presented
    The following scenario is executed for every node
    Scenario:
        1. SSH to node
        2. Kill prometheus server service
        3. Check prometheus server become ready
        4. Check that all pods are Running and Ready
    Expected result - all prometheus server services restored successfully.
    """
    target_cluster.check.check_ha_kill_prometheus_server()
