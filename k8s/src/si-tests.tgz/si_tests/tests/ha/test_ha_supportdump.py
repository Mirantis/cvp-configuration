# Copyright 2026 Mirantis, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License"); you may
# not use this file except in compliance with the License. You may obtain
# a copy of the License at
#
#      http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
# WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
# License for the specific language governing permissions and limitations
# under the License.

import pytest

from si_tests import logger, settings
from si_tests.fixtures.mcc_supportdump import check_supportdump_dump_in_pod, ensure_supportdump_is_not_present
from si_tests.managers.support_dumps_manager import SupportDumpManager
from si_tests.utils import waiters

LOG = logger.logger

REBOOT_CMD = 'sudo systemctl --force reboot'


def _reboot_supportdump_machine_and_wait_recovery(cluster, machine):
    """Soft reboot a machine and wait until the node and the cluster are healthy again."""
    k8s_node_name = machine.get_k8s_node_name()
    machine_ip = machine.public_ip

    LOG.info(f"Rebooting node {k8s_node_name} ({machine_ip})")
    try:
        machine.run_cmd(REBOOT_CMD, check_exit_code=False, timeout=10)
    except Exception:
        LOG.info("Current SSH connection closed by timeout since we performed a reboot")

    LOG.info(f"Wait until node {k8s_node_name} is no longer available via ICMP")
    waiters.wait(lambda: not waiters.icmp_ping(machine_ip), interval=5, timeout=1200)

    LOG.info(f"Wait until k8s node {k8s_node_name} becomes NotReady")
    cluster.check.wait_k8s_node_status(k8s_node_name, expected_status='NotReady', timeout=900)

    LOG.info(f"Wait until node {k8s_node_name} is available via ICMP")
    waiters.wait(lambda: waiters.icmp_ping(machine_ip), interval=5, timeout=1800)

    LOG.info(f"Wait until k8s node {k8s_node_name} becomes Ready")
    cluster.check.wait_k8s_node_status(k8s_node_name, expected_status='Ready', timeout=1800)

    LOG.info(f"Wait until cluster {cluster.name} is stable after the reboot of {k8s_node_name}")
    cluster.check.check_k8s_nodes(timeout=1800)
    cluster.check.check_cluster_readiness()


def _get_machine_for_supportdump_pod(kaas_manager, pod_name):
    """Resolve the management cluster Machine hosting a given supportdump-controller pod."""
    pod = kaas_manager.api.pods.get(name=pod_name, namespace='kaas')
    node_name = pod.node_name
    mgmt_cluster = kaas_manager.get_mgmt_cluster()
    machine = next((m for m in mgmt_cluster.get_machines() if m.get_k8s_node_name() == node_name), None)
    assert machine, f"Could not find a Machine for node {node_name} hosting {pod_name}"
    return mgmt_cluster, machine


def _wait_supportdump_podname(sd_manager, name, timeout=120, interval=5):
    """Wait until a SupportDump's status.podName is populated and return it."""
    def _get_pod_name():
        sd_status = sd_manager.get_supportdumps(name=name).data.get('status') or {}
        return sd_status.get('podName')

    waiters.wait(_get_pod_name, timeout=timeout, interval=interval,
                 timeout_msg=f"SupportDump {name} status has no podName after {timeout} sec")
    return _get_pod_name()


@pytest.mark.parametrize("_", [f"CLUSTER_NAME={settings.TARGET_CLUSTER}"])
@pytest.mark.usefixtures("supportdump_cleanup")
def test_ha_supportdump_controller_node_failure_during_collection(kaas_manager, _, show_step):
    """Verify that if the node hosting supportdump-controller fails during collection,
    the collection is automatically restarted once the node/pod recover.

    Scenario:
        1. Create a SupportDump for TARGET_CLUSTER
        2. Soft reboot the node hosting supportdump-controller leader pod while collection is in progress
        3. Wait until the node, the management cluster and the controller pod are healthy again
        4. Wait until the SupportDump reaches 'Completed' status and every collector completed
    """
    # supportdump-controller is a single-replica StatefulSet pinned to its node by a local PV,
    # so a real permanent node loss would require an operator to manually rebind the PVC to a
    # different node before the pod can migrate there. This test covers the automatable
    # equivalent - a reboot of that same node - and verifies the reconciler picks
    # the collection back up once the controller is running again. Leftover partial files from
    # the interrupted attempt are not asserted on, as they are expected to be purged later by
    # the controller rather than checked here.
    cluster_namespace = settings.TARGET_NAMESPACE
    cluster_name = settings.TARGET_CLUSTER
    ns = kaas_manager.get_namespace(cluster_namespace)
    cluster = ns.get_cluster(cluster_name)

    sd_manager = SupportDumpManager(cluster)
    sd_name = sd_manager.supportdump_name

    show_step(1)
    sd_manager.create_supportdump(sd_name)

    LOG.info("Reboot machine during support dump collection. Should be restarted after the pod recovered")
    sd_manager.wait_supportdumps_status(name=sd_name, expected_status='InProgress', timeout=600)

    show_step(2)
    leader_pod_name = kaas_manager.get_mgmt_cluster().check.get_leader(app_prefix='supportdump-controller')
    mgmt_cluster, machine = _get_machine_for_supportdump_pod(kaas_manager, leader_pod_name)
    assert sd_manager.get_supportdumps_status(sd_name) == 'InProgress', \
        "Supportdump still should be InProgress before reboot"
    _reboot_supportdump_machine_and_wait_recovery(mgmt_cluster, machine)

    show_step(3)
    LOG.info("Wait until the supportdump-controller pod is Running again")
    mgmt_cluster.check.check_k8s_pods(pods_prefix='supportdump-controller', target_namespaces='kaas',
                                      timeout=600, interval=15)

    show_step(4)
    LOG.info(f"Wait for SupportDump {sd_name} to finish despite the controller node failure")
    sd_manager.wait_supportdumps_collectors_status(sd_name)
    sd_manager.wait_supportdumps_status(sd_name)


@pytest.mark.parametrize("_", [f"CLUSTER_NAME={settings.TARGET_CLUSTER}"])
@pytest.mark.usefixtures("supportdump_cleanup")
def test_ha_supportdump_controller_node_failure_after_completion(kaas_manager, _, show_step):
    """Verify that an already collected SupportDump remains intact and downloadable even if
    the node hosting supportdump-controller fails shortly afterwards, before it is downloaded.

    Scenario:
        1. Create a SupportDump for TARGET_CLUSTER and wait until it completes
        2. Soft reboot the node hosting supportdump-controller leader pod after the SupportDump completed
        3. Wait until the node, the management cluster and the controller pod are healthy again
        4. Verify the collected dump is still present in the supportdump-controller pod
    """
    cluster_namespace = settings.TARGET_NAMESPACE
    cluster_name = settings.TARGET_CLUSTER
    ns = kaas_manager.get_namespace(cluster_namespace)
    cluster = ns.get_cluster(cluster_name)

    sd_manager = SupportDumpManager(cluster)
    sd_name = sd_manager.supportdump_name

    show_step(1)
    sd_manager.create_supportdump(sd_name)
    sd_manager.wait_supportdumps_status(sd_name)

    show_step(2)
    leader_pod_name = kaas_manager.get_mgmt_cluster().check.get_leader(app_prefix='supportdump-controller')
    mgmt_cluster, machine = _get_machine_for_supportdump_pod(kaas_manager, leader_pod_name)
    _reboot_supportdump_machine_and_wait_recovery(mgmt_cluster, machine)

    show_step(3)
    LOG.info("Wait until the supportdump-controller pod is Running again")
    mgmt_cluster.check.check_k8s_pods(pods_prefix='supportdump-controller', target_namespaces='kaas',
                                      timeout=600, interval=15)

    show_step(4)
    sd = sd_manager.get_supportdumps(name=sd_name)
    check_supportdump_dump_in_pod(kaas_manager, sd)


@pytest.mark.parametrize("_", [f"CLUSTER_NAME={settings.TARGET_CLUSTER}"])
@pytest.mark.usefixtures("supportdump_cleanup")
def test_ha_supportdump_leader_failover(kaas_manager, _, show_step):
    """Verify a new SupportDump is collected by a different supportdump-controller replica
    once the node hosting the current leader is rebooted.

    Scenario:
        1. Find the current leader supportdump-controller pod via its leader-election Lease
        2. Create a SupportDump and verify it is collected by that leader pod
        3. Soft reboot the node hosting the leader pod, so a new leader gets elected
        4. Create a second SupportDump (without deleting the first)
        5. Verify the second SupportDump is collected by a different supportdump-controller pod
    """
    cluster_namespace = settings.TARGET_NAMESPACE
    cluster_name = settings.TARGET_CLUSTER
    ns = kaas_manager.get_namespace(cluster_namespace)
    cluster = ns.get_cluster(cluster_name)

    sd_manager = SupportDumpManager(cluster)
    sd_name = sd_manager.supportdump_name
    second_sd_name = f"{sd_name}-second"

    show_step(1)
    leader_pod_name = kaas_manager.get_mgmt_cluster().check.get_leader(app_prefix='supportdump-controller')
    LOG.info(f"Current supportdump-controller leader is {leader_pod_name}")

    show_step(2)
    sd_manager.create_supportdump(sd_name)
    first_pod_name = _wait_supportdump_podname(sd_manager, sd_name)
    assert first_pod_name == leader_pod_name, (
        f"Expected SupportDump {sd_name} to be collected by the leader pod {leader_pod_name}, "
        f"but it was assigned to {first_pod_name}"
    )
    sd_manager.wait_supportdumps_status(sd_name)

    show_step(3)
    mgmt_cluster, machine = _get_machine_for_supportdump_pod(kaas_manager, leader_pod_name)
    _reboot_supportdump_machine_and_wait_recovery(mgmt_cluster, machine)
    LOG.info(f"Wait until a new supportdump-controller leader is elected (not {leader_pod_name})")
    waiters.wait(lambda: kaas_manager.get_mgmt_cluster().check.get_leader(
        app_prefix='supportdump-controller') != leader_pod_name,
                 timeout=120, interval=5,
                 timeout_msg=f"No new leader was elected after {leader_pod_name}'s node was rebooted")

    show_step(4)
    try:
        first_sd = sd_manager.get_supportdumps(name=sd_name)
        sd_manager.create_supportdump(second_sd_name, spec=first_sd.data['spec'])

        show_step(5)
        second_pod_name = _wait_supportdump_podname(sd_manager, second_sd_name)
        assert second_pod_name != leader_pod_name, (
            f"Expected SupportDump {second_sd_name} to be collected by a different pod than the original "
            f"leader {leader_pod_name}, but it was assigned to the same pod"
        )
        LOG.info(f"Second SupportDump {second_sd_name} was collected by {second_pod_name}")
        sd_manager.wait_supportdumps_status(second_sd_name)
        sd_manager.wait_supportdumps_collectors_status(second_sd_name)
    finally:
        ensure_supportdump_is_not_present(kaas_manager, second_sd_name, cluster_namespace)


@pytest.mark.parametrize("_", [f"CLUSTER_NAME={settings.TARGET_CLUSTER}"])
@pytest.mark.usefixtures("supportdump_cleanup")
def test_ha_supportdump_leader_pod_deleted_during_collection(kaas_manager, _, show_step):
    """Verify that deleting the leader supportdump-controller pod while a collection is in
    progress triggers a new leader election and the SupportDump still completes.

    Scenario:
        1. Find the current leader supportdump-controller pod
        2. Create a SupportDump
        3. Wait for created SupportDump to change status to InProgress
        4. Delete leader pod, where dump in progress
        5. Check that leader pod migrated
        6. Wait for SupportDump completion
    """
    cluster_namespace = settings.TARGET_NAMESPACE
    cluster_name = settings.TARGET_CLUSTER
    ns = kaas_manager.get_namespace(cluster_namespace)
    cluster = ns.get_cluster(cluster_name)

    sd_manager = SupportDumpManager(cluster)
    sd_name = sd_manager.supportdump_name

    show_step(1)
    leader_pod_name = kaas_manager.get_mgmt_cluster().check.get_leader(app_prefix='supportdump-controller')
    LOG.info(f"Current supportdump-controller leader is {leader_pod_name}")

    show_step(2)
    sd_manager.create_supportdump(sd_name)

    show_step(3)
    sd_manager.wait_supportdumps_status(name=sd_name, expected_status='InProgress', timeout=600)

    show_step(4)
    leader_pod = kaas_manager.api.pods.get(name=leader_pod_name, namespace='kaas')
    LOG.info(f"Deleting leader pod {leader_pod_name} while SupportDump {sd_name} collection is in progress")
    leader_pod.delete()

    show_step(5)
    LOG.info(f"Wait until a new supportdump-controller leader is elected (not {leader_pod_name})")
    waiters.wait(lambda: kaas_manager.get_mgmt_cluster().check.get_leader(
        app_prefix='supportdump-controller') != leader_pod_name,
                 timeout=120, interval=5,
                 timeout_msg=f"No new leader was elected after {leader_pod_name} was deleted")

    show_step(6)
    LOG.info(f"Wait for SupportDump {sd_name} to finish despite the leader pod being deleted")
    sd_manager.wait_supportdumps_status(sd_name)
    sd_manager.wait_supportdumps_collectors_status(sd_name)
