import copy
import pytest

from si_tests import logger
from si_tests import settings
from si_tests.managers.kaas_manager import Cluster, Machine, Manager  # noqa: F401
from si_tests.managers.openstack_manager import OpenStackManager
from si_tests.managers import tungstenfafric_manager
from si_tests.utils import waiters
from si_tests.managers.machine_deletion_policy_manager import check_machine_graceful_delete
from si_tests.utils import packaging_version as version

LOG = logger.logger


def create_master_node(cluster: Cluster, machine):
    """
    Get data from previous deleted master machine and create a new one
    Args:
        cluster: current cluster object
        machine: previous deleted master machine

    Returns: Machine object

    """

    public_key_name = "{cluster_name}-key".format(
        cluster_name=cluster.name)
    machine_node_labels = machine['spec']['providerSpec']['value'].get('nodeLabels', [])
    node_labels = {item['key']: item['value'] for item in machine_node_labels}
    new_machine = cluster.create_baremetal_machine(
        genname=machine['metadata']['name'],
        node_pubkey_name=public_key_name,
        matchlabels=machine['spec']['providerSpec']['value']['hostSelector']['matchLabels'],
        baremetalhostprofile=machine['spec']['providerSpec']['value'].get('bareMetalHostProfile', None),
        l2TemplateSelector=machine['spec']['providerSpec']['value'].get('l2TemplateSelector', None),
        labels=machine['metadata']['labels'],
        node_labels=node_labels,
        distribution=machine['spec']['providerSpec']['value'].get('distribution', None),
    )

    LOG.info(f'Master machine {new_machine}')

    LOG.info(f'Check newly created machine {new_machine.name}')

    # Waiting for master node become Ready
    cluster.check.wait_machine_status_by_name(machine_name=new_machine.name,
                                              expected_status='Ready',
                                              timeout=5400)

    # Waiting for machines are Ready
    cluster.check.check_machines_status(timeout=1800)
    cluster.check.check_cluster_nodes()
    cluster.check.check_k8s_nodes()

    return new_machine


def create_bmh(secret_data, bmh_data):
    """
    Create a new BMH based on deleted

    Args:
        secret_data: bmh secret cred data
        bmh_data: bmh data

    Returns: None

    """
    kaas_manager = Manager(kubeconfig=settings.KUBECONFIG_PATH)
    managed_ns = kaas_manager.get_namespace(settings.TARGET_NAMESPACE)
    region = kaas_manager.get_mgmt_cluster().region_name

    new_bmh_name = bmh_data['metadata']['name']

    # For backward compatibility for secrets in older versions where bmh creds are not supported
    cred_name = bmh_data['spec']['bmc']['credentialsName']

    annotations = bmh_data['metadata'].get('annotations', {}) or {}
    if "kaas.mirantis.com/baremetalhost-credentials-name" in annotations:
        cred_name = bmh_data['metadata'].get('annotations', {}).get(
                    'kaas.mirantis.com/baremetalhost-credentials-name', cred_name)
        if not kaas_manager.api.kaas_baremetalhostscredentials.present(name=cred_name,
                                                                       namespace=settings.TARGET_NAMESPACE):
            managed_ns.create_baremetalhostcredential(name=cred_name, data=secret_data.data, region=region,
                                                      provider="baremetal")
        else:
            LOG.warning(f'bmhc: {cred_name} already exist, skipping')
    else:
        raise Exception("IPMI credentials supported only over baremetalhostcredentials")

    address = bmh_data['spec']['bmc']['address'].split(":")

    if len(address) == 2:
        bmh_ipmi_data = {
            "ipmi_ip": address[0],
            "port": address[1]
        }
    else:
        bmh_ipmi_data = {
            "ipmi_ip": address[0]
        }
    bootUEFI = True if bmh_data['spec'].get('bootMode', '') == 'UEFI' else False
    managed_ns.create_baremetalhost(bmh_name=new_bmh_name,
                                    bmh_secret=cred_name,
                                    bmh_mac=bmh_data['spec']['bootMACAddress'],
                                    bmh_ipmi=bmh_ipmi_data,
                                    hardwareProfile=bmh_data['spec'].get('hardwareProfile', False),
                                    labels=bmh_data['metadata']['labels'],
                                    annotations=bmh_data['metadata'].get('annotations', {}),
                                    bootUEFI=bootUEFI)

    managed_ns.wait_baremetalhosts_statuses(nodes=new_bmh_name,
                                            wait_status='ready',
                                            retries=40,
                                            interval=60)


def wait_ceph_status(cluster: Cluster, expected_status="HEALTH_OK"):
    ceph_health_details = cluster.check.get_ceph_status_details()
    current_status = ceph_health_details.get('health', {}).get('status')
    if current_status == expected_status:
        LOG.info(f"Expected Ceph status {current_status} equal to current")
        return True
    else:
        LOG.info(f"Expected Ceph status = {expected_status}, but current = {current_status}. Waiting...")
        return False


def is_precaching_required(master):
    LOG.info("Checking whether to wait image-precaching or not")
    precaching_required_labels = ['openstack-', 'openvswitch', 'tf']
    master_labels = master.get_k8s_node().data.get('metadata', {}).get('labels', {}).keys()
    for label in master_labels:
        for role in precaching_required_labels:
            if label.startswith(role):
                LOG.info("image-precaching check will be required")
                return True
    LOG.info("image-precaching check is not required")
    return False


def collect_tf_data_before_replace(cluster, master):
    tf_data = {}
    machine_is_tf_contol = False
    tfconfigdb = False
    tfanalyticsdb = False
    if [n for n in master.nodeLabels if 'tfcontrol' in n.values()]:
        machine_is_tf_contol = True
        replaced_node_k8s_name = master.get_k8s_node_name()

        # Write kubeconfig
        child_kubeconfig_name, child_kubeconfig = cluster.get_kubeconfig_from_secret()
        with open('child_conf', 'w') as f:
            f.write(child_kubeconfig)
        tf_manager = tungstenfafric_manager.TFManager(kubeconfig='child_conf')

        if [n for n in master.nodeLabels if 'tfconfigdb' in n.values()]:
            tfconfigdb = True
            LOG.info("Cassandra tfconfigdb detected")
        if [n for n in master.nodeLabels if 'tfanalyticsdb' in n.values()] and tf_manager.is_analytics_enabled():
            tfanalyticsdb = True
            LOG.info("Cassandra tfanalyticsdb detected")

        # Get PVC bounded to the local volume from the node to be removed.
        storage_class = tf_manager.get_storage_class()
        delete_pvs = [pv for pv in cluster.k8sclient.pvolumes.list_all()
                      if pv.data['spec']['storage_class_name'] == storage_class
                      and pv.data['spec']['node_affinity']['required'][
                          'node_selector_terms'][0]['match_expressions'][0][
                          'values'][0] == replaced_node_k8s_name]
        LOG.info("PVCs from node to be removed:")
        delete_pvcs = []
        for pv in delete_pvs:
            if not pv.data['spec']['claim_ref']:
                continue
            pvc_name = pv.data['spec']['claim_ref']['name']
            delete_pvcs.append(pvc_name)
            LOG.info(f"{pvc_name}")

        # Get Cassandra pod IPs from the node to be removed.
        ip_configdb = None
        ip_analyticsdb = None
        cdb_pods = []
        adb_pods = []
        if tfconfigdb:
            cdb_pods = cluster.k8sclient.pods.list_all(
                namespace=tf_manager.tf_namespace,
                name_prefix="tf-cassandra-config"
            )
            pod = [p for p in cdb_pods if p.data['spec']['node_name'] == replaced_node_k8s_name]
            assert len(pod) == 1, "tf-cassandra-config pod not found! "\
                                  "Can't get IP of cassandra configdb pod from deleted node"
            pod = pod[0]
            cdb_pods.remove(pod)
            ip_configdb = pod.data['status']['pod_ip']
            LOG.info(f"Cassandra configdb node to be removed: {ip_configdb}")
        if tfanalyticsdb:
            adb_pods = cluster.k8sclient.pods.list_all(
                namespace=tf_manager.tf_namespace,
                name_prefix="tf-cassandra-analytics"
            )
            pod = [p for p in adb_pods if p.data['spec']['node_name'] == replaced_node_k8s_name]
            assert len(pod) == 1, "tf-cassandra-analytics pod not found! "\
                                  "Can't get IP of cassandra analyticsdb pod from deleted node"
            pod = pod[0]
            adb_pods.remove(pod)
            ip_analyticsdb = pod.data['status']['pod_ip']
            LOG.info(f"Cassandra analyticsdb node to be removed: {ip_analyticsdb}")

        tf_data['machine_is_tf_contol'] = machine_is_tf_contol
        tf_data['tfconfigdb'] = tfconfigdb
        tf_data['tfanalyticsdb'] = tfanalyticsdb
        tf_data['tf_manager'] = tf_manager
        tf_data['delete_pvs'] = delete_pvs
        tf_data['delete_pvcs'] = delete_pvcs
        tf_data['ip_configdb'] = ip_configdb
        tf_data['ip_analyticsdb'] = ip_analyticsdb
        tf_data['cdb_pods'] = cdb_pods
        tf_data['adb_pods'] = adb_pods

        return tf_data
    else:
        tf_data['machine_is_tf_contol'] = machine_is_tf_contol
        return tf_data


def tf_data_cleanup(cluster, tf_data):
    if tf_data['machine_is_tf_contol']:
        tfconfigdb = tf_data['tfconfigdb']
        tfanalyticsdb = tf_data['tfanalyticsdb']
        tf_manager = tf_data['tf_manager']
        delete_pvs = tf_data['delete_pvs']
        delete_pvcs = tf_data['delete_pvcs']
        ip_configdb = tf_data['ip_configdb']
        ip_analyticsdb = tf_data['ip_analyticsdb']
        cdb_pods = tf_data['cdb_pods']
        adb_pods = tf_data['adb_pods']
        if tfconfigdb:
            cmd = ['/bin/sh', '-c', f"id=$(nodetool -h ::FFFF:127.0.0.1 status | grep {ip_configdb} "
                                    "| awk '{{ print $7 }}') && nodetool -h ::FFFF:127.0.0.1 removenode force $id"]
            resutl_cmd = cdb_pods[0].exec(cmd, container='cassandra')
            LOG.info(f"Result of removing configdb node from cassandra cluster:\n{resutl_cmd}")
        if tfanalyticsdb:
            cmd = ['/bin/sh', '-c', f"id=$(nodetool -h ::FFFF:127.0.0.1 status | grep {ip_analyticsdb} "
                                    "| awk '{{ print $7 }}') && nodetool -h ::FFFF:127.0.0.1 removenode force $id"]
            resutl_cmd = adb_pods[0].exec(cmd, container='cassandra')
            LOG.info(f"Result of removing analyticsdb node from cassandra cluster:\n{resutl_cmd}")

        # Force delete all pv/pvc from old node
        for pv in delete_pvs:
            try:
                LOG.info(f"Delete persistent volume {pv.data['metadata']['name']}")
                cluster.k8sclient.api_core.delete_persistent_volume(
                    name=pv.data['metadata']['name'],
                    grace_period_seconds=0,
                    propagation_policy="Background")
            except Exception as e:
                if type(e).__name__ == 404:
                    LOG.info("Skip deleting due to one of Persistent Volume not found")
        for pvc in delete_pvcs:
            try:
                LOG.info(f"Delete persistent volume claim {pvc}")
                cluster.k8sclient.api_core.delete_namespaced_persistent_volume_claim(
                    namespace=tf_manager.tf_namespace,
                    name=pvc,
                    grace_period_seconds=0,
                    propagation_policy="Background")
            except Exception as e:
                if type(e).__name__ == 404:
                    LOG.info("Skip deleting due to one of Persistent Volume Claim not found")

        LOG.info("Check TFOperator health status")
        tf_manager.wait_tfoperator_healthy(timeout=300)
        tf_manager.wait_tf_controllers_healthy()


@pytest.mark.usefixtures("introspect_distribution_not_changed")
@pytest.mark.usefixtures("collect_downtime_statistics")     # Should be used if ALLOW_WORKLOAD == True
def test_replace_master_node(kaas_manager: Manager, show_step):
    """Replace BM control plane node.

    Scenario:
        1. Find master node where VIP hosted
        2. Collect data about BMH/secret/node
        3. Collect data about TF if it is enabled (optional)
        4. Delete master node
        5. Delete BMH
        6. Create a new BMH
        7. Create new master node
        8. Add new node to the Ceph cluster
        9. Delete all Pending openstack pvc for pods (optional)
        10. Cleanup old node TF data (pvc, pv, configdb, analyticsdb) (optional)
        11. Check OpenStack readiness (optional)
        12. Check cluster readiness
    """

    cluster_name = settings.TARGET_CLUSTER
    namespace_name = settings.TARGET_NAMESPACE

    ns = kaas_manager.get_namespace(namespace_name)
    LOG.info("Namespace name - %s", namespace_name)

    cluster = ns.get_cluster(cluster_name)
    LOG.info("Cluster name - %s", cluster_name)

    # Check or set customHostnamesEnabled flag in Cluster object to match settings.CUSTOM_HOSTNAMES
    cluster.set_custom_hostnames_enabled(flag=settings.CUSTOM_HOSTNAMES)

    show_step(1)
    master = cluster.get_keepalive_master_machine()
    check_precaching = is_precaching_required(master)

    show_step(2)
    machine_bmh_name = master.metadata['annotations'].get('metal3.io/BareMetalHost')
    bmh = ns.get_baremetalhost(name=machine_bmh_name.split("/")[1])
    old_bmh_data = copy.deepcopy(bmh.data)
    removed_master = copy.deepcopy(master.data)
    old_secret = kaas_manager.api.secrets.get(name=old_bmh_data['spec']['bmc']['credentialsName'],
                                              namespace=settings.TARGET_NAMESPACE).read()
    old_secret_data = copy.deepcopy(old_secret)
    bm_hosts_data = []
    bm_hosts_data.append({})
    bm_hosts_data[0]['name'] = machine_bmh_name.split("/")[1].split('-')[0]
    bm_hosts_data[0]['bmh_annotations'] = old_bmh_data['metadata'].get('annotations', {}) or {}

    show_step(3)
    tf_data = collect_tf_data_before_replace(cluster, master)

    show_step(4)
    LOG.info(f"Deleting master machine - {master.name}")
    if not cluster.workaround.prodx_27814():
        LOG.info("Use graceful delete policy explicitly")
        check_machine_graceful_delete(cluster, master, wait_deletion_timeout=3600)
    else:
        LOG.info("Use graceful delete policy by default")
        master.delete(check_deletion_policy=True)
        cluster.check.check_deleted_node(master.name)

    show_step(5)
    LOG.info(f"Deleting BMH: {bmh.name}")
    bmh.delete()
    ns.wait_baremetalhost_deletion(bmh.name, wait_bmh_cred=True, bm_hosts_data=bm_hosts_data)

    show_step(6)
    create_bmh(old_secret_data, old_bmh_data)

    show_step(7)
    new_master = create_master_node(cluster, removed_master)
    new_node = cluster.get_machine(name=new_master.name)
    new_master_node_name = new_node.get_k8s_node_name()
    # Check that Machine hostname is created with respect to Cluster flag 'customHostnamesEnabled'
    cluster.check.check_custom_hostnames_on_machines(machines=[new_node])
    # Check machine runtime
    if settings.DESIRED_RUNTIME:
        cluster.check.compare_machines_runtime_with_desired([new_node], machine_is_new=True)

    show_step(8)
    if cluster.is_child:
        LOG.info("Ceph cluster re-balancing may take some time. Wait timeout is 1h.")
        # Waiting for actual Ceph status from Ceph tools pod
        if settings.CEPH_EXEC_CRASH_ARCHIVE_ALL:
            # exec 'ceph crash archive-all' to wipe info about last crash warnings.
            cluster.check.exec_ceph_tools_command('ceph crash archive-all', return_json=False,
                                                  raise_on_fail=True)
        LOG.info("Wait Ceph HEALTH_OK status in Ceph tools")
        waiters.wait(lambda: wait_ceph_status(cluster), timeout=3600, interval=30)
        # Wait until KaaS update Cluster kind with Ceph status
        LOG.info("Wait Ceph HEALTH_OK status in cluster object")
        try:
            health_info = cluster.check.get_ceph_health_detail()
            assert health_info['status'] == "HEALTH_OK", f'Health is not OK. Will not proceed. ' \
                                                         f'Current ceph health status: {health_info}'
        except AssertionError:
            cluster.check.wait_ceph_health_status(timeout=600, interval=30)

    if cluster.clusterrelease_version.startswith(settings.MOSK_RELEASE_PREFIX) \
            and cluster.is_os_deployed():
        child_kubeconfig_name, child_kubeconfig = cluster.get_kubeconfig_from_secret()
        with open('child_conf', 'w') as f:
            f.write(child_kubeconfig)
        os_manager = OpenStackManager(kubeconfig='child_conf')
        if check_precaching:
            LOG.info("Wait image-precaching Ready")
            selector = f"spec.nodeName={new_master_node_name}"

            image_precaching_pod_timeout = 1800
            image_precaching_pod_timeout_msg = f"Image-precaching pod not found on node {new_master_node_name}"
            cluster.k8sclient.pods.wait_pod_present(timeout=image_precaching_pod_timeout,
                                                    interval=15,
                                                    timeout_msg=image_precaching_pod_timeout_msg,
                                                    namespace="openstack",
                                                    name_prefix='image-precaching',
                                                    field_selector=selector)
            image_precaching_pod = cluster.k8sclient.pods.list(namespace="openstack",
                                                               name_prefix='image-precaching',
                                                               field_selector=selector)
            assert image_precaching_pod, f"Image-precaching pod not found on node {new_master_node_name}"
            image_precaching_pod = image_precaching_pod[0]
            image_precaching_pod.wait_ready(timeout=5400)

        if version.parse(cluster.clusterrelease_version) < version.parse('mosk-17-1-0-rc-24-1'):
            show_step(9)  # Delete all Pending pvc for pods
            cluster.delete_pending_openstack_pods()

        show_step(10)  # Cleanup old node TF data (pvc, pv, configdb, analyticsdb)
        tf_data_cleanup(cluster, tf_data)

        show_step(11)
        LOG.info("Wait osdpl health status=Ready")
        os_manager.wait_openstackdeployment_health_status(timeout=1800)
        LOG.info("Wait os jobs to success and pods to become Ready")
        os_manager.wait_os_resources(timeout=1800)

    show_step(12)
    # Check/wait for correct docker service replicas in cluster
    ucp_worker_agent_name = cluster.check.get_ucp_worker_agent_name()
    cluster.check.check_actual_expected_docker_services(
        changed_after_upd={'ucp-worker-agent-x': ucp_worker_agent_name})
    cluster.check.check_k8s_pods()
    cluster.check.check_actual_expected_pods(timeout=3200)
    cluster.check.check_cluster_readiness()
    cluster.check.check_diagnostic_cluster_status()
    cluster.check.check_deploy_stage_success()
