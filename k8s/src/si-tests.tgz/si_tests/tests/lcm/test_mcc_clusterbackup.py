#    Copyright 2025 Mirantis, Inc.
#
#    Licensed under the Apache License, Version 2.0 (the "License"); you may
#    not use this file except in compliance with the License. You may obtain
#    a copy of the License at
#
#         http://www.apache.org/licenses/LICENSE-2.0
#
#    Unless required by applicable law or agreed to in writing, software
#    distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
#    WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
#    License for the specific language governing permissions and limitations
#    under the License.

import pytest
import yaml

from si_tests import logger
from si_tests import settings
from si_tests.utils import templates, mcc_clusterbackup_utils
from si_tests.managers.cluster_backups_manager import ClusterBackupManager

LOG = logger.logger


class MCCClusterBackupBase:
    """Base class for mcc ClusterBackup tests."""

    @pytest.fixture(autouse=True)
    def setup(self, kaas_manager):
        self.cluster_ns_name = settings.TARGET_NAMESPACE
        self.cluster_name = settings.TARGET_CLUSTER
        self.ns = kaas_manager.get_namespace(self.cluster_ns_name)
        self.cluster = self.ns.get_cluster(self.cluster_name)
        if not self.cluster.workaround.cluster_supports_backups():
            pytest.skip(f"Clusterbackups is not supported for cluster {self.cluster.clusterrelease_version}")
        self.clusterbackup_manager = ClusterBackupManager(self.cluster)

    def create_kek(self):
        return mcc_clusterbackup_utils.ensure_kek_created_and_create_if_not(
            self.clusterbackup_manager, self.cluster_ns_name)

    def create_rclone_cred(self):
        return mcc_clusterbackup_utils.ensure_rclone_cred_created_and_create_if_not(
            self.clusterbackup_manager, self.cluster_ns_name)

    def create_clusterbackup(self, name=None):
        if not name:
            name = self.clusterbackup_manager.clusterbackup_name
        existed_clusterbackups = self.clusterbackup_manager.clusterbackups.list(namespace=self.cluster_ns_name)
        for backup in existed_clusterbackups:
            if backup.name == name:
                LOG.info(f"Clusterbackup object {name} already existed. Skipping creation")
                return backup
        else:
            data = yaml.safe_load(templates.render_template(self.clusterbackup_manager.cluster_backup_file_path))
            return self.clusterbackup_manager.create_clusterbackup(data=data)

    def get_full_files_names(self, clusterbackup_object, share_type="s3", encrypted=True):
        names_list = []
        cb_name = clusterbackup_object.name
        full_file_path = self.clusterbackup_manager.get_backup_file_full_path(cb_name=cb_name)
        if share_type == "s3" or share_type == "local":
            file_name = full_file_path.split(":")[-1]
        elif share_type == "nfs":
            file_name = full_file_path.split("/")[-1]
        else:
            raise NotImplementedError(f"Not implemented share type: {share_type}")
        names_list.append(file_name)
        if encrypted:
            dek_file = file_name.replace('.encrypted', '.dek')
            names_list.append(dek_file)
        return names_list


class TestClusterBackup(MCCClusterBackupBase):
    """Class for Clusterbackup tests"""

    @pytest.mark.parametrize("clusterbackup_cleanup_actions", ["s3"], indirect=True)
    def test_s3_share(self, clusterbackup_cleanup_actions):
        """Create clusterbackup with upload to S3 bucket.

        Scenario:
            1. Check cluster readiness before creating backups
            2. Configure cluster for s3 share type
            3. Create keyencryptionkey for backup encryption
            4. Create clusterbackup object and wait Completed status
            5. Check backups exist on remote
            6. Check objects are not empty and can be decoded
            7. Check cluster readiness after backups
        """

        self.cluster.check.check_cluster_readiness()
        self.cluster.check.check_k8s_nodes()

        self.create_kek()
        self.create_rclone_cred()
        self.clusterbackup_manager.configure_cluster(share_type='s3')
        cb_obj = self.create_clusterbackup()
        self.clusterbackup_manager.wait_clusterbackup_status(name=self.clusterbackup_manager.clusterbackup_name,
                                                             expected_status='Completed')
        files_names = self.get_full_files_names(clusterbackup_object=cb_obj, share_type="s3")
        LOG.info("Waiting for files exist on remote")
        self.clusterbackup_manager.wait_objects_exist_on_remote(files_list=files_names, share_type="s3")
        LOG.info("Check objects are not empty and can be decoded")
        mcc_clusterbackup_utils.extract_backup_plain(clusterbackup_manager=self.clusterbackup_manager,
                                                     file_names=files_names, share_type="s3", encrypted=True)
        self.cluster.check.check_cluster_readiness()
        self.cluster.check.check_k8s_nodes()

    @pytest.mark.parametrize("clusterbackup_cleanup_actions", ["nfs"], indirect=True)
    def test_nfs_share(self, clusterbackup_cleanup_actions):
        """Create clusterbackup with upload to NFS share.

        Scenario:
            1. Check cluster readiness before creating backups
            2. Configure cluster for NFS share type
            3. Create keyencryptionkey for backup encryption
            4. Create clusterbackup object and wait Completed status
            5. Check backups exist on remote
            6. Check objects are not empty and can be decoded
            7. Check cluster readiness after backups
        """

        self.cluster.check.check_cluster_readiness()
        self.cluster.check.check_k8s_nodes()
        self.create_kek()
        self.clusterbackup_manager.configure_cluster(share_type='nfs')
        cb_obj = self.create_clusterbackup()
        self.clusterbackup_manager.wait_clusterbackup_status(name=self.clusterbackup_manager.clusterbackup_name,
                                                             expected_status='Completed')
        files_names = self.get_full_files_names(clusterbackup_object=cb_obj, share_type="nfs")
        LOG.info("Waiting for files exist on remote")
        self.clusterbackup_manager.wait_objects_exist_on_remote(files_list=files_names, share_type="nfs")
        LOG.info("Check objects are not empty and can be decoded")
        seed_nfs_share_mount_path = self.clusterbackup_manager.seed_nfs_share_mount_path
        mcc_clusterbackup_utils.extract_backup_plain(clusterbackup_manager=self.clusterbackup_manager,
                                                     file_names=files_names,
                                                     share_type="nfs",
                                                     nfs_mount_path=seed_nfs_share_mount_path,
                                                     encrypted=True)
        self.cluster.check.check_cluster_readiness()
        self.cluster.check.check_k8s_nodes()

    @pytest.mark.parametrize("clusterbackup_cleanup_actions", ["s3"], indirect=True)
    def test_backup_no_encryption(self, clusterbackup_cleanup_actions):
        """Create clusterbackup without encryption and upload to S3 bucket.

        Scenario:
            1. Check cluster readiness before creating backups
            2. Configure cluster for s3 share type without using keyencryptionkey
            3. Create clusterbackup object and wait Completed status
            4. Check backups exist on remote and not encryted
            5. Check cluster readiness after backups
        """

        self.cluster.check.check_cluster_readiness()
        self.cluster.check.check_k8s_nodes()
        self.create_rclone_cred()
        self.clusterbackup_manager.configure_cluster(share_type='s3', encrypted=False)
        cb_obj = self.create_clusterbackup()
        self.clusterbackup_manager.wait_clusterbackup_status(name=self.clusterbackup_manager.clusterbackup_name,
                                                             expected_status='Completed')
        files_names = self.get_full_files_names(clusterbackup_object=cb_obj, share_type="s3", encrypted=False)
        LOG.info("Waiting for file exists on remote")
        self.clusterbackup_manager.wait_objects_exist_on_remote(files_list=files_names, share_type="s3")
        LOG.info("Check objects are not empty and can be decoded")
        mcc_clusterbackup_utils.extract_backup_plain(clusterbackup_manager=self.clusterbackup_manager,
                                                     file_names=files_names, share_type="s3", encrypted=False)
        self.cluster.check.check_cluster_readiness()
        self.cluster.check.check_k8s_nodes()

    @pytest.mark.parametrize("clusterbackup_cleanup_actions", ["local"], indirect=True)
    def test_local_backup(self, clusterbackup_cleanup_actions):
        """Create clusterbackup with upload to NFS share.

        Scenario:
            1. Check cluster readiness before creating backups
            4. Create clusterbackup object and wait Completed status
            5. Check backups exist locally on node specified in cb object
            6. Check cluster readiness after backups
        """

        self.cluster.check.check_cluster_readiness()
        self.cluster.check.check_k8s_nodes()
        cb_name = self.clusterbackup_manager.clusterbackup_name
        self.create_clusterbackup(name=cb_name)
        self.clusterbackup_manager.wait_clusterbackup_status(name=cb_name,
                                                             expected_status='Completed')
        full_file_path = self.clusterbackup_manager.get_backup_file_full_path(cb_name=cb_name)
        node_name, file_name = full_file_path.split(":")
        self.clusterbackup_manager.wait_object_exists_locally(file_name=file_name, target_node_name=node_name)
        mcc_clusterbackup_utils.extract_backup_plain(clusterbackup_manager=self.clusterbackup_manager,
                                                     file_names=[file_name], local_backup_node=node_name,
                                                     encrypted=False)
        self.cluster.check.check_cluster_readiness()
        self.cluster.check.check_k8s_nodes()
