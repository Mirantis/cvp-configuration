#    Copyright 2025 Mirantis, Inc.
#
#    Licensed under the Apache License, Version 2.0 (the "License"); you may
#    not use this file except in compliance with the License. You may obtain
#    a copy of the License at
#
#         http://www.apache.org/licenses/LICENSE-2.0
#
#    Unless required by applicable law or agreed to in writing, software
#    distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
#    WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
#    License for the specific language governing permissions and limitations
#    under the License.
import exec_helpers
import pytest

from si_tests import logger
from si_tests import settings
from si_tests.utils import utils, waiters

LOG = logger.logger

cluster_name = settings.TARGET_CLUSTER
namespace_name = settings.TARGET_NAMESPACE
test_namespace_name = 'default'
# We choose this storage class as we have it on mgmt and child clusters and
# it always has free PVs in Available state
storage_class_name = 'stacklight-postgresql-db'


def check_pv_dir_is_clean(ssh, pv_mount_path, machine):
    res = ssh.check_call(f"sudo ls {pv_mount_path}")
    if not res.stdout_str:
        LOG.info(f"Directory mount_path: {pv_mount_path} is clean on machine: {machine.name}")
        return 0
    else:
        raise Exception(f"Directory: {pv_mount_path} contains next data: {res.stdout_str}. "
                        f"Directory should be clean before first test")


def symbolic_to_octal(mode_str):
    mapping = {'r': 4, 'w': 2, 'x': 1, '-': 0}
    perms = mode_str[-9:]
    return ''.join(str(sum(mapping[c] for c in perms[i:i + 3])) for i in range(0, 9, 3))


@pytest.fixture(scope='function')
def test_setup(kaas_manager):
    ns = kaas_manager.get_namespace(namespace_name)
    cluster = ns.get_cluster(cluster_name)
    ssh_key_file = utils.load_keyfile(settings.KAAS_CLUSTER_PRIVATE_KEY_FILE)
    pkey = utils.get_rsa_key(ssh_key_file['private'])
    pv_list = cluster.k8sclient.pvolumes.list_all()
    available_pv = [pv for pv in pv_list if
                    pv.data['status']['phase'] == 'Available'
                    and pv.data['spec']['storage_class_name'] == storage_class_name][0]
    assert available_pv, f"No PV in Available state found on env for storageclass: {storage_class_name}"
    LOG.info(f"Available PV: {available_pv}")
    pv_node_name = available_pv.data['spec']['node_affinity']['required'][
        'node_selector_terms'][0]['match_expressions'][0]['values'][0]
    pv_mount_path = available_pv.data['spec']['local']['path']
    machine = cluster.get_machine_by_k8s_name(pv_node_name)
    # Check that PV mount_path directory is empty before first test
    LOG.info(f'Accessing {machine.name} machine and check that mount directory is empty')
    auth = exec_helpers.SSHAuth(username='mcc-user',
                                password='', key=pkey)
    ssh = exec_helpers.SSHClient(
        host=machine.public_ip, port=22, auth=auth)
    ssh.logger.addHandler(logger.console)
    ssh.sudo_mode = True
    ssh.reconnect()

    yield cluster, pv_node_name, pv_mount_path, machine, ssh

    LOG.info(f"Check one more time directory {pv_mount_path} is clean")
    try:
        check_pv_dir_is_clean(ssh, pv_mount_path, machine)
    except Exception as e:
        LOG.info(f"{e}")
        LOG.info("Cleanup directory manually in teardown")
        res = ssh.check_call(f"sudo rm -rf {pv_mount_path}/*")
        if res.exit_code == 0:
            LOG.info(f"Cleanup result stdout: {res.stdout_str}")
        else:
            raise Exception(f"Unknown error during PV cleanup stderr: "
                            f"{res.stderr_str}, stdout {res.stdout_str}")


@pytest.mark.parametrize("perm_mode, owner_uid_gid", [
    ("644", "0:0"),        # Owner rw, group/other r
    ("755", "1000:1000"),  # Owner rwx, group/other rx; non-root owner
    ("000", "0:0"),        # No perms, root owner
    ("777", "999:999"),    # Full perms, arbitrary non-root
])
def test_pv_cleanup_with_file_perms_owners(test_setup, perm_mode, owner_uid_gid):
    cluster, pv_node_name, pv_mount_path, machine, ssh = test_setup
    check_pv_dir_is_clean(ssh, pv_mount_path, machine)
    rnd = utils.gen_random_string(6)
    test_pvc = cluster.check.create_pvc(ns=test_namespace_name,
                                        pvc_name=f"test-pv-claim-{machine.name[:6]}-{rnd}",
                                        storage_class=storage_class_name, expected_status='Pending')

    test_pod = cluster.check.create_pod(pvc_name=test_pvc.name,
                                        ns=test_namespace_name,
                                        node_name=pv_node_name,
                                        mount_path=pv_mount_path,
                                        template_path=settings.SI_TEST_FILE_PERMISSION_POD_YAML)

    active_pv = cluster.get_pv_by_name(test_pvc.data['spec']['volume_name'])
    # Check that PV in Bound state
    cluster.check.wait_pv_status(pv_name=active_pv.name, expected_status='Bound')
    waiters.wait(lambda: active_pv.data['status']['phase'] == 'Bound', timeout=180, interval=10)
    LOG.info(f"PV: {active_pv} in status {active_pv.data['status']['phase']}, continue...")
    # Create files with different owners and permissions
    file_name = f"testfile_{perm_mode}_{owner_uid_gid.replace(':', '_')}"
    file_path = f"{pv_mount_path}/{file_name}"
    LOG.info(f"Create file: {file_path}")
    uid, gid = map(int, owner_uid_gid.split(":"))
    create_file_cmd = ['/bin/bash', '-c',
                       f"touch {file_path}"]
    test_pod.exec(create_file_cmd)
    chmod_file_cmd = ['/bin/bash', '-c',
                      f"chmod {perm_mode} {file_path}"]
    test_pod.exec(chmod_file_cmd)
    chown_file_cmd = ['/bin/bash', '-c',
                      f"chown {uid}:{gid} {file_path}"]
    test_pod.exec(chown_file_cmd)
    LOG.info('Check that file was created successfully')
    check_file_cmd = ['/bin/bash', '-c',
                      f"ls -ln {file_path}"]
    out = test_pod.exec(check_file_cmd).strip().split()
    LOG.info(f"Output of ls command inside pod: {out}")
    assert out, f"Output of ls command inside pod: {out} - looks like empty"
    mode_from_pod = symbolic_to_octal(out[0])
    uid_from_pod = out[2]
    gid_from_pod = out[3]
    assert int(perm_mode) == int(mode_from_pod), (f"Test file: {file_path} has permissions: {mode_from_pod}, "
                                                  f"but should have: {perm_mode}")
    assert int(uid) == int(uid_from_pod), (f"Test file: {file_path} has uid: {uid_from_pod} "
                                           f"but should have: {uid}")
    assert int(gid) == int(gid_from_pod), (f"Test file: {file_path} has permissions: {gid_from_pod} "
                                           f"but should have: {gid}")

    # Delete pod
    LOG.info(f"Delete test pod: {test_pod.name}")
    test_pod.delete(timeout=180)
    # Delete pvc
    LOG.info(f"Delete PVC: {test_pvc.name}")
    test_pvc.delete()
    # Check that PV is Available and Empty, it should be cleaned and released by LVP
    LOG.info("Check that used PV is moved back to Available state")
    cluster.check.wait_pv_status(pv_name=active_pv.name, expected_status='Available')
    LOG.info(f"PV: {active_pv} in status {active_pv.data['status']['phase']}, continue...")
    LOG.info(f"Check that directory {pv_mount_path} is clean on machine, "
             f"it means that PV were cleand by LVP")
    check_pv_dir_is_clean(ssh, pv_mount_path, machine)
    LOG.banner("Done")


@pytest.mark.parametrize("perm_mode, owner_uid_gid", [
    ("755", "0:0"),  # Standard dir perms, root
    ("700", "1001:1001"),  # Owner-only, non-root
    ("777", "0:0"),  # World-writable dir
    ("644", "999:999"),  # File-like perms on dir (invalid but test edge), non-root
])
def test_pv_cleanup_with_dir_perms_owners(test_setup, perm_mode, owner_uid_gid):
    """Test PV creation with a directories having varying perms/owners, then validate cleanup."""
    cluster, pv_node_name, pv_mount_path, machine, ssh = test_setup
    check_pv_dir_is_clean(ssh, pv_mount_path, machine)
    rnd = utils.gen_random_string(6)
    test_pvc = cluster.check.create_pvc(ns=test_namespace_name,
                                        pvc_name=f"test-pv-claim-{machine.name[:6]}-{rnd}",
                                        storage_class=storage_class_name, expected_status='Pending')

    test_pod = cluster.check.create_pod(pvc_name=test_pvc.name,
                                        ns=test_namespace_name,
                                        node_name=pv_node_name,
                                        mount_path=pv_mount_path,
                                        template_path=settings.SI_TEST_FILE_PERMISSION_POD_YAML)

    active_pv = cluster.get_pv_by_name(test_pvc.data['spec']['volume_name'])
    # Check that PV in Bound state
    cluster.check.wait_pv_status(pv_name=active_pv.name, expected_status='Bound')
    waiters.wait(lambda: active_pv.data['status']['phase'] == 'Bound', timeout=180, interval=10)
    LOG.info(f"PV: {active_pv} in status {active_pv.data['status']['phase']}, continue...")
    # Create directories with different owners and permissions
    dir_name = f"testdir_{perm_mode}_{owner_uid_gid.replace(':', '_')}"
    dir_path = f"{pv_mount_path}/{dir_name}"
    LOG.info(f"Create directory: {dir_path}")
    uid, gid = map(int, owner_uid_gid.split(":"))
    create_file_cmd = ['/bin/bash', '-c',
                       f"mkdir -p {dir_path}"]
    test_pod.exec(create_file_cmd)
    chmod_file_cmd = ['/bin/bash', '-c',
                      f"chmod {perm_mode} {dir_path}"]
    test_pod.exec(chmod_file_cmd)
    chown_file_cmd = ['/bin/bash', '-c',
                      f"chown {uid}:{gid} {dir_path}"]
    test_pod.exec(chown_file_cmd)
    LOG.info('Check that file was created successfully')
    check_file_cmd = ['/bin/bash', '-c',
                      f"ls -ln {pv_mount_path} | grep {dir_name}"]
    res = test_pod.exec(check_file_cmd)
    assert "total 0" not in res, f"Directory: {dir_name} wasn't found in path: {pv_mount_path}"
    out = res.strip().split()
    LOG.info(f"Output of ls command inside pod: {out}")
    assert out, f"Output of ls command inside pod: {out} - looks like empty"
    mode_from_pod = symbolic_to_octal(out[0])
    uid_from_pod = out[2]
    gid_from_pod = out[3]
    assert int(perm_mode) == int(mode_from_pod), (f"Test file: {dir_path} has permissions: {mode_from_pod}, "
                                                  f"but should have: {perm_mode}")
    assert int(uid) == int(uid_from_pod), (f"Test file: {dir_path} has uid: {uid_from_pod} "
                                           f"but should have: {uid}")
    assert int(gid) == int(gid_from_pod), (f"Test file: {dir_path} has permissions: {gid_from_pod} "
                                           f"but should have: {gid}")

    # Delete pod
    LOG.info(f"Delete test pod: {test_pod.name}")
    test_pod.delete(timeout=180)
    # Delete pvc
    LOG.info(f"Delete PVC: {test_pvc.name}")
    test_pvc.delete()
    # Check that PV is Available and Empty, it should be cleaned and released by LVP
    LOG.info("Check that used PV is moved back to Available state")
    cluster.check.wait_pv_status(pv_name=active_pv.name, expected_status='Available')
    LOG.info(f"PV: {active_pv} in status {active_pv.data['status']['phase']}, continue...")
    LOG.info(f"Check that directory {pv_mount_path} is clean on machine, "
             f"it means that PV were cleand by LVP")
    check_pv_dir_is_clean(ssh, pv_mount_path, machine)
    LOG.banner("Done")
