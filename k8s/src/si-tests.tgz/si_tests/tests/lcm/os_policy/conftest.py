import pytest
import random
import string

from si_tests.lcm.openstack_lcm.policies import Policy


@pytest.fixture
def nova_policy_isolation():
    """Backup existing nova policies, clear them before the test, restore after."""
    policy = Policy('nova', 'nova-api-osapi')
    backup = policy.backup_policy()
    if backup:
        policy.clear_policy(step='setup')
    yield policy
    if backup:
        policy.restore_policy(backup, step='restore')


@pytest.fixture(scope='session')
def policy_user(openstack_client_manager):
    letters = string.ascii_lowercase
    user_name = "si_user_" + (
        ''.join(random.choice(letters) for i in range(5)))
    password = (''.join(random.choice(letters) for i in range(5)))
    openstack_client_manager.user.create(["--domain", "default",
                                          "--project", "admin",
                                          "--password", password,
                                          user_name])
    openstack_client_manager.role.add(["--user", user_name,
                                       "--project", "admin", "member"])
    yield user_name, password

    openstack_client_manager.user.delete([user_name])
