#    Copyright 2022 Mirantis, Inc.
#
#    Licensed under the Apache License, Version 2.0 (the "License"); you may
#    not use this file except in compliance with the License. You may obtain
#    a copy of the License at
#
#         http://www.apache.org/licenses/LICENSE-2.0
#
#    Unless required by applicable law or agreed to in writing, software
#    distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
#    WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
#    License for the specific language governing permissions and limitations
#    under the License.
import base64
from datetime import datetime
from kubernetes.client.rest import ApiException

from si_tests import logger
from si_tests import settings
from si_tests.managers import bootstrap_manager
from si_tests.managers import pdns_manager
from si_tests.managers.kaas_manager import Manager
from si_tests.utils import certs, utils, waiters

LOG = logger.logger


def test_set_custom_cert_mgmt_regional(kaas_manager, show_step):
    """Add custom cert to the regional cluster.

    Scenario:
        1. Collecting env data
        2. Init bootstrap using SI_CONFIG
        3. Apply MKE/K0S TLS settings
        4. Wait for kubeconfig to be updated
        5. Check clusters
        6. Update cluster kubeconfig

    With SEED_PDNS_ENABLED the certificate is generated for a name published in the seed
    node PowerDNS instead of the load balancer IP address, which k0s does not accept as
    the API server certificate name. See si-test-install-pdns-on-seed-node.
    """

    def cluster_contains_ca(kaas_manager, cluster, ca):
        ns = kaas_manager.get_namespace(cluster.namespace)
        cluster = ns.get_cluster(cluster.name)

        provider_status = cluster.data['status']['providerStatus']
        api_server_cert = provider_status['apiServerCertificate']
        api_server_cert_decoded = base64.b64decode(api_server_cert).decode("utf-8")

        if ca in api_server_cert_decoded:
            return True
        else:
            return False

    show_step(1)
    cluster_name = settings.TARGET_CLUSTER
    namespace_name = settings.TARGET_NAMESPACE
    ns = kaas_manager.get_namespace(namespace_name)
    cluster = ns.get_cluster(cluster_name)

    show_step(2)
    bootstrap = bootstrap_manager.BootstrapManager.get_si_config_bootstrap_manager()

    show_step(3)
    # 'k0s' and 'mke' are different keys in Cluster spec.providerSpec.value.tls,
    # the one matching the cluster LCM engine must be used
    app = "k0s" if cluster.k0s_enabled() else "mke"
    ca_dir_suffix = datetime.now().strftime('%d-%-H-%-M')  # 17-7-37
    ca_path = f'{app}-{ca_dir_suffix}'
    cert_dir = cluster.name

    host, ips, dns_names, host_address = pdns_manager.get_app_cert_hostname(
        bootstrap=bootstrap, cluster=cluster, record=app)

    port = cluster.get_kube_api_port()
    LOG.info(f"Kube API port on the control nodes: {port}")

    cert_pem, key_pem, ca_pem = bootstrap.generate_cert(ips=ips, dns_names=dns_names,
                                                        ca_path=ca_path, cert_dir=cert_dir)

    # Keep the connection to the cluster during the certificate update. 'host_address'
    # comes from 'loadBalancerIP' and stays numeric on a repeated apply.
    if cluster.is_management:
        kubeconfig_path = certs.update_seed_kubeconfig(
            bootstrap=bootstrap, cluster=cluster, skip_tls_verify=True,
            new_server_url=f"https://{host_address}:443")
        kaas_manager = Manager(kubeconfig=kubeconfig_path)
        ns = kaas_manager.get_namespace(cluster.namespace)
        cluster = ns.get_cluster(cluster.name)

    cert_manager = certs.CertManager(kaas_manager=kaas_manager)
    cert_manager.apply_cert_for_app(app=app, cluster=cluster, hostname=host,
                                    cert_pem=cert_pem, key_pem=key_pem, ca_pem=ca_pem,
                                    address=host_address, timeout=1800)

    if cluster.is_management:
        kaas_manager = Manager(kubeconfig=kubeconfig_path)
    ns = kaas_manager.get_namespace(cluster.namespace)
    cluster = ns.get_cluster(cluster.name)

    show_step(4)
    waiters.wait(
        lambda: cluster_contains_ca(kaas_manager=kaas_manager, cluster=cluster, ca=ca_pem),
        interval=10, timeout=300,
        timeout_msg="status.providerStatus.apiServerCertificate was not updated with the new CA")

    # k0s serves the custom certificate only for the matching SNI name, so the name has
    # to be requested explicitly, otherwise the default k0s certificate is returned
    waiters.wait_pass(
        lambda: cluster.check.check_cert_equal(
            port, cert=cert_pem, servername=host if cluster.k0s_enabled() else None),
        expected=(AssertionError, ApiException),
        interval=30, timeout=600,
        timeout_msg="The custom certificate is not served on every node")

    show_step(5)
    target_clusters = kaas_manager.get_child_clusters_in_region(cluster.region_name)
    target_clusters.append(cluster)

    for target_cluster in target_clusters:
        LOG.info(f"Checking cluster {target_cluster.name} certificate")
        if cluster.k0s_enabled():
            # The agents reach the API by address, where k0s serves its own certificate,
            # so their kubeconfig keeps the k0s CA
            LOG.info(f"Mgmt cluster {cluster.name} runs k0s, skipping the agent "
                     f"kubeconfig CA check for all clusters")
        else:
            target_cluster.check.validate_agent_kubeconfig(ca=ca_pem)
        # helm-controller reaches the API by 'loadBalancerHost', so it needs the CA of
        # the certificate served for that name
        target_cluster.check.validate_helm_controller_secret(ca=ca_pem)
        LOG.info(f"Checking cluster {target_cluster.name} readiness")
        target_cluster.check.check_cluster_readiness()

    show_step(6)
    lb_address = cluster.get_load_balancer_address()
    if utils.is_resolvable(lb_address):
        # Update KUBECONFIG with new CA and actual loadBalancerHost
        kubeconfig_path = certs.update_seed_kubeconfig(
            bootstrap=bootstrap, cluster=cluster, new_ca_pem=ca_pem,
            new_server_url=f"https://{lb_address}:443")
    else:
        # The name is served by the seed node only, so keep the address for the next
        # jobs of the pipeline, as test_tlsconfig_for_public_services does
        LOG.warning(f"loadBalancerHost '{lb_address}' is resolvable on the seed node only, "
                    f"storing KUBECONFIG with the IP address and disabled TLS verify")
        kubeconfig_path = certs.update_seed_kubeconfig(
            bootstrap=bootstrap, cluster=cluster, skip_tls_verify=True,
            new_server_url=f"https://{host_address}:443")

    LOG.info(f"Stored KUBECONFIG: {kubeconfig_path}")
    cluster.store_k8s_artifacts()
