#    Copyright 2026 Mirantis, Inc.
#
#    Licensed under the Apache License, Version 2.0 (the "License"); you may
#    not use this file except in compliance with the License. You may obtain
#    a copy of the License at
#
#         http://www.apache.org/licenses/LICENSE-2.0
#
#    Unless required by applicable law or agreed to in writing, software
#    distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
#    WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
#    License for the specific language governing permissions and limitations
#    under the License.
import pytest

from si_tests import logger
from si_tests.deployments.utils import kubectl_utils
from si_tests.deployments.utils.namespace import NAMESPACE
from si_tests.utils.switch_ingress_to_gateway_api import switch_ingress_to_envoy

LOG = logger.logger


@pytest.mark.usefixtures("mos_api_loadtest")
def test_ingress_to_envoy_switch(os_manager, openstack_client_manager, show_step):
    """Verifies migration procedure from ingress to envoy
    Parameters required for the test execution:
        - KUBECONFIG
    Scenario:
        1. Run migration from ingress to envoy
        2. Remove ingress NGINX service
        3. Check all changes are applied and check health status
        4. Check that ingress service is absent
    """

    # Start migration
    show_step(1)
    LOG.info("Executing migration from Ingress to Envoy...")
    switch_ingress_to_envoy(os_manager)

    show_step(2)
    LOG.info("Remove ingress NGINX service")
    osdpl = os_manager.get_osdpl_deployment()

    patch = {
        "spec": {
            "migration": {
                "ingress": {
                    "state": "absent"
                }
            }
        }
    }
    osdpl.patch(patch)
    os_manager.wait_os_deployment_status(timeout=90, status="APPLYING")
    os_manager.wait_os_deployment_status(timeout=600, status="APPLIED")

    # Check OSDPL healths status
    show_step(3)
    LOG.info("Wait osdpl health status=Ready")
    os_manager.wait_openstackdeployment_health_status(timeout=1800)

    # Check that ingress service is absent
    show_step(4)
    kubectl = kubectl_utils.Kubectl()
    resource_status = kubectl.get(
        resource_type="all",
        command="-l application=ingress",
        namespace=NAMESPACE.openstack)

    assert resource_status.result_yaml is None, "Ingress service resources are still present"
