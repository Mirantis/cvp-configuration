import pytest
import random
from si_tests import logger
from si_tests import settings

from si_tests.utils import waiters

LOG = logger.logger


def check_success_result_on_machine(machine, cmd):
    """ For exit code == 0
        0: command was executed successfully
    """
    LOG.info(f"Check command {cmd} on machine: {machine.name}")
    res = machine.exec_pod_cmd(cmd)
    if res.get('exit_code') != 0:
        raise Exception(f"Command {cmd} finished on Machine '{machine.name}' "
                        f"with exit.code='{res.get('exit_code')}'\n{res.get('events')}, "
                        f"but expected value was SUCCESS with code 0")
    return True


def check_missing_package_result_on_machine(machine, cmd):
    """ For exit code = 127:
        127: return code which means: 'command not found', we expect this return code
        when we try to execute not installed package
    """
    LOG.info(f"Check that command {cmd} failed on machine: {machine.name} with exit code 127")
    res = machine.exec_pod_cmd(cmd)
    if res.get('exit_code') != 127:
        raise Exception(f"Command {cmd} finished on Machine '{machine.name}' "
                        f"with exit.code='{res.get('exit_code')}'\n{res.get('events')}, "
                        f"but expected value was FAIL with code 127, because here we "
                        f"expect that package is not installed on machine")
    return True


def check_failure_result_on_machine(machine, cmd):
    """ For exit code = 1:
        1: command return general error, for example 'ls /var | grep fail'
        returns 1 if there are no file with name 'fail' in dir /var
    """
    LOG.info(f"Check that command {cmd} failed on machine: {machine.name} with exit code 1")
    res = machine.exec_pod_cmd(cmd)
    if res.get('exit_code') != 1:
        raise Exception(f"Command {cmd} finished on Machine '{machine.name}' "
                        f"with exit.code='{res.get('exit_code')}'\n{res.get('events')}, "
                        f"but expected value was FAIL with code 1, because here we "
                        f"unspecified ERROR return from command")
    return True


@pytest.mark.parametrize("_", [f"CLUSTER_NAME={settings.TARGET_CLUSTER}"])
def test_hoc_package_install_remove_packet(kaas_manager, _, show_step):
    """ Test package module against installing and removing packages from nodes in child cluster
    Scenario:
        1. Add packet traceroute to 1 machine(by label) from child cluster with HOC object
        2. Add label to second machine in cluster and check that new packet will be installed there
        3. Set “absent” into HOC object and check that packet traceroute is removed from 2 nodes
        4. Delete HOC object and clean machine labels
    """
    cluster_name = settings.TARGET_CLUSTER
    namespace_name = settings.TARGET_NAMESPACE
    ns = kaas_manager.get_namespace(namespace_name)
    cluster = ns.get_cluster(cluster_name)
    hoc_name = "si-team-hoc-package-pack" + str(random.randint(10, 99))
    machines = cluster.get_machines()
    assert machines, f"No machines in cluster: {cluster_name}"
    first_machine = machines[0]
    first_lcmmachine = cluster.get_cluster_lcmmachine(first_machine.name, cluster.namespace)
    second_machine = machines[1]
    second_lcmmachine = cluster.get_cluster_lcmmachine(second_machine.name, cluster.namespace)
    cmd = "traceroute --version"

    day2_label = {"day2-custom-si-label" + str(random.randint(10, 99)): "enabled"}

    # traceroute package sample
    hostoscfg_config_traceroute = [
        {
            "module": "package",
            "moduleVersion": settings.HOC_PACKAGE_MODULE_VERSION,
            "values": {"packages": [{"name": "traceroute", "state": "present"}]},
        }
    ]

    # hoc sample
    hostoscfg_data = {
        "apiVersion": "kaas.mirantis.com/v1alpha1",
        "kind": "HostOSConfiguration",
        "metadata": {
            "name": hoc_name,
            "namespace": namespace_name,
        },
        "spec": {
            "configs": hostoscfg_config_traceroute,
            "machineSelector": {
                "matchLabels": day2_label,
            }
        }
    }

    show_step(1)
    LOG.info(f"Add label day-2-custom-si to first machine: {first_machine.name} in child cluster: {cluster_name}")
    first_machine.add_machine_labels(day2_label)
    LOG.info(f"Check that packet traceroute is not installed on machine: {first_machine.name} BEFORE we set label")
    check_missing_package_result_on_machine(machine=first_machine, cmd=cmd)

    first_lcmmachine_timestamp_before = cluster.get_lcmmachine_timestamps(first_lcmmachine)
    LOG.info(f"Create HOC object with module package version: {settings.HOC_PACKAGE_MODULE_VERSION}")
    hostoscfg = ns.create_hostosconfiguration_raw(hostoscfg_data)
    cluster.check.wait_hoc_state_item_statuses_are_changed_in_lcmmachine(first_lcmmachine,
                                                                         first_lcmmachine_timestamp_before)
    ns.wait_hostosconfiguration_config_state_items_status(hoc_name=hoc_name, expected_status="Success")
    LOG.info("Check that we have only one machine")
    assert len(cluster.check.get_hostosconfig_machines_status(hostoscfg)) == 1, \
        "HOC object has more than 1 machine"
    LOG.info(f"Check that packet traceroute is installed on machine: {first_machine.name} "
             f"AFTER we set label and created HOC")
    check_success_result_on_machine(machine=first_machine, cmd=cmd)

    show_step(2)
    LOG.info(f"Check that packet traceroute is not installed on machine: {second_machine.name} BEFORE we set label")
    check_missing_package_result_on_machine(machine=second_machine, cmd=cmd)
    LOG.info(f"Add label day-2-custom-si to second machine: {second_machine.name} in child cluster: {cluster_name}")
    second_lcmmachine_timestamp_before = cluster.get_lcmmachine_timestamps(second_lcmmachine)
    second_machine.add_machine_labels(day2_label)
    cluster.check.wait_hoc_state_item_statuses_are_changed_in_lcmmachine(second_lcmmachine,
                                                                         second_lcmmachine_timestamp_before)
    ns.wait_hostosconfiguration_config_state_items_status(hoc_name=hoc_name, expected_status="Success")
    LOG.info(f"Check that packet traceroute is installed on machine: {second_machine.name} AFTER we set label")
    check_success_result_on_machine(machine=second_machine, cmd=cmd)
    show_step(3)
    hostcfg = ns.get_hostosconfiguration(name=hoc_name)
    first_lcmmachine_timestamp_before = cluster.get_lcmmachine_timestamps(first_lcmmachine)
    second_lcmmachine_timestamp_before = cluster.get_lcmmachine_timestamps(second_lcmmachine)
    hostcfg.patch({"spec": {"configs": [{"module": "package",
                                         "moduleVersion": settings.HOC_PACKAGE_MODULE_VERSION,
                                         "phase": "reconfigure",
                                         "values": {"packages": [{"name": "traceroute",
                                                                  "state": "absent"}]}}]}})

    cluster.check.wait_hoc_state_item_statuses_are_changed_in_lcmmachine(first_lcmmachine,
                                                                         first_lcmmachine_timestamp_before)
    cluster.check.wait_hoc_state_item_statuses_are_changed_in_lcmmachine(second_lcmmachine,
                                                                         second_lcmmachine_timestamp_before)
    ns.wait_hostosconfiguration_config_state_items_status(hoc_name=hoc_name, expected_status="Success")

    LOG.info("Check that packages were deleted from both nodes")
    check_missing_package_result_on_machine(machine=first_machine, cmd=cmd)
    check_missing_package_result_on_machine(machine=second_machine, cmd=cmd)
    show_step(4)
    existing_config = ns.get_hostosconfiguration(name=hoc_name)
    LOG.info(f"Deleting HostOSConfiguration '{existing_config.name}'")
    existing_config.delete(async_req=True)
    timeout_msg = f"HostOSConfiguration {hoc_name} was not deleted"
    waiters.wait(lambda: not bool(ns.hostosconfiguration_is_present(name=hoc_name)),
                 timeout=1200,
                 interval=10,
                 timeout_msg=timeout_msg)
    first_machine.remove_machine_labels(list(day2_label.keys()))
    second_machine.remove_machine_labels(list(day2_label.keys()))


@pytest.mark.parametrize("_", [f"CLUSTER_NAME={settings.TARGET_CLUSTER}"])
def test_hoc_package_add_remove_repository(kaas_manager, _, show_step):
    """ Test package module for adding/removing repository and install/remove package from added repository
    Scenario:
        1. Add “wrong” repo(with address from which we can’t download key) and check that we have error in hoc object
        2. Add correct repo and gpg key URL and check that repo will be added to selected node
        3. Install package from repo and check result on machine
        4. Set “absent” to package and repo check result on machines
        5. TODO: Set diff priority to the added repos (add bionic repo with less priority then mcc ones < 500)
        6. Delete HOC object and clean machine labels
    """
    cluster_name = settings.TARGET_CLUSTER
    namespace_name = settings.TARGET_NAMESPACE
    ns = kaas_manager.get_namespace(namespace_name)
    cluster = ns.get_cluster(cluster_name)
    hoc_name = "si-team-hoc-package-repo" + str(random.randint(10, 99))
    machines = cluster.get_machines()
    assert machines, f"No machines in cluster: {cluster_name}"
    first_machine = machines[0]
    first_lcmmachine = cluster.get_cluster_lcmmachine(first_machine.name, cluster.namespace)
    repo_file_name = "si-custom-repo"
    cmd = f"cat /etc/apt/sources.list.d/{repo_file_name}.list"

    day2_label = {"day2-custom-si-label" + str(random.randint(10, 99)): "enabled"}

    # wrong repo package sample
    hostoscfg_config_traceroute = [
        {
            "module": "package",
            "moduleVersion": settings.HOC_PACKAGE_MODULE_VERSION,
            "values": {"repositories": [{"filename": repo_file_name,
                                         "key": "https://example.org/packages/key.gpg",
                                         "repo": "deb https://example.org/packages/ apt/stable/",
                                         "state": "present"}]},
        }
    ]

    hostoscfg_data = {
        "apiVersion": "kaas.mirantis.com/v1alpha1",
        "kind": "HostOSConfiguration",
        "metadata": {
            "name": hoc_name,
            "namespace": namespace_name,
        },
        "spec": {
            "configs": hostoscfg_config_traceroute,
            "machineSelector": {
                "matchLabels": day2_label,
            }
        }
    }

    show_step(1)
    LOG.info(f"Add label day-2-custom-si to first machine: {first_machine.name} in child cluster: {cluster_name}")
    first_machine.add_machine_labels(day2_label)
    LOG.info(f"Check that repo is not added to machine: {first_machine.name}")
    check_failure_result_on_machine(machine=first_machine, cmd=cmd)

    first_lcmmachine_timestamp_before = cluster.get_lcmmachine_timestamps(first_lcmmachine)
    LOG.info(f"Create HOC object with module package version: {settings.HOC_PACKAGE_MODULE_VERSION}")
    hostoscfg = ns.create_hostosconfiguration_raw(hostoscfg_data)
    cluster.check.wait_hoc_state_item_statuses_are_changed_in_lcmmachine(first_lcmmachine,
                                                                         first_lcmmachine_timestamp_before)
    ns.wait_hostosconfiguration_config_state_items_status(hoc_name=hoc_name, expected_status="Failed")
    LOG.info("Check that we have only one machine")
    assert len(cluster.check.get_hostosconfig_machines_status(hostoscfg)) == 1, \
        "HOC object has more than 1 machine"
    LOG.info(f"Check that repo still is not added to machine: {first_machine.name} because of failed parameter")
    check_failure_result_on_machine(machine=first_machine, cmd=cmd)
    show_step(2)
    hostcfg = ns.get_hostosconfiguration(name=hoc_name)
    first_lcmmachine_timestamp_before = cluster.get_lcmmachine_timestamps(first_lcmmachine)
    hostcfg.patch({"spec": {"configs": [{"module": "package",
                                         "moduleVersion": settings.HOC_PACKAGE_MODULE_VERSION,
                                         "phase": "reconfigure",
                                         "values": {"repositories": [{
                                                    "filename": repo_file_name,
                                                    "key": "https://download.sublimetext.com/sublimehq-pub.gpg",
                                                    "repo": "deb https://download.sublimetext.com/ apt/stable/",
                                                    "state": "present"}]}}]}})

    cluster.check.wait_hoc_state_item_statuses_are_changed_in_lcmmachine(first_lcmmachine,
                                                                         first_lcmmachine_timestamp_before)
    ns.wait_hostosconfiguration_config_state_items_status(hoc_name=hoc_name, expected_status="Success")
    LOG.info(f"Check that repo is added to machine: {first_machine.name}")
    check_success_result_on_machine(machine=first_machine, cmd=cmd)
    show_step(3)
    sublime_cmd = "ls /usr/bin/ | grep subl"
    LOG.info(f"Check that package sublime-text is not installed on machine: {first_machine.name}")
    check_failure_result_on_machine(machine=first_machine, cmd=sublime_cmd)
    first_lcmmachine_timestamp_before = cluster.get_lcmmachine_timestamps(first_lcmmachine)
    hostcfg.patch({"spec": {"configs": [
        {"module": "package",
         "moduleVersion": settings.HOC_PACKAGE_MODULE_VERSION,
         "phase": "reconfigure",
         "values": {"packages": [
                                {"name": "sublime-text",
                                 "state": "present"}],
                    "repositories": [
                                    {"filename": repo_file_name,
                                     "key": "https://download.sublimetext.com/sublimehq-pub.gpg",
                                     "repo": "deb https://download.sublimetext.com/ apt/stable/",
                                     "state": "present"}]
                    },
         }]}})
    cluster.check.wait_hoc_state_item_statuses_are_changed_in_lcmmachine(first_lcmmachine,
                                                                         first_lcmmachine_timestamp_before)
    ns.wait_hostosconfiguration_config_state_items_status(hoc_name=hoc_name, expected_status="Success")
    LOG.info(f"Check that package sublime is installed on machine: {first_machine.name}")
    check_success_result_on_machine(machine=first_machine, cmd=sublime_cmd)

    show_step(4)
    first_lcmmachine_timestamp_before = cluster.get_lcmmachine_timestamps(first_lcmmachine)
    hostcfg.patch({"spec": {"configs": [
        {"module": "package",
         "moduleVersion": settings.HOC_PACKAGE_MODULE_VERSION,
         "phase": "reconfigure",
         "values": {"packages": [
                                {"name": "sublime-text",
                                 "state": "absent"}],
                    "repositories": [
                                    {"filename": repo_file_name,
                                     "key": "https://download.sublimetext.com/sublimehq-pub.gpg",
                                     "repo": "deb https://download.sublimetext.com/ apt/stable/",
                                     "state": "absent"}]
                    },
         }]}})
    cluster.check.wait_hoc_state_item_statuses_are_changed_in_lcmmachine(first_lcmmachine,
                                                                         first_lcmmachine_timestamp_before)
    ns.wait_hostosconfiguration_config_state_items_status(hoc_name=hoc_name, expected_status="Success")
    LOG.info(f"Check that repo and package sublime were removed from machine: {first_machine.name}")
    check_failure_result_on_machine(machine=first_machine, cmd=sublime_cmd)
    check_failure_result_on_machine(machine=first_machine, cmd=cmd)
    show_step(6)
    existing_config = ns.get_hostosconfiguration(name=hoc_name)
    LOG.info(f"Deleting HostOSConfiguration '{existing_config.name}'")
    existing_config.delete(async_req=True)
    timeout_msg = f"HostOSConfiguration {hoc_name} was not deleted"
    waiters.wait(lambda: not bool(ns.hostosconfiguration_is_present(name=hoc_name)),
                 timeout=1200,
                 interval=10,
                 timeout_msg=timeout_msg)
    first_machine.remove_machine_labels(list(day2_label.keys()))
