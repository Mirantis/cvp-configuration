#    Copyright 2026 Mirantis, Inc.
#
#    Licensed under the Apache License, Version 2.0 (the "License"); you may
#    not use this file except in compliance with the License. You may obtain
#    a copy of the License at
#
#         http://www.apache.org/licenses/LICENSE-2.0
#
#    Unless required by applicable law or agreed to in writing, software
#    distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
#    WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
#    License for the specific language governing permissions and limitations
#    under the License.
import re
from urllib.parse import urlparse

import pytest
import yaml

from si_tests import logger
from si_tests import settings
from si_tests.deployments.utils import wait_utils, kubectl_utils
from si_tests.deployments.utils.namespace import NAMESPACE
from si_tests.managers.openstack_manager import OpenStackManager
from si_tests.utils import packaging_version as version
from si_tests.utils import waiters

LOG = logger.logger


class IngressEnvoyMigrationTestBase:
    """Shared logic for ingress -> Envoy Gateway migration and its checks.

    Instantiate in a thin test function and call the step methods, e.g.::

        migration = IngressEnvoyMigrationTestBase(kaas_manager)
        migration.prepare()
        migration.switch_ingress_to_envoy()
        ...
        migration.verify_traffic_via_envoy()
        migration.verify_no_ingress_controller()

    The verify_* / switch_* methods are independent and can be reused from
    other tests (green-deploy validation, post-update checks, etc.).
    """

    COREDNS_CONFIGMAP = "coredns-coredns"
    DNS_ZONE_KEY = "it.just.works.db"          # zone for the *.it.just.works test domain
    A_RECORD_RE = re.compile(r'(\sIN\s+A\s+)(\d+\.\d+\.\d+\.\d+)')
    EXTERNAL_IP_TIMEOUT = 600
    DNS_WARMUP_TIMEOUT = 600

    # Envoy Gateway that must serve all OpenStack API traffic after migration.
    GATEWAY_NAME = "app-gateway"
    GATEWAY_NAMESPACE = NAMESPACE.openstack

    # nginx ingress controller objects (Service/Endpoints/DaemonSet/Deployment):
    # `ingress`, `ingress-udp`, `ingress-error-pages`, `ingress-exporter`.
    # `mariadb-ingress-*` is Galera's own ingress and legitimately stays, so the
    # anchored regex deliberately does not match it.
    INGRESS_NAME_RE = re.compile(r"^ingress(-|$)")
    # Namespaces where the nginx controller may live (Ingress *objects* are
    # scanned cluster-wide separately; this bounds only the controller scan).
    INGRESS_CONTROLLER_NAMESPACES = ("openstack", "openstack-redis", "rook-ceph", "tf")

    def __init__(self, kaas_manager):
        self.kaas_manager = kaas_manager
        self.cluster_name = settings.TARGET_CLUSTER
        self.namespace_name = settings.TARGET_NAMESPACE
        self.ns = kaas_manager.get_namespace(self.namespace_name)
        self.cluster = self.ns.get_cluster(self.cluster_name)
        self.os_manager = None

    # === prepare: skip unsupported clusters + build child OpenStackManager ===
    def prepare(self):
        if not self.cluster.workaround.cluster_supports_envoy():
            pytest.skip(f"Cluster version {self.cluster.clusterrelease_version} doesn't support "
                        f"Envoy. Will not proceed with migration")
        _, child_kubeconfig = self.cluster.get_kubeconfig_from_secret()
        with open('child_conf', 'w') as f:
            f.write(child_kubeconfig)
        self.os_manager = OpenStackManager(kubeconfig='child_conf')

    # === generic waits shared by several steps ===
    def check_cluster_ready(self):
        self.cluster.check.check_cluster_readiness()

    def wait_osdpl_healthy(self, timeout=1800):
        self.os_manager.wait_openstackdeployment_health_status(timeout=timeout)

    # === migration steps ===
    def switch_ingress_to_envoy(self):
        """Point the *.it.just.works DNS zone at the Envoy app-gateway VIP.

        Waits for app-gateway to get an external IP, rewrites every A-record in
        the coredns zone to that IP, restarts coredns and waits until the child
        resolver serves the new IP. Returns the VIP.
        """
        LOG.info("Wait for app-gateway external IP")
        svc = self.os_manager.api.services.get("app-gateway", NAMESPACE.openstack)
        svc.wait_for_external_ip(timeout=self.EXTERNAL_IP_TIMEOUT)
        envoy_ip = svc.get_external_ip()
        assert envoy_ip, "app-gateway has no external IP after wait"
        LOG.info("Envoy app-gateway VIP: %s", envoy_ip)

        LOG.info("Rewrite coredns zone %s -> %s", self.DNS_ZONE_KEY, envoy_ip)
        coredns_cm = self.os_manager.api.configmaps.get(self.COREDNS_CONFIGMAP, NAMESPACE.coredns)
        zone = coredns_cm.read().data[self.DNS_ZONE_KEY]
        # all *.it.just.works records converge on the single gateway VIP
        updated_zone, replaced = self.A_RECORD_RE.subn(rf'\g<1>{envoy_ip}', zone)
        assert replaced, f"No A-records matched in {self.DNS_ZONE_KEY} - zone format changed?"
        LOG.debug("Rewrote %d A-record(s)", replaced)
        self.os_manager.api.configmaps.update(
            self.COREDNS_CONFIGMAP, NAMESPACE.coredns,
            {"data": {self.DNS_ZONE_KEY: updated_zone}})

        LOG.debug("Restart coredns pods")
        kubectl = kubectl_utils.Kubectl(kubeconfig=self.os_manager.kubeconfig)
        kubectl.rollout_restart("deployment", self.COREDNS_CONFIGMAP, namespace=NAMESPACE.coredns)

        keystone_pods = self.os_manager.api.pods.list_starts_with(
            "keystone-client", NAMESPACE.openstack)
        assert keystone_pods, "no keystone-client pod to verify DNS warmup"
        keystone_pod_name = keystone_pods[0].read().metadata.name

        wait = wait_utils.Waiter(self.os_manager, self.DNS_WARMUP_TIMEOUT)
        wait.wait_pass(
            lambda: wait.wait_for_dns_warmup(
                kubectl, keystone_pod_name=keystone_pod_name,
                resolved_expected_ip=envoy_ip, ns=NAMESPACE.openstack),
            expected=Exception)
        LOG.info("Envoy gateway successfully configured")
        return envoy_ip

    def remove_ingress_nginx(self):
        """Ask the OpenStack controller to remove the nginx ingress deployment."""
        LOG.info("Remove ingress NGINX service")
        osdpl = self.os_manager.get_osdpl_deployment()
        # controller 1.3.3 supported
        patch = {"spec": {"migration": {"ingress": {"state": "absent"}}}}
        osdpl.patch(patch)
        self.os_manager.wait_os_deployment_status(timeout=120, status="APPLYING")
        self.os_manager.wait_os_deployment_status(timeout=1200, status="APPLIED")

    def disable_ceph_ingress(self):
        """Disable ingress for Ceph via ceph-controller helm values and wait
        until the rook-ceph Ingress object is gone and Ceph is healthy again."""
        LOG.info("Disabling Ingress for ceph")
        helm_releases = self.cluster.data["spec"]["providerSpec"]["value"]["helmReleases"]
        ceph_helm_config = next(
            (release for release in helm_releases if release.get("name") == "ceph-controller"),
            None,
        )
        ingress_conf = {
            "pelagia-ceph": {
                "lcmConfig": {
                    "useIngress": False,
                }
            }
        }
        if ceph_helm_config is None:
            ceph_helm_config = {
                "name": "ceph-controller",
                "values": ingress_conf
            }
            helm_releases.append(ceph_helm_config)
        else:
            ceph_helm_config["values"] = ingress_conf
        body = {'spec': {'providerSpec': {'value': {'helmReleases': helm_releases}}}}
        self.kaas_manager.api.kaas_clusters.update(
            name=self.cluster_name, namespace=self.namespace_name, body=body)

        def _check_ingress_removed():
            rook_ns = settings.ROOK_CEPH_NS
            ceph_ingress = self.cluster.k8sclient.ingresses.list(namespace=rook_ns)
            if ceph_ingress:
                LOG.info(f"Ceph ingress {ceph_ingress[0].name} still exists")
                return False
            LOG.info("Ceph ingress was removed from cluster")
            return True

        ingress_removed_timeout = 600
        timeout_message = (f"Ceph ingress was not removed from cluster in "
                           f"{ingress_removed_timeout} sec")
        waiters.wait(lambda: _check_ingress_removed(),
                     timeout=ingress_removed_timeout, interval=60, timeout_msg=timeout_message)
        LOG.info("Check cluster readiness after ceph ingress removed")
        self.cluster.check.check_cluster_readiness()
        self.cluster.check.wait_cephdeployment_phase()
        self.cluster.check.wait_cephdeploymenthealth_state()

    def should_raise_on_ingress_leftovers(self):
        """Whether leftover ingress controller objects must fail the check
        (True since mosk-22-0-0-rc-27-1, warn-only before)."""
        return (version.parse(self.cluster.clusterrelease_version)
                >= version.parse("mosk-22-0-0-rc-27-1"))

    def _gateway_served_hostnames(self):
        """Hostnames served by Accepted HTTPRoutes bound to the app-gateway.

        HTTPRoutes are scanned across ALL namespaces because Gateway-API allows
        cross-namespace attachment (e.g. the Ceph RGW route lives in ``rook-ceph``
        yet attaches to ``openstack/app-gateway``). A route counts only if THIS
        gateway Accepted it; a parentRef without a namespace defaults to the
        route's own namespace, per the Gateway-API spec.
        """
        served = set()
        for route in self.cluster.k8sclient.httproutes.list_all():
            for parent in (route.data.get("status") or {}).get("parents") or []:
                ref = parent.get("parentRef") or {}
                ref_ns = ref.get("namespace") or route.namespace
                if ref.get("name") != self.GATEWAY_NAME or ref_ns != self.GATEWAY_NAMESPACE:
                    continue
                if any(c.get("type") == "Accepted" and c.get("status") == "True"
                       for c in parent.get("conditions") or []):
                    served.update((route.data.get("spec") or {}).get("hostnames") or [])
        return served

    @staticmethod
    def _hostname_served(host, served):
        """True if `host` is covered by a served hostname, exact or wildcard
        (``*.it.just.works`` matches ``keystone.it.just.works``)."""
        return any(hn == host or (hn.startswith("*.") and host.endswith(hn[1:]))
                   for hn in served)

    def verify_traffic_via_envoy(self):
        """Assert every public OpenStack endpoint really goes through Envoy.

        Source of truth is the child Keystone catalog: for every public endpoint
        host there must be an Accepted HTTPRoute bound to a Programmed app-gateway.
        """
        errors = []

        gateways = self.cluster.k8sclient.gateways.list(
            namespace=self.GATEWAY_NAMESPACE, name_prefix=self.GATEWAY_NAME)
        gw = next((g for g in gateways if g.name == self.GATEWAY_NAME), None)
        if gw is None:
            errors.append(f"Gateway {self.GATEWAY_NAMESPACE}/{self.GATEWAY_NAME} not found")
        elif not gw.is_programmed():
            errors.append(f"Gateway {self.GATEWAY_NAMESPACE}/{self.GATEWAY_NAME} is not Programmed")

        served = self._gateway_served_hostnames()
        public_endpoints = self.os_manager.get_openstack_endpoints(interface="public")
        hosts = {urlparse(e.get("URL", "")).hostname for e in public_endpoints}
        hosts.discard(None)
        assert hosts, "Keystone catalog returned no public endpoints"
        for host in sorted(hosts):
            if not self._hostname_served(host, served):
                errors.append(f"public endpoint not served by Envoy gateway: {host}")

        assert not errors, (
            "Not all traffic goes through Envoy:\n- " + "\n- ".join(errors))

    def verify_no_ingress_controller(self, raise_on_leftovers=True):
        """Assert no live nginx ingress controller remains.

        Only the *controller* is a competing data path. Leftover ``Ingress``
        objects are rendered by Helm until the next release and legitimately
        linger, so they are intentionally not checked here.

        :param raise_on_leftovers: (bool) whether to raise or not if some objects
                                   are still present
        """
        present = {ns.name for ns in self.cluster.k8sclient.namespaces.list_all()}
        listers = {
            "Service": self.cluster.k8sclient.services,
            "Endpoints": self.cluster.k8sclient.endpoints,
            "DaemonSet": self.cluster.k8sclient.daemonsets,
            "Deployment": self.cluster.k8sclient.deployments,
        }
        leftovers = []
        for ns in self.INGRESS_CONTROLLER_NAMESPACES:
            if ns not in present:
                continue
            for kind, manager in listers.items():
                for obj in manager.list(namespace=ns):
                    if self.INGRESS_NAME_RE.match(obj.name):
                        leftovers.append(f"{kind} {ns}/{obj.name}")
        msg = f"Next nginx ingress controller objects still present:\n{yaml.dump(leftovers)}"
        if not raise_on_leftovers and leftovers:
            LOG.warning(msg)
        else:
            assert not leftovers, msg
