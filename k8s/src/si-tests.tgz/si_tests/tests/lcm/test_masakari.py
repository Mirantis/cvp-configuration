#    Copyright 2025 Mirantis, Inc.
#
#    Licensed under the Apache License, Version 2.0 (the "License"); you may
#    not use this file except in compliance with the License. You may obtain
#    a copy of the License at
#
#         http://www.apache.org/licenses/LICENSE-2.0
#
#    Unless required by applicable law or agreed to in writing, software
#    distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
#    WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
#    License for the specific language governing permissions and limitations
#    under the License.

import configparser
import pytest
import yaml

from si_tests import logger, settings
from si_tests.utils import waiters, utils
from si_tests.managers.openstack_client_manager import OpenStackClientManager
from kubernetes.client.rest import ApiException
from retry import retry

TEMPLATE_PATH = settings.OPENSTACK_MASAKARI_STACK_TEMPLATE_PATH
stack_name = settings.OPENSTACK_MASAKARI_STACK_NAME
availability_zone = settings.OPENSTACK_MASAKARI_STACK_AVAILABILITY_ZONE
ms_server_name = settings.OPENSTACK_MASAKARI_STACK_SERVER_NAME
ms_subnet_range = settings.OPENSTACK_MASAKARI_STACK_SUBNET_RANGE
ms_segment_name = settings.OPENSTACK_MASAKARI_SEGMENT_NAME
ms_network_name = "masakari-net"
ms_subnet_name = "masakari-subnet"
ms_volume_name = "masakari-volume"
key_name = "masakari-stack-key"
HOST_CRASH_TIMEOUT = settings.OPENSTACK_MASAKARI_HOST_CRASH_TIMEOUT
OSDPL_APPLIED_TIMEOUT = settings.OSDPL_APPLIED_TIMEOUT
LOG = logger.logger


def get_openstack_pids(machine):
    """
    Return a list of PIDs for running OpenStack services (nova, neutron, cinder)
    on the remote machine.
    """

    openstack_processes = ["nova",
                           "neutron",
                           "cinder",
                           "qemu-system",
                           "libvirtd",
                           "virtlogd",
                           "masakari"]
    pids = []
    for process in openstack_processes:
        res = machine.run_cmd(f"pgrep -f {process}", verbose=False, check_exit_code=False)
        if res.exit_code == 0:
            pids.extend([int(pid.strip()) for pid in res.stdout if pid.strip()])
    return pids


def wait_ssh_back(machine, timeout=HOST_CRASH_TIMEOUT):
    """
    Wait until the node accepts SSH again after the simulated host crash.

    SSH on the crashed node is paused for HOST_CRASH_TIMEOUT seconds, so it
    still may be down by the time we start restoring the node.
    """

    def _is_ssh_available():
        try:
            machine.run_cmd("true", verbose=False, timeout=60, check_exit_code=False)
            return True
        except Exception as e:
            LOG.info(f"SSH to {machine.name} is not available yet: {e}")
            return False

    LOG.info(f"Wait for SSH on {machine.name} to become available again")
    waiters.wait(_is_ssh_available, timeout=timeout, interval=20,
                 timeout_msg=f"SSH did not become available on {machine.name} in {{spent}} sec")


def is_masakari_enabled(os_manager):
    osdpl = os_manager.get_osdpl_deployment()
    return 'instance-ha' in osdpl.data.get('spec', {}).get('features', {}).get('services', [])


def check_readiness(cluster, os_manager):
    cluster.check.check_cluster_readiness()
    os_manager.wait_openstackdeployment_health_status()


class TestMasakari:
    """
    Masakari tests:
      - test_instance_evacuated: Checks instance evacuation
      - test_instance_recover: Checks instance recover on failure
      - test_check_configuration_applied: Checks Config in osdpl applied to masakari config
    """

    @pytest.fixture(autouse=True)
    def setup(self, kaas_manager):
        self.namespace_name = settings.TARGET_NAMESPACE
        self.cluster_name = settings.TARGET_CLUSTER
        self.ns = kaas_manager.get_namespace(self.namespace_name)
        self.child_cluster = self.ns.get_cluster(self.cluster_name)
        child_kubeconfig_name, child_kubeconfig = self.child_cluster.get_kubeconfig_from_secret()
        with open('child_conf', 'w') as f:
            f.write(child_kubeconfig)
        self.openstack_client_manager = OpenStackClientManager(kubeconfig='child_conf')
        self.is_masakari_enabled = is_masakari_enabled(os_manager=self.openstack_manager)
        if not self.is_masakari_enabled:
            pytest.skip("Masakari is disabled. Nothing to check")

    @property
    def openstack_manager(self):
        return self.openstack_client_manager.os_manager

    @pytest.fixture
    def restore_and_cleanup_actions(self, request):
        """Restore node and cleanup resources after test"""

        is_segment_existed_before_test = False
        is_stack_existed_before_test = False

        existed_segments = self.openstack_client_manager.segment.list([])
        for segment in existed_segments:
            if segment.get('name', '') == ms_segment_name:
                is_segment_existed_before_test = True
                break
        all_stacks = self.openstack_client_manager.stack.list([])
        for stack in all_stacks:
            if stack.get('Stack Name', '') == stack_name:
                is_stack_existed_before_test = True
        yield
        self.openstack_client_manager.reload_client()
        if self.openstack_client_manager.stack.exists(stack_name):
            server = self.openstack_client_manager.server.show([ms_server_name])
            hostname = server["OS-EXT-SRV-ATTR:host"]
            cluster_machines = self.child_cluster.get_machines()
            target_machine = [m for m in cluster_machines if m.get_k8s_node_name() == hostname]
            assert target_machine, f"No machine found associated with k8s node name {hostname}"
            target_machine = target_machine[0]
            wait_ssh_back(target_machine)
            LOG.info("Start docker on node")
            target_machine.run_cmd("sudo systemctl start docker")
            LOG.info("Restore compute service on the crushed node")
            self.openstack_client_manager.compute_service.set(["--enable", hostname, "nova-compute"])
            waiters.wait(lambda: not [x["Host"] for x in self.openstack_client_manager.compute_service.list([])
                                      if (x["Host"] == hostname and x["State"] == "down")],
                         timeout=600, interval=30)
            if is_stack_existed_before_test:
                LOG.info("Skipping stack deletion because it was existed before test")
            else:
                LOG.info(f"Removing stack {stack_name}")
                self.openstack_client_manager.stack.delete([stack_name])
                waiters.wait(lambda: not self.openstack_client_manager.stack.exists(stack_name), timeout=180)
                LOG.info(f"Stack {stack_name} deleted")
        if is_segment_existed_before_test:
            LOG.info(f"Segment {ms_segment_name} will not be removed, because it was existed before test")
            segment_hosts = self.openstack_client_manager.segment.host_list([ms_segment_name])
            for host in segment_hosts:
                if host.get('on_maintenance', False):
                    host_name = host.get('name')
                    LOG.info(f"Maintenance for host {host_name} is enabled. Disabling maintenance")
                    self.openstack_client_manager.segment.host_disable_maintenance(segment=ms_segment_name,
                                                                                   host=host_name,
                                                                                   yaml_output=False)
        else:
            LOG.info(f"Delete segment {ms_segment_name}")
            self.openstack_client_manager.segment.delete([ms_segment_name])
        LOG.info("Check cluster readiness after restore")
        check_readiness(cluster=self.child_cluster, os_manager=self.openstack_manager)

    def create_masakari_resources(self, request):
        """Create masakari related resources: segment, hosts to segment, stack with HA_Enabled for VM"""
        recovery_method = 'auto'
        service_type = 'compute'
        description = 'si-test masakari segment'
        LOG.info(f"Creating segment for masakari\nName: {ms_segment_name}, Recovery method: {recovery_method}, "
                 f"Service type: {service_type}")
        all_segments = self.openstack_client_manager.segment.list([])
        for segment in all_segments:
            existed_segment_name = segment.get('name', '')
            segment_service_type = segment.get('service_type', '')
            segment_recovery_method = segment.get('recovery_method', '')
            if (existed_segment_name == ms_segment_name and
                    segment_service_type == service_type and
                    segment_recovery_method == recovery_method):
                LOG.info(f"Segment {ms_segment_name} already exists. Skipping creation")
                break
        else:
            self.openstack_client_manager.segment.create([
                "--description", f"{description}", f"{ms_segment_name}",
                f"{recovery_method}", f"{service_type}"
            ])
        # Add hosts
        segment_hosts = self.openstack_client_manager.segment.host_list([ms_segment_name])
        segment_hosts_names = []
        for host_data in segment_hosts:
            host_name = host_data.get('name')
            if host_data.get('on_maintenance', False):
                LOG.info(f"Maintenance for host {host_name} is enabled. Disabling maintenance")
                self.openstack_client_manager.segment.host_disable_maintenance(segment=ms_segment_name,
                                                                               host=host_name,
                                                                               yaml_output=False)
            segment_hosts_names.append(host_name)
        hosts = [h for h in self.openstack_client_manager.compute_service.list(['--service', 'nova-compute'])
                 if 'nova-compute-ironic' not in h.get('Host')]
        hosts_names = [data.get('Host', '') for data in hosts]
        for host in hosts_names:
            if host not in segment_hosts_names:
                LOG.info(f"Adding host {host} to segment {ms_segment_name}")
                self.openstack_client_manager.segment.host_create([host, 'compute', 'SSH', ms_segment_name])
        else:
            LOG.info(f"All hosts are added to segment {ms_segment_name}")
        ssh_keys = utils.load_keyfile(settings.KAAS_CLUSTER_PRIVATE_KEY_FILE)
        stack_options = {
            "ssh_public_key": f"ssh-rsa {ssh_keys['public']}",
            "ssh_private_key": ssh_keys["private"],
            "instance_name": ms_server_name,
            "volume_name": ms_volume_name,
            "subnet_name": ms_subnet_name,
            "network_name": ms_network_name,
            "availability_zone": availability_zone,
            "key_name": key_name
        }
        self.openstack_client_manager.ensure_stack(
            request, stack_name, TEMPLATE_PATH,
            kubeconfig=None, stack_params=stack_options, finalizer=False
        )

    def wait_masakari_notification(self, host_uuid, notification_type,
                                   remove_notification_num, status="finished", timeout=600):
        """Wait notification exists for specefic actions"""

        def _wait_notification():
            notifications = self.openstack_client_manager.notification.list([])
            if len(notifications) <= remove_notification_num:
                return False
            for notification in notifications[:len(notifications) - remove_notification_num]:
                if (notification["source_host_uuid"] == host_uuid and
                        notification["type"] == notification_type and
                        notification["status"] == status):
                    return True
            return False

        waiters.wait(_wait_notification, timeout=timeout, interval=30)

    def test_instance_evacuated(self, request, restore_and_cleanup_actions):
        """
        Verify instance is evacuated from failed host.

        Scenario:
            1. Create Masakari resources (segment, hosts, VM stack).
            2. Simulate host crash by stopping Docker and killing OpenStack services on the node.
            3. Wait until the OpenStack compute service reports the host as 'down'.
            4. Check Masakari notification to ensure the compute host crash is reported.
            5. Verify that the compute service on the crashed host is disabled.
            6. Verify that the VM hosted on the crashed compute node is evacuated to another host.
            7. Check that the VM's power state is 'Running'.
            8. Restore the crashed node: start Docker, wait for the k8s node to be ready,
               and re-enable the compute service.
        """

        if settings.OPENSTACK_MASAKARI_PROJECT_TAG:
            pytest.skip("OPENSTACK_MASAKARI_PROJECT_TAG IS SET")
        ssh_pause_time = HOST_CRASH_TIMEOUT
        LOG.info("Check cluster readiness before proceed")
        check_readiness(cluster=self.child_cluster, os_manager=self.openstack_manager)

        LOG.info("Create masakari resources")
        self.create_masakari_resources(request)
        server = self.openstack_client_manager.server.show([ms_server_name])
        hostname = server["OS-EXT-SRV-ATTR:host"]
        cluster_machines = self.child_cluster.get_machines()
        target_machine = [m for m in cluster_machines if m.get_k8s_node_name() == hostname]
        assert target_machine, f"No machine found associated with k8s node name {hostname}"
        target_machine = target_machine[0]
        LOG.info(f"Using target machine with name {target_machine.name} and hostname "
                 f"{target_machine.get_k8s_node_name()}")
        segment_hosts = self.openstack_client_manager.segment.host_list([ms_segment_name])
        host_uuid = [x["uuid"] for x in segment_hosts if x["name"] == hostname][0]
        hyper_indx = None
        for hv in self.openstack_client_manager.hypervisor.list([]):
            if hostname in hv["Hypervisor Hostname"]:
                hyper_indx = self.openstack_client_manager.hypervisor.list([]).index(hv)
                break
        current_notifications_num = len(self.openstack_client_manager.notification.list([]))
        LOG.info("Simulate host crush")
        target_machine.run_cmd("sudo systemctl stop docker; sleep 30")
        pids = get_openstack_pids(target_machine)
        LOG.info(pids)
        for pid in pids:
            target_machine.run_cmd(f"sudo kill {pid} || true")
        res = target_machine.run_cmd("sudo systemctl is-active ssh.service", check_exit_code=False)
        if res.exit_code.value != 0:
            # Ubuntu 22.04
            svc = "sshd.service"
        else:
            # on Ubuntu 24.04, name of ssh service is different than before,
            # and socket also must be stopped, otherwise attempts to connect
            # by our host monitor will start the server back again
            svc = "ssh.socket ssh.service"
        LOG.info(f"Pausing {svc} for {ssh_pause_time} seconds")
        # at least on Ubuntu 24.04 need to explicitly redirect all output
        # so that script is not blocked on it
        target_machine.run_cmd(
            f"nohup bash -c "
            f"'sudo systemctl stop {svc}; "
            f"sleep {ssh_pause_time}; "
            f"sudo systemctl start {svc}' > /dev/null 2>&1 &",
        )
        LOG.info("Wait openstack compute is down.")
        waiters.wait(lambda: len([x["Host"] for x in self.openstack_client_manager.compute_service.list([])
                                  if (x["Host"] == hostname and x["State"] == "down")]) == 1,
                     timeout=HOST_CRASH_TIMEOUT, interval=30)
        LOG.info("Check Masakari notification")
        self.wait_masakari_notification(host_uuid,
                                        notification_type="COMPUTE_HOST",
                                        remove_notification_num=current_notifications_num,
                                        timeout=1200)
        LOG.info("Check that compute service is disabled on crashed compute")
        assert hostname in [x["Host"] for x in self.openstack_client_manager.compute_service.list([])
                            if (x["Host"] == hostname and x["Status"] == "disabled")], \
            "compute service is NOT disabled on crashed compute"
        LOG.info("Check VM's host is changed")
        assert hostname != self.openstack_client_manager.server.show([ms_server_name])["OS-EXT-SRV-ATTR:host"], \
            "VM's host is NOT changed"
        assert (self.openstack_client_manager.server.show([ms_server_name])["OS-EXT-STS:power_state"] in
                ["Running", 1]), "VM's instance is NOT running"
        LOG.info("Restore Node")
        wait_ssh_back(target_machine)
        target_machine.run_cmd("sudo systemctl start docker")
        if hyper_indx is not None:
            LOG.info("Wait k8s node is ready again")
            waiters.wait(lambda: self.openstack_client_manager.hypervisor.list([])[hyper_indx]["State"] == "up",
                         timeout=300, interval=30)
        self.openstack_client_manager.compute_service.set(["--enable", hostname, "nova-compute"])
        LOG.info("Check cluster readiness after test")
        check_readiness(cluster=self.child_cluster, os_manager=self.openstack_manager)

    def test_instance_recover(self, request, restore_and_cleanup_actions):
        """
        Verify instance is recovered after failure.

        Scenario:
            1. Create Masakari resources (segment, hosts, VM stack).
            2. Simulate instance crash by killing the VM process (qemu-system-x86_64) on the host.
            3. Wait for Masakari to detect the crash and generate a VM notification.
            4. Check Masakari notification to ensure the instance failure was reported.
            5. Wait until the VM is recovered and its power state is 'Running'.
        """

        LOG.info("Check cluster readiness before proceed")
        check_readiness(cluster=self.child_cluster, os_manager=self.openstack_manager)

        LOG.info("Create masakari resources")
        self.create_masakari_resources(request)
        server = self.openstack_client_manager.server.show([ms_server_name])
        hostname = server["OS-EXT-SRV-ATTR:host"]
        cluster_machines = self.child_cluster.get_machines()
        target_machine = [m for m in cluster_machines if m.get_k8s_node_name() == hostname]
        assert target_machine, f"No machine found associated with k8s node name {hostname}"
        target_machine = target_machine[0]
        LOG.info(f"Using target machine with name {target_machine.name} and hostname "
                 f"{target_machine.get_k8s_node_name()}")
        segment_hosts = self.openstack_client_manager.segment.host_list([ms_segment_name])
        host_uuid = [x["uuid"] for x in segment_hosts if x["name"] == hostname][0]
        current_notifications_num = len(self.openstack_client_manager.notification.list([]))
        instance_id = server["id"]
        LOG.info(f"Simulate instance crush for instance {instance_id}")
        res = target_machine.run_cmd(
            f"pgrep -f -- '-uuid {instance_id}'", check_exit_code=False
        )
        qemu_pids = [int(pid.strip()) for pid in res.stdout if pid.strip()]
        assert qemu_pids, f"No qemu process found for instance {instance_id}"
        for pid in qemu_pids:
            target_machine.run_cmd(f"sudo kill -9 {pid}")
        LOG.info("Check Masakari notification")
        self.wait_masakari_notification(host_uuid, notification_type="VM",
                                        remove_notification_num=current_notifications_num)
        LOG.info("Wait VM is running again")
        waiters.wait(lambda: self.openstack_client_manager.server.show([ms_server_name])["OS-EXT-STS:power_state"]
                     in ["Running", 1], timeout=180, interval=30)
        LOG.info("Check cluster readiness after test")
        check_readiness(cluster=self.child_cluster, os_manager=self.openstack_manager)

    def test_check_configuration_applied(self):
        """
        Verify that Masakari configuration changes are correctly applied and can be restored.

        Scenario:
            1. Retrieve the current Masakari configuration from the masakari-engine pod:
               - evacuate_all_instances (from [host_failure] section)
               - process_all_instances (from [instance_failure] section)
            2. Invert the current configuration values to prepare new settings.
            3. Patch the 'instance-ha' service deployment with the new configuration.
            4. Wait until the OpenStack deployment status is 'APPLYING' and then 'APPLIED'.
            5. Retrieve the configuration again and verify that the new values are applied correctly.
            6. Assert that the applied configuration matches the expected values.
            7. Restore the original Masakari configuration to leave the environment unchanged.
            8. Wait again until the OpenStack deployment status is 'APPLYING' and then 'APPLIED' after restoration.
        """

        LOG.info("Check cluster readiness before proceed")
        check_readiness(cluster=self.child_cluster, os_manager=self.openstack_manager)

        @retry((ApiException,), delay=10, tries=12, logger=LOG)
        def get_parameters_from_config():
            masakari_pods = self.child_cluster.k8sclient.pods.list(
                namespace='openstack', name_prefix='masakari-engine')
            assert masakari_pods, "No masakari-engine pods found"
            masakari_healthy_pod = [pod for pod in masakari_pods if pod.read().status.phase == "Running"]
            assert masakari_healthy_pod, "No masakari-engine pod with phase Running found"
            masakari_pod = masakari_healthy_pod[0]
            conf_path = '/etc/masakari/masakari.conf'
            cmd = ['/bin/sh', '-c', f'PYTHONWARNINGS=ignore::UserWarning cat {conf_path}']
            res = masakari_pod.exec(cmd)
            config = configparser.ConfigParser()
            config.read_string(res)
            evac_all_instances = config.getboolean('host_failure', option='evacuate_all_instances', fallback=False)
            proc_all_instances = config.getboolean('instance_failure', option='process_all_instances', fallback=False)
            return evac_all_instances, proc_all_instances

        evacuate_all_instances, process_all_instances = get_parameters_from_config()
        LOG.info(f"CURRENT VALUES:\nevacuate_all_instances: {evacuate_all_instances}\n"
                 f"process_all_instances: {process_all_instances}")
        evacuate_all_instances_to_apply = not evacuate_all_instances
        process_all_instances_to_apply = not process_all_instances
        patch_data = {
            'masakari': {
                'values': {
                    'conf': {
                        'masakari': {
                            'host_failure': {'evacuate_all_instances': evacuate_all_instances_to_apply},
                            'instance_failure': {'process_all_instances': process_all_instances_to_apply}
                        }
                    }
                }
            }
        }
        osdpl = self.openstack_manager.get_osdpl_deployment()
        original_fingerprint = osdpl.read().status["fingerprint"]
        osdpl.patch({"spec": {"services": {'instance-ha': patch_data}}})
        self.openstack_manager.wait_os_deployment_status(timeout=300, status="APPLYING")
        self.openstack_manager.wait_os_deployment_status(timeout=OSDPL_APPLIED_TIMEOUT, status="APPLIED")
        LOG.info("Wait for osdpl fingerprint updated")
        self.openstack_manager.wait_osdpl_fingerprint_changed(original_fingerprint)

        def _wait_config_changed(exp_evac, exp_proc):
            new_evacuate, new_process = get_parameters_from_config()
            if new_evacuate == exp_evac and new_process == exp_proc:
                return True
            else:
                LOG.info(f"Some values are not applied, retrying\n"
                         f"{yaml.dump({'evacuate_all_instances': new_evacuate, 'process_all_instances': new_process})}")
                return False

        waiters.wait(lambda: _wait_config_changed(evacuate_all_instances_to_apply, process_all_instances_to_apply),
                     timeout=450, interval=15)

        # Restore configuration
        LOG.info("Restore default values for masakari config")
        patch_data['masakari']['values']['conf']['masakari']['host_failure']['evacuate_all_instances'] = (
            evacuate_all_instances)
        patch_data['masakari']['values']['conf']['masakari']['instance_failure']['process_all_instances'] = (
            process_all_instances)
        original_fingerprint = osdpl.read().status["fingerprint"]
        osdpl.patch({"spec": {"services": {'instance-ha': patch_data}}})
        self.openstack_manager.wait_os_deployment_status(timeout=300, status="APPLYING")
        self.openstack_manager.wait_os_deployment_status(timeout=OSDPL_APPLIED_TIMEOUT, status="APPLIED")
        LOG.info("Wait for osdpl fingerprint updated")
        self.openstack_manager.wait_osdpl_fingerprint_changed(original_fingerprint)
        waiters.wait(lambda: _wait_config_changed(evacuate_all_instances, process_all_instances),
                     timeout=450, interval=15)
        LOG.info("Check cluster readiness after test")
        check_readiness(cluster=self.child_cluster, os_manager=self.openstack_manager)
