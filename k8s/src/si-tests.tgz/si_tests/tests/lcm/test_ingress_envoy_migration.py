#    Copyright 2026 Mirantis, Inc.
#
#    Licensed under the Apache License, Version 2.0 (the "License"); you may
#    not use this file except in compliance with the License. You may obtain
#    a copy of the License at
#
#         http://www.apache.org/licenses/LICENSE-2.0
#
#    Unless required by applicable law or agreed to in writing, software
#    distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
#    WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
#    License for the specific language governing permissions and limitations
#    under the License.
import pytest

from si_tests import logger
from si_tests.tests.lcm.base_test_ingress_envoy_migration import IngressEnvoyMigrationTestBase

LOG = logger.logger


@pytest.mark.usefixtures('mcc_per_node_workload_check_after_test')
@pytest.mark.usefixtures("collect_downtime_statistics")
def test_ingress_to_envoy_migration(kaas_manager, show_step):
    """Verifies migration procedure from ingress to envoy
    Parameters required for the test execution:
        - KUBECONFIG from mgmt cluster
    Scenario:
        1. Check Cluster readiness before proceed
        2. Switch services from ingress to Envoy
        3. Remove ingress NGINX deployment
        4. Check all services after removing ingress NGINX
        5. Disable Ingress for Ceph (If Ceph deployed)
        6. Check all services after ingress disabled
        7. Verify all traffic goes through Envoy and no ingress controller left
    """
    migration = IngressEnvoyMigrationTestBase(kaas_manager)
    migration.prepare()

    show_step(1)
    migration.check_cluster_ready()
    migration.wait_osdpl_healthy()

    show_step(2)
    LOG.info("Executing migration from Ingress to Envoy...")
    migration.switch_ingress_to_envoy()

    show_step(3)
    migration.remove_ingress_nginx()

    show_step(4)
    LOG.info("Wait osdpl health status=Ready")
    migration.wait_osdpl_healthy()

    if migration.cluster.is_ceph_deployed:
        show_step(5)
        migration.disable_ceph_ingress()

        show_step(6)
        LOG.info("Wait osdpl health status=Ready")
        migration.wait_osdpl_healthy()

    show_step(7)
    LOG.info("Verify all public traffic goes through Envoy")
    migration.verify_traffic_via_envoy()
    LOG.info("Verify no nginx ingress controller left")
    migration.verify_no_ingress_controller(
        raise_on_leftovers=migration.should_raise_on_ingress_leftovers())
