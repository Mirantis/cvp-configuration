from datetime import datetime as dt

from exec_helpers import proc_enums
import pytest

from si_tests import logger
from si_tests import settings
from si_tests.utils import waiters, utils
from si_tests.managers.openstack_client_manager import OpenStackClientManager

LOG = logger.logger

ms_server_name = 'masakari_test_'
ms_server_flavor = "m1.extra_tiny_test"
ms_segment_name = "allcomputes"
test_cloud = "test"
extra_role = "global-secret-decoder"
HOST_CRASH_TIMEOUT = settings.OPENSTACK_MASAKARI_HOST_CRASH_TIMEOUT
NOTIFICATION_FINISHED_TIMEOUT = 1200


def change_user_roles(ocm_admin, user_info, action, role):
    # doing only project auth as the test user must be able to boot VMs
    command = [
        "--user", user_info["user_id"],
        "--project", user_info["project_id"],
        role
    ]
    if action.lower() == "add":
        ocm_admin.role.add(command)
    elif action.lower() == "remove":
        ocm_admin.role.remove(command)


def get_openstack_pids(ssh):
    openstack_processes = [
        "nova",
        "neutron",
        "cinder",
        "qemu-system",
        "libvirtd",
        "virtlogd",
        "masakari",
    ]
    pids = []
    res = ssh.check_call("ps -xaeo pid,command")
    for line in res.stdout:
        line = line.decode().strip()
        for os_pattern in openstack_processes:
            if os_pattern in line:
                pid = line.split(' ')[0]
                if pid:
                    pids.append(pid)
    return pids


def simulate_host_crash(ssh):
    LOG.info(f"Simulate crash of host {ssh.hostname}")
    # NOTE(pas-ha): this is highly dependent on underlay system.
    # In MKE specifically, kubelet runs as a docker container,
    # and thus will die if docker deamon is stopped.
    LOG.info("Stopping docker")
    ssh.check_call("systemctl stop docker.service; sleep 30")
    LOG.info("Ensure no openstack-related processes running")
    pids = get_openstack_pids(ssh)
    for pid in pids:
        ssh.check_call(
            f"kill {pid}",
            expected=(
                proc_enums.ExitCodes.EX_OK,
                proc_enums.ExitCodes.EX_ERROR,
            ),
        )
    # NOTE(pas-ha): MOSK's host monitor checks for k8s node being NotReady,
    # but also for SSH on the node being down.
    # Need to stop SSH, but also ensure it comes back up eventually by itself,
    # so we could start docker/kubelet back in the test cleanup phase.
    res = ssh.check_call("systemctl is-active ssh.service", raise_on_err=False)
    if res.exit_code > 0:
        # Ubuntu 22.04
        svc = "sshd.service"
    else:
        # on Ubuntu 24.04, name of ssh service is different than before,
        # and socket also must be stopped, otherwise attempts to connect
        # by our host monitor will start the server back again
        svc = "ssh.socket ssh.service"
    LOG.info(f"Pausing {svc} for {HOST_CRASH_TIMEOUT} seconds")
    # at least on Ubuntu 24.04 need to explicitly redirect all output
    # so that script is not blocked on it
    ssh.check_call(
        f"nohup bash -c "
        f"'systemctl stop {svc}; "
        f"sleep {HOST_CRASH_TIMEOUT}; "
        f"systemctl start {svc}' > /dev/null 2>&1 &",
    )
    # we want to interrupt any connections with test host
    ssh.close()


def restore_simulated_host_crash(hostname):
    def _ssh_connect(hostname):
        try:
            return utils.ssh_k8s_node(hostname)
        except Exception as e:
            LOG.error(f"SSH is not available yet with next error:\n{e}")
            return False
    timeout_msg = f"SSH is not became available on host {hostname} in {HOST_CRASH_TIMEOUT} sec"
    ssh = waiters.wait(
        _ssh_connect,
        timeout=HOST_CRASH_TIMEOUT,
        timeout_msg=timeout_msg,
        interval=20,
        predicate_kwargs={'hostname': hostname}
    )

    LOG.info(f"Cleanup: rollback simulated crash of host {ssh.hostname}")
    ssh.check_call("systemctl start docker.service")


def create_masakari_resources(ocm, segment_name):
    LOG.info("Create Masakari segment")
    ocm.segment.create([segment_name, 'auto', 'compute'])

    # Add Hosts to Masakari segment
    LOG.info("Add Hosts to Masakari segment")
    for hs in ocm.compute_service.list(['--service', 'nova-compute']):
        ocm.segment.host_create(
            [hs.get('Host'), 'compute', 'SSH', segment_name]
        )


def cleanup_masakari_resources(ocm, segment_name):
    LOG.info("Delete Masakari segment")
    ocm.segment.delete([segment_name])


def create_nova_vm(ocm, vm_name, flavor, host=None, ha_enabled=True):
    # Create a VM
    LOG.info("Create a VM")
    cli_args = [
        # requires OpenStack Train or newer, we do not support Masakari
        # for such old releases anyway
        "--os-compute-api-version", "2.74",
        "--image", ocm.cirros_image_name,
        "--flavor", flavor,
        "--property", f"HA_Enabled={str(ha_enabled)}",
        "--nic", "none",  # this should work for even older OSC
        vm_name
    ]
    if host:
        cli_args.extend(["--host", host, ])
    server_id = ocm.server.create(cli_args)["id"]
    assert server_id, f"Failed to create server {vm_name}"
    # Check VM is running
    LOG.info("Check VM is running")
    waiters.wait(
        lambda: ocm.server.show(
            [server_id])["OS-EXT-STS:power_state"] in ["Running", 1],
        timeout=60, interval=10
    )
    return server_id


def cleanup_nova_vm(ocm, server_id):
    LOG.info("Delete VM")
    ocm.server.delete([server_id])
    LOG.info("Wait VM is not present anymore")
    waiters.wait(
        lambda: server_id not in [x["ID"] for x in ocm.server.list([])],
        timeout=120, interval=10
    )


def check_compute_service(ocm, host, **checks):
    search_args = ["--service", "nova-compute", "--host", host]
    services = ocm.compute_service.list(search_args)
    assert len(services) == 1, f"No unique compute service on host {host}"
    return all(services[0][k] == v for k, v in checks.items())


def wait_masakari_notification(
    openstack_client_manager: OpenStackClientManager,
    host_uuid: str,
    notification_type: str,
    since: dt,
    status: str = "finished",
    timeout: int = 300,
):
    since = since.isoformat(timespec='seconds')

    def _wait_notification():
        search_args = [
            "--filter", f"source_host_uuid={host_uuid}",
            "--filter", f"type={notification_type}",
            "--filter", f"status={status}",
            "--filter", f"generated-since={since}"

        ]
        notifications = openstack_client_manager.notification.list(search_args)
        return bool(notifications)

    waiters.wait(_wait_notification, timeout=timeout, interval=30)


def set_project_tag(ocm_admin, project_id, tag):
    if tag in ocm_admin.project.show([project_id])["tags"]:
        return False
    ocm_admin.project.set([project_id, "--tag", tag])
    return True


def _test_host_monitor(ocm_admin, project_tag=None):

    ssh = None
    hostname = None
    cleanup_tag = False
    test_server_id = None
    admin_server_id = None
    try:
        ocm_test = OpenStackClientManager(os_cloud=test_cloud)
        test_user_info = ocm_test.token.issue([])
        if project_tag:
            LOG.info("Setup: tag test project with provided masakari tag")
            admin_user_info = ocm_admin.token.issue([])
            assert project_tag not in ocm_admin.project.show([
                admin_user_info["project_id"]
            ])["tags"], f"admin project DOES HAVE {project_tag} tag"
            cleanup_tag = set_project_tag(
                ocm_admin, test_user_info["project_id"], project_tag)

        # Create Masakari segment
        LOG.info("Setup: Create masakari resources")
        create_masakari_resources(ocm_admin, ms_segment_name)
        # Extend test user roles to work with signed images
        change_user_roles(ocm_admin, test_user_info, "add", extra_role)

        LOG.info("Setup: Create VMs")
        test_server_id = create_nova_vm(
            ocm_test, ms_server_name + "test", ms_server_flavor)
        # get values of the created Masakari resources
        test_server = ocm_test.server.show([test_server_id])
        hostname = test_server["OS-EXT-SRV-ATTR:host"]
        segment_hosts = ocm_admin.segment.host_list([ms_segment_name])
        host_uuid = [x["uuid"] for x in segment_hosts
                     if x["name"] == hostname][0]
        admin_server_id = create_nova_vm(
            ocm_admin, ms_server_name + "admin", ms_server_flavor,
            host=hostname)
        admin_server = ocm_test.server.show([admin_server_id])
        assert admin_server["OS-EXT-SRV-ATTR:host"] == hostname, \
            f"admin server was NOT created on host {hostname}"

        # Simulate host crush on the node where the instance is running
        LOG.info(f"Step 1: Simulate host crash for {hostname}")
        ssh = utils.ssh_k8s_node(hostname)
        crash_time = dt.utcnow()
        simulate_host_crash(ssh)

        LOG.info("Step 2: Wait openstack compute is down.")
        waiters.wait(
            lambda: check_compute_service(ocm_admin, hostname, State="down"),
            timeout=HOST_CRASH_TIMEOUT,
            interval=30)

        LOG.info("Step 3: Check Masakari notification")
        wait_masakari_notification(ocm_admin, host_uuid,
                                   notification_type="COMPUTE_HOST",
                                   since=crash_time,
                                   timeout=NOTIFICATION_FINISHED_TIMEOUT)

        LOG.info("Step 4: Check that compute service is disabled on crashed "
                 "compute")
        assert check_compute_service(ocm_admin, hostname, Status="disabled"), \
            "compute service is NOT disabled on crashed compute"

        LOG.info("Step 5: Check test VM is running on another host")
        test_server = ocm_admin.server.show([test_server_id])
        assert hostname != test_server["OS-EXT-SRV-ATTR:host"], \
            "test VM's host has NOT changed"
        assert test_server["OS-EXT-STS:power_state"] in ["Running", 1], \
            "test VM's instance is NOT running"

        # Check 'admin' VM
        admin_server = ocm_admin.server.show([admin_server_id])
        if project_tag:
            LOG.info("Step 6: Check admin VM was not migrated")
            assert hostname == admin_server["OS-EXT-SRV-ATTR:host"], \
                "admin VM's host HAS changed"
            # Don't check for state, might be bogus on a down host.
            # instead, check that evacuation has not even been called
            admin_server_event_actions = [
                e["Action"]
                for e in ocm_admin.server.event_list([admin_server_id])
            ]
            assert "evacuate" not in admin_server_event_actions, \
                "evacuate for admin VM WAS called"
        else:
            LOG.info("Step 6: Check admin VM is running on another host")
            assert hostname != admin_server["OS-EXT-SRV-ATTR:host"], \
                "admin VM's host has NOT changed"
            assert admin_server["OS-EXT-STS:power_state"] in ["Running", 1], \
                "admin VM's instance is NOT running"

    finally:
        # Restore Node and cleanup
        # NOTE(pas-ha): we do this not in specific reverse order
        # for the most likely failing cleanup to be run later,
        # and reset masakari to original state to not affect other tests
        LOG.info("Cleanup: Cleanup Masakari resources")
        # NOTE(pas-ha): we delete the segment completely,
        # otherwise we'd need to unset maintenance from the masakari host
        cleanup_masakari_resources(ocm_admin, ms_segment_name)
        if cleanup_tag:
            LOG.info("Cleanup: Remove added tag from test project")
            ocm_admin.project.set([
                test_user_info["project_id"],
                "--remove-tag", settings.OPENSTACK_MASAKARI_PROJECT_TAG
            ])
        if hostname is not None:
            LOG.info(f"Cleanup: Restore Node {hostname}")
            if ssh is not None:
                restore_simulated_host_crash(hostname)
            LOG.info("Cleanup: Wait compute service is up again")
            waiters.wait(
                lambda: check_compute_service(ocm_admin, hostname, State="up"),
                timeout=300, interval=30)
            LOG.info("Cleaunp: Re-enable compute service on the crushed node")
            ocm_admin.compute_service.set(
                ["--enable", hostname, "nova-compute"])
        LOG.info("Cleanup: Delete created VMs")
        if admin_server_id:
            cleanup_nova_vm(ocm_admin, admin_server_id)
        if test_server_id:
            cleanup_nova_vm(ocm_test, test_server_id)
        change_user_roles(ocm_admin, test_user_info, "remove", extra_role)


def test_host_monitor(openstack_client_manager):
    """Verify Masakari host monitor.
    https://mirantis.testrail.com/index.php?/cases/view/4963423

    Scenario:
        Setup:
        - Create Masakari resources
        - Boot VM in test project
        - Boot VM in admin project on the same compute host
        1. Simulate host crash
        2. Wait compute node is down
        3. Check Masakari notification
        4. Check that compute service is disabled on crashed compute
        5. Check test VM is running on another host
        6. Check admin VM is running on another host
        Cleanup:
        - Cleanup Masakari resources
        - Restore node
        - Clean up VMs

    """
    if settings.OPENSTACK_MASAKARI_PROJECT_TAG:
        pytest.skip("OPENSTACK_MASAKARI_PROJECT_TAG is set")
    _test_host_monitor(openstack_client_manager, project_tag=None)


def test_masakari_node_evacuate_project_selective(openstack_client_manager):
    """Verify Masakari evacuating only VMs of specific project

    Scenario:
        Setup:
        - Tag test project with provided masakari tag
        - Create Masakari resources
        - Boot VM in test project on some compute host
        - Boot VM in admin project on the same compute host
        1. Simulate host crash
        2. Wait compute node is down
        3. Check Masakari notification
        4. Check that compute service is disabled on crashed compute
        5. Check test VM is running on another host
        6. Check admin VM was not migrated
        Cleanup:
        - Cleanup Masakari resources
        - Remove added tag from test project
        - Restore node
        - Clean up VMs
    """
    if not settings.OPENSTACK_MASAKARI_PROJECT_TAG:
        pytest.skip("OPENSTACK_MASAKARI_PROJECT_TAG is not set")

    _test_host_monitor(
        openstack_client_manager,
        project_tag=settings.OPENSTACK_MASAKARI_PROJECT_TAG)


def test_instance_monitor(openstack_client_manager):
    """Verify Masakari instance monitor.
    https://mirantis.testrail.com/index.php?/cases/view/4963424

     Scenario:
         1. Create Masakari resources
         2. Boot VM on compute host
         3. Simulate instance crush
         4. Check Masakari notification
         5. Check VM instance is running
         6. Clean up

     """
    server_id = None
    try:
        ocm_admin = openstack_client_manager
        ocm_test = OpenStackClientManager(os_cloud=test_cloud)
        test_user_info = ocm_test.token.issue([])

        LOG.info("Step 1: Create masakari resources")
        create_masakari_resources(ocm_admin, ms_segment_name)
        change_user_roles(ocm_admin, test_user_info, "add", extra_role)

        # get values of the created Masakari resources
        server_id = create_nova_vm(
            ocm_test, ms_server_name + "test", ms_server_flavor)
        server = ocm_test.server.show([server_id])
        hostname = server["OS-EXT-SRV-ATTR:host"]
        segment_hosts = ocm_admin.segment.host_list([ms_segment_name])
        host_uuid = [x["uuid"] for x in segment_hosts if x["name"] == hostname][0]

        LOG.info("Step 3: Simulate instance crush")
        ssh = utils.ssh_k8s_node(hostname)
        stop_time = dt.utcnow()
        # TODO(pas-ha): kill only that VM we created
        ssh.check_call("kill -9 $(pidof qemu-system-x86_64)")

        LOG.info("Step 4: Check Masakari notification")
        wait_masakari_notification(
            ocm_admin, host_uuid, notification_type="VM", since=stop_time)

        LOG.info("Step 5: Wait VM is running again")
        waiters.wait(
            lambda: ocm_test.server.show([server_id])["OS-EXT-STS:power_state"] in ["Running", 1],
            timeout=180, interval=30
        )

    finally:
        LOG.info("Step 6: Restore Node and cleanup")
        if server_id:
            cleanup_nova_vm(ocm_test, server_id)
        change_user_roles(ocm_admin, test_user_info, "remove", extra_role)
        cleanup_masakari_resources(ocm_admin, ms_segment_name)
