import pytest
import yaml
import time

from si_tests import settings
from si_tests import logger
from si_tests.utils import waiters, templates, utils, exceptions
from si_tests.managers import openstack_manager
from si_tests.managers.machine_deletion_policy_manager import check_machine_unsafe_delete

LOG = logger.logger

cluster_name = settings.TARGET_CLUSTER
namespace_name = settings.TARGET_NAMESPACE
osdpl_name = settings.OSH_DEPLOYMENT_NAME


def delete_pending_pods(cluster, pending_pods):
    try:
        for pending_pod in pending_pods:
            if pending_pod.data['status']['phase'] == 'Pending':
                for pvc in cluster.k8sclient.pvolumeclaims.list_all():
                    if pending_pod.data['metadata']['name'] in \
                            pvc.data['metadata']['name']:
                        pvc.delete()
                        LOG.info(
                            f"Delete {pvc.data['metadata']['name']}"
                            " PVC for pod "
                            f"{pending_pod.data['metadata']['name']}")
                pending_pod.delete()
                LOG.info(
                    f"Delete {pending_pod.data['metadata']['name']}"
                    " pod with Pending phase")
    except Exception:
        LOG.info("Stacklight Pending pods not found!")


@pytest.mark.usefixtures("introspect_distribution_not_changed")
@pytest.mark.usefixtures("collect_downtime_statistics")     # Should be used if ALLOW_WORKLOAD == True
@pytest.mark.usefixtures('log_method_time')
def test_replace_failed_os_control(kaas_manager, show_step):
    """Replace OpenStack control plane node after the outage.

    Scenario:
        1. Simulate power outage (Hard power off)
        2. Wait for NotReady node state
        3. Get info about nodeforscale node
        4. Create bmh
        5. Add labels
        6. Create BareMetal machine
        7. Recreate octavia resources and check
        8. Identity and rotate StackLight stateful applications
    """

    # Get namespace
    LOG.info(f"Namespace name: {namespace_name}")
    ns = kaas_manager.get_namespace(namespace_name)
    cluster = ns.get_cluster(cluster_name)

    # Check or set customHostnamesEnabled flag in Cluster object to match settings.CUSTOM_HOSTNAMES
    cluster.set_custom_hostnames_enabled(flag=settings.CUSTOM_HOSTNAMES)

    # Get public key
    LOG.info(f"Public key name {cluster_name}-key")
    public_key_name = f"{cluster_name}-key"
    ns.get_publickey(public_key_name)

    mgmt_version = \
        kaas_manager.get_mgmt_cluster().spec['providerSpec']['value']['kaas'][
            'release']
    # Gather nodes information from yaml file
    child_data = yaml.safe_load(
        templates.render_template(settings.BM_CHILD_SETTINGS_YAML_PATH,
                                  options=dict(mgmt_version=mgmt_version)))[0]
    bm_hosts_data = child_data['nodes']
    show_step(3)

    # get machine data from .yaml
    replacement_node = []
    for node in bm_hosts_data:
        if 'replaceoscontrol' in node.get('si_roles', []):
            replacement_node.append(node)
            break
    assert len(replacement_node) == 1, "BMH with si_roles " \
                                       "'replaceoscontrol'" \
                                       " not found in file!"
    replacement_node = replacement_node[0]
    print(f"Node for replacement: {replacement_node['name']}")

    workers = cluster.get_machines(machine_type='worker',
                                   machine_status='Ready')
    # get cluster machine (outage candidate)
    os_control = []
    stacklight = False
    for w in workers:
        if [n for n in w.nodeLabels if 'openstack-control-plane'
                                       in n.values()]:
            os_control.append(w)
            if [n for n in w.nodeLabels if 'stacklight' in n.values()]:
                stacklight = True
                LOG.info("StackLight enabled on node")

    show_step(4)
    target_node = [n for n in os_control
                   if replacement_node['name'] in n.name]
    assert len(target_node) == 1, "BM Machine not found on the cluster, " \
                                  "or Machine not in Ready status"
    target_node = target_node[0]

    # Get bmh and power off
    # Wait form k8s node status NotReady
    # Remove all labels from k8s node
    target_node.set_baremetalhost_power(online=False)

    LOG.info("Get k8s node!!!")
    k8s_node = target_node.get_k8s_node()
    LOG.info("Delete, and start waiting k8s node status NotReady!!!")
    old_node_k8s_name = k8s_node.name
    cluster.check.wait_k8s_node_status(old_node_k8s_name, expected_status='NotReady')
    cluster.remove_k8s_node_all_labels(target_node.name)
    machine_deletion_policy_enabled = cluster.machine_deletion_policy_enabled()
    if machine_deletion_policy_enabled:
        check_machine_unsafe_delete(cluster, target_node, wait_deletion_timeout=3600)
    else:
        target_node.delete()
        cluster.check.check_deleted_node(target_node.name)

    bmh_for_delete = [bmh for bmh in ns.get_baremetalhosts()
                      if 'replaceoscontrol' in bmh.name]
    bmh = bmh_for_delete[0]

    bmh_name = bmh.name
    ns.wait_baremetalhosts_statuses(nodes=bmh_name,
                                    wait_status='ready',
                                    retries=30,
                                    interval=60)
    LOG.info(f"Deleting BMH: {bmh_name}")
    bmh.delete()
    ns.wait_baremetalhost_deletion(bmh_name, wait_bmh_cred=True, bm_hosts_data=bm_hosts_data)

    # Create credentials, bmh, machine
    cred_name = replacement_node['name'] + '-cred'
    bmh_name = utils.render_bmh_name(
        replacement_node['name'], cluster_name,
        replacement_node.get('bootUEFI', True),
        replacement_node['bmh_labels'],
        si_roles=replacement_node.get('si_roles', False))

    replacement_node.update({'bmh_name': bmh_name, 'cred_name': cred_name})
    secret_data = {
        "username": replacement_node['ipmi']['username'],
        "password": replacement_node['ipmi']['password']
    }

    if "kaas.mirantis.com/baremetalhost-credentials-name" in replacement_node.get('bmh_annotations', {}):
        if replacement_node['ipmi'].get('monitoringUsername', False):
            secret_data.update({
                "monitoringPassword": replacement_node['ipmi']['monitoringPassword'],
                "monitoringUsername": replacement_node['ipmi']['monitoringUsername']
            })
        if not kaas_manager.api.kaas_baremetalhostscredentials.present(name=cred_name,
                                                                       namespace=ns.name):
            region = kaas_manager.get_mgmt_cluster().region_name
            ns.create_baremetalhostcredential(name=cred_name, data=secret_data, region=region,
                                              provider="baremetal")
        else:
            LOG.warning(f'bmhc: {cred_name} already exist, skipping')
    else:
        raise Exception("IPMI credentials supported only over baremetalhostcredentials")

    osdpl_node_overrides = dict()
    node_override = replacement_node.get('osdpl_node_override', {})
    if node_override:
        osdpl_node_overrides[replacement_node['name']] = node_override

    LOG.info(f"Recreate BMH node:\n{replacement_node['bmh_name']}")
    ns.create_baremetalhost(
        bmh_name=replacement_node['bmh_name'],
        bmh_secret=replacement_node['cred_name'],
        bmh_mac=replacement_node['networks'][0]['mac'],
        bmh_ipmi=node['ipmi'],
        hardwareProfile=replacement_node.get('hardwareProfile', False),
        labels=replacement_node['bmh_labels'],
        annotations=node.get('bmh_annotations', {}),
        bootUEFI=replacement_node.get('bootUEFI', True))

    LOG.info(f"Wait for bmh '{replacement_node['bmh_name'], bmh_name}' Ready")
    ns.wait_baremetalhosts_statuses(nodes=replacement_node['bmh_name'],
                                    wait_status='ready',
                                    retries=20,
                                    interval=60)

    labels = replacement_node.get('node_labels', {})

    show_step(6)
    l2TemplateSelector = replacement_node.get('l2TemplateSelector', dict())

    custom_bmhp = False
    if replacement_node.get('bmh_profile'):
        custom_bmhp = {
            'namespace': namespace_name,
            'name': replacement_node['bmh_profile']
        }
    replacement_node.update({'bmh_name': bmh_name+"-replaced"})
    release_name = cluster.clusterrelease_version
    distribution = utils.get_distribution_for_node(kaas_manager, node, release_name)
    new_machine = cluster.create_baremetal_machine(
        genname=replacement_node['bmh_name'],
        node_pubkey_name=public_key_name,
        matchlabels={'kaas.mirantis.com/'
                     'baremetalhost-id':
                         replacement_node['bmh_labels']
                         ['kaas.mirantis.com/baremetalhost-id']},
        baremetalhostprofile=custom_bmhp,
        l2TemplateSelector=l2TemplateSelector,
        labels=replacement_node['machine_labels'],
        node_labels=labels,
        distribution=distribution,
    )

    # Wait Baremetal hosts be provisioned
    ns.wait_baremetalhosts_statuses(nodes=replacement_node['bmh_name'],
                                    wait_status='provisioned',
                                    retries=30,
                                    interval=90)

    # Waiting for cluster,pods,hb are Ready after machines were added
    cluster.check.check_machines_status()
    cluster.check.check_cluster_nodes()
    cluster.check.check_k8s_nodes()
    cluster.check.check_helmbundles()

    # Check that Machine hostname is created with respect to Cluster flag 'customHostnamesEnabled'
    cluster.check.check_custom_hostnames_on_machines(machines=[cluster.get_machine(name=(new_machine.name))])

    new_k8s_node = [n for n in cluster.get_machines()
                    if replacement_node['name'] in n.name][0]
    new_node_k8s_name = new_k8s_node.get_k8s_node().name
    LOG.info(f"New node k8s name: {new_node_k8s_name}")

    show_step(7)
    LOG.info("Rerun the octavia-create-resources job")
    client_pods = cluster.k8sclient.pods.list(
        namespace="osh-system",
        name_prefix='openstack-controller')
    client_pod = [cp for cp in client_pods
                  if 'admission' not in cp.name]
    assert len(client_pod) > 0, ("No pods found with prefix "
                                 "openstack-controller in namespace "
                                 "osh-systme")
    client_pod = client_pod[0]
    cmd_octavia = ['/bin/sh', '-c',
                   'osctl-job-rerun octavia-create-resources openstack']
    resutl_cmd_octavia = client_pod.exec(cmd_octavia, container='osdpl')
    LOG.info(f"Octavia rerun job result: {resutl_cmd_octavia}")

    LOG.info("Wait for octavia-health-manager pod started on new node")

    def wait_octavia_pod(k8s_node_name=''):
        octavia_pods = cluster.k8sclient.pods.list_starts_with(
            "octavia-health-manager")
        octavia_pod = [op for op in octavia_pods
                       if op.data['spec']['node_name'] == k8s_node_name]
        if len(octavia_pod) > 0:
            LOG.info("octavia-health-manager was created")
            return True
        else:
            return False
    waiters.wait(
        lambda: wait_octavia_pod(k8s_node_name=new_node_k8s_name),
        timeout=600, interval=10,
        timeout_msg="Octavia pod is not created on the new node")
    oct_pods = cluster.k8sclient.pods.list_starts_with(
        "octavia-health-manager")
    octavia_hm_pod = [o for o in oct_pods
                      if o.data['spec']
                      ['node_name'] == new_node_k8s_name][0]
    LOG.info("Wait for octavia-health-manager pod in Ready state")
    try:
        octavia_hm_pod.wait_ready(timeout=300, interval=10)
    except exceptions.TimeoutError:
        LOG.error("Octavia pod is not ready. "
                  "Try to delete and wait again status (documentation step)")
        octavia_hm_pod.delete()
        time.sleep(10)
        oct_pods = cluster.k8sclient.pods.list_starts_with(
            "octavia-health-manager")
        octavia_hm_pod = [o for o in oct_pods
                          if o.data['spec']
                          ['node_name'] == new_node_k8s_name][0]
        octavia_hm_pod.wait_ready(timeout=450, interval=10)

    LOG.info("Verify that an OpenStack port for the node "
             "has been created and Active")
    client_pod = cluster.k8sclient.pods.list(
        namespace="openstack",
        name_prefix='keystone-client')
    assert len(client_pod) > 0, ("No pods found with prefix "
                                 "keystone-client in namespace "
                                 "openstack")
    client_pod = client_pod[0]
    port_cmd = ['/bin/sh', '-c', "openstack port show "
                                 "octavia-health-manager-listen-port-"
                                 f"{new_node_k8s_name} -f value -c status"]
    octavia_active_port = client_pod.exec(port_cmd).strip()
    assert octavia_active_port == "ACTIVE", \
        "Octavia listen port not found, or not not in status Active"
    LOG.info("Delete old ovtavia port")
    client_pod.exec(['/bin/sh', '-c',
                     "openstack port delete "
                     "octavia-health-manager-listen-port-"
                     f"{old_node_k8s_name}"])

    osdpl = cluster.k8sclient.openstackdeployment.get(osdpl_name,
                                                      namespace="openstack")
    # If Ironic is enabled, then nova-compute service is existed
    # on control nodes, so we should check that service can be removed
    if osdpl.data.get('spec').get('features', {}).get('ironic', {}):
        service_list_cmd = ['/bin/sh', '-c',
                            'openstack compute service list -f yaml']
        s_list = yaml.safe_load(client_pod.exec(service_list_cmd))
        ironic_compute_service = [
            s for s in s_list if s.get('Host') == old_node_k8s_name]

        if ironic_compute_service:
            LOG.info("Check Ironic compute-service can be deleted.")
            # After PRODX-15809 is fixed, an exception must be thrown
            # if the service can not be deleted.
            ironic_compute_service = ironic_compute_service[0]
            service_state = ironic_compute_service.get('State')
            if service_state == 'down':
                LOG.info('Serivce is down. Trying to delete service')
                s_id = ironic_compute_service.get('ID')
                delete_cmd = ['/bin/sh', '-c',
                              f'openstack compute service delete {s_id}']
                stdout = client_pod.exec(delete_cmd)
                if stdout:
                    raise Exception("Something went wrong during "
                                    f"service deletion: {stdout}")
                else:
                    LOG.info("Service deleted succesfully")
            else:
                raise Exception(f"Wrong service status: {service_state}")
        else:
            LOG.info(f"nova-compute service for host {old_node_k8s_name} "
                     "is not existed anymore")

    child_kubeconfig_name, child_kubeconfig = cluster.get_kubeconfig_from_secret()
    with open('child_conf', 'w') as f:
        f.write(child_kubeconfig)
    os_manager = openstack_manager.OpenStackManager(kubeconfig='child_conf')
    os_controller_version = os_manager.os_controller_version()
    LOG.info(f"OpenStack controller version: {os_controller_version}")

    if stacklight:
        show_step(8)  # Identity and rotate StackLight stateful applications
        try:
            pending_pods_sl = cluster.k8sclient.pods.list(namespace='stacklight')
            delete_pending_pods(cluster=cluster, pending_pods=pending_pods_sl)
        except Exception as e:
            LOG.debug(e)
            LOG.info('Trying one more time after sleep in 3 minutes')
            time.sleep(180)
            pending_pods_sl = cluster.k8sclient.pods.list(namespace='stacklight')
            LOG.debug(f"Current list of lma pending pods {pending_pods_sl}")
            delete_pending_pods(cluster=cluster, pending_pods=pending_pods_sl)

    cluster.check.check_cluster_readiness()
    cluster.check.check_k8s_pods()
    cluster.check.check_deploy_stage_success()

    LOG.info("Check Openstack resources statuses")
    os_manager.wait_all_osdpl_children_status()
    os_manager.wait_openstackdeployment_health_status()
    os_manager.wait_all_os_pods(timeout=900, interval=90)
