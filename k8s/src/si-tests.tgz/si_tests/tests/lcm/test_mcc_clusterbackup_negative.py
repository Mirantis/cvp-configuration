#    Copyright 2026 Mirantis, Inc.
#
#    Licensed under the Apache License, Version 2.0 (the "License"); you may
#    not use this file except in compliance with the License. You may obtain
#    a copy of the License at
#
#         http://www.apache.org/licenses/LICENSE-2.0
#
#    Unless required by applicable law or agreed to in writing, software
#    distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
#    WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
#    License for the specific language governing permissions and limitations
#    under the License.
import pytest
import yaml
from kubernetes.client.rest import ApiException

from si_tests import logger
from si_tests.tests.lcm.test_mcc_clusterbackup import MCCClusterBackupBase
from si_tests.utils import templates, mcc_clusterbackup_utils
from si_tests.utils import waiters, exceptions

LOG = logger.logger


NONEXISTENT_RCLONE_CRED_NAME = "si-tests-nonexistent-rclone-credential"
NONEXISTENT_KEK_NAME = "si-tests-nonexistent-keyencryptionkey"
WRONG_TARGET_CLUSTER = "si-tests-nonexistent-cluster-name"
FAKE_NAMESPACE = "si-tests-nonexistent-ns-for-clusterbackup"

# Placeholder for negative tests that intentionally break S3 remoteSecret
# (see create_s3_autobackup_resources_wrong_remote_secret).
WRONG_S3_REMOTE_SECRET_VALUE = "wrong_value"

# RFC 5737 TEST-NET-1 — typically unreachable; use for "NFS host down" style negative tests.
UNREACHABLE_NFS_HOST = "192.0.2.254"


class TestClusterBackupNegative(MCCClusterBackupBase):
    """Negative e2e scenarios for cluster backup"""

    def _build_wrong_nfs_url_from_good(self, good_url):
        """Return a malformed host:path URL (wrong export path) for the same host."""

        if ":" not in good_url:
            return f"{UNREACHABLE_NFS_HOST}:/nonexistent-export-path"
        host, _, path = good_url.partition(":")
        return f"{host}:/this-export-path-does-not-exist-neg-test"

    def _build_unreachable_nfs_url(self, good_url):
        """Replace host with UNREACHABLE_NFS_HOST, keep path from good_url if present."""

        if ":" in good_url:
            _, _, path = good_url.partition(":")
            return f"{UNREACHABLE_NFS_HOST}:{path}"
        return f"{UNREACHABLE_NFS_HOST}:{good_url}"

    def _admission_denied_unknown_parameter(self, exception, parameter_name,
                                            webhook_name="validations.kaas.mirantis.com"):
        """True when cluster admission rejects backup spec due to poisoned parameter."""

        if exception.status != 400:
            return False
        body = exception.body or ""
        if isinstance(body, bytes):
            body = body.decode("utf-8", errors="replace")
        return (
                webhook_name in body
                and parameter_name in body.lower()
                and "not found" in body.lower()
        )

    def _check_incorrect_namespace(self, exception):
        """True when cluster admission rejects cluster backup spec due to incorrect namespace"""

        if exception.status != 400:
            return False
        body = exception.body or ""
        if isinstance(body, bytes):
            body = body.decode("utf-8", errors="replace")
        return (
                "the namespace of the provided object does not match the namespace" in body.lower()
        )

    @pytest.mark.parametrize("clusterbackup_cleanup_actions", ["s3"], indirect=True)
    def test_negative_wrong_rclone_s3_credential_ref_in_cluster_spec(self, clusterbackup_cleanup_actions):
        """Test negative scenario for wrong rclone credential reference in cluster backup spec for S3"""

        self.cluster.check.check_cluster_readiness()
        self.cluster.check.check_k8s_nodes()

        try:
            poisoned_backup_configuration = {
                "rclone": {
                    "bucket": self.clusterbackup_manager.s3_dir_path,
                    "credential": NONEXISTENT_RCLONE_CRED_NAME,
                },
            }
            self.cluster.patch({"spec": {"providerSpec": {"value": {"backup": poisoned_backup_configuration}}}})

            raise Exception("Test passed but should have failed. Admission should block "
                            "incorrect values in cluster backup spec.")
        except ApiException as e:
            if self._admission_denied_unknown_parameter(e, "rclonecredential"):
                LOG.info(
                    "Admission webhook rejected the cluster backup spec: invalid or missing rclone credential "
                    "reference. This is expected behaviour. Cleaning up KEK, rclone credential, and backup spec."
                )
            else:
                raise Exception(
                    f"Admission webhook rejected the cluster backup spec: invalid or missing rclone credential "
                    f"(status={e.status}, body={e.body})")

    @pytest.mark.parametrize("clusterbackup_cleanup_actions", ["nfs"], indirect=True)
    def test_negative_wrong_nfs_upload_url_in_cluster_spec(self, clusterbackup_cleanup_actions):
        """Test negative scenario for wrong NFS upload URL in cluster backup spec for NFS"""

        self.cluster.check.check_cluster_readiness()
        self.cluster.check.check_k8s_nodes()
        self.create_kek()

        bad_url = self._build_wrong_nfs_url_from_good(self.clusterbackup_manager.nfs_endpoint)
        backup_configuration = {"nfsUploadUrl": bad_url, "keyEncryptionKey": self.clusterbackup_manager.kek_name}

        LOG.info(f"Patching cluster with backup configuration with wrong URL: {backup_configuration}")
        self.cluster.patch({"spec": {"providerSpec": {"value": {"backup": backup_configuration}}}})

        failed_cluster_backup = self.create_clusterbackup()
        try:
            self.clusterbackup_manager.wait_clusterbackup_status(
                name=failed_cluster_backup.name, expected_status="Failed", timeout=2100, interval=120)
        except exceptions.TimeoutError as e:
            if self.cluster.workaround.prodx_59965():
                LOG.info("Workaround for ProDX-59965 is applying.")
                failed_cluster_backup.patch(
                    {
                        "metadata": {
                            "annotations": {
                                "kaas.mirantis.com/validate": "false",
                            },
                        },
                    }
                )
                pytest.skip("Workaround for PRODX-59965 is applied. Skipping test.")
            else:
                raise Exception(f"Cluster backup failed with unexpected status: Exception={e}")

        LOG.info(f"Backup with wrong URL was failed. Deleting cluster backup {failed_cluster_backup.name} "
                 f"then fix Error and create new backup")
        failed_cluster_backup.delete()
        waiters.wait(
            lambda: not self.clusterbackup_manager.clusterbackups.present(
                name=failed_cluster_backup.name, namespace=self.clusterbackup_manager.cluster.namespace),
            timeout=120, interval=2,
            timeout_msg=f"Object {failed_cluster_backup.name} wasn't deleted on time")

        backup_configuration = {"nfsUploadUrl": self.clusterbackup_manager.nfs_endpoint}
        LOG.info(f"Patching cluster with backup configuration with correct URL: {backup_configuration}")
        self.cluster.patch({"spec": {"providerSpec": {"value": {"backup": backup_configuration}}}})

        recovered_cluster_backup = self.create_clusterbackup()
        self.clusterbackup_manager.wait_clusterbackup_status(
            name=recovered_cluster_backup.name, expected_status="Completed", timeout=600, interval=30)

        LOG.info("Backup with correct URL was created. Verifying files on remote storage")
        cluster_backup_verification = self.clusterbackup_manager.get_clusterbackup(
            name=self.clusterbackup_manager.clusterbackup_name)
        files_names = self.get_full_files_names(clusterbackup_object=cluster_backup_verification, share_type="nfs")
        self.clusterbackup_manager.wait_objects_exist_on_remote(files_list=files_names, share_type="nfs")

    @pytest.mark.parametrize("clusterbackup_cleanup_actions", ["s3"], indirect=True)
    def test_negative_wrong_key_encryption_key_ref_in_cluster_spec_s3(self, clusterbackup_cleanup_actions):
        """Test negative scenario for wrong key encryption key reference in cluster backup spec for S3"""

        self.cluster.check.check_cluster_readiness()
        self.cluster.check.check_k8s_nodes()

        try:
            poisoned_backup_configuration = {
                "keyEncryptionKey": NONEXISTENT_KEK_NAME,
                "rclone": {
                    "bucket": self.clusterbackup_manager.s3_dir_path,
                    "credential": NONEXISTENT_RCLONE_CRED_NAME,
                },
            }
            self.cluster.patch({
                "spec": {
                    "providerSpec": {
                        "value": {
                            "backup": poisoned_backup_configuration
                        }
                    }
                }
            })

            raise Exception("Test passed but should have failed. Admission should block "
                            "incorrect values in cluster backup spec.")
        except ApiException as e:
            if self._admission_denied_unknown_parameter(e, "keyencryptionkey"):
                LOG.info(
                    "Admission webhook rejected the cluster backup spec: "
                    "invalid or missing rkeyEncryptionKey credential reference. "
                    "This is expected behaviour. Cleaning up KEK, rclone credential, and backup spec."
                )
            else:
                raise Exception(
                    f"Admission webhook rejected the cluster backup spec: "
                    f"invalid or missing rkeyEncryptionKey credential "
                    f"(status={e.status}, body={e.body})")

    @pytest.mark.parametrize("clusterbackup_cleanup_actions", ["nfs"], indirect=True)
    def test_negative_wrong_key_encryption_key_ref_in_cluster_spec_nfs(self, clusterbackup_cleanup_actions):
        """Test negative scenario for wrong key encryption key reference in cluster backup spec for NFS"""

        self.cluster.check.check_cluster_readiness()
        self.cluster.check.check_k8s_nodes()

        try:
            poisoned_backup_configuration = {
                "keyEncryptionKey": NONEXISTENT_KEK_NAME,
                "nfsUploadUrl": self.clusterbackup_manager.nfs_endpoint
            }
            self.cluster.patch({
                "spec": {
                    "providerSpec": {
                        "value": {
                            "backup": poisoned_backup_configuration
                        }
                    }
                }
            })
            self.cluster.patch({"spec": {"providerSpec": {"value": {"backup": poisoned_backup_configuration}}}})

            raise Exception("Test passed but should have failed. Admission should block "
                            "incorrect values in cluster backup spec.")
        except ApiException as e:
            if self._admission_denied_unknown_parameter(e, "keyencryptionkey"):
                LOG.info(
                    "Admission webhook rejected the cluster backup spec: "
                    "invalid or missing keyEncryptionKey. This is expected behaviour. "
                    "Cleaning up KEK, rclone credential, and backup spec."
                )
            else:
                raise Exception(
                    f"Admission webhook rejected the cluster backup spec: "
                    f"invalid or missing keyEncryptionKey credential "
                    f"(status={e.status}, body={e.body})")

    @pytest.mark.parametrize("clusterbackup_cleanup_actions", ["s3"], indirect=True)
    def test_negative_wrong_s3_remote_secret_value_then_fix(self, clusterbackup_cleanup_actions):
        """Test negative scenario for wrong S3 remote secret value in cluster backup spec for S3"""

        self.cluster.check.check_cluster_readiness()
        self.cluster.check.check_k8s_nodes()
        self.create_kek()

        data = yaml.safe_load(templates.render_template(
            self.clusterbackup_manager.cluster_backup_rclone_cred_file_path))
        data["spec"]["remoteConfig"]["access_key_id"] = self.clusterbackup_manager.s3_access_key_id
        data["spec"]["remoteSecret"]["value"] = WRONG_S3_REMOTE_SECRET_VALUE
        data["metadata"]["namespace"] = self.cluster_ns_name
        rclone_cred = self.clusterbackup_manager.create_rclonecredential(data=data)

        self.clusterbackup_manager.configure_cluster(share_type="s3")
        failed_cluster_backup = self.create_clusterbackup()
        self.clusterbackup_manager.wait_clusterbackup_status(
            name=failed_cluster_backup.name, expected_status="Failed", timeout=1200, interval=60)

        LOG.info(f"Backup with wrong S3 remote secret value was failed. "
                 f"Deleting cluster backup {failed_cluster_backup.name} "
                 f"then fix remoteSecret and create new backup")

        rclone_cred.patch({"spec": {"remoteSecret": {"value": self.clusterbackup_manager.s3_access_secret_key}}})
        failed_cluster_backup.delete()

        waiters.wait(
            lambda: not self.clusterbackup_manager.clusterbackups.present(
                name=failed_cluster_backup.name, namespace=self.clusterbackup_manager.cluster.namespace),
            timeout=120, interval=2,
            timeout_msg=f"Object {failed_cluster_backup.name} wasn't deleted on time")

        recovered_cluster_backup = self.create_clusterbackup()
        self.clusterbackup_manager.wait_clusterbackup_status(
            name=recovered_cluster_backup.name, expected_status="Completed", timeout=800, interval=30)

        LOG.info("Backup with correct S3 remote secret value was created. Verifying files on remote storage")
        cluster_backup_verification = self.clusterbackup_manager.get_clusterbackup(
            name=self.clusterbackup_manager.clusterbackup_name)
        files_names = self.get_full_files_names(clusterbackup_object=cluster_backup_verification, share_type="s3")
        self.clusterbackup_manager.wait_objects_exist_on_remote(files_list=files_names, share_type="s3")
        LOG.info("Check objects are not empty and can be decoded")
        mcc_clusterbackup_utils.extract_backup_plain(clusterbackup_manager=self.clusterbackup_manager,
                                                     file_names=files_names, share_type="s3", encrypted=True)

    @pytest.mark.parametrize("clusterbackup_cleanup_actions", ["nfs"], indirect=True)
    def test_negative_nfs_unreachable_endpoint_then_fix(self, clusterbackup_cleanup_actions):
        """Test negative scenario for unreachable NFS endpoint in cluster backup spec for NFS"""

        self.cluster.check.check_cluster_readiness()
        self.cluster.check.check_k8s_nodes()
        self.create_kek()

        bad_url = self._build_unreachable_nfs_url(self.clusterbackup_manager.nfs_endpoint)

        backup_configuration = {"nfsUploadUrl": bad_url, "keyEncryptionKey": self.clusterbackup_manager.kek_name}

        LOG.info(f"Patching cluster with backup configuration with wrong URL: {backup_configuration}")
        self.cluster.patch({"spec": {"providerSpec": {"value": {"backup": backup_configuration}}}})
        failed_cluster_backup = self.create_clusterbackup()

        try:
            self.clusterbackup_manager.wait_clusterbackup_status(
                name=failed_cluster_backup.name, expected_status="Failed", timeout=3600, interval=120)
        except exceptions.TimeoutError as e:
            if self.cluster.workaround.prodx_59965():
                LOG.info("Workaround for ProDX-59965 is applying.")
                failed_cluster_backup.patch(
                    {
                        "metadata": {
                            "annotations": {
                                "kaas.mirantis.com/validate": "false",
                            },
                        },
                    }
                )
                pytest.skip("Workaround for PRODX-59965 is applied. Skipping test.")
            else:
                raise Exception(f"Cluster backup failed with unexpected status: Exception={e}")

        LOG.info("Delete failed clusterbackup object")
        failed_cluster_backup.delete()

        waiters.wait(
            lambda: not self.clusterbackup_manager.clusterbackups.present(
                name=failed_cluster_backup.name, namespace=self.clusterbackup_manager.cluster.namespace),
            timeout=120, interval=2,
            timeout_msg=f"Object {failed_cluster_backup.name} wasn't deleted on time")

        LOG.info("Patch cluster with correct NFS endpoint URL and recreate clusterbackup object")
        self.cluster.patch({
            "spec": {
                "providerSpec": {
                    "value": {
                        "backup": {
                            "nfsUploadUrl": self.clusterbackup_manager.nfs_endpoint
                        }
                    }
                }
            }
        })

        recovered_cluster_backup = self.create_clusterbackup()
        self.clusterbackup_manager.wait_clusterbackup_status(
            name=recovered_cluster_backup.name, expected_status="Completed", timeout=600, interval=30)
        cluster_backup_verification = self.clusterbackup_manager.get_clusterbackup(
            name=self.clusterbackup_manager.clusterbackup_name)
        files_names = self.get_full_files_names(clusterbackup_object=cluster_backup_verification, share_type="nfs")
        self.clusterbackup_manager.wait_objects_exist_on_remote(files_list=files_names, share_type="nfs")
        LOG.info("Check objects are not empty and can be decoded")
        seed_nfs_share_mount_path = self.clusterbackup_manager.seed_nfs_share_mount_path
        mcc_clusterbackup_utils.extract_backup_plain(clusterbackup_manager=self.clusterbackup_manager,
                                                     file_names=files_names,
                                                     share_type="nfs",
                                                     nfs_mount_path=seed_nfs_share_mount_path,
                                                     encrypted=True)

    @pytest.mark.parametrize("clusterbackup_cleanup_actions", ["nfs"], indirect=True)
    def test_negative_wrong_nfs_path_or_malformed_url_nfs(self, clusterbackup_cleanup_actions):
        self.cluster.check.check_cluster_readiness()
        self.cluster.check.check_k8s_nodes()
        self.create_kek()

        bad_url = "invalid-nfs-url-missing-colon-separator"

        backup_configuration = {"nfsUploadUrl": bad_url, "keyEncryptionKey": self.clusterbackup_manager.kek_name}

        LOG.info(f"Patching cluster with backup configuration with wrong URL: {backup_configuration}")
        self.cluster.patch({"spec": {"providerSpec": {"value": {"backup": backup_configuration}}}})
        failed_cluster_backup = self.create_clusterbackup()

        try:
            self.clusterbackup_manager.wait_clusterbackup_status(
                name=failed_cluster_backup.name, expected_status="Failed", timeout=800, interval=20)
        except exceptions.TimeoutError as e:
            if self.cluster.workaround.prodx_59965():
                LOG.info("Workaround for ProDX-59965 is applying.")
                failed_cluster_backup.patch(
                    {
                        "metadata": {
                            "annotations": {
                                "kaas.mirantis.com/validate": "false",
                            },
                        },
                    }
                )
                pytest.skip("Workaround for PRODX-59965 is applied. Skipping test.")
            else:
                raise Exception(f"Cluster backup failed with unexpected status: Exception={e}")

        LOG.info("Delete failed clusterbackup object")
        failed_cluster_backup.delete()
        waiters.wait(
            lambda: not self.clusterbackup_manager.clusterbackups.present(
                name=failed_cluster_backup.name, namespace=self.clusterbackup_manager.cluster.namespace),
            timeout=120, interval=2,
            timeout_msg=f"Object {failed_cluster_backup.name} wasn't deleted on time")

        LOG.info("Patch cluster with correct NFS endpoint URL and recreate clusterbackup object")
        self.cluster.patch({
            "spec": {
                "providerSpec": {
                    "value": {
                        "backup": {
                            "nfsUploadUrl": self.clusterbackup_manager.nfs_endpoint
                        }
                    }
                }
            }
        })

        recovered_cluster_backup = self.create_clusterbackup()
        self.clusterbackup_manager.wait_clusterbackup_status(
            name=recovered_cluster_backup.name, expected_status="Completed", timeout=600, interval=30)
        cluster_backup_verification = self.clusterbackup_manager.get_clusterbackup(
            name=self.clusterbackup_manager.clusterbackup_name)
        files_names = self.get_full_files_names(clusterbackup_object=cluster_backup_verification, share_type="nfs")
        self.clusterbackup_manager.wait_objects_exist_on_remote(files_list=files_names, share_type="nfs")

    @pytest.mark.parametrize("clusterbackup_cleanup_actions", ["s3"], indirect=True)
    def test_negative_clusterbackup_wrong_target_cluster_name_s3(self, clusterbackup_cleanup_actions):
        self.cluster.check.check_cluster_readiness()
        self.cluster.check.check_k8s_nodes()
        self.create_kek()
        self.create_rclone_cred()

        self.clusterbackup_manager.configure_cluster(share_type="s3")
        cluster_backup_spec = yaml.safe_load(templates.render_template
                                             (self.clusterbackup_manager.cluster_backup_file_path))
        cluster_backup_spec["spec"]["targetCluster"] = WRONG_TARGET_CLUSTER

        try:
            self.clusterbackup_manager.create_clusterbackup(data=cluster_backup_spec)

            raise Exception("Test passed but should have failed. Admission should block "
                            "incorrect values(wrong target cluster name) in cluster backup spec.")
        except ApiException as e:
            if self._admission_denied_unknown_parameter(e, "clusters",
                                                        webhook_name="clusterbackups.kaas.mirantis.com"):
                LOG.info(
                    "Admission webhook rejected the cluster backup spec: invalid target cluster name "
                    "reference. This is expected behaviour"
                )
            else:
                raise Exception(f"Admission webhook rejected the cluster backup spec: "
                                f"(status={e.status}, body={e.body})")

    @pytest.mark.parametrize("clusterbackup_cleanup_actions", ["nfs"], indirect=True)
    def test_negative_clusterbackup_wrong_target_cluster_name_nfs(self, clusterbackup_cleanup_actions):
        """Test negative scenario for wrong target cluster name in cluster backup spec for NFS"""

        self.cluster.check.check_cluster_readiness()
        self.cluster.check.check_k8s_nodes()
        self.create_kek()
        self.create_rclone_cred()

        self.clusterbackup_manager.configure_cluster(share_type="nfs")
        cluster_backup_spec = yaml.safe_load(templates.render_template
                                             (self.clusterbackup_manager.cluster_backup_file_path))
        cluster_backup_spec["spec"]["targetCluster"] = WRONG_TARGET_CLUSTER

        try:
            self.clusterbackup_manager.create_clusterbackup(data=cluster_backup_spec)

            raise Exception("Test passed but should have failed. Admission should block "
                            "incorrect values(wrong target cluster name) in cluster backup spec.")
        except ApiException as e:
            if self._admission_denied_unknown_parameter(e, "clusters",
                                                        webhook_name="clusterbackups.kaas.mirantis.com"):
                LOG.info(
                    "Admission webhook rejected the cluster backup spec: invalid target cluster name "
                    "reference. This is expected behaviour"
                )
            else:
                raise Exception(f"Admission webhook rejected the cluster backup spec: "
                                f"(status={e.status}, body={e.body})")

    @pytest.mark.parametrize("clusterbackup_cleanup_actions", ["s3"], indirect=True)
    def test_negative_clusterbackup_wrong_namespace_s3(self, clusterbackup_cleanup_actions):
        """Test negative scenario for wrong namespace in cluster backup spec for S3"""

        self.cluster.check.check_cluster_readiness()
        self.cluster.check.check_k8s_nodes()
        self.create_kek()
        self.create_rclone_cred()

        self.clusterbackup_manager.configure_cluster(share_type="s3")
        cluster_backup_spec = yaml.safe_load(templates.render_template
                                             (self.clusterbackup_manager.cluster_backup_file_path))
        cluster_backup_spec["metadata"]["namespace"] = FAKE_NAMESPACE

        try:
            self.clusterbackup_manager.create_clusterbackup(data=cluster_backup_spec)

            raise Exception("Test passed but should have failed. Admission should block "
                            "incorrect values(wrong target cluster name) in cluster backup spec.")
        except ApiException as e:
            if self._check_incorrect_namespace(e):
                LOG.info(
                    "Admission webhook rejected the cluster backup spec: invalid target cluster name "
                    "reference. This is expected behaviour"
                )
            else:
                raise Exception(f"Admission webhook rejected the cluster backup spec: "
                                f"(status={e.status}, body={e.body})")

    @pytest.mark.parametrize("clusterbackup_cleanup_actions", ["nfs"], indirect=True)
    def test_negative_clusterbackup_wrong_namespace_nfs(self, clusterbackup_cleanup_actions):
        """Test negative scenario for wrong namespace in cluster backup spec for NFS"""

        self.cluster.check.check_cluster_readiness()
        self.cluster.check.check_k8s_nodes()
        self.create_kek()

        self.clusterbackup_manager.configure_cluster(share_type="nfs")
        cluster_backup_spec = yaml.safe_load(templates.render_template
                                             (self.clusterbackup_manager.cluster_backup_file_path))
        cluster_backup_spec["metadata"]["namespace"] = FAKE_NAMESPACE

        try:
            self.clusterbackup_manager.create_clusterbackup(data=cluster_backup_spec)

            raise Exception("Test passed but should have failed. Admission should block "
                            "incorrect values(wrong target cluster name) in cluster backup spec.")
        except ApiException as e:
            if self._check_incorrect_namespace(e):
                LOG.info(
                    "Admission webhook rejected the cluster backup spec: invalid target cluster name "
                    "reference. This is expected behaviour"
                )
            else:
                raise Exception(f"Admission webhook rejected the cluster backup spec: "
                                f"(status={e.status}, body={e.body})")

    @pytest.mark.parametrize("clusterbackup_cleanup_actions", ["s3"], indirect=True)
    def test_delete_clusterbackup_denied_while_in_progress_s3(self, clusterbackup_cleanup_actions):
        """Test negative scenario for deletion of active cluster backup while it is in progress for S3"""
        self.cluster.check.check_cluster_readiness()
        self.cluster.check.check_k8s_nodes()
        self.create_kek()
        self.create_rclone_cred()

        self.clusterbackup_manager.configure_cluster(share_type="s3")
        active_cluster_backup = self.create_clusterbackup()

        self.clusterbackup_manager.wait_clusterbackup_status(
            name=active_cluster_backup.name, expected_status="UploadPending", timeout=180, interval=2)
        try:
            active_cluster_backup.delete()
            raise Exception(
                "Deletion succeeded but should have failed. "
                "The system must block the deletion of an active cluster backup."
            )
        except ApiException as api_exception:
            if api_exception.status == 400:
                LOG.info(
                    f"Deletion of active cluster backup was blocked with expected status {api_exception.status}. "
                    "This is expected behaviour."
                )
                LOG.info("Wait until clusterbackup will be in Completed state for successful deletion")
                self.clusterbackup_manager.wait_clusterbackup_status(
                    name=active_cluster_backup.name, expected_status="Completed", timeout=1200, interval=60)
            else:
                raise Exception(
                    f"Active cluster backup deletion was rejected with unexpected status: {api_exception.status}. "
                    f"Response body: {api_exception.body}"
                ) from api_exception

    @pytest.mark.parametrize("clusterbackup_cleanup_actions", ["nfs"], indirect=True)
    def test_delete_clusterbackup_denied_while_in_progress_nfs(self, clusterbackup_cleanup_actions):
        """Test negative scenario for deletion of active cluster backup while it is in progress for NFS"""

        self.cluster.check.check_cluster_readiness()
        self.cluster.check.check_k8s_nodes()
        self.create_kek()

        self.clusterbackup_manager.configure_cluster(share_type="nfs")
        active_cluster_backup = self.create_clusterbackup()

        self.clusterbackup_manager.wait_clusterbackup_status(
            name=active_cluster_backup.name, expected_status="UploadPending", timeout=180, interval=2)
        try:
            active_cluster_backup.delete()
            raise Exception(
                "Deletion succeeded but should have failed. "
                "The system must block the deletion of an active cluster backup."
            )
        except ApiException as api_exception:
            if api_exception.status == 400:
                LOG.info(
                    f"Deletion of active cluster backup was blocked with expected status {api_exception.status}. "
                    "This is expected behaviour."
                )
                LOG.info("Wait until clusterbackup will be in Completed state for successful deletion")
                self.clusterbackup_manager.wait_clusterbackup_status(
                    name=active_cluster_backup.name, expected_status="Completed", timeout=1200, interval=60)
            else:
                raise Exception(
                    f"Active cluster backup deletion was rejected with unexpected status: {api_exception.status}. "
                    f"Response body: {api_exception.body}"
                ) from api_exception

    @pytest.mark.parametrize("clusterbackup_cleanup_actions", ["s3"], indirect=True)
    def test_delete_rclonecredential_denied_while_in_progress_s3(self, clusterbackup_cleanup_actions):
        """Test negative scenario for deletion of rclone credential while it is in progress for S3"""

        self.cluster.check.check_cluster_readiness()
        self.cluster.check.check_k8s_nodes()
        self.create_kek()
        rclone_cred = self.create_rclone_cred()

        self.clusterbackup_manager.configure_cluster(share_type="s3")
        active_cluster_backup = self.create_clusterbackup()

        self.clusterbackup_manager.wait_clusterbackup_status(
            name=active_cluster_backup.name, expected_status="UploadPending", timeout=180, interval=2)
        try:
            rclone_cred.delete()
            raise Exception(
                "Deletion succeeded but should have failed. "
                "The system must block the deletion of an active cluster backup."
            )
        except ApiException as api_exception:
            if api_exception.status == 400:
                LOG.info(
                    f"Deletion of rclone credentials backup was blocked with expected status {api_exception.status}. "
                    "This is expected behaviour."
                )
                LOG.info("Wait until clusterbackup will be in Completed state for successful "
                         "deletion by cleanup procedure")
                self.clusterbackup_manager.wait_clusterbackup_status(
                    name=active_cluster_backup.name, expected_status="Completed", timeout=1200, interval=60)
            else:
                raise Exception(
                    f"Active cluster backup deletion was rejected with unexpected status: {api_exception.status}. "
                    f"Response body: {api_exception.body}"
                ) from api_exception

    @pytest.mark.parametrize("clusterbackup_cleanup_actions", ["s3"], indirect=True)
    def test_delete_keyencryptionkey_denied_while_in_progress_s3(self, clusterbackup_cleanup_actions):
        """Test negative scenario for deletion of key encryption key while it is in progress for S3"""

        self.cluster.check.check_cluster_readiness()
        self.cluster.check.check_k8s_nodes()
        kek = self.create_kek()
        self.create_rclone_cred()

        self.clusterbackup_manager.configure_cluster(share_type="s3")
        active_cluster_backup = self.create_clusterbackup()

        self.clusterbackup_manager.wait_clusterbackup_status(
            name=active_cluster_backup.name, expected_status="UploadPending", timeout=180, interval=2)
        try:
            kek.delete()
            raise Exception(
                "Deletion succeeded but should have failed. "
                "The system must block the deletion of an active cluster backup."
            )
        except ApiException as api_exception:
            if api_exception.status == 400:
                LOG.info(
                    f"Deletion of kek for backup was blocked with expected status {api_exception.status}. "
                    "This is expected behaviour."
                )
                LOG.info("Wait until clusterbackup will be in Completed state for successful "
                         "deletion by cleanup procedure")
                self.clusterbackup_manager.wait_clusterbackup_status(
                    name=active_cluster_backup.name, expected_status="Completed", timeout=1200, interval=60)
            else:
                raise Exception(
                    f"Active cluster backup deletion was rejected with unexpected status: {api_exception.status}. "
                    f"Response body: {api_exception.body}"
                ) from api_exception

    @pytest.mark.parametrize("clusterbackup_cleanup_actions", ["nfs"], indirect=True)
    def test_delete_keyencryptionkey_denied_while_in_progress_nfs(self, clusterbackup_cleanup_actions):
        """Test negative scenario for deletion of key encryption key while it is in progress for NFS"""

        self.cluster.check.check_cluster_readiness()
        self.cluster.check.check_k8s_nodes()
        kek = self.create_kek()

        self.clusterbackup_manager.configure_cluster(share_type="nfs")
        active_cluster_backup = self.create_clusterbackup()

        self.clusterbackup_manager.wait_clusterbackup_status(
            name=active_cluster_backup.name, expected_status="UploadPending", timeout=180, interval=2)
        try:
            kek.delete()
            raise Exception(
                "Deletion succeeded but should have failed. "
                "The system must block the deletion of an active cluster backup."
            )
        except ApiException as api_exception:
            if api_exception.status == 400:
                LOG.info(
                    f"Deletion of kek for backup was blocked with expected status {api_exception.status}. "
                    "This is expected behaviour."
                )
                LOG.info("Wait until clusterbackup will be in Completed state for successful "
                         "deletion by cleanup procedure")
                self.clusterbackup_manager.wait_clusterbackup_status(
                    name=active_cluster_backup.name, expected_status="Completed", timeout=1200, interval=60)
            else:
                raise Exception(
                    f"Active cluster backup deletion was rejected with unexpected status: {api_exception.status}. "
                    f"Response body: {api_exception.body}"
                ) from api_exception

    @pytest.mark.parametrize("clusterbackup_cleanup_actions", ["s3"], indirect=True)
    def test_delete_backup_job_during_backup_s3(self, clusterbackup_cleanup_actions):
        """Test negative scenario for deletion of backup job during backup for S3"""

        self.cluster.check.check_cluster_readiness()
        self.cluster.check.check_k8s_nodes()
        self.create_kek()
        self.create_rclone_cred()
        backup_job_prefix = "backup"
        backup_job_namespace = "kaas"

        self.clusterbackup_manager.configure_cluster(share_type="s3")
        active_cluster_backup = self.create_clusterbackup()

        LOG.info(
            f"Wait for upload Job with prefix {backup_job_prefix} "
            f"in namespace {backup_job_namespace}, then delete it once"
        )
        self.cluster.wait_for_job_to_appear(
            name_prefix=backup_job_prefix, namespace=backup_job_namespace, timeout=300, interval=1
        )
        backup_jobs = self.cluster.k8sclient.jobs.list(namespace=backup_job_namespace, name_prefix=backup_job_prefix)
        assert backup_jobs, f"No Job with prefix {backup_job_prefix} in {backup_job_namespace}"
        for backup_job in backup_jobs:
            LOG.info(f"Deleting backup job {backup_job.namespace}/{backup_job.name}")
            backup_job.delete()

        waiters.wait(
            lambda: not self.cluster.k8sclient.jobs.list(namespace=backup_job_namespace, name_prefix=backup_job_prefix),
            timeout=120,
            interval=1,
            timeout_msg=f"Job {backup_job_prefix} still listed in {backup_job_namespace} after delete",
        )

        LOG.info(f"Wait for upload Job {backup_job_prefix} to be recreated and complete in {backup_job_namespace}")
        self.cluster.wait_for_job_to_appear(
            name_prefix=backup_job_prefix, namespace=backup_job_namespace, timeout=600, interval=2
        )
        waiters.wait(
            lambda: self.cluster.k8sclient.jobs.check_jobs_completed(
                target_namespaces=[backup_job_namespace], jobs_prefix=backup_job_prefix
            ),
            timeout=600,
            interval=5,
            timeout_msg=f"Upload Job {backup_job_prefix} in {backup_job_namespace} did not complete after recreation",
        )

        self.clusterbackup_manager.wait_clusterbackup_status(
            name=active_cluster_backup.name, expected_status="Completed", timeout=1200, interval=60
        )

        LOG.info("Backup completed after job recreation. Verifying files on remote storage")
        cluster_backup_verification = self.clusterbackup_manager.get_clusterbackup(
            name=self.clusterbackup_manager.clusterbackup_name)
        files_names = self.get_full_files_names(clusterbackup_object=cluster_backup_verification, share_type="s3")
        self.clusterbackup_manager.wait_objects_exist_on_remote(files_list=files_names, share_type="s3")
        LOG.info("Check objects are not empty and can be decoded")
        mcc_clusterbackup_utils.extract_backup_plain(clusterbackup_manager=self.clusterbackup_manager,
                                                     file_names=files_names, share_type="s3", encrypted=True)

    @pytest.mark.parametrize("clusterbackup_cleanup_actions", ["nfs"], indirect=True)
    def test_delete_backup_job_during_backup_nfs(self, clusterbackup_cleanup_actions):
        """Test negative scenario for deletion of backup job during backup for NFS"""

        self.cluster.check.check_cluster_readiness()
        self.cluster.check.check_k8s_nodes()
        self.create_kek()

        backup_job_prefix = "backup"
        backup_job_namespace = "kaas"

        self.clusterbackup_manager.configure_cluster(share_type="nfs")
        active_cluster_backup = self.create_clusterbackup()

        LOG.info(
            f"Wait for upload Job with prefix {backup_job_prefix} in "
            f"namespace {backup_job_namespace}, then delete it once"
        )
        self.cluster.wait_for_job_to_appear(
            name_prefix=backup_job_prefix, namespace=backup_job_namespace, timeout=300, interval=1
        )
        backup_jobs = self.cluster.k8sclient.jobs.list(namespace=backup_job_namespace, name_prefix=backup_job_prefix)
        assert backup_jobs, f"No Job with prefix {backup_job_prefix} in {backup_job_namespace}"
        for backup_job in backup_jobs:
            LOG.info(f"Deleting backup job {backup_job.namespace}/{backup_job.name}")
            backup_job.delete()

        waiters.wait(
            lambda: not self.cluster.k8sclient.jobs.list(namespace=backup_job_namespace, name_prefix=backup_job_prefix),
            timeout=120,
            interval=1,
            timeout_msg=f"Job {backup_job_prefix} still listed in {backup_job_namespace} after delete",
        )

        LOG.info(f"Wait for upload Job {backup_job_prefix} to be recreated and complete in {backup_job_namespace}")
        self.cluster.wait_for_job_to_appear(
            name_prefix=backup_job_prefix, namespace=backup_job_namespace, timeout=600, interval=2
        )
        waiters.wait(
            lambda: self.cluster.k8sclient.jobs.check_jobs_completed(
                target_namespaces=[backup_job_namespace], jobs_prefix=backup_job_prefix
            ),
            timeout=600,
            interval=5,
            timeout_msg=f"Upload Job {backup_job_prefix} in {backup_job_namespace} did not complete after recreation",
        )

        self.clusterbackup_manager.wait_clusterbackup_status(
            name=active_cluster_backup.name, expected_status="Completed", timeout=1200, interval=60)

        LOG.info("Backup completed after job recreation. Verifying files on remote storage")
        cluster_backup_verification = self.clusterbackup_manager.get_clusterbackup(
            name=self.clusterbackup_manager.clusterbackup_name)
        files_names = self.get_full_files_names(clusterbackup_object=cluster_backup_verification, share_type="nfs")
        self.clusterbackup_manager.wait_objects_exist_on_remote(files_list=files_names, share_type="nfs")
        LOG.info("Check objects are not empty and can be decoded")
        seed_nfs_share_mount_path = self.clusterbackup_manager.seed_nfs_share_mount_path
        mcc_clusterbackup_utils.extract_backup_plain(clusterbackup_manager=self.clusterbackup_manager,
                                                     file_names=files_names,
                                                     share_type="nfs",
                                                     nfs_mount_path=seed_nfs_share_mount_path,
                                                     encrypted=True)

    @pytest.mark.parametrize("clusterbackup_cleanup_actions", ["s3"], indirect=True)
    def test_second_clusterbackup_same_target_denied_s3(self, clusterbackup_cleanup_actions):
        """Test negative scenario for creation of second cluster backup with the same target for S3"""

        self.cluster.check.check_cluster_readiness()
        self.cluster.check.check_k8s_nodes()
        self.create_kek()
        self.create_rclone_cred()

        self.clusterbackup_manager.configure_cluster(share_type="s3")
        first_cluster_backup = self.create_clusterbackup()

        second_clusterbackup_name = self.clusterbackup_manager.clusterbackup_name + "-second"
        try:
            self.create_clusterbackup(name=second_clusterbackup_name)
            raise Exception(
                "Creation succeeded but should have failed. "
                "The system must block the creation of a cluster backup with the same target."
            )
        except ApiException as api_exception:
            if api_exception.status == 400:
                LOG.info(
                    f"Creation of second cluster backup with the same target was "
                    f"blocked with expected status {api_exception.status}. "
                    f"Response body: {api_exception.body}. This is expected behaviour."
                )
                LOG.info("Wait until clusterbackup will be in Completed state for successful "
                         "deletion by cleanup procedure")
                self.clusterbackup_manager.wait_clusterbackup_status(
                    name=first_cluster_backup.name, expected_status="Completed", timeout=1200, interval=60)
            else:
                raise Exception(
                    f"Active cluster backup deletion was rejected with unexpected status: {api_exception.status}. "
                    f"Response body: {api_exception.body}"
                ) from api_exception

        self.clusterbackup_manager.wait_clusterbackup_status(
            name=first_cluster_backup.name, expected_status="Completed", timeout=1200, interval=30)

    @pytest.mark.parametrize("clusterbackup_cleanup_actions", ["nfs"], indirect=True)
    def test_second_clusterbackup_same_target_denied_nfs(self, clusterbackup_cleanup_actions):
        """Test negative scenario for creation of second cluster backup with the same target for NFS"""

        self.cluster.check.check_cluster_readiness()
        self.cluster.check.check_k8s_nodes()
        self.create_kek()

        self.clusterbackup_manager.configure_cluster(share_type="nfs")
        first_cluster_backup = self.create_clusterbackup()

        second_clusterbackup_name = self.clusterbackup_manager.clusterbackup_name + "-second"
        try:
            self.create_clusterbackup(name=second_clusterbackup_name)
            raise Exception(
                "Creation succeeded but should have failed. "
                "The system must block the creation of a cluster backup with the same target."
            )
        except ApiException as api_exception:
            if api_exception.status == 400:
                LOG.info(
                    f"Creation of second cluster backup with the same target was "
                    f"blocked with expected status {api_exception.status}. "
                    f"Response body: {api_exception.body}. This is expected behaviour."
                )
                LOG.info("Wait until clusterbackup will be in Completed state for successful "
                         "deletion by cleanup procedure")
                self.clusterbackup_manager.wait_clusterbackup_status(
                    name=first_cluster_backup.name, expected_status="Completed", timeout=1200, interval=60)
            else:
                raise Exception(
                    f"Active cluster backup deletion was rejected with unexpected status: {api_exception.status}. "
                    f"Response body: {api_exception.body}"
                ) from api_exception
