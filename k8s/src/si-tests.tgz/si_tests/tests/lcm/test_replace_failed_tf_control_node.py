import pytest
import yaml

from si_tests import settings
from si_tests import logger
from si_tests.utils import templates, utils
from si_tests.managers import tungstenfafric_manager
from si_tests.managers import openstack_manager
from si_tests.managers.machine_deletion_policy_manager import check_machine_unsafe_delete

LOG = logger.logger

cluster_name = settings.TARGET_CLUSTER
namespace_name = settings.TARGET_NAMESPACE
tfoperator_name = settings.TF_OPERATOR_CR_NAME


@pytest.mark.usefixtures('log_method_time')
@pytest.mark.usefixtures("collect_downtime_statistics")  # Should be used if ALLOW_WORKLOAD == True
def test_replace_failed_tf_control(kaas_manager, show_step):
    """Replace TF control plane node after the outage.

    Scenario:
        1. Get info about replace node
        2. Identity of cassandra services
        3. Simulate power outage (Hard power off)
        4. Create bmh
        5. Add labels
        6. Create BareMetal machine
        7. Remove old Cassandra hosts from the cluster configuration
        8. Force delete all pods from replaced node
        9. Force delete PV/PVC from replaced node
    """

    # Get namespace
    LOG.info(f"Namespace name: {namespace_name}")
    ns = kaas_manager.get_namespace(namespace_name)
    cluster = ns.get_cluster(cluster_name)

    # Check or set customHostnamesEnabled flag in Cluster object to match settings.CUSTOM_HOSTNAMES
    cluster.set_custom_hostnames_enabled(flag=settings.CUSTOM_HOSTNAMES)

    # Write kubeconfig
    child_kubeconfig_name, child_kubeconfig = cluster.get_kubeconfig_from_secret()
    with open('child_conf', 'w') as f:
        f.write(child_kubeconfig)
    tf_manager = tungstenfafric_manager.TFManager(kubeconfig='child_conf')
    os_manager = openstack_manager.OpenStackManager(kubeconfig='child_conf')

    # Get public key
    LOG.info(f"Public key name {cluster_name}-key")
    public_key_name = f"{cluster_name}-key"
    ns.get_publickey(public_key_name)

    show_step(1)

    mgmt_version = \
        kaas_manager.get_mgmt_cluster().spec['providerSpec']['value']['kaas'][
            'release']
    # Gather nodes information from yaml file
    child_data = yaml.safe_load(
        templates.render_template(settings.BM_CHILD_SETTINGS_YAML_PATH,
                                  options=dict(mgmt_version=mgmt_version)))[0]
    bm_hosts_data = child_data['nodes']

    # get machine data from .yaml
    replacement_node = []
    for node in bm_hosts_data:
        if 'replacetfcontrol' in node.get('si_roles', []):
            replacement_node.append(node)
            break
    assert len(replacement_node) == 1, "BMH with si_roles " \
                                       "'replacetfcontrol'" \
                                       " not found in file!"
    replacement_node = replacement_node[0]
    LOG.info(f"Node for replacement: {replacement_node['name']}")

    # get cluster machine (outage candidate)
    machines = cluster.get_machines(machine_status='Ready')
    tf_control = []
    for m in machines:
        if [n for n in m.nodeLabels if 'tfcontrol' in n.values()]:
            tf_control.append(m)
    target_node = [n for n in tf_control
                   if replacement_node['name'] in n.name]
    assert len(target_node) == 1, "BM Machine not found on the cluster, " \
                                  "or Machine not in Ready status"
    target_node = target_node[0]

    show_step(2)
    # Check if target node has cassandra db (config/analytics) to get the IP
    # addresses of the Cassandra pods that run on the node to be replaced:
    tfconfigdb = False
    tfanalyticsdb = False
    for label in target_node.nodeLabels:
        if 'tfconfigdb' in label.values():
            tfconfigdb = True
            LOG.info("Cassandra tfconfigdb detected")
        if ('tfanalyticsdb' in label.values() and
                tf_manager.is_analytics_enabled()):
            tfanalyticsdb = True
            LOG.info("Cassandra tfanalyticsdb detected")

    show_step(3)
    # Get bmh and power off
    # Wait form k8s node status NotReady
    # Remove all labels from k8s node
    target_node.set_baremetalhost_power(online=False)

    k8s_node = target_node.get_k8s_node()
    LOG.info(f"K8s node: {k8s_node.name}")
    old_node_k8s_name = k8s_node.name

    # Get PVC bounded to the local volume from the node to be removed.
    storage_class = tf_manager.get_storage_class()
    delete_pvs = [pv for pv in cluster.k8sclient.pvolumes.list_all()
                  if pv.data['spec']['storage_class_name'] == storage_class
                  and pv.data['spec']['node_affinity']['required'][
                      'node_selector_terms'][0]['match_expressions'][0][
                      'values'][0] == old_node_k8s_name]
    LOG.info("PVCs from node to be removed:")
    delete_pvcs = []
    for pv in delete_pvs:
        if not pv.data['spec']['claim_ref']:
            continue
        pvc_name = pv.data['spec']['claim_ref']['name']
        delete_pvcs.append(pvc_name)
        LOG.info(f"{pvc_name}")

    # Get Cassandra pod IPs from the node to be removed.
    ip_configdb = None
    ip_analyticsdb = None
    if tfconfigdb:
        cdb_pods = cluster.k8sclient.pods.list_all(
            namespace=tf_manager.tf_namespace,
            name_prefix="tf-cassandra-config"
        )
        pod = [p for p in cdb_pods if p.data['spec']['node_name'] ==
               old_node_k8s_name]
        assert len(pod) == 1, "Can't get IP of cassandra configdb pod from " \
                              "deleted node"
        pod = pod[0]
        cdb_pods.remove(pod)
        ip_configdb = pod.data['status']['pod_ip']
        LOG.info(f"Cassandra configdb node to be removed: {ip_configdb}")
    if tfanalyticsdb:
        adb_pods = cluster.k8sclient.pods.list_all(
            namespace=tf_manager.tf_namespace,
            name_prefix="tf-cassandra-analytics"
        )
        pod = [p for p in adb_pods if p.data['spec']['node_name'] ==
               old_node_k8s_name]
        assert len(pod) == 1, "Can't get IP of cassandra analyticsdb pod " \
                              "from deleted node"
        pod = pod[0]
        adb_pods.remove(pod)
        ip_analyticsdb = pod.data['status']['pod_ip']
        LOG.info(f"Cassandra analyticsdb node to be removed: {ip_analyticsdb}")

    LOG.info("Delete, and start waiting k8s node status `NotReady`")
    cluster.check.wait_k8s_node_status(old_node_k8s_name, expected_status='NotReady')
    cluster.remove_k8s_node_all_labels(target_node.name)
    machine_deletion_policy_enabled = cluster.machine_deletion_policy_enabled()
    if machine_deletion_policy_enabled:
        check_machine_unsafe_delete(cluster, target_node,
                                    wait_deletion_timeout=3600)
    else:
        target_node.delete()
        cluster.check.check_deleted_node(target_node.name)

    bmh_for_delete = [bmh for bmh in ns.get_baremetalhosts()
                      if 'replacetfcontrol' in bmh.name]
    bmh = bmh_for_delete[0]

    bmh_name = bmh.name
    ns.wait_baremetalhosts_statuses(nodes=bmh_name,
                                    wait_status='ready',
                                    retries=30,
                                    interval=60)
    LOG.info(f"Deleting BMH: {bmh_name}")
    bmh.delete()
    ns.wait_baremetalhost_deletion(bmh_name, wait_bmh_cred=True, bm_hosts_data=bm_hosts_data)

    show_step(4)

    # Create credentials, bmh, machine
    cred_name = replacement_node['name'] + '-cred'
    bmh_name = utils.render_bmh_name(
        replacement_node['name'], cluster_name,
        replacement_node.get('bootUEFI', True),
        replacement_node['bmh_labels'],
        si_roles=replacement_node.get('si_roles', False))

    replacement_node.update({'bmh_name': bmh_name, 'cred_name': cred_name})
    secret_data = {
        "username": replacement_node['ipmi']['username'],
        "password": replacement_node['ipmi']['password']
    }
    if "kaas.mirantis.com/baremetalhost-credentials-name" in replacement_node.get('bmh_annotations', {}):
        if replacement_node['ipmi'].get('monitoringUsername', False):
            secret_data.update({
                "monitoringPassword": replacement_node['ipmi']['monitoringPassword'],
                "monitoringUsername": replacement_node['ipmi']['monitoringUsername']
            })
        if not kaas_manager.api.kaas_baremetalhostscredentials.present(name=cred_name,
                                                                       namespace=ns.name):
            region = kaas_manager.get_mgmt_cluster().region_name
            ns.create_baremetalhostcredential(name=cred_name, data=secret_data, region=region,
                                              provider=settings.BAREMETAL_PROVIDER_NAME)
        else:
            LOG.warning(f'bmhc: {cred_name} already exist, skipping')
    else:
        raise Exception("IPMI credentials supported only over baremetalhostcredentials")

    osdpl_node_overrides = dict()
    node_override = replacement_node.get('osdpl_node_override', {})
    if node_override:
        osdpl_node_overrides[replacement_node['name']] = node_override

    LOG.info(f"Recreate BMH node:\n{replacement_node['bmh_name']}")
    ns.create_baremetalhost(
        bmh_name=replacement_node['bmh_name'],
        bmh_secret=replacement_node['cred_name'],
        bmh_mac=replacement_node['networks'][0]['mac'],
        bmh_ipmi=node['ipmi'],
        hardwareProfile=replacement_node.get('hardwareProfile', False),
        labels=replacement_node['bmh_labels'],
        annotations=node.get('bmh_annotations', {}),
        bootUEFI=replacement_node.get('bootUEFI', True))

    LOG.info(f"Wait for bmh '{replacement_node['bmh_name'], bmh_name}' Ready")
    ns.wait_baremetalhosts_statuses(nodes=replacement_node['bmh_name'],
                                    wait_status='ready',
                                    retries=20,
                                    interval=60)

    labels = replacement_node.get('node_labels', {})

    show_step(6)
    l2TemplateSelector = replacement_node.get('l2TemplateSelector', dict())

    custom_bmhp = False
    if replacement_node.get('bmh_profile'):
        custom_bmhp = {
            'namespace': namespace_name,
            'name': replacement_node['bmh_profile']
        }
    replacement_node.update({'bmh_name': bmh_name+"-replaced"})
    new_machine = cluster.create_baremetal_machine(
        genname=replacement_node['bmh_name'],
        node_pubkey_name=public_key_name,
        matchlabels={'kaas.mirantis.com/'
                     'baremetalhost-id':
                         replacement_node['bmh_labels']
                         ['kaas.mirantis.com/baremetalhost-id']},
        baremetalhostprofile=custom_bmhp,
        l2TemplateSelector=l2TemplateSelector,
        labels=replacement_node['machine_labels'],
        node_labels=labels,
        distribution=node.get('distribution', None),
    )

    # Wait Baremetal hosts be provisioned
    ns.wait_baremetalhosts_statuses(nodes=replacement_node['bmh_name'],
                                    wait_status='provisioned',
                                    retries=30,
                                    interval=90)

    # Waiting for cluster,pods,hb are Ready after machines were added
    cluster.check.check_machines_status()
    cluster.check.check_cluster_nodes()
    cluster.check.check_k8s_nodes()
    cluster.check.check_helmbundles()

    # Check machine runtime
    if settings.DESIRED_RUNTIME:
        machines = cluster.get_machines()
        replaced_machine_for_runtime_check = [machine for machine in machines
                                              if 'replaceoscontrol' in machine.name][0]
        cluster.check.compare_machines_runtime_with_desired([replaced_machine_for_runtime_check],
                                                            machine_is_new=True)

    # Check that Machine hostname is created with respect to Cluster flag 'customHostnamesEnabled'
    cluster.check.check_custom_hostnames_on_machines(machines=[cluster.get_machine(name=(new_machine.name))])

    new_k8s_node = [n for n in cluster.get_machines()
                    if replacement_node['name'] in n.name][0]
    new_node_k8s_name = new_k8s_node.get_k8s_node().name
    LOG.info(f"New node k8s name: {new_node_k8s_name}")

    show_step(7)
    if tfconfigdb:
        cmd = ['/bin/sh', '-c', f"id=$(nodetool status | grep {ip_configdb} "
                                "| awk '{{ print $7 }}') && nodetool "
                                "removenode force $id"]
        resutl_cmd = cdb_pods[0].exec(cmd, container='cassandra')
        LOG.info(f"Result of removing configdb node from cassandra cluster:"
                 f"\n{resutl_cmd}")
    if tfanalyticsdb:
        cmd = ['/bin/sh', '-c', f"id=$(nodetool status | grep {ip_analyticsdb} "
                                "| awk '{{ print $7 }}') && nodetool "
                                "removenode force $id"]
        resutl_cmd = adb_pods[0].exec(cmd, container='cassandra')
        LOG.info(f"Result of removing analyticsdb node from cassandra cluster:"
                 f"\n{resutl_cmd}")

    show_step(8)    # Force delete all pods from old node
    delete_pods = cluster.k8sclient.pods.list_all()
    try:
        for delete_pod in delete_pods:
            if delete_pod.data['spec']['node_name'] == old_node_k8s_name:
                LOG.info(f"Delete pod {delete_pod.data['metadata']['name']}")
                cluster.k8sclient.api_core.delete_namespaced_pod(
                    namespace=delete_pod.data['metadata']['namespace'],
                    name=delete_pod.data['metadata']['name'],
                    grace_period_seconds=0,
                    propagation_policy="Background")
    except Exception as e:
        if type(e).__name__ == 404:
            LOG.info("Skip deleting due to one of pods not found")

    show_step(9)  # Force delete all pv/pvc from old node
    for pv in delete_pvs:
        try:
            LOG.info(f"Delete persistent volume {pv.data['metadata']['name']}")
            cluster.k8sclient.api_core.delete_persistent_volume(
                name=pv.data['metadata']['name'],
                grace_period_seconds=0,
                propagation_policy="Background")
        except Exception as e:
            if type(e).__name__ == 404:
                LOG.info("Skip deleting due to one of Persistent Volume not "
                         "found")
    for pvc in delete_pvcs:
        try:
            LOG.info(f"Delete persistent volume claim {pvc}")
            cluster.k8sclient.api_core.delete_namespaced_persistent_volume_claim(
                namespace=tf_manager.tf_namespace,
                name=pvc,
                grace_period_seconds=0,
                propagation_policy="Background")
        except Exception as e:
            if type(e).__name__ == 404:
                LOG.info("Skip deleting due to one of Persistent Volume Claim "
                         "not found")

    cluster.check.check_cluster_readiness()
    cluster.check.check_k8s_pods()
    cluster.check.check_deploy_stage_success()
    cluster.check.check_diagnostic_cluster_status()

    LOG.info("Check TFOperator health status")
    tf_manager.wait_tfoperator_healthy(timeout=300)
    tf_manager.wait_tf_controllers_healthy()

    LOG.info("Check Openstack resources statuses")
    os_manager.wait_all_osdpl_children_status()
    os_manager.wait_openstackdeployment_health_status()
    os_manager.wait_all_os_pods()
