import pytest
import json
import time
import yaml
import os

from si_tests import logger
from si_tests.deployments.deploy_refapp import Refapp
from si_tests.deployments.utils import helpers, kubectl_utils, file_utils
from si_tests.utils.workload_report import VMWorkloadDowntimeReport
from si_tests.lcm import openstack_lcm
from si_tests import settings
from si_tests.utils import utils, waiters, templates
from si_tests.utils import packaging_version as version

LOG = logger.logger


def update_prerequisites(os_manager):
    src_version = version.parse(os_manager.os_controller_version())
    dst_version = version.parse(settings.OSH_OPERATOR_UPDATE_TAG)
    if (
        src_version >= version.parse("1.2.0") and
        dst_version >= version.parse("1.3.0")
    ):
        kubectl = kubectl_utils.Kubectl()
        LOG.info("Applying Envoy Gateway")
        kubectl.apply(file_utils.get_release("60-envoy-gateway.yaml"))


def update_postrequisites(os_manager):
    # TODO(mkarpin): add ability to disable testing of postrequisites updates for MOSK master
    if version.parse(settings.OSH_OPERATOR_UPDATE_TAG) >= version.parse("1.3.0"):
        kubectl = kubectl_utils.Kubectl()
        LOG.info("Applying Ceph")
        release_yaml = helpers.get_ceph_operator_yaml()
        release_content = file_utils.get_yaml_content(release_yaml)
        release_version = list(filter(
            lambda x: x["name"] == "ceph-operator",
            release_content["spec"]["releases"]))[0]["version"]
        kubectl.apply(release_yaml)
        os_manager.wait_helmbundle_release_update(
            "ceph-operator",
            "ceph-operator",
            os_manager.os_helm_system_namespace,
            release_version
        )
        os_manager.wait_resources(settings.CEPH_LCM_MIRANTIS_NS, 1800, 60)
        os_manager.wait_resources(settings.ROOK_CEPH_NS, 1800, 60)
        ceph_dpl = os_manager.api.cephdeployments.get(
            name="cephcluster", namespace=settings.CEPH_LCM_MIRANTIS_NS
        )
        ceph_dpl.wait_ready()
        # Ceph update rotates the ceph secret, which triggers a redeploy of OpenStack services
        os_manager.wait_os_deployment_status(
            timeout=settings.OPENSTACK_LCM_OPERATIONS_TIMEOUT,
            status='APPLIED'
        )
        LOG.info("Wait until all services in health section get status `Ready`")
        os_manager.wait_openstackdeployment_health_status()
        LOG.info("Wait os jobs to success and pods to become Ready")
        os_manager.wait_os_resources(
            timeout=settings.OPENSTACK_LCM_OPERATIONS_TIMEOUT,
            interval=20
        )


@pytest.mark.usefixtures("mos_workload_downtime_report")
@pytest.mark.usefixtures("mos_per_node_workload_check_after_test")
@pytest.mark.usefixtures("check_pods_during_update")
def test_update_os_controller_simple(os_manager):
    """Update OS Controller.
       Parameters required for test execution:
         - KUBECONFIG
         - OSH_OPERATOR_UPDATE_REPO
         - OSH_OPERATOR_UPDATE_TAG
         - OSH_OPERATOR_CHART_URL
    """

    update_prerequisites(os_manager)
    openstack_lcm.update_os_controller(os_manager)
    update_postrequisites(os_manager)


@pytest.mark.usefixtures("mos_per_node_workload_check_after_test")
@pytest.mark.usefixtures("check_pods_during_update")
def test_update_os_controller_with_refapp(os_manager,
                                          openstack_client_manager,
                                          func_name):
    """Update OS Controller with refapp tests. Test can be run only on vms.
    1) Deploy RefApp
    2) Check RefApp workability before update
    3) Update OpenStack controller
    4) Check RefApp workability after update
    5) Delete RefApp

       Parameters required for test execution:
         - KUBECONFIG
         - OSH_OPERATOR_UPDATE_REPO
         - OSH_OPERATOR_UPDATE_TAG
         - OSH_OPERATOR_CHART_URL
    """

    refapp = Refapp(openstack_client_manager)
    try:
        refapp.deploy()
        refapp.check()
        with VMWorkloadDowntimeReport(func_name, 'mos'):
            update_prerequisites(os_manager)
            openstack_lcm.update_os_controller(os_manager)
            update_postrequisites(os_manager)
        refapp.check()
    except Exception:
        if (settings.OPENSTACK_COLLECT_REFAPP_MODE.lower() == "on_error"):
            refapp.collect_logs()
        raise
    finally:
        if (settings.OPENSTACK_COLLECT_REFAPP_MODE.lower() == "always"):
            refapp.collect_logs()
        refapp.delete()


@pytest.mark.parametrize("_", ["CLUSTER_NAME={0}"
                               .format(settings.TARGET_CLUSTER)])
@pytest.mark.usefixtures("check_pods_during_update")
def test_update_os_controller_with_pinning_images(os_manager, _):
    """Update OS Controller to the patch version with pinning the image versions
     of the following components:
     - Open vSwitch
     - Kubernetes entrypoint
     https://docs.mirantis.com/mosk/25.2/ops/update-managed/patch.html

     1) Disable automated_openvswitch_restart by setting it to false
     2) Create configmap in OpenStack namespace if Rockoon is used
     3) Add the OpenvSwitch and kubernetes-entrypoint images
     to the OpenStack deployment object
     4) Waiting for network section in OpenStack deployment has been updated
     5) Start updating OpenStack controller

           Parameters required for test execution:
             - KUBECONFIG
             - OSH_OPERATOR_UPDATE_REPO
             - OSH_OPERATOR_UPDATE_TAG
             - OSH_OPERATOR_CHART_URL
        """

    LOG.info("Disable automated_openvswitch_restart option in rockoon-config ConfigMap")
    body = {
        "data": {
            "extra_conf.ini": "[maintenance]\n"
                              "respect_nova_az = false\n"
                              "automated_openvswitch_restart = false\n"
        }
    }

    os_manager.api.configmaps.update(
        name="rockoon-config",
        namespace="osh-system",
        body=body
    )

    os_helmbundle_images = os_manager.get_os_helmbundle_images()[
        "openstack-networking"]["openstack-openvswitch"]
    osdpl_name = settings.OSH_DEPLOYMENT_NAME
    osdpl = os_manager.get_openstackdeployment(osdpl_name)
    openstack_version = osdpl.read().spec["openstack_version"]
    fp_before_update = osdpl.read().status["fingerprint"]
    netw_body = osdpl.data

    if os_manager.is_rockoon_used:
        LOG.info("Rockoon is used")
        openstack_deployment_artifacts_config = file_utils.join(os.path.dirname(
            os.path.abspath(__file__)),
            "../../templates/configmaps/openstack_deployment_artifacts_config.yaml")
        configmap_name = ('test-update-os-controller-with-pinning-images-%s' %
                          str(time.time_ns()))
        configmap_template = templates.render_template(
            openstack_deployment_artifacts_config,
            {'OPENSTACK_DEPLOYMENT_ARTIFACTS_NAME': configmap_name,
             'KUBE_ENTRYPOINT_IMAGE_URL': os_helmbundle_images["dep_check"],
             'OPENVSWITCH_IMAGE_URL': os_helmbundle_images["openvswitch_vswitchd"],
             'OPENSTACK_VERSION': openstack_version}
        )
        configmap_json_body = json.dumps(
            yaml.load(configmap_template, Loader=yaml.SafeLoader))
        LOG.info(f"Creating configmap {configmap_name} in OpenStack namespace")
        os_manager.api.configmaps.create(
            name=configmap_name, namespace="openstack",
            body=json.loads(configmap_json_body))

    LOG.info("Adding the OpenvSwitch and kubernetes-entrypoint images"
             "to the openstackdeployment object")
    netw_body = utils.merge_dicts(netw_body, {"spec": {"services": {
        "networking": {"openvswitch": {"values": {"images": {"tags": {
            "dep_check": os_helmbundle_images["dep_check"],
            "openvswitch_db_server": os_helmbundle_images[
                "openvswitch_db_server"],
            "openvswitch_vswitchd": os_helmbundle_images[
                "openvswitch_vswitchd"]
        }}}}}}}})
    osdpl.patch(body=netw_body)
    LOG.info("Waiting for network section in OpenStack deployment has been updated")
    timeout_msg = "Network section in Openstack deployment hasn't been updated"
    waiters.wait(os_manager.check_osdpl_status_value,
                 predicate_args=('fingerprint',
                                 fp_before_update,
                                 False),
                 timeout=1200,
                 timeout_msg=timeout_msg)

    update_prerequisites(os_manager)
    LOG.info("Start updating OpenStack controller")
    openstack_lcm.update_os_controller(os_manager)
    LOG.info("Finished updating OpenStack controller")
    update_postrequisites(os_manager)


def test_pods_not_restarted_during_update(request):
    """Checks whether pods were restarted during the update."""
    result = getattr(request.session, "pods_restart_result", None)

    if result is None:
        pytest.skip("Pod restart check is disabled")

    if result["restarted"]:
        pytest.fail(
            "Pods restarted during update\n"
            f"Removed: {result['removed']}\n"
            f"Added: {result['added']}"
        )
