import yaml
import pytest

from dateutil import parser
from datetime import datetime
from dataclasses import dataclass
from si_tests import logger, settings

LOG = logger.logger


@dataclass
class MachineData:
    upgrade_index: int
    started_at: datetime
    finished_at: datetime
    reconfigure_started_at: datetime
    reconfigure_finished_at: datetime
    machine_name: str

    def __lt__(self, other):
        return self.upgrade_index < other.upgrade_index


def test_compare_indexes_timestamps():
    """
    This test is comparing upgrade order based on timestamps vs UpgradeIndex values
    Also checks logic based on dedicated controlplane True/False
    """

    timestamps_file = settings.MACHINES_TIMESTAMPS_YAML_FILE
    if not timestamps_file:
        message = "No data was provided for testing. Skipping"
        LOG.warning(message)
        pytest.skip(message)
    with open(timestamps_file, 'r') as f:
        data = yaml.safe_load(f)

    if not data['is_ansible_version_changed']:
        message = "Ansible version on machines is the same as before, nothing to check here. Skipping"
        LOG.warning(message)
        pytest.skip(message)

    compare_list_control = []
    compare_list_worker = []

    for machine, d in data.get('after_test').items():
        m_type = d.get('machine_type')
        upgrade_index = d.get('upgradeIndex')
        started_at = parser.isoparse(d.get('phases').get('deploy').get('startedAt'))
        finished_at = parser.isoparse(d.get('phases').get('deploy').get('finishedAt'))
        reconfigure_started = parser.isoparse(d.get('phases').get('reconfigure').get('startedAt'))
        reconfigure_finished = parser.isoparse(d.get('phases').get('reconfigure').get('finishedAt'))

        LOG.info(f"Machine {machine} type is {m_type} with upgrade index {upgrade_index} "
                 f"started to upgrade at: {started_at}")
        m_data = MachineData(
            upgrade_index=upgrade_index,
            started_at=started_at,
            finished_at=finished_at,
            reconfigure_started_at=reconfigure_started,
            reconfigure_finished_at=reconfigure_finished,
            machine_name=machine)
        if m_type == 'control':
            compare_list_control.append(m_data)
        elif m_type in ['worker', 'storage']:
            compare_list_worker.append(m_data)
        else:
            raise NotImplementedError("Unexpected machine type")

    # Sort machines lists by timestamps and indexes to compare
    sorted_by_time_ctl = sorted(compare_list_control, key=lambda x: x.started_at)
    sorted_by_index_ctl = sorted(compare_list_control, key=lambda x: x.upgrade_index)
    sorted_by_time_wkr = sorted(compare_list_worker, key=lambda x: x.started_at)
    sorted_by_index_wkr = sorted(compare_list_worker, key=lambda x: x.upgrade_index)

    expected_upgrade_sequence_ctrl = " --> ".join([i.machine_name for i in sorted_by_index_ctl])
    actual_upgrade_sequence_ctrl = " --> ".join([i.machine_name for i in sorted_by_time_ctl])
    LOG.info(f"Expected sequence for control machines: {expected_upgrade_sequence_ctrl}")
    LOG.info(f"Actual   sequence for control machines: {actual_upgrade_sequence_ctrl}")

    fail_messages = []
    if sorted_by_time_ctl != sorted_by_index_ctl:
        fail_messages.append("Upgrade sequence for controllers is not as expected.")

    parallel = data.get('max_worker_upgrade_count')

    # Split by groups depending on maxWorkerUpgradeCount value
    groups = [
        sorted(sorted_by_index_wkr[i:i+parallel]) for i in range(0, len(sorted_by_index_wkr), parallel)]
    groups_by_time = [
        sorted(sorted_by_time_wkr[i:i+parallel]) for i in range(0, len(sorted_by_time_wkr), parallel)]

    expected_seq = " --> ".join([str([k.machine_name for k in j]) for j in groups])
    expected_seq_time = " --> ".join([str([k.machine_name for k in j]) for j in groups_by_time])
    LOG.info(f"MaxWorkerUpgradeCount is set to {parallel}")
    LOG.info(f"Expected sequence for worker machines: {expected_seq}")
    LOG.info(f"Actual   sequence for worker machines: {expected_seq_time}")
    if groups_by_time != groups:
        fail_messages.append("Upgrade sequence for workers is not as expected")

    dedicated_ctrplane = data.get('dedicated_control_plane', True)
    if not dedicated_ctrplane:
        # If not dedicated controlplane, then the first worker must start to upgrade only after all of controllers are
        # upgraded. So, we'll check that first worker started_at time greater then last controller finished_at time
        # Finished time is the time, when reconfigure is finished
        first_wkr_by_time = sorted_by_time_wkr[0]
        last_ctl_by_time = sorted_by_time_ctl[-1]
        first_worker_started = first_wkr_by_time.started_at
        last_ctrl_finished = last_ctl_by_time.reconfigure_finished_at
        if not first_worker_started > last_ctrl_finished:
            fail_messages.append(f"Dedicated controlplane is set to False. Workers should start to upgrade only "
                                 f"after all of controllers are upgraded. But, first worker started to upgrade at "
                                 f"{first_worker_started} and last controller finished at: {last_ctrl_finished}")
    else:
        # In this case at least one of controllers had to be finished before workers are started
        # Check that first worker started_time greater then first controller finished_time
        first_wkr_by_time = sorted_by_time_wkr[0]
        first_ctl_by_time = sorted_by_time_ctl[0]
        first_worker_started = first_wkr_by_time.started_at
        first_ctl_finished = first_ctl_by_time.reconfigure_finished_at
        if not first_worker_started > first_ctl_finished:
            fail_messages.append("First worker started to upgrade earlier then first control is finished")

    if fail_messages:
        for message in fail_messages:
            LOG.error(message)
        raise AssertionError(fail_messages)
