#    Copyright 2022 Mirantis, Inc.
#
#    Licensed under the Apache License, Version 2.0 (the "License"); you may
#    not use this file except in compliance with the License. You may obtain
#    a copy of the License at
#
#         http://www.apache.org/licenses/LICENSE-2.0
#
#    Unless required by applicable law or agreed to in writing, software
#    distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
#    WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
#    License for the specific language governing permissions and limitations
#    under the License.
import base64
from datetime import datetime

from kubernetes.client.rest import ApiException
import pytest
import yaml

from si_tests import logger
from si_tests import settings
from si_tests.managers import bootstrap_manager
from si_tests.managers import pdns_manager
from si_tests.utils import waiters
from si_tests.utils.certs import CertManager

LOG = logger.logger


@pytest.mark.usefixtures("introspect_distribution_not_changed")
def test_set_child_custom_cert(kaas_manager, show_step):
    """Add custom cert to the child cluster.

    Scenario:
        1. Collecting env data
        2. Init bootstrap using SI_CONFIG
        3. Get old cert from lb and kubeconfig data
        4. Generate and set new cert
        5. Wait for update data in kubeconfig - WR for PRODX-27128
        6. Check and validate cert

    With SEED_PDNS_ENABLED the certificate is generated for a name published in the seed
    node PowerDNS instead of the load balancer IP address, which k0s does not accept as
    the API server certificate name. See si-test-install-pdns-on-seed-node.
    """

    def cluster_kubeconfig_contains_ca(cluster, ca):
        _, kubeconfig_yaml = cluster.get_kubeconfig_from_secret()
        kubeconfig = yaml.load(kubeconfig_yaml, Loader=yaml.SafeLoader)
        cert_auth_data = kubeconfig['clusters'][0]['cluster']['certificate-authority-data']
        cert_auth_data_decoded = base64.b64decode(cert_auth_data).decode("utf-8")

        if ca in cert_auth_data_decoded:
            return True
        else:
            return False

    def cluster_contains_ca(kaas_manager, cluster, ca):
        ns = kaas_manager.get_namespace(cluster.namespace)
        cluster = ns.get_cluster(cluster.name)

        provider_status = cluster.data['status']['providerStatus']
        api_server_cert = provider_status['apiServerCertificate']
        api_server_cert_decoded = base64.b64decode(api_server_cert).decode("utf-8")

        if ca in api_server_cert_decoded:
            return True
        else:
            return False

    show_step(1)
    cluster_name = settings.TARGET_CLUSTER
    namespace_name = settings.TARGET_NAMESPACE
    ns = kaas_manager.get_namespace(namespace_name)
    cluster = ns.get_cluster(cluster_name)

    show_step(2)
    bootstrap = bootstrap_manager.BootstrapManager.get_si_config_bootstrap_manager()

    # 'k0s' and 'mke' are different keys in Cluster spec.providerSpec.value.tls,
    # the one matching the cluster LCM engine must be used
    app = "k0s" if cluster.k0s_enabled() else "mke"

    host, ips, dns_names, host_address = pdns_manager.get_app_cert_hostname(
        bootstrap=bootstrap, cluster=cluster, record=app)

    show_step(3)
    port = cluster.get_kube_api_port()
    LOG.info(f"Kube API port on the control nodes: {port}")

    show_step(4)
    ca_dir_suffix = datetime.now().strftime('%d-%-H-%-M')
    ca_path = f'{app}-{cluster.name}-{ca_dir_suffix}'
    cert_dir = cluster.name

    cert_pem, key_pem, ca_pem = bootstrap.generate_cert(ips=ips, dns_names=dns_names,
                                                        ca_path=ca_path, cert_dir=cert_dir)
    cert_manager = CertManager(kaas_manager=kaas_manager)
    cert_manager.apply_cert_for_app(app=app, cluster=cluster, hostname=host,
                                    cert_pem=cert_pem, key_pem=key_pem, ca_pem=ca_pem,
                                    address=host_address)

    show_step(5)
    # WR for PRODX-27128
    if cluster.k0s_enabled():
        waiters.wait(
            lambda: cluster_contains_ca(kaas_manager, cluster, ca=ca_pem),
            interval=10, timeout=300,
            timeout_msg="status.providerStatus.apiServerCertificate was not updated with the new CA")
    else:
        waiters.wait(
            lambda: cluster_kubeconfig_contains_ca(cluster, ca=ca_pem),
            interval=10, timeout=300,
            timeout_msg="Kubeconfig was not updated with new cert data.")

    show_step(6)
    # renew cluster obj with updated cert
    cluster.check.check_cert_conversation(host, address=host_address)
    # k0s serves the custom certificate only for the matching SNI name, so the name has
    # to be requested explicitly, otherwise the default k0s certificate is returned
    waiters.wait_pass(
        lambda: cluster.check.check_cert_equal(
            port, cert=cert_pem, servername=host if cluster.k0s_enabled() else None),
        expected=(AssertionError, ApiException),
        interval=30, timeout=600,
        timeout_msg="The custom certificate is not served on every node")
    cluster.store_k8s_artifacts()
