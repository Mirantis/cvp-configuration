#    Copyright 2013 - 2016 Mirantis, Inc.
#
#    Licensed under the Apache License, Version 2.0 (the "License"); you may
#    not use this file except in compliance with the License. You may obtain
#    a copy of the License at
#
#         http://www.apache.org/licenses/LICENSE-2.0
#
#    Unless required by applicable law or agreed to in writing, software
#    distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
#    WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
#    License for the specific language governing permissions and limitations
#    under the License.

import os
from uuid import uuid4

import pytest
import yaml

import si_tests.utils.waiters as helpers
from si_tests import logger
from si_tests import settings
from si_tests.deployments.utils import kubectl_utils
from si_tests.managers import helm3_manager
from si_tests.managers.kaas_manager import Manager
from si_tests.utils import waiters, utils

LOG = logger.logger


def get_status_waiter(kubectl: kubectl_utils.Kubectl, tgt):
    try:
        _data = kubectl.get('', f'{tgt} -o yaml').result_yaml
        _ = _data['status']
    except KeyError as k:
        LOG.warning(f'Yaml parsing error: {k}')
        return False
    return True


def test_base_cnnc_on_child(show_step):
    """Simple installation test for https://gerrit.mcp.mirantis.com/c/mcp/k8s-cross-node-network-checker/
    * simple install, using re-filled configs
    * dump generated objects to artifacts, for debug.
    * perform simple test checks:
    - all pods alive
    - all discovered nodes in OK status
    - expected and discovered nodes count is same
    """

    artifacts_dir = settings.ARTIFACTS_DIR
    # dummy uuuid, for multiply debug runs. we don't want to lost staging yamls
    run_uuid = str(uuid4())[0:6]
    # NOTE(alexz): we continue work with k8s-kaas style, aka with everything through mgmt.
    # This will be required later, for integration with mcc-provider-whatever-config-passed.
    # if test required to run w\o kaas mgmt-need to fix accordingly.
    kaas_manager = Manager(kubeconfig=settings.KUBECONFIG_PATH)
    # NOTE: artifact download must be managed by groovy
    cnnc_chart_file = os.path.join(artifacts_dir, 'cnnc.tgz')
    cloud_prober_chart_file = os.path.join(artifacts_dir, 'cloudprober.tgz')
    for t in [cnnc_chart_file, cloud_prober_chart_file]:
        if not os.path.isfile(t):
            pytest.fail(f"File {t} not exist!")
    child_name = settings.TARGET_CLUSTER
    child_namespace = settings.TARGET_NAMESPACE
    # TODO(alexz): after integration with SL, double check - if we can populate more than one NS.
    # currently, sane hardcode, to not allow multiply installations
    cnnc_namespace = 'netchecker-test1'
    # currently hardcoded in chart.
    netcheckertargetsconfig_name = 'config'

    # Acquiring child kubeconfig
    ns = kaas_manager.get_namespace(child_namespace)
    child_cluster = ns.get_cluster(child_name)
    kubeconfig_name, child_kubeconfig = child_cluster.get_kubeconfig()
    kubeconfig_path = os.path.join(artifacts_dir, f'{kubeconfig_name}_{run_uuid}')
    LOG.info(f"Saving child cluster kubeconfig to {kubeconfig_path}")
    with open(kubeconfig_path, "w") as f:
        f.write(child_kubeconfig)
    # just to stop warning messages from helm...
    os.chmod(path=kubeconfig_path, mode=400)
    #
    helm = helm3_manager.Helm3Manager(namespace=child_namespace, kubeconfig_path=kubeconfig_path, verbose=True)
    kubectl = kubectl_utils.Kubectl(kubeconfig=kubeconfig_path, verbose=True, namespace=cnnc_namespace)
    child_manager = Manager(kubeconfig_path)
    # Creating namespace
    LOG.info(f"Creating cnnc namespace {cnnc_namespace}")
    child_manager.get_or_create_namespace(cnnc_namespace)
    helm.install_chart(kubeconfig_path, chart_name="cnnc", chart_path=cnnc_chart_file,
                       namespace=cnnc_namespace, values_path=None)
    helm.install_chart(kubeconfig_path, chart_name="cloudprober", chart_path=cloud_prober_chart_file,
                       namespace=cnnc_namespace, values_path=None)
    LOG.info(f"Waiting all pods in ns:{cnnc_namespace} to be ready, pre-config")
    helpers.wait(lambda: child_manager.api.pods.check_pods_statuses(target_namespaces=cnnc_namespace),
                 timeout=240, interval=10,
                 timeout_msg="Some pods are not in correct status/phase")

    child_data = utils.render_child_data(kaas_manager.si_config, {'cnnc_namespace': cnnc_namespace})

    for checkerinventoryconfigs in child_data.get('checkerinventoryconfigs_raw', []):
        checkerinventoryconfigs_file = os.path.join(artifacts_dir, f'input_checkerinventoryconfigs_{run_uuid}.yaml')
        LOG.info(f"Saving object checkerinventoryconfigs to {checkerinventoryconfigs_file}")
        with open(os.path.join(checkerinventoryconfigs_file), "w") as f:
            yaml.safe_dump(checkerinventoryconfigs, f)
        kubectl.create('', command=f"-f {checkerinventoryconfigs_file}")

    for netcheckertargetsconfig in child_data.get('netcheckertargetsconfigs_raw', []):
        netcheckertargetsconfig_file = os.path.join(artifacts_dir, f'input_netcheckertargetsconfig_{run_uuid}.yaml')
        LOG.info(f"Saving object netcheckertargetsconfig to {netcheckertargetsconfig_file}")
        with open(os.path.join(netcheckertargetsconfig_file), "w") as f:
            yaml.safe_dump(netcheckertargetsconfig, f)
        kubectl.create('', command=f"-f {netcheckertargetsconfig_file}")

    # waiting for cnnc object to be spawned with alive status
    waiters.wait_pass(lambda: get_status_waiter(kubectl,
                                                f'netcheckertargetsconfigs {netcheckertargetsconfig_name}'),
                      timeout_msg=f"netcheckertargetsconfigs/{netcheckertargetsconfig_name}:status "
                                  f"has not been populated")

    LOG.info(f"Waiting all pods in ns:{cnnc_namespace} to be ready, post-config")
    helpers.wait(lambda: child_manager.api.pods.check_pods_statuses(target_namespaces=cnnc_namespace),
                 timeout=240, interval=10,
                 timeout_msg="Some pods are not in correct status/phase")
    # waiting cnnc to process
    # Get objects for debug only
    for obj in ['checkerinventoryconfigs', 'inventoryagents', 'netcheckertargetsconfigs', 'cm']:
        LOG.info(f'Dumping {obj}s')
        out = kubectl.get(f'{obj}', '-o yaml', cnnc_namespace).result_yaml
        for i in out['items']:
            name = i['metadata']['name']
            # we don't need those internal k8s info
            if name == 'kube-root-ca.crt':
                continue
            result_obj_file = os.path.join(artifacts_dir, f'{cnnc_namespace}_{obj}_{name}_{run_uuid}.yaml')
            with open(os.path.join(result_obj_file), "w") as f:
                yaml.safe_dump(result_obj_file, f)

    # test: check object statuses
    netcheckertargetsconfig = kubectl.get('netcheckertargetsconfigs',
                                          f'{netcheckertargetsconfig_name} -o yaml', cnnc_namespace).result_yaml
    LOG.info(f"check status of {netcheckertargetsconfig['kind']}/{netcheckertargetsconfig['metadata']['name']}")
    for node in netcheckertargetsconfig["status"]["nodes"]:
        _n_status = node.get('status', 'NOTFOUND').lower()
        _n_name = node['name']
        LOG.info(f"netcheckertargetsconfigs status for {_n_name}:{_n_status}")
        if _n_status != 'ok':
            pytest.fail(f"netcheckertargetsconfigs status for node:{_n_name} if wrong:{_n_status}")

    # test: expected amount of discovered nodes
    si_test_label = 'si-test/test-cnnc-should-have-nodes-count'
    si_test_label_data = netcheckertargetsconfig['metadata'].get('labels', []).get(si_test_label, '')
    if si_test_label_data:
        nodes_count = len(netcheckertargetsconfig["status"]["nodes"])
        LOG.info(f"Test expected {si_test_label}: {si_test_label_data}, actual nodes count {nodes_count}")
        if int(nodes_count) != int(si_test_label_data):
            pytest.fail("Wrong expected and real discovered nodes count")
