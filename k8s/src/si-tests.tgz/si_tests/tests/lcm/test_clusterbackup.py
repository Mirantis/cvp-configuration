# Copyright 2025 Mirantis, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License"); you may
# not use this file except in compliance with the License. You may obtain
# a copy of the License at
#
#      http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
# WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
# License for the specific language governing permissions and limitations
# under the License.

import pytest
import random
import secrets
import time
import datetime
import hashlib
import numpy
import exec_helpers
from si_tests import logger, settings
from si_tests.utils import utils, waiters

LOG = logger.logger


def _clusterbackupschedule_status(cbs_obj, state='Completed'):
    cbs_obj_status = cbs_obj.data.get('status', {})
    if cbs_obj_status and isinstance(cbs_obj_status, dict):
        return str(cbs_obj_status.get('attempts', {}).get('last', {}).get('status', '')) == state
    return False


def _applicationbackup_state(ab_obj, state='Completed'):
    ab_obj_status = ab_obj.data.get('status', {})
    if ab_obj_status and isinstance(ab_obj_status, dict):
        return str(ab_obj_status.get('state', '')) == state
    return False


def _applicationbackup_syncstate(ab_obj, syncstate='Completed'):
    ab_obj_status = ab_obj.data.get('status', {})
    if ab_obj_status and isinstance(ab_obj_status, dict):
        return str(ab_obj_status.get('syncState', '')) == syncstate
    return False


def _configure_cluster_for_clusterbackup(ns, kek_name, kek_value, rclonecred_name):
    cluster_name = settings.TARGET_CLUSTER
    namespace_name = settings.TARGET_NAMESPACE
    cluster = ns.get_cluster(cluster_name)

    assert settings.KAAS_CLUSTERBACKUP_SWIFT_ACCESS_KEY, 'KAAS_CLUSTERBACKUP_SWIFT_ACCESS_KEY is empty!'
    assert settings.KAAS_CLUSTERBACKUP_SWIFT_SECRET_KEY, 'KAAS_CLUSTERBACKUP_SWIFT_SECRET_KEY is empty!'
    kek_data = {
        "apiVersion": "kaas.mirantis.com/v1alpha1",
        "kind": "KeyEncryptionKey",
        "metadata": {
            "name": kek_name,
            "namespace": namespace_name,
        },
        "spec": {
            "secret": {
                "value": kek_value,
            }
        }
    }
    kek_creation_timeout = 30
    kek_creation_interval = 5
    kek_creation_timeout_msg = (f"KeyEncryptionKey object {kek_name} in "
                                f"namespace {namespace_name} has not been created")
    LOG.info(f"Create KeyEncryptionKey object {kek_name}")
    kek = None
    kek = ns.create_keyencryptionkey_raw(kek_data)
    LOG.info(f"Wait till KeyEncryptionKey object {kek_name} appears on mgmt")
    waiters.wait(lambda: bool(ns.keyencryptionkey_is_present(name=kek_name)),
                 timeout=kek_creation_timeout,
                 interval=kek_creation_interval,
                 timeout_msg=kek_creation_timeout_msg)

    rclonecred_data = {
        "apiVersion": "kaas.mirantis.com/v1alpha1",
        "kind": "RCloneCredential",
        "metadata": {
            "name": rclonecred_name,
            "namespace": namespace_name,
        },
        "spec": {
            "remoteName": "swift",
            "remoteConfig": {
                "type": "s3",
                "access_key_id": settings.KAAS_CLUSTERBACKUP_SWIFT_ACCESS_KEY,
                "endpoint": settings.KAAS_CLUSTERBACKUP_SWIFT_ENDPOINT,
            },
            "remoteConfigSecretKey": "secret_access_key",
            "remoteSecret": {
                "value": settings.KAAS_CLUSTERBACKUP_SWIFT_SECRET_KEY,
            }
        }
    }
    rclonecred_creation_timeout = 30
    rclonecred_creation_interval = 5
    rclonecred_creation_timeout_msg = (f"RCloneCredential object {rclonecred_name} in "
                                       f"namespace {namespace_name} has not been created")
    LOG.info(f"Create RCloneCredential object {rclonecred_name}")
    rclonecred = None
    rclonecred = ns.create_rclonecredential_raw(rclonecred_data)
    LOG.info(f"Wait till RCloneCredential object {rclonecred_name} appears on mgmt")
    waiters.wait(lambda: bool(ns.rclonecredential_is_present(name=rclonecred_name)),
                 timeout=rclonecred_creation_timeout,
                 interval=rclonecred_creation_interval,
                 timeout_msg=rclonecred_creation_timeout_msg)

    cluster_backup_settings_patch = {
        "spec": {
            "providerSpec": {
                "value": {
                    "backup": {
                        "keyEncryptionKey": kek_name,
                        "rclone": {
                            "bucket": settings.KAAS_CLUSTERBACKUP_SWIFT_CONTAINER,
                            "credential": rclonecred_name,
                        }
                    }
                }
            }
        }
    }
    LOG.info(f"Patching cluster {cluster_name} with backup backend configuration")
    cluster.patch(cluster_backup_settings_patch)
    return kek, rclonecred


def _create_clusterbackup(ns, cb_name):
    cluster_name = settings.TARGET_CLUSTER
    namespace_name = settings.TARGET_NAMESPACE

    cb_data = {
        "apiVersion": "kaas.mirantis.com/v1alpha1",
        "kind": "ClusterBackup",
        "metadata": {
            "name": cb_name,
            "namespace": namespace_name,
        },
        "spec": {
            "targetCluster": cluster_name,
        }
    }

    cb_creation_timeout = 120
    cb_creation_interval = 5
    cb_creation_timeout_msg = (f"ClusterBackup object {cb_name} in "
                               f"namespace {namespace_name} has not been created")
    LOG.info(f"Create ClusterBackup object {cb_data}")
    cb = None
    cb = ns.create_clusterbackup_raw(cb_data)
    LOG.info(f"Wait till ClusterBackup object {cb_name} to backup targetCluster {cluster_name} appears on mgmt")
    waiters.wait(lambda: bool(ns.clusterbackup_is_present(name=cb_name)),
                 timeout=cb_creation_timeout,
                 interval=cb_creation_interval,
                 timeout_msg=cb_creation_timeout_msg)
    return cb


def _create_clusterbackup_schedule(ns, cbs_name, schedule, sleep_seconds):
    cluster_name = settings.TARGET_CLUSTER
    namespace_name = settings.TARGET_NAMESPACE

    cbs_data = {
        "apiVersion": "kaas.mirantis.com/v1alpha1",
        "kind": "ClusterBackupSchedule",
        "metadata": {
            "name": cbs_name,
            "namespace": namespace_name,
        },
        "spec": {
            "targetCluster": cluster_name,
            "schedule": schedule,
        }
    }

    cbs_creation_timeout = 30
    cbs_creation_interval = 5
    cbs_creation_timeout_msg = (f"ClusterBackupSchedule object {cbs_name} in "
                                f"namespace {namespace_name} has not been created")
    LOG.info(f"Create ClusterBackupSchedule object {cbs_data}")
    cbs = ns.create_clusterbackupschedule_raw(cbs_data)
    LOG.info(f"Wait till ClusterBackupSchedule object {cbs_name} to backup targetCluster "
             f"{cluster_name} appears on mgmt")
    waiters.wait(lambda: bool(ns.clusterbackupschedule_is_present(name=cbs_name)),
                 timeout=cbs_creation_timeout,
                 interval=cbs_creation_interval,
                 timeout_msg=cbs_creation_timeout_msg)

    LOG.info(f"Sleeping for {sleep_seconds} seconds to wait schedule {schedule} run")
    time.sleep(sleep_seconds)

    cb_creation_timeout = 120
    cb_creation_interval = 5
    cb_creation_timeout_msg = (f"ClusterBackup object {cbs_name} in namespace {namespace_name}"
                               f"has not been created by ClusterBackupSchedule {cbs_data}")

    cb_label = {'kaas.mirantis.com/clusterbackupschedule-reference': cbs_name}

    LOG.info(f"Wait till ClusterBackup object with label {cb_label} appears on mgmt")
    waiters.wait(lambda: bool(len(ns.get_clusterbackups_by_labels(cb_label)) == 1),
                 timeout=cb_creation_timeout,
                 interval=cb_creation_interval,
                 timeout_msg=cb_creation_timeout_msg)
    cb = ns.get_clusterbackups_by_labels(cb_label)[0]
    return cbs, cb


def wait_for_backup_job(ns, cb_name, job_postfix='upload', creation_timeout=300, creation_interval=10,
                        completion_timeout=300, completion_interval=10):
    cluster_name = settings.TARGET_CLUSTER
    cluster = ns.get_cluster(cluster_name)

    cb_job_namespace = 'kaas'
    cb_job_hash = numpy.base_repr(int(hashlib.sha224(cb_name.encode('utf-8')).hexdigest(), 16), base=35).lower()
    cb_job_name = f"backup-{cb_job_hash}-{job_postfix}"
    LOG.info(f"Wait till Job {cb_job_name} appears on targetCluster {cluster_name} in {cb_job_namespace} namespace")
    cluster.wait_for_job_to_appear(name_prefix=cb_job_name, namespace=cb_job_namespace,
                                   timeout=creation_timeout, interval=creation_interval)

    completion_timeout_msg = (f"Job {cb_job_name} from {cb_job_namespace} namespace"
                              f" on targetCluster {cluster_name} has not been completed")
    LOG.info(f"Wait till Job {cb_name} completes on targetCluster {cluster_name} in {cb_job_namespace} namespace")
    waiters.wait(lambda: cluster.k8sclient.jobs.check_jobs_completed(target_namespaces=[cb_job_namespace],
                                                                     jobs_prefix=cb_job_name),
                 timeout=completion_timeout,
                 interval=completion_interval,
                 timeout_msg=completion_timeout_msg)


def _disable_clusterbackup_and_cleanup(ns, cb_list, rclonecred, kek, cbs=None):
    cluster_name = settings.TARGET_CLUSTER
    cluster = ns.get_cluster(cluster_name)

    cluster_backup_settings_patch_cleanup = {
        "spec": {
            "providerSpec": {
                "value": {
                    "backup": None,
                }
            }
        }
    }

    cluster_backup_delete_patch = {
        "spec": {
            "delete": True,
        }
    }

    LOG.info(f"Removing backup configuration from cluster {cluster_name} providerSpec")
    cluster.patch(cluster_backup_settings_patch_cleanup)

    if cbs:
        LOG.info(f"Deleting ClusterBackupSchedule '{cbs.name}'")
        cbs.delete(async_req=True)
        cbs_deletion_timeout = 30
        cbs_deletion_interval = 5
        cbs_deletion_timeout_msg = f"Deletion failed, ClusterBackupSchedule with name '{cbs.name}' still exists"
        waiters.wait(lambda: not bool(ns.clusterbackupschedule_is_present(name=cbs.name)),
                     timeout=cbs_deletion_timeout,
                     interval=cbs_deletion_interval,
                     timeout_msg=cbs_deletion_timeout_msg)

    for cb in cb_list:
        LOG.info(f"Patching ClusterBackup '{cb.name}' with 'spec.delete: true' to remove data from external storage")
        cb.patch(cluster_backup_delete_patch)
        wait_for_backup_job(ns, cb.name, job_postfix='delete')
        cb_patch_timeout = 120
        cb_patch_interval = 30
        cb_patch_timeout_msg = "Data deletion failed, ClusterBackup archive still exists on remote storage"
        waiters.wait(lambda: bool(cb.data.get('status', {}).get('status', '') == 'Deleted'),
                     timeout=cb_patch_timeout,
                     interval=cb_patch_interval,
                     timeout_msg=cb_patch_timeout_msg)
        LOG.info(f"Deleting ClusterBackup '{cb.name}'")
        cb.delete(async_req=True)
        cb_deletion_timeout = 30
        cb_deletion_interval = 5
        cb_deletion_timeout_msg = f"Deletion failed, ClusterBackup with name '{cb.name}' still exists"
        waiters.wait(lambda: not bool(ns.clusterbackup_is_present(name=cb.name)),
                     timeout=cb_deletion_timeout,
                     interval=cb_deletion_interval,
                     timeout_msg=cb_deletion_timeout_msg)

    if rclonecred:
        LOG.info(f"Deleting RCloneCredential '{rclonecred.name}'")
        rclonecred.delete(async_req=True)
        rclonecred_deletion_timeout = 120
        rclonecred_deletion_interval = 10
        rclonecred_deletion_timeout_msg = ("Deletion failed, RCloneCredential with "
                                           f"name '{rclonecred.name}' still exists")
        waiters.wait(lambda: not bool(ns.rclonecredential_is_present(name=rclonecred.name)),
                     timeout=rclonecred_deletion_timeout,
                     interval=rclonecred_deletion_interval,
                     timeout_msg=rclonecred_deletion_timeout_msg)
    if kek:
        LOG.info(f"Deleting KeyEncryptionKey '{kek.name}'")
        kek.delete(async_req=True)
        kek_deletion_timeout = 120
        kek_deletion_interval = 30
        kek_deletion_timeout_msg = f"Deletion failed, ClusterBackup with name '{kek.name}' still exists"
        waiters.wait(lambda: not bool(ns.keyencryptionkey_is_present(name=kek.name)),
                     timeout=kek_deletion_timeout,
                     interval=kek_deletion_interval,
                     timeout_msg=kek_deletion_timeout_msg)


def _validate_clusterbackup(ns, cb):
    namespace_name = settings.TARGET_NAMESPACE
    cluster_name = settings.TARGET_CLUSTER
    cluster = ns.get_cluster(cluster_name)
    cb_name = cb.name

    ab_creation_timeout = 120
    ab_creation_interval = 5
    ab_creation_timeout_msg = (f"ApplicationBackup object {cb_name} "
                               f" on targetCluster {cluster_name} has not been created")
    LOG.info(f"Wait till ApplicationBackup object {cb_name} appears on targetCluster {cluster_name}")
    waiters.wait(lambda: bool(cluster.applicationbackup_is_present(name=cb_name)),
                 timeout=ab_creation_timeout,
                 interval=ab_creation_interval,
                 timeout_msg=ab_creation_timeout_msg)
    ab_completion_timeout = 300
    ab_completion_interval = 10
    ab_completion_timeout_msg = (f"ApplicationBackup object {cb_name} on targetCluster {cluster_name} "
                                 f" does not have 'status.state' field set to 'Completed'. "
                                 "Backup creation is stuck/failed!")
    ab = cluster.get_applicationbackup(name=cb_name)
    LOG.info(f"Wait till ApplicationBackup object {cb_name} finishes backup creation "
             f" on targetCluster {cluster_name} ('status.state' == 'Completed')")
    waiters.wait(lambda: _applicationbackup_state(ab),
                 timeout=ab_completion_timeout,
                 interval=ab_completion_interval,
                 timeout_msg=ab_completion_timeout_msg)

    wait_for_backup_job(ns, cb_name, job_postfix='upload')

    ab_sync_completion_timeout = 360
    ab_sync_completion_interval = 30
    ab_sync_completion_timeout_msg = (f"ApplicationBackup object {cb_name} on targetCluster {cluster_name} "
                                      f" does not have 'status.syncState' field set to 'Completed'. "
                                      "Backup sync to an external storage was not performed!")
    LOG.info(f"Wait till ApplicationBackup object {cb_name} on targetCluster {cluster_name} "
             f" finishes backup sync to an external storage ('status.syncState' == 'Completed')")
    waiters.wait(lambda: _applicationbackup_syncstate(ab),
                 timeout=ab_sync_completion_timeout,
                 interval=ab_sync_completion_interval,
                 timeout_msg=ab_sync_completion_timeout_msg)

    LOG.info(f"Waiting for ClusterBackup object {cb_name} 'status: Completed'")
    cb_status_timeout = 300
    cb_status_interval = 10
    cb_status_timeout_msg = (f"ClusterBackup object {cb_name} in namespace {namespace_name}"
                             f" does not have 'status.status' field set to 'Completed'")
    waiters.wait(lambda: bool(cb.data.get('status', {}).get('status', '') == 'Completed'),
                 timeout=cb_status_timeout,
                 interval=cb_status_interval,
                 timeout_msg=cb_status_timeout_msg)

    status = cb.data.get('status', {})
    LOG.info(f"ClusterBackup object {cb_name} has 'status' field:\n{status}")


def _check_cluster_ready(cluster):
    # Check that all machines in 'Ready' status
    # before machine removing
    cluster.check.check_machines_status()
    cluster.check.check_cluster_nodes()
    cluster.check.check_cluster_readiness()
    cluster.check.check_helmbundles()
    cluster.check.check_k8s_nodes()


@pytest.mark.parametrize("_", [f"CLUSTER_NAME={settings.TARGET_CLUSTER}"])
def test_create_clusterbackup_bm(kaas_manager, _, show_step):
    """This test should verify ClusterBackup feature functionality.

    Scenario:
        1. Create RCloneCredential, KeyEncryptionKey objects, patch Cluster object with backup config
        2. Create a ClusterBackup object
        3. Check ApplicationBackup object, sync job and ClusterBackup object status
        4. Create ClusterBackupSchedule object, wait till ClusterBackup object appears
        5. Check ApplicationBackup object, sync job and ClusterBackup object status for
           second, scheduled backup
        6. Patch Cluster object back (remove providerSpec.values.backup section settings).
           Delete ClusterBackup, RCloneCredential, KeyEncryptionKey objects
    """
    namespace_name = settings.TARGET_NAMESPACE
    ns = kaas_manager.get_namespace(namespace_name)

    _id = f"{random.randint(0, 999999):06}"

    show_step(1)
    kek_name = f"test-create-clusterbackup-{_id}-kek"
    # Admission webhook requires at least 32 bytes
    kek_value = secrets.token_urlsafe(40)
    rclonecred_name = f"test-create-clusterbackup-{_id}-rclonecred"
    kek, rclonecred = _configure_cluster_for_clusterbackup(ns, kek_name, kek_value, rclonecred_name)

    show_step(2)
    cb_name = f"test-create-clusterbackup-{_id}"
    cb = _create_clusterbackup(ns, cb_name)

    show_step(3)
    _validate_clusterbackup(ns, cb)

    show_step(4)
    cbs_name = f"test-create-clusterbackupschedule-{_id}"
    # Run after 2 minutes from now
    run_after_minutes = 2
    schedule = f"{(datetime.datetime.now().minute + run_after_minutes) % 60} * * * *"
    cbs, cb_scheduled = _create_clusterbackup_schedule(ns, cbs_name, schedule, run_after_minutes*60)

    show_step(5)
    _validate_clusterbackup(ns, cb_scheduled)
    LOG.info(f"Waiting for ClusterBackupSchedule object {cbs_name} 'status.attempts.last.status: Completed'")
    cbs_status_timeout = 300
    cbs_status_interval = 10
    cbs_status_timeout_msg = (f"ClusterBackupSchedule object {cbs_name} in namespace {namespace_name}"
                              f" does not have 'status.attempts.last.status' field set to 'Completed'")
    waiters.wait(lambda: _clusterbackupschedule_status(cbs),
                 timeout=cbs_status_timeout,
                 interval=cbs_status_interval,
                 timeout_msg=cbs_status_timeout_msg)

    show_step(6)
    _disable_clusterbackup_and_cleanup(ns, [cb, cb_scheduled], rclonecred, kek, cbs)


@pytest.mark.parametrize("_", [f"CLUSTER_NAME={settings.TARGET_CLUSTER}"])
def test_create_clusterbackup_and_restore_bm(kaas_manager, _, show_step):
    """This test should verify ClusterBackup feature functionality. It creates a backup and then
    tries to restore from it.

    Scenario:
        1. Create RCloneCredential, KeyEncryptionKey objects, patch Cluster object with backup config
        2. Create a ClusterBackup object
        3. Check ApplicationBackup object, sync job and ClusterBackup object status
        4. Download cluster backup file on one of controller nodes
        5. Patch Cluster object back (remove providerSpec.values.backup section settings).
           Delete ClusterBackup, RCloneCredential, KeyEncryptionKey objects
        6. Delete and restore MKE cluster
    """
    cluster_name = settings.TARGET_CLUSTER
    namespace_name = settings.TARGET_NAMESPACE
    ns = kaas_manager.get_namespace(namespace_name)
    cluster = ns.get_cluster(cluster_name)

    _id = f"{random.randint(0, 999999):06}"

    show_step(1)
    kek_name = f"test-create-clusterbackup-{_id}-kek"
    # Admission webhook requires at least 32 bytes
    kek_value = secrets.token_urlsafe(40)
    rclonecred_name = f"test-create-clusterbackup-{_id}-rclonecred"
    kek, rclonecred = _configure_cluster_for_clusterbackup(ns, kek_name, kek_value, rclonecred_name)

    show_step(2)
    cb_name = f"test-create-clusterbackup-{_id}"
    cb = _create_clusterbackup(ns, cb_name)

    show_step(3)
    _validate_clusterbackup(ns, cb)

    show_step(4)
    mgmt_machines = cluster.get_machines(machine_type='control')
    assert len(mgmt_machines) > 0, "No management machines found in cluster {cluster_name}"
    chosen_mgmt_machine = mgmt_machines[0]
    LOG.info(f"Using machine {chosen_mgmt_machine.name} for backup restoration test")
    bk_file = cb.data.get('status', {}).get('fileNames', {}).get('MKE', '').split(':')[-1]
    dek_file = f"{bk_file.split('.encrypted')[0]}.dek"
    assert bk_file, "Cannot get backup file name from 'status.filenames.MKE'"
    # Downloading the archive is a read-only operation: use the RO creds if provided,
    # otherwise fall back to the write creds. The in-cluster backup agent keeps using
    # the write creds (RCloneCredential) for upload/delete.
    ro_access = settings.KAAS_CLUSTERBACKUP_SWIFT_RO_ACCESS_KEY or settings.KAAS_CLUSTERBACKUP_SWIFT_ACCESS_KEY
    ro_secret = settings.KAAS_CLUSTERBACKUP_SWIFT_RO_SECRET_KEY or settings.KAAS_CLUSTERBACKUP_SWIFT_SECRET_KEY
    download_backup_cmd = f"""
access="{ro_access}"
secret="{ro_secret}"
host="{settings.KAAS_CLUSTERBACKUP_SWIFT_ENDPOINT}"

for file in {bk_file} {dek_file}; do
    path="/{settings.KAAS_CLUSTERBACKUP_SWIFT_CONTAINER}/${{file}}"
    date_str=$(date -R)

    # Construct the string to sign. Note the double backslashes for the \n
    # to ensure Bash receives a literal backslash-n for the echo command.
    string_to_sign="GET\\n\\n\\n${{date_str}}\\n${{path}}"

    # Calculate signature
    sig=$(echo -en "${{string_to_sign}}" | openssl sha1 -hmac "${{secret}}" -binary | base64)

    # Execute curl
    curl -H "Date: ${{date_str}}" \\
        -H "Authorization: AWS ${{access}}:${{sig}}" \\
        "${{host}}${{path}}" \\
        -o "/tmp/${{file}}"
done
"""
    chosen_mgmt_machine.run_cmd(cmd=download_backup_cmd, timeout=300, verbose=False)
    kek_save_cmd = f"""
echo "{kek_value}" > /tmp/kek_value
"""
    chosen_mgmt_machine.run_cmd(cmd=kek_save_cmd, timeout=30, verbose=False)
    decrypt_backup_cmd = f"""
openssl enc -d -aes-256-cbc -pbkdf2 -pass file:/tmp/kek_value -in /tmp/{dek_file} > dek.plain
openssl enc -d -aes-256-cbc -pbkdf2 -pass file:dek.plain -in /tmp/{bk_file} > backup.plain.tar
tar tf backup.plain.tar
"""
    chosen_mgmt_machine.run_cmd(cmd=decrypt_backup_cmd, timeout=30)

    show_step(5)
    _disable_clusterbackup_and_cleanup(ns, [cb], rclonecred, kek)

    show_step(6)
    ucp_tag = kaas_manager.get_ucp_tag(cluster.clusterrelease_version)

    # Prepare for time when k8s cluster will not exist
    cluster_lb_ip = cluster.load_balancer_ip
    all_machines = cluster.get_machines()
    keys = utils.load_keyfile(cluster.private_key)
    pkey = utils.get_rsa_key(keys['private'])
    auth = exec_helpers.SSHAuth(username='mcc-user',
                                password='', key=pkey)
    ssh_client_chosen_mgmt_machine = exec_helpers.SSHClient(host=chosen_mgmt_machine.public_ip,
                                                            port=22, auth=auth)
    ssh_clients_all_machines = []
    for m in all_machines:
        ssh = exec_helpers.SSHClient(host=m.public_ip, port=22, auth=auth)
        ssh.logger.addHandler(logger.console)
        ssh_clients_all_machines.append(ssh)

    uninstall_mke_cmd = f"""
docker container run --rm -v /var/run/docker.sock:/var/run/docker.sock \
mirantis/ucp:{ucp_tag} uninstall-ucp --id $(docker info --format '{{{{.Swarm.Cluster.ID}}}}')
sleep 30
"""
    chosen_mgmt_machine.run_cmd(cmd=uninstall_mke_cmd, timeout=300)

    for ssh in ssh_clients_all_machines:
        with ssh.sudo(True):
            LOG.info(f"Restarting containerd on {ssh}")
            ssh.check_stderr('systemctl restart containerd', verbose=True, timeout=60)

    restore_backup_cmd = f"""
sleep 60
docker container run --rm --interactive --name ucp \
    --volume /var/run/docker.sock:/var/run/docker.sock \
    mirantis/ucp:{ucp_tag} restore \
    --san={cluster_lb_ip} < backup.plain.tar
"""
    ssh_client_chosen_mgmt_machine.check_call(restore_backup_cmd, verbose=True, timeout=1800)

    _check_cluster_ready(cluster)
