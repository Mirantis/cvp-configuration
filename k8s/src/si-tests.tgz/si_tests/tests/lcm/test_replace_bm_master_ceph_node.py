# Copyright 2025 Mirantis, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License"); you may
# not use this file except in compliance with the License. You may obtain
# a copy of the License at
#
#      http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
# WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
# License for the specific language governing permissions and limitations
# under the License.

import pytest

from si_tests import logger
from si_tests import settings
from si_tests.managers.kaas_manager import Cluster, Machine, Manager  # noqa: F401
from si_tests.managers.openstack_manager import OpenStackManager
from si_tests.managers import tungstenfafric_manager
from si_tests.utils import waiters
from si_tests.utils import packaging_version as version

LOG = logger.logger


def wait_ceph_status(cluster: Cluster, expected_status="HEALTH_OK"):
    ceph_health_details = cluster.check.get_ceph_status_details()
    current_status = ceph_health_details.get('health', {}).get('status')
    if current_status == expected_status:
        LOG.info(f"Expected Ceph status {current_status} equal to current")
        return True
    else:
        LOG.info(f"Expected Ceph status = {expected_status}, but current = {current_status}. Waiting...")
        return False


def is_precaching_required(master):
    LOG.info("Checking whether to wait image-precaching or not")
    precaching_required_labels = ['openstack-', 'openvswitch', 'tf']
    master_labels = master.get_k8s_node().data.get('metadata', {}).get('labels', {}).keys()
    for label in master_labels:
        for role in precaching_required_labels:
            if label.startswith(role):
                LOG.info("image-precaching check will be required")
                return True
    LOG.info("image-precaching check is not required")
    return False


def collect_tf_data_before_replace(cluster, master):
    tf_data = {}
    machine_is_tf_contol = False
    tfconfigdb = False
    tfanalyticsdb = False
    if [n for n in master.nodeLabels if 'tfcontrol' in n.values()]:
        machine_is_tf_contol = True
        replaced_node_k8s_name = master.get_k8s_node_name()

        # Write kubeconfig
        child_kubeconfig_name, child_kubeconfig = cluster.get_kubeconfig_from_secret()
        with open('child_conf', 'w') as f:
            f.write(child_kubeconfig)
        tf_manager = tungstenfafric_manager.TFManager(kubeconfig='child_conf')

        if [n for n in master.nodeLabels if 'tfconfigdb' in n.values()]:
            tfconfigdb = True
            LOG.info("Cassandra tfconfigdb detected")
        if [n for n in master.nodeLabels if 'tfanalyticsdb' in n.values()] and tf_manager.is_analytics_enabled():
            tfanalyticsdb = True
            LOG.info("Cassandra tfanalyticsdb detected")

        # Get PVC bounded to the local volume from the node to be removed.
        storage_class = tf_manager.get_storage_class()
        delete_pvs = [pv for pv in cluster.k8sclient.pvolumes.list_all()
                      if pv.data['spec']['storage_class_name'] == storage_class
                      and pv.data['spec']['node_affinity']['required'][
                          'node_selector_terms'][0]['match_expressions'][0][
                          'values'][0] == replaced_node_k8s_name]
        LOG.info("PVCs from node to be removed:")
        delete_pvcs = []
        for pv in delete_pvs:
            if not pv.data['spec']['claim_ref']:
                continue
            pvc_name = pv.data['spec']['claim_ref']['name']
            delete_pvcs.append(pvc_name)
            LOG.info(f"{pvc_name}")

        # Get Cassandra pod IPs from the node to be removed.
        ip_configdb = None
        ip_analyticsdb = None
        cdb_pods = []
        adb_pods = []
        if tfconfigdb:
            cdb_pods = cluster.k8sclient.pods.list_all(
                namespace=tf_manager.tf_namespace,
                name_prefix="tf-cassandra-config"
            )
            pod = [p for p in cdb_pods if p.data['spec']['node_name'] == replaced_node_k8s_name]
            assert len(pod) == 1, "tf-cassandra-config pod not found! "\
                                  "Can't get IP of cassandra configdb pod from deleted node"
            pod = pod[0]
            cdb_pods.remove(pod)
            ip_configdb = pod.data['status']['pod_ip']
            LOG.info(f"Cassandra configdb node to be removed: {ip_configdb}")
        if tfanalyticsdb:
            adb_pods = cluster.k8sclient.pods.list_all(
                namespace=tf_manager.tf_namespace,
                name_prefix="tf-cassandra-analytics"
            )
            pod = [p for p in adb_pods if p.data['spec']['node_name'] == replaced_node_k8s_name]
            assert len(pod) == 1, "tf-cassandra-analytics pod not found! "\
                                  "Can't get IP of cassandra analyticsdb pod from deleted node"
            pod = pod[0]
            adb_pods.remove(pod)
            ip_analyticsdb = pod.data['status']['pod_ip']
            LOG.info(f"Cassandra analyticsdb node to be removed: {ip_analyticsdb}")

        tf_data['machine_is_tf_contol'] = machine_is_tf_contol
        tf_data['tfconfigdb'] = tfconfigdb
        tf_data['tfanalyticsdb'] = tfanalyticsdb
        tf_data['tf_manager'] = tf_manager
        tf_data['delete_pvs'] = delete_pvs
        tf_data['delete_pvcs'] = delete_pvcs
        tf_data['ip_configdb'] = ip_configdb
        tf_data['ip_analyticsdb'] = ip_analyticsdb
        tf_data['cdb_pods'] = cdb_pods
        tf_data['adb_pods'] = adb_pods

        return tf_data
    else:
        tf_data['machine_is_tf_contol'] = machine_is_tf_contol
        return tf_data


def tf_data_cleanup(cluster, tf_data):
    if tf_data['machine_is_tf_contol']:
        tfconfigdb = tf_data['tfconfigdb']
        tfanalyticsdb = tf_data['tfanalyticsdb']
        tf_manager = tf_data['tf_manager']
        delete_pvs = tf_data['delete_pvs']
        delete_pvcs = tf_data['delete_pvcs']
        ip_configdb = tf_data['ip_configdb']
        ip_analyticsdb = tf_data['ip_analyticsdb']
        cdb_pods = tf_data['cdb_pods']
        adb_pods = tf_data['adb_pods']
        if tfconfigdb:
            cmd = ['/bin/sh', '-c', f"id=$(nodetool -h ::FFFF:127.0.0.1 status | grep {ip_configdb} "
                                    "| awk '{{ print $7 }}') && nodetool -h ::FFFF:127.0.0.1 removenode force $id"]
            resutl_cmd = cdb_pods[0].exec(cmd, container='cassandra')
            LOG.info(f"Result of removing configdb node from cassandra cluster:\n{resutl_cmd}")
        if tfanalyticsdb:
            cmd = ['/bin/sh', '-c', f"id=$(nodetool -h ::FFFF:127.0.0.1 status | grep {ip_analyticsdb} "
                                    "| awk '{{ print $7 }}') && nodetool -h ::FFFF:127.0.0.1 removenode force $id"]
            resutl_cmd = adb_pods[0].exec(cmd, container='cassandra')
            LOG.info(f"Result of removing analyticsdb node from cassandra cluster:\n{resutl_cmd}")

        # Force delete all pv/pvc from old node
        for pv in delete_pvs:
            try:
                LOG.info(f"Delete persistent volume {pv.data['metadata']['name']}")
                cluster.k8sclient.api_core.delete_persistent_volume(
                    name=pv.data['metadata']['name'],
                    grace_period_seconds=0,
                    propagation_policy="Background")
            except Exception as e:
                if type(e).__name__ == 404:
                    LOG.info("Skip deleting due to one of Persistent Volume not found")
        for pvc in delete_pvcs:
            try:
                LOG.info(f"Delete persistent volume claim {pvc}")
                cluster.k8sclient.api_core.delete_namespaced_persistent_volume_claim(
                    namespace=tf_manager.tf_namespace,
                    name=pvc,
                    grace_period_seconds=0,
                    propagation_policy="Background")
            except Exception as e:
                if type(e).__name__ == 404:
                    LOG.info("Skip deleting due to one of Persistent Volume Claim not found")

        LOG.info("Check TFOperator health status")
        tf_manager.wait_tfoperator_healthy(timeout=300)
        tf_manager.wait_tf_controllers_healthy()


def replace_kaascephcluster_machine(cluster, kaascephcluster_old, old_machine_name, new_machine_name):
    kaascephcluster = cluster.get_kaascephcluster()

    if not kaascephcluster:
        LOG.warning("KaasCephCluster not found")
        return

    nodes = kaascephcluster.data.get('spec', {}).get('cephClusterSpec', {}).get('nodes', {})

    if not nodes:
        LOG.warning("KaasCephCluster nodes not found")
        return

    machine_spec = nodes.get(old_machine_name) or kaascephcluster_old.get('spec', {})\
        .get('cephClusterSpec', {}).get('nodes', {}).get(old_machine_name)

    if not machine_spec:
        LOG.warning(f"KaasCephCluster machine {old_machine_name} not found in spec.nodes. Skip replacing")
        return

    nodes.pop(old_machine_name, None)
    nodes[new_machine_name] = machine_spec

    kaascephcluster.patch({"spec": {"cephClusterSpec": {"nodes": nodes}}})


@pytest.mark.usefixtures("introspect_distribution_not_changed")
@pytest.mark.usefixtures("collect_downtime_statistics")     # Should be used if ALLOW_WORKLOAD == True
@pytest.mark.usefixtures('mcc_loadtest_prometheus')
@pytest.mark.usefixtures('mcc_loadtest_grafana')
@pytest.mark.usefixtures('mcc_loadtest_alerta')
@pytest.mark.usefixtures('mcc_loadtest_keycloak')
@pytest.mark.usefixtures('create_hoc_before_lcm_and_delete_after')
def test_replace_master_ceph_node(kaas_manager: Manager, show_step):
    """Replace BM node with control plane and Ceph roles.

    Scenario:
        1. Find master node where VIP hosted
        2. Collect data about TF if it is enabled (optional)
        3. Collect data about KaaSCephCluster
        4. Replace master Machine
        5. Add new node to the Ceph cluster
        6. Delete all Pending openstack pvc for pods (optional)
        7. Cleanup old node TF data (pvc, pv, configdb, analyticsdb) (optional)
        8. Check OpenStack readiness (optional)
        9. Check cluster readiness
    """

    cluster_name = settings.TARGET_CLUSTER
    namespace_name = settings.TARGET_NAMESPACE

    ns = kaas_manager.get_namespace(namespace_name)
    LOG.info("Namespace name - %s", namespace_name)

    cluster = ns.get_cluster(cluster_name)
    LOG.info("Cluster name - %s", cluster_name)

    # Check or set customHostnamesEnabled flag in Cluster object to match settings.CUSTOM_HOSTNAMES
    cluster.set_custom_hostnames_enabled(flag=settings.CUSTOM_HOSTNAMES)

    show_step(1)
    master = cluster.get_keepalive_master_machine()
    check_precaching = is_precaching_required(master)

    show_step(2)
    tf_data = collect_tf_data_before_replace(cluster, master)

    show_step(3)
    kaascephcluster_data = cluster.get_kaascephcluster().data

    show_step(4)
    old_k8s_node_name = master.get_k8s_node_name()
    old_k8s_machine_name = master.name
    new_machine = cluster.day2operations.replace_baremetal_machine_and_bmh(master)
    cluster.check.check_deleted_node(old_k8s_node_name)
    # Waiting for machines are Ready
    cluster.check.check_machines_status(timeout=1800)
    cluster.check.check_cluster_nodes()
    cluster.check.check_k8s_nodes()

    new_master_node_name = new_machine.get_k8s_node_name()
    # Check that Machine hostname is created with respect to Cluster flag 'customHostnamesEnabled'
    cluster.check.check_custom_hostnames_on_machines(machines=[new_machine])
    # Check machine runtime
    if settings.DESIRED_RUNTIME:
        cluster.check.compare_machines_runtime_with_desired([new_machine])

    show_step(5)
    if cluster.is_child:
        if kaascephcluster_data:
            LOG.info(f"Replace machine {old_k8s_machine_name} with {new_machine.name} in KaasCephCluster")
            replace_kaascephcluster_machine(cluster, kaascephcluster_data, old_k8s_machine_name, new_machine.name)
        LOG.info("Ceph cluster re-balancing may take some time. Wait timeout is 1h.")
        # Waiting for actual Ceph status from Ceph tools pod
        if settings.CEPH_EXEC_CRASH_ARCHIVE_ALL:
            # exec 'ceph crash archive-all' to wipe info about last crash warnings.
            cluster.check.exec_ceph_tools_command('ceph crash archive-all', return_json=False,
                                                  raise_on_fail=True)
        LOG.info("Wait Ceph HEALTH_OK status in Ceph tools")
        waiters.wait(lambda: wait_ceph_status(cluster), timeout=3600, interval=30)
        # Wait until KaaS update Cluster kind with Ceph status
        LOG.info("Wait Ceph HEALTH_OK status in cluster object")
        try:
            health_info = cluster.check.get_ceph_health_detail()
            assert health_info['status'] == "HEALTH_OK", f'Health is not OK. Will not proceed. ' \
                                                         f'Current ceph health status: {health_info}'
        except AssertionError:
            cluster.check.wait_ceph_health_status(timeout=600, interval=30)

    if cluster.clusterrelease_version.startswith(settings.MOSK_RELEASE_PREFIX) \
            and cluster.is_os_deployed():
        child_kubeconfig_name, child_kubeconfig = cluster.get_kubeconfig_from_secret()
        with open('child_conf', 'w') as f:
            f.write(child_kubeconfig)
        os_manager = OpenStackManager(kubeconfig='child_conf')
        if check_precaching:
            LOG.info("Wait image-precaching Ready")
            selector = f"spec.nodeName={new_master_node_name}"

            image_precaching_pod_timeout = 1800
            image_precaching_pod_timeout_msg = f"Image-precaching pod not found on node {new_master_node_name}"
            cluster.k8sclient.pods.wait_pod_present(timeout=image_precaching_pod_timeout,
                                                    interval=15,
                                                    timeout_msg=image_precaching_pod_timeout_msg,
                                                    namespace="openstack",
                                                    name_prefix='image-precaching',
                                                    field_selector=selector)
            image_precaching_pod = cluster.k8sclient.pods.list(namespace="openstack",
                                                               name_prefix='image-precaching',
                                                               field_selector=selector)
            assert image_precaching_pod, f"Image-precaching pod not found on node {new_master_node_name}"
            image_precaching_pod = image_precaching_pod[0]
            image_precaching_pod.wait_ready(timeout=5400)

        if version.parse(cluster.clusterrelease_version) < version.parse('mosk-17-1-0-rc-24-1'):
            show_step(6)  # Delete all Pending pvc for pods
            cluster.delete_pending_openstack_pods()

        show_step(7)  # Cleanup old node TF data (pvc, pv, configdb, analyticsdb)
        tf_data_cleanup(cluster, tf_data)

        show_step(8)
        LOG.info("Wait osdpl health status=Ready")
        os_manager.wait_openstackdeployment_health_status(timeout=1800)
        LOG.info("Wait os jobs to success and pods to become Ready")
        os_manager.wait_os_resources(timeout=1800)

    show_step(9)
    # Check/wait for correct docker service replicas in cluster
    ucp_worker_agent_name = cluster.check.get_ucp_worker_agent_name()
    cluster.check.check_actual_expected_docker_services(
        changed_after_upd={'ucp-worker-agent-x': ucp_worker_agent_name})
    cluster.check.check_k8s_pods()
    cluster.check.check_actual_expected_pods(timeout=3200)
    cluster.check.check_cluster_readiness()
    cluster.check.check_diagnostic_cluster_status()
    cluster.check.check_deploy_stage_success()

    cluster.check.check_bmh_inventory_presense()
