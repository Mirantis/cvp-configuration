import calendar
from datetime import datetime
import pytest
import yaml
from si_tests import logger
from si_tests.managers import bootstrap_manager
from si_tests import settings
from si_tests.utils import waiters

LOG = logger.logger


def autoupdate_mgmt_cluster(kaas_manager, show_step):
    cluster = kaas_manager.get_mgmt_cluster()
    r_clusters = kaas_manager.get_regional_clusters()
    # Get the current mgmt clusterrelease version until update is not started
    unexpected_message = 'Unexpected message for favorite schedule'

    def check_message():
        assert (
                "New release scheduled for upgrade" in
                kaas_manager.get_kaas_mcc_upgrade_status_condition(
                    'mcc-upgrade', 'message') and
                kaas_manager.get_kaas_mcc_upgrade_status_condition(
                    'mcc-upgrade', 'reason') == 'ReleaseScheduled'
        ), unexpected_message

    def change_weekday():
        if tomorrow_weekday_flag:
            schedule['weekdays'][str.lower(tomorrow_weekday)] = True
        else:
            schedule['weekdays'][str.lower(weekday_now)] = True

        kaas_manager.update_mccupgrade(name='mcc-upgrade', schedule=schedule)
        LOG.info(
            f"Updated mccupgrades crd: \n{yaml.dump(kaas_manager.get_kaas_mcc_upgrade('mcc-upgrade').data)}")
        check_message()

    show_step(1)
    LOG.info(f"Check init state on the {cluster._cluster_type} cluster {cluster.namespace}/{cluster.name}")
    cluster.check.check_cluster_nodes()
    cluster.check.check_machines_status()
    cluster.check.check_cluster_readiness()
    cluster.check.check_k8s_nodes()

    for r_cluster in r_clusters:
        LOG.info(f"Check init state on the {r_cluster._cluster_type} cluster {r_cluster.namespace}/{r_cluster.name}")
        r_cluster.check.check_cluster_nodes()
        r_cluster.check.check_machines_status()
        r_cluster.check.check_cluster_readiness()
        r_cluster.check.check_k8s_nodes()

    show_step(2)
    cr_before = kaas_manager.get_mgmt_cluster().clusterrelease_version
    LOG.info("Management cluster clusterrelease version is "
             "{}".format(cr_before))

    ucp_tag_in_cr_before = set(
        [x['params']['ucp_tag'] for x in kaas_manager.get_clusterrelease(
            cr_before).data['spec']['machineTypes']['control']
         if 'ucp_tag' in x['params'].keys()])
    LOG.info("Current management cluster ucp version is "
             "{}".format(ucp_tag_in_cr_before))

    # Check schedule changes
    show_step(3)

    LOG.info(f"Initial state mccupgrade crd:\n{yaml.dump(kaas_manager.get_kaas_mcc_upgrade('mcc-upgrade').data)}")
    log_message = kaas_manager.get_kaas_mcc_upgrade_status_condition('mcc-upgrade', 'message')

    LOG.info(f"Message from crd: {log_message}")
    check_message()

    ex_release_version = kaas_manager.get_kaas_mcc_upgrade_status('mcc-upgrade')['nextRelease']['version']
    LOG.info(f"Expected release to be installed: {ex_release_version}")

    show_step(4)
    date = datetime.now()
    hour_now = date.hour
    weekday_now, yesterday_weekday = (calendar.day_name[date.weekday()]), (calendar.day_name[(date.weekday() - 1) % 7])
    tomorrow_weekday = (calendar.day_name[(date.weekday() + 1) % 7])
    tomorrow_weekday_flag = False

    if hour_now == 23:
        tomorrow_weekday_flag = True
        hour_now = 0

    schedule = {
        "hours": {
            "from": hour_now + 2,
            "to": hour_now + 4,
        },
        "weekdays": {
            str.lower(yesterday_weekday): True,
            str.lower(weekday_now): False,
            str.lower(tomorrow_weekday): False,
        }
    }

    LOG.info("Add hours and weekdays in schedule mccupgrade crd")
    kaas_manager.update_mccupgrade(name='mcc-upgrade', schedule=schedule)
    check_message()

    LOG.info("Update autodelay value to False")
    kaas_manager.update_mccupgrade(name='mcc-upgrade', autodelay=False)

    LOG.info(
        f"State mccupgrade crd:\n{yaml.dump(kaas_manager.get_kaas_mcc_upgrade('mcc-upgrade').data)}")
    check_message()
    show_step(6)
    schedule['hours']['from'] = hour_now
    LOG.info("Update start time in schedule mccupgrade crd")
    kaas_manager.update_mccupgrade(name='mcc-upgrade', schedule=schedule)
    check_message()
    change_weekday()

    waiters.wait(
        lambda: (
                "New release scheduled for upgrade" not in
                kaas_manager.get_kaas_mcc_upgrade_status_condition(
                    'mcc-upgrade', 'message') and
                kaas_manager.get_kaas_mcc_upgrade_status_condition(
                    'mcc-upgrade', 'reason') == 'UpgradeStarted'
        ),
        timeout=300,
        interval=5,
        timeout_msg=f'The mcc-upgrade crd does not currently display the status of the ongoing update.'
                    f'{log_message}'
    )

    LOG.info(f"Message from crd: {log_message}")

    LOG.info(
        f"Final mccupgrade crd:\n{yaml.dump(kaas_manager.get_kaas_mcc_upgrade('mcc-upgrade').data)}")

    show_step(7)
    cluster.check.check_cluster_status("Updating", 1800)
    cluster.check.check_cluster_nodes(timeout=settings.KAAS_UPDATE_MGMT_WAIT_TIMEOUT)
    cluster.check.check_k8s_nodes()
    cluster.check.check_machines_status()
    cluster.check.check_cluster_readiness()
    cluster.check.check_upgrade_stage_success()

    kr_data = kaas_manager.get_kaasrelease("kaas-" + ex_release_version.replace(".", "-")).data
    spec_cr = kr_data['spec']['clusterRelease']
    LOG.info(f"Expected cluster release {spec_cr}")

    # Check after upgrade
    show_step(8)
    cluster.check.check_cluster_release(spec_cr)
    if cr_before != spec_cr:
        cluster.check.check_update_finished(check_managed_clusters=True)

    mgmt_cluster = kaas_manager.get_mgmt_cluster().spec['providerSpec']
    cr_after = mgmt_cluster['value']['release']

    assert spec_cr == cr_after, (
        "Cluster version in KaasRelease and Mgmt "
        "Cluster differs, that's wrong")

    LOG.info("Management cluster update clusterrelease version to "
             "{} ".format(spec_cr))

    ucp_tag_after = set(
        [x['params']['ucp_tag']
         for x in kaas_manager.get_clusterrelease(
            spec_cr).data['spec']['machineTypes']['control']
         if 'ucp_tag' in x['params'].keys()])
    if ucp_tag_in_cr_before != ucp_tag_after:
        LOG.info("Management cluster new ucp version will be "
                 "{}".format(ucp_tag_after))

    cluster.check.check_cluster_readiness(timeout=3600)
    # Check/wait for correct docker service replicas in cluster
    if cluster.lcm_type_is_ucp:
        cluster.check.check_actual_expected_docker_services()
    cluster.check.check_actual_expected_pods(timeout=600)

    show_step(9)
    for r_cluster in r_clusters:

        r_cluster.check.check_cluster_release(spec_cr)
        r_cluster.check.check_cluster_nodes()
        r_cluster.check.check_cluster_readiness()
        r_cluster.check.check_helmbundles()
        r_cluster.check.check_k8s_nodes()
        r_cluster.check.check_persistent_volumes_mounts()
        r_cluster.check.check_k8s_pods()
        r_cluster.check.check_upgrade_stage_success()

        region_after = r_cluster.spec['providerSpec']['value']['release']
        LOG.info("Regional cluster clusterrelease version is "
                 "{}".format(region_after))
        assert cr_before != region_after, "Clusterrelease version is the same as " \
                                          "the clusterrelease before the upgrade on regional cluster"

        cr_after_regional = r_cluster.spec['providerSpec']['value']['release']
        LOG.info("Regional cluster update clusterrelease version to "
                 "{} ".format(cr_after_regional))

        # Check/wait for correct docker service replicas in cluster
        if r_cluster.lcm_type_is_ucp:
            r_cluster.check.check_actual_expected_docker_services()
        r_cluster.check.check_actual_expected_pods(timeout=600)

    LOG.info("Check clusterRelease objects are existed for every release "
             "announced as supported in kaasRelease object")
    cluster.check.compare_supported_and_existed_clusterreleases()


@pytest.mark.usefixtures("store_updated_mgmt_cluster_description")
def test_mcc_autoupgrade(kaas_manager, mgmt_k8s_ip: str, show_step):
    """Check auto upgrade mgmt cluster

        Scenario:
                1. Check init state clusters
                2. Check mgmt clusterrelease version until update is not started
                3. Check initial state mccupgrade crd
                4. Add days of the week to the schedule mccupgrade
                5. Update time in mccupgrade crd
                6. Check that the update does not start earlier than the planned schedule
                7. Check the transition to the cluster update state
                8. Check mgmt clusterrelease version after update
                9. Check region clusterrelease version after update
        """
    # Keyed on the active KaaSRelease name rather than on its bootstrap version:
    # the label moves on every autoupgrade, while spec.bootstrap.version stays
    # the same within a release line and would never signal the move.
    active_kr_before = kaas_manager.get_active_kaasrelease().name
    LOG.info("Active kaasrelease before upgrade: {}".format(active_kr_before))

    upgrade_succeeded = False
    try:
        autoupdate_mgmt_cluster(kaas_manager, show_step)
        upgrade_succeeded = True
    except Exception as e:
        LOG.error("Management upgrade failed: {}".format(e))
        raise e
    finally:
        # `container-cloud bootstrap download` resolves the tarball through the
        # ACTIVE KaaSRelease ("Getting active kaas release"), but nothing above
        # waits for that label to move: autoupdate_mgmt_cluster() completes on
        # ClusterRelease / node / machine readiness, which flips earlier. So the
        # refresh used to run while `kaas.mirantis.com/active` still pointed at
        # the OLD KaaSRelease, re-download the same old binary, exit 0, and
        # leave kaas-bootstrap stale. Every later container-cloud call then died
        # with "binary version X doesn't equal to management cluster version Y"
        # — which is how three si-test-get-cluster-logs jobs per run lost the
        # logs for the exact window that needed diagnosing.
        if upgrade_succeeded:
            try:
                waiters.wait(
                    lambda: kaas_manager.get_active_kaasrelease().name != active_kr_before,
                    timeout=900,
                    # get_active_kaasrelease() is ttl_cache(ttl=10); polling
                    # faster than that only re-reads a cached answer.
                    interval=15,
                    timeout_msg="The active kaasrelease is still {}, so kaas-bootstrap "
                                "cannot be refreshed to the upgraded "
                                "version".format(active_kr_before))
            except Exception as e:
                # Refresh anyway and let the check below decide: raising here
                # would skip the very refresh that makes the binary usable.
                LOG.warning("Giving up waiting for the active kaasrelease to change, "
                            "refreshing anyway: {}".format(e))

        LOG.info('Updating bootstrap version')
        bootstrap = bootstrap_manager.BootstrapManager(seed_ip=settings.SEED_STANDALONE_EXTERNAL_IP)
        bootstrap.update_bootstrap_version(mgmt_k8s_ip)

        mgmt_bootstrap_version = kaas_manager.get_kaasrelease_bootstrap_version()
        kaas_binary_version = bootstrap.get_kaas_binary_version()
        LOG.info("After refresh: management cluster bootstrap version '{}', "
                 "binary version '{}'".format(mgmt_bootstrap_version, kaas_binary_version))
        # Asserted only when the upgrade itself passed: raising while an exception
        # from the try block is in flight would replace the real failure.
        if upgrade_succeeded:
            assert kaas_binary_version == mgmt_bootstrap_version, (
                "kaas-bootstrap is still at {} while the management cluster is at {}, so "
                "every later container-cloud call, log collection included, will "
                "fail".format(kaas_binary_version, mgmt_bootstrap_version))
