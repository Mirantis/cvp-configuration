#    Copyright 2026 Mirantis, Inc.
#
#    Licensed under the Apache License, Version 2.0 (the "License"); you may
#    not use this file except in compliance with the License. You may obtain
#    a copy of the License at
#
#         http://www.apache.org/licenses/LICENSE-2.0
#
#    Unless required by applicable law or agreed to in writing, software
#    distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
#    WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
#    License for the specific language governing permissions and limitations
#    under the License.

import pytest

from si_tests import logger
from si_tests import settings
from si_tests.managers import bootstrap_manager
from si_tests.managers.kaas_manager import Manager
from si_tests.tests.lcm.test_update_mgm_cluster import TestUpdateMgmCluster, save_management_version_artifact
from si_tests.utils import exceptions
from si_tests.utils import packaging_version as version
from si_tests.utils.mcc_clusterbackup_utils import (
    create_nfs_autobackup_resources_wrong_endpoint,
    create_s3_autobackup_resources_wrong_remote_secret,
    find_failed_ucp_clusterbackup
)

LOG = logger.logger
WRONG_S3_REMOTE_SECRET_VALUE = "wrong_value"
# RFC 5737 TEST-NET-1 — unreachable host; NFS path matches default export layout
WRONG_NFS_ENDPOINT_VALUE = "192.0.2.254:/exports/data"
mcc_upgrade_object_name = settings.MCC_UPGRADE_OBJECT_NAME


class TestUpdateMgmClusterClusterbackupNegative(TestUpdateMgmCluster):
    """Management upgrade with a negative auto-clusterbackup (bad S3 creds), then recovery and full checks."""

    def test_update_mgmt_cluster_negative_auto_clusterbackup(self, kaas_manager: Manager, mgmt_k8s_ip: str):
        try:
            self._update_mgmt_cluster_negative_auto_clusterbackup(kaas_manager)
        except Exception as e:
            LOG.error("Management upgrade failed: {}".format(e))
            raise e
        finally:
            save_management_version_artifact(kaas_manager)

            LOG.info('Updating bootstrap version')
            bootstrap = bootstrap_manager.BootstrapManager.get_si_config_bootstrap_manager()
            bootstrap.update_bootstrap_version(mgmt_k8s_ip)

    def _update_mgmt_cluster_negative_auto_clusterbackup(self, kaas_manager: Manager):
        if not settings.MCC_CLUSTER_BACKUP_VERIFY_ON_UPGRADE:
            pytest.fail("MCC_CLUSTER_BACKUP_VERIFY_ON_UPGRADE is False")

        share_type = settings.MCC_CLUSTER_BACKUP_SHARE_TYPE_FOR_UPDATE
        if not share_type:
            pytest.fail("MCC_CLUSTER_BACKUP_SHARE_TYPE_FOR_UPDATE is not set")

        ns = kaas_manager.get_namespace(settings.TARGET_NAMESPACE)
        target_cluster = ns.get_cluster(settings.TARGET_CLUSTER)
        if not target_cluster.workaround.cluster_supports_backups():
            pytest.skip(
                f"Cluster backups not supported for cluster version {target_cluster.clusterrelease_version}")

        cluster_backup_manager = None
        correct_secret = ""
        rclone_cred = None
        correct_nfs_url = ""

        if share_type == "s3":
            cluster_backup_manager, correct_secret, rclone_cred = create_s3_autobackup_resources_wrong_remote_secret(
                target_cluster, WRONG_S3_REMOTE_SECRET_VALUE)
        elif share_type == "nfs":
            cluster_backup_manager, correct_nfs_url = create_nfs_autobackup_resources_wrong_endpoint(
                target_cluster, WRONG_NFS_ENDPOINT_VALUE)
        else:
            pytest.fail(f"Unsupported share type: {share_type}")

        LOG.info("Collecting management cluster version before update")
        cluster = kaas_manager.get_mgmt_cluster()
        # Get the current mgmt kaasrelease version until update is not started
        kr_before = kaas_manager.get_mgmt_cluster().get_kaasrelease_version()
        # Get the current mgmt clusterrelease version until update is not started
        cr_before = kaas_manager.get_mgmt_cluster().clusterrelease_version
        LOG.info(f"Management cluster ClusterRelease version is "
                 f"'{cr_before}' , KaaSRelease is '{kr_before}'")

        mcc_upgrade_obj = cluster._manager.get_kaas_mcc_upgrade(name=mcc_upgrade_object_name)
        is_auto_delay_enabled = mcc_upgrade_obj.data.get('spec', {}).get('autoDelay', False)
        if is_auto_delay_enabled:
            msg = "MCC upgrade auto-delay enabled as expected. Going to disable it to start update"
            LOG.info(msg)
            LOG.info("Disabling mcc upgrade auto-delay to continue upgrade")
            body = {
                "spec": {
                    "autoDelay": False,
                }
            }
            kaas_manager.api.kaas_mccupgrades.update(name=mcc_upgrade_object_name, body=body)

        ###############################
        #  Start MCC release upgrade  #
        ###############################
        try:
            kaas_manager.wait_kaasrelease(releases_count=2, timeout=settings.KAAS_UPDATE_MGMT_WAIT_TIMEOUT)
        except exceptions.TimeoutError as e:
            if "Expected count: 2, got 1" not in str(e):
                raise AssertionError(
                    f"Unexpected TimeoutError message: {e!r}") from e
        else:
            raise AssertionError(
                "wait_kaasrelease succeeded but a timeout was expected while the new KaaSRelease was blocked")

        failed_cb = find_failed_ucp_clusterbackup(cluster_backup_manager)
        assert failed_cb is not None, (
            f"Expected a Failed auto clusterbackup in {cluster_backup_manager.cluster.namespace} was not found")

        LOG.info(f"Restoring correct credentials for cluster {target_cluster.name}")
        if share_type == "s3":
            rclone_cred.patch({"spec": {"remoteSecret": {"value": correct_secret}}})
            LOG.info(f"Restored remote secret for rclone credential {rclone_cred.name}")
        else:
            target_cluster.patch({"spec": {"providerSpec": {"value": {"backup": {"nfsUploadUrl": correct_nfs_url}}}}})
            LOG.info(f"Restored nfsUploadUrl for cluster {target_cluster.name}")

        failed_cb = find_failed_ucp_clusterbackup(cluster_backup_manager)
        if failed_cb is not None:
            LOG.info(f"Deleting failed clusterbackup {failed_cb.name}")
            failed_cb.delete()

        LOG.info("Waiting for downloading of new kaasrelease (after fixing credentials)")
        kaas_manager.wait_kaasrelease(
            releases_count=2, timeout=settings.KAAS_UPDATE_MGMT_WAIT_TIMEOUT)

        avail_kaas_releases = kaas_manager.get_kaasrelease_names()
        LOG.info('Available KaaS releases are {}'.format(avail_kaas_releases))

        assert len(avail_kaas_releases) > 1, (
            "There are not new kaas releases, current list: {}".format(
                avail_kaas_releases))

        avail_kaas_releases = kaas_manager.get_kaasrelease_names()
        LOG.info('Available KaaS releases are {}'.format(avail_kaas_releases))
        kaas_r_sorted = str(max(
            [version.parse(x) for x in avail_kaas_releases]))
        LOG.info('Sorted release {}'.format(kaas_r_sorted))
        LOG.info("Wait until update finished")
        kr_data = kaas_manager.get_kaasrelease(kaas_r_sorted).data
        LOG.debug("Release_details {}".format(kr_data))
        kaas_manager.wait_kaasrelease_label(kaas_r_sorted, timeout=settings.KAAS_UPDATE_MGMT_ACTIVE_WAIT_TIMEOUT)

        cluster.check.check_cluster_nodes()
        cluster.check.check_cluster_readiness(timeout=3600)
        cluster.check.check_helmbundles()
        cluster.check.check_k8s_nodes()
        cluster.check.check_persistent_volumes_mounts()
        cluster.check.check_k8s_pods()
        cluster.check.check_no_leftovers_after_upgrade()
        cluster.check.check_upgrade_stage_success()
