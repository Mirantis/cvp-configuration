#    Copyright 2025 Mirantis, Inc.
#
#    Licensed under the Apache License, Version 2.0 (the "License"); you may
#    not use this file except in compliance with the License. You may obtain
#    a copy of the License at
#
#         http://www.apache.org/licenses/LICENSE-2.0
#
#    Unless required by applicable law or agreed to in writing, software
#    distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
#    WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
#    License for the specific language governing permissions and limitations
#    under the License.

import random

from si_tests import logger
from si_tests import settings

from si_tests.utils import waiters

LOG = logger.logger


def test_auditd_module_apply_conf(kaas_manager, show_step):
    """ Test auditd hoc module
    Scenario:
        1. Check cluster initial state.
        2. Ensure "auditd:managed" is not true in cluster spec.
        3. Prepare and set label for machine.
        4. Create auditd HOC and wait until applied.
        5. Check host configuration for auditd/grub.
        6. Update HOC spec with new parameters, apply and wait.
        7. Check host configuration for auditd/grub/logrotation.
        8. Check log rotation.
        9. Purge auditd from host (cleanup).
        10. Ensure auditd is deleted from host.
        11. Delete HOC and machine label.
    """
    ns = kaas_manager.get_namespace(settings.TARGET_NAMESPACE)
    cluster = ns.get_cluster(settings.TARGET_CLUSTER)

    show_step(1)

    LOG.info(f"Check init state on the {cluster._cluster_type} cluster {cluster.namespace}/{cluster.name}")
    cluster.check.check_machines_status()
    cluster.check.check_cluster_readiness()
    cluster.check.check_k8s_nodes()

    show_step(2)
    auditd_managed = cluster.spec.get('providerSpec', {}).get('value', {}).get('audit', {}).get("auditd", {}).get(
        "managed")
    assert not auditd_managed, "Auditd management is enabled in clusterspec"

    show_step(3)
    machines = cluster.get_machines()
    assert machines, f"No machines in cluster: {cluster.name}"
    first_machine = machines[0]

    LOG.info(f"Add label day2_label to first machine: {first_machine.name} in child namespace: {cluster.name}")
    day2_label = {"day2-auditd-label" + str(random.randint(10, 99)): "true"}  #
    first_machine.add_machine_labels(day2_label)

    show_step(4)
    # Create or update exist HostOSConfiguration
    hostoscfg_data = {
        'apiVersion': 'kaas.mirantis.com/v1alpha1',
        'kind': 'HostOSConfiguration', 'metadata':
            {'name': settings.HOC_AUDITD_TEST_HOC_NAME,
             'namespace': settings.TARGET_NAMESPACE
             },
        'spec': {
            'configs': [{
                'module': 'auditd',
                'moduleVersion': settings.HOC_AUDITD_MODULE_VERSION,
                'values': {
                    "enabled": True
                }
            }],
            'machineSelector': {
                'matchLabels': day2_label
            }}
    }
    cluster.day2operations.create_update_hoc(hostoscfg_data)

    show_step(5)
    cluster.check.check_auditd_via_hoc([first_machine], hostoscfg_data['spec']['configs'][0]['values'])

    show_step(6)
    hostoscfg_data['spec']['configs'][0]['values'] = {
        "enabled": True,
        "enabledAtBoot": True,
        "backlogLimit": 1024,
        "maxLogFile": 10,
        "maxLogFileAction": "compress",
        "presetRules": "all,!delete,!immutable"
    }
    cluster.day2operations.create_update_hoc(hostoscfg_data)
    show_step(7)
    cluster.check.check_auditd_via_hoc([first_machine], hostoscfg_data['spec']['configs'][0]['values'])
    show_step(8)
    cluster.check.check_auditd_log_rotation([first_machine])

    show_step(9)
    # note: if "purge" is present in spec - module should ignore other parameters
    hostoscfg_data['spec']['configs'][0]['values']["purge"] = True
    hostoscfg = cluster.day2operations.create_update_hoc(hostoscfg_data)
    show_step(10)
    cluster.check.check_auditd_via_hoc([first_machine], hostoscfg_data['spec']['configs'][0]['values'])

    show_step(11)
    LOG.info(f"Delete HostOSConfiguration '{first_machine.name}'")
    hostoscfg.delete(async_req=True)
    timeout_msg = f"HostOSConfiguration {settings.HOC_AUDITD_TEST_HOC_NAME} was not deleted"
    waiters.wait(lambda: not bool(ns.hostosconfiguration_is_present(name=settings.HOC_AUDITD_TEST_HOC_NAME)),
                 timeout=1200,
                 interval=10,
                 timeout_msg=timeout_msg)

    LOG.info(f"Check cluster {cluster.namespace}/{cluster.name} after delete HostOSConfiguration")
    cluster.check.check_machines_status()
    cluster.check.check_cluster_readiness()

    LOG.info(f"Remove '{day2_label}' label from Machine '{first_machine.name}'")
    first_machine.remove_machine_labels(list(day2_label.keys()))
