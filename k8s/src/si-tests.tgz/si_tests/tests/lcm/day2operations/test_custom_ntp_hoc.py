#    Copyright 2025 Mirantis, Inc.
#
#    Licensed under the Apache License, Version 2.0 (the "License"); you may
#    not use this file except in compliance with the License. You may obtain
#    a copy of the License at
#
#         http://www.apache.org/licenses/LICENSE-2.0
#
#    Unless required by applicable law or agreed to in writing, software
#    distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
#    WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
#    License for the specific language governing permissions and limitations
#    under the License.

import random

from si_tests import logger
from si_tests import settings

from si_tests.utils import waiters
from si_tests.managers.remote_shell_manager import RemoteShellManager

LOG = logger.logger

cluster_name = settings.TARGET_CLUSTER
namespace_name = settings.TARGET_NAMESPACE


def check_ntp_server_on_machine(machine, ntp_servers):
    """ check_success_result_on_machine for list ntp servers
        For exit code == 0
        0: command was executed successfully
    """
    for _ntp_server in ntp_servers:
        cmd = f"grep {_ntp_server} /etc/chrony/chrony.conf | grep -v '^#'"
        res = machine.exec_pod_cmd(cmd)
        if res.get('exit_code') != 0:
            raise Exception(f"Command {cmd} finished on Machine '{machine.name}' "
                            f"with exit.code='{res.get('exit_code')}'\n{res.get('events')}, "
                            f"but expected value was SUCCESS with code 0")
    return True


def create_ntp_spec(ntp_enabled=True):
    return {
        'spec': {
            'providerSpec': {
                'value': {
                    'ntpEnabled': ntp_enabled
                }
            }
        }
    }


def test_ntp_module_apply_conf(kaas_manager, show_step):
    """ Test ntp hoc module
        Scenario:
            1. Check init state cluster
            2. Set ntpEnabled flag to False
            3. Add label to main machine
            4. Get old chrony servers
            5. Create a ntp HostOSConfiguration object
            6. Wait while ntp module configuration is applied.
            7. Check change chrony on machine
            8. Update module config with old ntp servers
            9. Check change chrony on machine
            10. Delete HostOSConfiguration object and label
            11. Set ntpEnabled flag to True
            12. Check cluster readiness
    """

    ns = kaas_manager.get_namespace(namespace_name)
    cluster = ns.get_cluster(cluster_name)

    show_step(1)
    LOG.info(f"Check init state on the {cluster._cluster_type} cluster {cluster.namespace}/{cluster.name}")
    cluster.check.check_machines_status()
    cluster.check.check_cluster_readiness()

    show_step(2)
    cluster.patch(body=create_ntp_spec(False))
    cluster.check.check_cluster_readiness()

    machines = cluster.get_machines()
    assert machines, f"No machines in cluster: {cluster_name}"

    show_step(3)
    first_machine = machines[0]
    day2_label = {"day2-custom-ntp-label" + str(random.randint(10, 99)): "enabled"}
    ntp_servers = ['0.ubuntu.pool.ntp.org',
                   '1.ubuntu.pool.ntp.org']
    ntp_config = [
        {
            "module": "ntp",
            "moduleVersion": settings.HOC_NTP_PACKAGE_MODULE_VERSION,
            "values": {
                "ntp_servers": ntp_servers
            }
        }
    ]

    # hoc sample
    hostoscfg_data = {
        "apiVersion": "kaas.mirantis.com/v1alpha1",
        "kind": "HostOSConfiguration",
        "metadata": {
            "name": settings.HOC_NTP_TEST_HOC_NAME,
            "namespace": namespace_name,
        },
        "spec": {
            "configs": ntp_config,
            "machineSelector": {
                "matchLabels": day2_label
            }
        }
    }

    LOG.info(f"Add label day2_label to first machine: {first_machine.name} in child namespace: {cluster_name}")
    first_machine.add_machine_labels(day2_label)

    show_step(4)
    # Remember ntp servers before module apply
    old_ntp_servers = RemoteShellManager.get_ntp_servers_from_machine(first_machine)
    LOG.info(f"Old ntp servers: {old_ntp_servers} from {first_machine}")

    show_step(5)
    # Remember LCMMachines timestamps before creating HostOSConfiguration
    lcmmachines_timestamps_before = cluster.get_cluster_lcmmachines_timestamps()

    # Create HostOSConfiguration
    hostoscfg = ns.create_hostosconfiguration_raw(hostoscfg_data)

    # Wait for the selected Machine in the hostosconfiguration status
    show_step(6)
    LOG.info("Check that new items added into machineTypes in LCMCluster")
    cluster.check.wait_lcmcluster_day2_machinetypes(hostoscfg)
    LOG.info("Check that new items added into stateItems in LCMMachine")
    cluster.check.wait_lcmmachine_day2_stateitems(hostoscfg, lcmmachines_timestamps_before)
    cluster.check.get_hostosconfig_machines_status(hostoscfg)

    show_step(7)
    LOG.info(f"Check change chrony ntp on machine: {first_machine.name}")
    check_ntp_server_on_machine(machine=first_machine, ntp_servers=ntp_servers)

    show_step(8)
    # Remember LCMMachines timestamps before update HostOSConfiguration
    lcmmachines_timestamps_before = cluster.get_cluster_lcmmachines_timestamps()

    LOG.info(f"Update ntp with old configuration '{first_machine.name}'")
    hostoscfg.patch(
        {"spec": {
            "configs": [{
               "module": "ntp",
               "moduleVersion": settings.HOC_NTP_PACKAGE_MODULE_VERSION,
               "values": {
                  "ntp_servers": old_ntp_servers
               }
            }],
            "machineSelector": {
                "matchLabels": day2_label
            }
        }})
    LOG.info("Check that old items restored into machineTypes in LCMCluster")
    cluster.check.wait_lcmcluster_day2_machinetypes(hostoscfg)

    LOG.info("Check that old items restored into stateItems in LCMMachine")
    cluster.check.wait_lcmmachine_day2_stateitems(hostoscfg, lcmmachines_timestamps_before)

    show_step(9)
    LOG.info(f"Check change chrony ntp on machine: {first_machine.name}")
    check_ntp_server_on_machine(machine=first_machine, ntp_servers=old_ntp_servers)

    show_step(10)
    LOG.info(f"Delete HostOSConfiguration '{first_machine.name}'")
    existing_config = ns.get_hostosconfiguration(name=settings.HOC_NTP_TEST_HOC_NAME)
    existing_config.delete(async_req=True)
    timeout_msg = f"HostOSConfiguration {settings.HOC_NTP_TEST_HOC_NAME} was not deleted"
    waiters.wait(lambda: not bool(ns.hostosconfiguration_is_present(name=settings.HOC_NTP_TEST_HOC_NAME)),
                 timeout=1200,
                 interval=10,
                 timeout_msg=timeout_msg)

    LOG.info(f"Remove '{day2_label}' label from Machine '{first_machine.name}'")
    first_machine.remove_machine_labels(list(day2_label.keys()))

    show_step(11)
    cluster.patch(body=create_ntp_spec(True))

    show_step(12)
    cluster.check.check_cluster_readiness()
    cluster.check.check_helmbundles()
