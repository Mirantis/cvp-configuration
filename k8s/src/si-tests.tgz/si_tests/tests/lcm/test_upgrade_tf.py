import pytest

from si_tests import logger
from si_tests import settings
from si_tests.utils import waiters

LOG = logger.logger


@pytest.mark.usefixtures("introspect_distribution_not_changed")
@pytest.mark.usefixtures("collect_downtime_statistics")     # Should be used if ALLOW_WORKLOAD == True
def test_upgrade_tf(kaas_manager):
    """Upgrade tf control and data planes
    Scenario:
        1. Get tfoperator
        2. Update control plane over patching tfoperator with new tf version
        3. Wait tfoperator has updated the control plane
        4. Wait pods are running in tf namespace
        5. Start dataplane updates: get vrouter-agent pods
        6. Delete vrouter-agent pods
        7. Wait pods in tf namespace are running
        8. Check cluster readiness

    Required environment variables:
        KUBECONFIG : config to access KaaS cluster
        TARGET_NAMESPACE : child cluster namespace in KaaS
        TARGET_CLUSTER : child cluster name in KaaS
        OPENSTACK_UPDATE_TF_VERSION : version to update
    """
    cluster_name = settings.TARGET_CLUSTER
    namespace_name = settings.TARGET_NAMESPACE
    tf_update_version = settings.OPENSTACK_UPDATE_TF_VERSION
    operator_name = 'openstack-tf'
    operator_ns = 'tf'
    ns = kaas_manager.get_namespace(namespace_name)
    child_cluster = ns.get_cluster(cluster_name)
    tfoperator = child_cluster.k8sclient.tfoperator_v2.get(
        name=operator_name, namespace=operator_ns)
    LOG.info(f"tf operator {tfoperator}")
    assert tfoperator.data['spec'].get('tfVersion') != tf_update_version, \
        f"TF is already on the {tf_update_version} version, nothing to update"
    # Patch operator spec. NOTE: in TFOperator v2 the version lives in
    # 'spec.tfVersion'. There is no 'spec.settings' in the v2 CRD schema, and
    # a patch to that path is silently pruned by the API server.
    tfoperator.patch({"spec": {"tfVersion": tf_update_version}})
    LOG.info(f'Tf operator spec after patch {tfoperator.data["spec"]}')
    assert tfoperator.data['spec'].get('tfVersion') == tf_update_version, \
        f"tfVersion has not been set to {tf_update_version} in tfoperator"

    # Wait for the control plane before touching the dataplane: the vrouter
    # daemonset template must already carry the new version, otherwise the
    # recreated pods come back with the old one and are never updated, because
    # vrouter daemonsets use the OnDelete update strategy.
    def _is_control_plane_updated():
        status = tfoperator.read().status
        # 'tf-vrouter' stays not updated until its pods are recreated below
        modules = {name: state.get('updated')
                   for name, state in status['modules'].items()
                   if name != 'tf-vrouter'}
        LOG.info(f"TF version: {status.get('tfVersion')}, "
                 f"modules updated: {modules}")
        return (status.get('tfVersion') == tf_update_version
                and all(updated == "Yes" for updated in modules.values()))

    LOG.info(f"Wait tfoperator has updated the control plane "
             f"to {tf_update_version}")
    waiters.wait(_is_control_plane_updated, interval=30, timeout=3600,
                 timeout_msg=f"tfoperator has not updated the control plane "
                             f"to the {tf_update_version} version")
    # check pods are running after control plane update
    child_cluster.check.check_k8s_pods(
        target_namespaces=operator_ns, pods_prefix='tf')
    # Update data plane (need to delete vrouter-agent pods wait when ready)
    pods = child_cluster.k8sclient.pods.list(
        namespace=operator_ns, name_prefix='tf-vrouter-agent')
    # Delete vrouter agent pods and wait rescheduling
    LOG.info("Delete vrouter-agent pods and check they are rescheduled")
    for pod in pods:
        child_cluster.k8sclient.pods.api.delete_namespaced_pod(
            name=pod.name, namespace=operator_ns)
    LOG.info('wait pods rescheduled and running')
    upd_pods = child_cluster.k8sclient.pods.list(
        namespace=operator_ns, name_prefix='tf-vrouter-agent')
    for pod in upd_pods:
        pod.wait_phase('Running')
    child_cluster.check.check_k8s_pods(
        target_namespaces=operator_ns, pods_prefix='tf')
    child_cluster.check.check_cluster_readiness()
