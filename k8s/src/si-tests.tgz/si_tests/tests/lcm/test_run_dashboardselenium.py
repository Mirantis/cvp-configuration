from si_tests.lcm.openstack_lcm import run_test, dashboardselenium


def test_run_dashboardselenium(os_manager):
    report_name = "integration_test_results.xml"
    run_pod = "openstack-dashboard-selenium-run-tests"
    service = "dashboard-selenium"
    try:
        run_test.run_tests(os_manager, report_name, run_pod, service,
                           dashboardselenium.get_run_command)

        volume_log_dir = "/opt/horizon/test_reports/"
        results_pod = "dashboard-selenium-test-results-pod"
        run_test.save_report(
            os_manager, report_name, results_pod, volume_log_dir)
    finally:
        run_test.turn_off_service(os_manager, service)
