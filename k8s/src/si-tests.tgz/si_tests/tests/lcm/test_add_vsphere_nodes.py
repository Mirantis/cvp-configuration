import pytest

from si_tests import settings
from si_tests import logger
from si_tests.utils import waiters
from si_tests.utils import utils


LOG = logger.logger


@pytest.mark.parametrize("_", ["CLUSTER_NAME={0}"
                               .format(settings.KAAS_CHILD_CLUSTER_NAME)])
@pytest.mark.usefixtures("store_cluster_description")
@pytest.mark.usefixtures("introspect_child_deploy_objects")
def test_add_nodes(kaas_manager, show_step, _):
    """Add nodes to the child cluster."""
    # Collecting env data
    cluster_name = settings.KAAS_CHILD_CLUSTER_NAME
    namespace_name = settings.KAAS_NAMESPACE

    # step 001 - Get namespace
    LOG.info("Namespace name - %s", namespace_name)
    ns = kaas_manager.get_namespace(namespace_name)
    cluster = ns.get_cluster(cluster_name)
    region = kaas_manager.get_mgmt_cluster().region_name
    stacklight_label = {"key": "stacklight", "value": "enabled"}
    # Check or set customHostnamesEnabled flag in Cluster object to match settings.CUSTOM_HOSTNAMES
    cluster.set_custom_hostnames_enabled(flag=settings.CUSTOM_HOSTNAMES)

    rhel_license = kaas_manager.find_rhel_license(
        name_prefix=cluster_name,
        namespace=namespace_name,
        region=region)
    rhel_license_name = rhel_license['metadata']['name']

    LOG.info("Negative checks for nodeLabels")
    worker_machine = cluster.get_machines(machine_type="worker")[0]
    try:
        non_existing = {"key": "nonexiting", "value": "enabled"}
        worker_machine.add_labels([non_existing])
    except Exception as e:
        LOG.info(e)
        LOG.info(e.status)
        if e.status != 400:
            raise e
    else:
        raise Exception("Unexpected success: 'nonexiting' label was assigned")

    assert non_existing not in worker_machine.nodeLabels, \
        "Not allowed label was successfully set"

    # check duplicates
    # PRODX-8361
    """
    try:
        worker_machine.add_labels([stacklight_label])
    except Exception as e:
        LOG.info(e)
        message = json.loads(e.body)['message']
        if e.status != 400 or 'duplicate' not in message:
            raise e
    else:
        raise Exception("Unexpected success: duplicated label was assigned")

    assert worker_machine.nodeLabels.count(stacklight_label) == 1, \
        "Duplicated label was assigned: {}".format(worker_machine.nodeLabels)
    """

    vm_templates = utils.vsphere_set_vm_template_list()
    if len(vm_templates) == 0:
        raise RuntimeError("No VM templates provided for machines")
    template = vm_templates[0]
    rhel_license = utils.vsphere_set_rhel_license(template, rhel_license_name)
    try:
        non_existing = {"key": "nonexiting", "value": "enabled"}
        cluster.create_vsphere_machine(
            node_type="node",
            template=template,
            rhel_license=rhel_license,
            region=region,
            node_labels=[non_existing])
    except Exception as e:
        LOG.info(e)
        if e.status != 400:
            raise e
    else:
        raise Exception("Unexpected success: machine was created "
                        "with 'nonexiting' label")

    LOG.info("Adding worker machine")
    # step 003 - Add 1 slave node
    slave_node = cluster.create_vsphere_machine(
        node_type="node",
        template=template,
        rhel_license=rhel_license,
        region=region)
    LOG.info('Added worker machine {}'.format(slave_node))

    # Waiting for slave node become Ready
    cluster.check.wait_machine_status_by_name(machine_name=slave_node.name,
                                              expected_status='Ready')

    # Waiting for machines are Ready
    cluster.check.check_machines_status(timeout=1800)
    cluster.check.check_cluster_nodes()
    cluster.check.check_k8s_nodes()

    new_machine = [x for x in cluster.get_machines(machine_type="worker")
                   if not x.nodeLabels][0]

    # Check that Machine hostname is created with respect to Cluster flag 'customHostnamesEnabled'
    cluster.check.check_custom_hostnames_on_machines(machines=[new_machine])

    LOG.info("Assigning 'stacklight' label to worker machine")
    try:
        new_machine.add_labels([stacklight_label])
    except Exception as e:
        LOG.info(e)

    assert stacklight_label in new_machine.nodeLabels, \
        "Label was not set"
    waiters.wait(lambda: new_machine.check_k8s_nodes_has_labels(),
                 timeout=300, interval=10)

    assert stacklight_label in worker_machine.nodeLabels, \
        "Label 'stacklight' was not found on "\
        "machine {}".format(worker_machine.name)
    # TODO (tleontovich): Uncomment when PRODX-28063 has been done
    # LOG.info("Removing 'stacklight' label from previous worker machine")
    # worker_machine.remove_labels([stacklight_label])
    # assert stacklight_label not in worker_machine.nodeLabels, \
    #     "Label was not removed"
    # waiters.wait(lambda: worker_machine.check_k8s_nodes_has_labels(),
    #              timeout=300, interval=10)

    # Collecting artifacts
    cluster.store_k8s_artifacts()

    # Check/wait for correct docker service replicas in cluster
    ucp_worker_agent_name = cluster.check.get_ucp_worker_agent_name()
    cluster.check.check_actual_expected_docker_services(
        changed_after_upd={'ucp-worker-agent-x': ucp_worker_agent_name})
    cluster.check.check_k8s_pods()
    cluster.check.check_actual_expected_pods()
    cluster.check.check_cluster_readiness()
    cluster.provider_resources.save_artifact()

    if settings.CHILD_MKE_CUSTOM_CERTIFICATES:
        host = cluster.get_load_balancer_address()
        cluster.check.check_cert_conversation(host)
        cluster.check.check_cert_equal(port=5443)
