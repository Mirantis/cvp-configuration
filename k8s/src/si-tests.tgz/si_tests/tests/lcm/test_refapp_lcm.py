from si_tests.deployments.deploy_refapp import Refapp


def test_refapp(openstack_client_manager):

    Refapp(openstack_client_manager).check()
