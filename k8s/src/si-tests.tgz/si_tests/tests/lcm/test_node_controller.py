import copy
import time
from hashlib import sha256
import multiprocessing

import os
import pytest
import uuid

from si_tests import settings
from si_tests.deployments.deploy_refapp import Refapp
from si_tests.deployments.utils import commons, file_utils
from si_tests.managers import openstack_manager
from si_tests.utils import waiters, utils
from si_tests.utils.workload_report import VMWorkloadDowntimeReport

NMR_META = {
    "group": "lcm.mirantis.com",
    "version": "v1alpha1",
    "plural": "nodemaintenancerequests",
}

NWL_META = {
    "group": "lcm.mirantis.com",
    "version": "v1alpha1",
    "plural": "nodeworkloadlocks",
}


def host_hash(host):
    host = host.split(".")[0]
    return sha256(host.encode()).hexdigest()[:8]


def create_node_maintenance_request(api, node, name, scope="os"):
    nmr_body = {
        "apiVersion": "lcm.mirantis.com/v1alpha1",
        "kind": "NodeMaintenanceRequest",
        "metadata": {"name": name},
        "spec": {"nodeName": node, "scope": scope},
    }
    api.create_cluster_custom_object(**NMR_META, body=nmr_body)


def delete_node_maintenance_request(api, name):
    api.delete_cluster_custom_object(**NMR_META, name=name, body={})


def get_node_workload_lock_state(api, name):
    nwl = api.get_cluster_custom_object_status(**NWL_META, name=name)
    return nwl["status"]["state"]


def check_nwl_state(api, name, state):
    return get_node_workload_lock_state(api.api_custom, name) == state


def get_nwl_by_state(api, state):
    res = []
    for nwl in api.nodeworkloadlocks.list_raw().to_dict()['items']:
        if nwl["status"] and nwl["status"]["state"] == state:
            res.append(nwl)
    return res


def check_nwl_by_state_number(api, state, number):
    return len(get_nwl_by_state(api, state)) == number


def check_node_controller(openstack_client_manager, os_manager, hosts=None):
    hostname_attr = "OS-EXT-SRV-ATTR:hypervisor_hostname"

    hypervisor_list = openstack_client_manager.hypervisor.list([])

    assert len(hypervisor_list) > 1, (
        "Environment has 1 or less " "compute nodes %s",
        hypervisor_list,
    )

    for hypervisor in hypervisor_list:
        hostname = hypervisor["Hypervisor Hostname"]
        if hosts and hostname not in hosts:
            commons.LOG.info(f"Skip maintenance mode on {hostname}")
            continue
        commons.LOG.info("Start maintenance mode on %s", hostname)
        nmr_name = "nmr-si-test-" + host_hash(hostname)
        nwl_name = "openstack-" + hostname.split(".")[0]
        create_node_maintenance_request(os_manager.api.api_custom, hostname, nmr_name)

        # Check evacuation finished successfully
        commons.LOG.info("Check evacuation finished successfully")

        def _wait_os_workload_status(status="inactive"):
            return get_node_workload_lock_state(os_manager.api.api_custom, nwl_name) == status

        waiters.wait(_wait_os_workload_status, timeout=2760, interval=30)
        commons.LOG.info("Check node controller evacuation " "finished successfully.")

        def _check_instances_migrated(hostname):
            instances = openstack_client_manager.server.list(["--all"])
            instances = [x["ID"] for x in instances]
            not_migrated = []
            for instance_id in instances:
                instance = openstack_client_manager.server.show([instance_id])
                if instance[hostname_attr] == hostname:
                    not_migrated.append(instance["id"])
            assert not not_migrated, ("Some instances are not migrated %s, but workloadlock is inactive",
                                      not_migrated)

        _check_instances_migrated(hostname)

        commons.LOG.info("Return node from maintenance mode to status mode.")
        delete_node_maintenance_request(os_manager.api.api_custom, nmr_name)
        waiters.wait(
            _wait_os_workload_status,
            predicate_args=("active",),
            timeout=1800,
            interval=30,
        )


def check_nodes_parallel(os_manager, nodes, concurrency=1, tf_computes=False):
    commons.LOG.info(f"Checking parallel nwl with concurrency {concurrency} for nodes {nodes}")
    handled_nodes = []
    nmr_prefix = "nmr-si-test"
    for hostname in nodes:
        nmr_name = f"{nmr_prefix}-{hostname}"
        create_node_maintenance_request(os_manager.api.api_custom, hostname, nmr_name, scope="drain")

    while set(nodes) - set(handled_nodes):
        to_handle = set(nodes) - set(handled_nodes)
        commons.LOG.info(f"Checking locks for nodes {to_handle}")
        wait_len = min(concurrency, len(to_handle))
        # If it's compute node and TF enabled we should track NWLs for TF
        if tf_computes:
            wait_len = wait_len*2
        waiters.wait(
            check_nwl_by_state_number,
            predicate_args=(
                os_manager.api,
                "inactive",
                wait_len,
            ),
            timeout=600,
            interval=10,
        )
        # Make sure number of inactive locks is not changed
        for i in range(1, 3):
            commons.LOG.info(f"Checking number of inactive locks {wait_len}, attempt {i}")
            nwl_inactive = get_nwl_by_state(os_manager.api, "inactive")
            assert (
                len(nwl_inactive) == wait_len
            ), "Expected number of nwl in inactive is {wait_len}, but got {len(nwl_inactive)}"
            time.sleep(60)
        for nwl in nwl_inactive:
            hostname = nwl["spec"]["nodeName"]
            nmr_name = f"{nmr_prefix}-{hostname}"
            if hostname not in handled_nodes:
                delete_node_maintenance_request(os_manager.api.api_custom, nmr_name)
                handled_nodes.append(hostname)
            waiters.wait(
                check_nwl_state,
                predicate_args=(
                    os_manager.api,
                    nwl["metadata"]["name"],
                    "active",
                ),
                timeout=60,
                interval=10,
            )


@pytest.mark.usefixtures('mos_workload_downtime_report')
@pytest.mark.usefixtures('mos_per_node_workload_check_after_test')
def test_node_controller_parallel(os_manager):
    """Test node controller maintenance parallel
    1) Create nmr for all controller nodes simulteniously
    2) Check 1st controller nwl is inactive
    3) Remove 1st controller nmr
    4) Wait 1st controller nwl is active again
    5) Repeat 2-4 for rest controllers
    6) Create nmr for all compute nodes
    7) Check 2 of them moved to inactive state
    8) Remove nmr for 2 nodes
    9) Check nwl is active again
    10) Repeat 7-9 unless all compute nodes are checked.
    """

    tf_enabled = os_manager.is_tf_enabled()
    ctl_concurrency = 1
    compute_concurrency = 30
    control_nodes = os_manager.api.nodes.list(label_selector="openstack-control-plane=enabled")
    compute_nodes = os_manager.api.nodes.list(label_selector="openstack-compute-node=enabled")
    control_node_names = [n.name for n in control_nodes]
    if tf_enabled:
        # Exclude tf-vrouter gateway nodes in case of TF:
        compute_node_names = [n.name for n in compute_nodes if
                              n.data['metadata']['labels'].get('openstack-gateway') != "enabled"]
    else:
        compute_node_names = [n.name for n in compute_nodes]

    # NOTE(vsaienko): we need +1 node up to concurrency to check that nwl still
    # active while we have nmr for it.
    assert (
        len(control_node_names) >= ctl_concurrency + 1
    ), f"Environment has controller nodes less node than required minimum {ctl_concurrency + 1}"
    commons.LOG.info("Check nmr for controllers")
    check_nodes_parallel(os_manager, control_node_names, concurrency=ctl_concurrency)
    commons.LOG.info("Check nmr for computes")
    check_nodes_parallel(os_manager, compute_node_names, concurrency=compute_concurrency, tf_computes=tf_enabled)


@pytest.mark.usefixtures('mos_workload_downtime_report')
@pytest.mark.usefixtures('mos_per_node_workload_check_after_test')
@pytest.mark.usefixtures('skip_by_network_backend')
@pytest.mark.network_backend('tf')
def test_tf_node_controller_parallel(os_manager):
    """Test tf node controller maintenance parallel
    1) Create nmr for all tf controller nodes simulteniously
    2) Check 1st controller nwl is inactive
    3) Remove 1st controller nmr
    4) Wait 1st controller nwl is active again
    5) Repeat 2-4 for rest controllers
    6) Create nmr for all gateway (vrouter-vgw) compute nodes
    7) Check 1st gateway nwl is inactive
    8) Remove 1st gateway nmr
    9) Wait 1st gateway nwl is active again
    10) Repeat 7-9 unless all gateway compute nodes are checked.
    """

    concurrency = 1
    tf_control_nodes = os_manager.api.nodes.list(label_selector="tfcontrol=enabled")
    tf_control_node_names = [n.name for n in tf_control_nodes]
    compute_gw_nodes = os_manager.api.nodes.list(
        label_selector="openstack-compute-node=enabled,openstack-gateway=enabled"
    )
    compute_gw_node_names = [n.name for n in compute_gw_nodes]

    assert (
        len(tf_control_nodes) >= concurrency + 1
    ), f"Environment has tf controller nodes less node than required minimum {concurrency + 1}"
    assert (
            len(compute_gw_nodes) >= concurrency + 1
    ), f"Environment has gw compute nodes less node than required minimum {concurrency + 1}"

    commons.LOG.info("Check nmr for tf controllers")
    check_nodes_parallel(os_manager, tf_control_node_names, concurrency=concurrency)
    commons.LOG.info("Check nmr for gateway compute nodes")
    check_nodes_parallel(os_manager, compute_gw_node_names, concurrency=concurrency, tf_computes=True)


def check_loadbalancer(openstack_client_manager, num_members: int, base_url,
                       url=''):
    # Simple check of LoadBalancer. Not applicable for some types of LB
    cmd = ['/bin/sh', '-c', f"curl -s {base_url}/{url}"]
    raw_responses = []
    unique_responses = 0
    commons.LOG.info("LB responses:")
    for i in range(num_members*2):
        content = openstack_client_manager.client.exec(cmd)
        commons.LOG.info(f"{content}")
        if content not in raw_responses:
            unique_responses += 1
        raw_responses.append(content)
    if unique_responses == num_members:
        return True
    commons.LOG.warning(f"LoadBalancer returned {unique_responses} unique "
                        f"responses while number of members is {num_members}")
    return False


@pytest.mark.usefixtures('mos_workload_downtime_report')
@pytest.mark.usefixtures('mos_per_node_workload_check_after_test')
def test_node_controller_computes_az(openstack_client_manager, os_manager):
    """Test node controller maintenance parallel computes with respect AZ settings.
    The test requires at least 3 compute nodes.

    1) Configure openstack-controller
       nwl_parallel_max_compute = 2, respect_nova_az = True
    2) Left 2 computes to AZ nova, create rack1 AZ and add rest of hosts there.
    3) Create nmr for 1 compute in nova AZ
    4) Wait nwl is inactive
    5) Create nmr for 1 compute in rack1 AZ
    6) Ensure nwl is active for a while
    7) Create nmr for 2nd compute in nova AZ
    8) Wait when nwl for 2nd compute in nova AZ is inactive
    9) Remove nmr for computes from nova AZ
    10) Check nmr for compute in rack1 is inactive
    11) Check nmr for compute in nova is active
    12) Remove all nmrs
    13) Check all nwl are active
    14) Cleanup
    """

    compute_concurrency = 2
    compute_nodes = os_manager.api.nodes.list(label_selector="openstack-compute-node=enabled")
    if os_manager.is_tf_enabled():
        # Exclude tf-vrouter gateway nodes in case of TF:
        compute_node_names = [n.name for n in compute_nodes if
                              n.data['metadata']['labels'].get(
                                  'openstack-gateway') != "enabled"]
    else:
        compute_node_names = [n.name for n in compute_nodes]

    nova_az_node_names = compute_node_names[:2]
    rack1_az_node_names = compute_node_names[2:]

    # NOTE(vsaienko): we need +1 node up to concurrency to check that nwl still
    # active while we have nmr for it.
    assert (
        len(compute_node_names) >= compute_concurrency + 1
    ), f"Environment has compute nodes less node than required minimum {compute_concurrency + 1}"
    commons.LOG.info("Step 1: Configure respect AZ openstack-controller settings")
    om = openstack_manager.OpenStackManager()
    os_config_orig = om.operator_config
    os_config = copy.deepcopy(os_config_orig)
    os_config["maintenance"]["respect_nova_az"] = "True"
    om.operator_config = os_config
    time.sleep(60)

    commons.LOG.info("Step 2: Create AZ setup")
    rack1_cmp1 = rack1_az_node_names[0]
    openstack_client_manager.aggregate.create(["rack1", "--zone", "rack1"])
    openstack_client_manager.aggregate.add_host("rack1", rack1_cmp1)

    commons.LOG.info("Step 3: Create nmr for cmp1 nova AZ")
    cmp1, cmp2 = nova_az_node_names
    create_node_maintenance_request(os_manager.api.api_custom, cmp1, f"nmr-si-test-{cmp1}", scope="drain")
    commons.LOG.info("Step 4: Wait nwl for cmp1 nova AZ is inactive")
    waiters.wait(
        check_nwl_state,
        predicate_args=(
            os_manager.api,
            f"openstack-{cmp1}",
            "inactive",
        ),
        timeout=60,
        interval=10,
    )
    commons.LOG.info("Step 5: Create nmr for cmp1 rack1 AZ")
    create_node_maintenance_request(
        os_manager.api.api_custom,
        rack1_cmp1,
        f"nmr-si-test-{rack1_cmp1}",
        scope="drain",
    )
    commons.LOG.info("Step 6: Ensure nwl for cmp1 rack1 AZ is still active")
    # Make sure number of inactive locks is not changed
    for i in range(1, 3):
        commons.LOG.info(f"Checking state of nwl cmp1 rack1 is active, attempt {i}")
        assert check_nwl_state(os_manager.api, f"openstack-{rack1_cmp1}", "active"), "The nwl cmp1 rack1 is inactive."
        time.sleep(60)

    commons.LOG.info("Step 7: Create nmr for cmp2 nova AZ")
    create_node_maintenance_request(os_manager.api.api_custom, cmp2, f"nmr-si-test-{cmp2}", scope="drain")
    commons.LOG.info("Step 8: Wait nwl for cmp2 nova AZ is inactive")
    waiters.wait(
        check_nwl_state,
        predicate_args=(
            os_manager.api,
            f"openstack-{cmp2}",
            "inactive",
        ),
        timeout=60,
        interval=10,
    )
    assert check_nwl_state(os_manager.api, f"openstack-{rack1_cmp1}", "active"), "The nwl cmp1 rack1 is inactive."

    commons.LOG.info("Step 9: Remove nmr for cmp1,cmp2 nova AZ")
    for host in nova_az_node_names:
        delete_node_maintenance_request(os_manager.api.api_custom, f"nmr-si-test-{host}")
        waiters.wait(
            check_nwl_state,
            predicate_args=(
                os_manager.api,
                f"openstack-{host}",
                "active",
            ),
            timeout=60,
            interval=10,
        )
    commons.LOG.info("Step 10: Ensure nwl for cmp1,cmp2 nova AZ are active")
    commons.LOG.info("Step 11: Ensure nwl for cmp1 rack1 AZ is inactive")

    waiters.wait(
        check_nwl_state,
        predicate_args=(
            os_manager.api,
            f"openstack-{rack1_cmp1}",
            "inactive",
        ),
        timeout=60,
        interval=10,
    )
    commons.LOG.info("Step 12: Remove nmr for cmp1 rack1 AZ")
    delete_node_maintenance_request(os_manager.api.api_custom, f"nmr-si-test-{rack1_cmp1}")

    commons.LOG.info("Step 13: Ensure nwl for cmp1 rack1 AZ is active")

    waiters.wait(
        check_nwl_state,
        predicate_args=(
            os_manager.api,
            f"openstack-{rack1_cmp1}",
            "active",
        ),
        timeout=60,
        interval=10,
    )
    commons.LOG.info("Step 14: Cleanup")
    om.operator_config = os_config_orig
    openstack_client_manager.aggregate.remove_host("rack1", rack1_cmp1)
    openstack_client_manager.aggregate.delete(["rack1"])


@pytest.mark.usefixtures('mos_per_node_workload_check_after_test')
def test_node_controller_evacuate(openstack_client_manager, os_manager, request, func_name):
    """Test node controller evacuation. Test can be run only on vms.
    1) Deploy RefApp
    2) Run in parallel refapp requests and
       maintenance mode for node
    3) Check that evacuation finished successfully
    """
    refapp = Refapp(openstack_client_manager)
    refapp.deploy()
    request.addfinalizer(refapp.delete)
    # TODO(mkarpin): switch report to fixture when refapp fixture is ready.
    with VMWorkloadDowntimeReport(func_name, 'mos'):
        commons.LOG.info("Init 2 processes check controller evacuation and RefApp pings")
        process_check_controller = multiprocessing.Process(
            target=check_node_controller,
            args=(openstack_client_manager, os_manager),
        )

        process_collect_statistic = multiprocessing.Process(target=refapp.collect_statistic)

        commons.LOG.info("Start Check controller evacuation and refapp ping processes")
        process_check_controller.start()
        process_collect_statistic.start()

        commons.LOG.info("Wait when Check node evacuation process finished")
        process_check_controller.join()

        commons.LOG.info("Terminate refapp pings process")
        process_collect_statistic.terminate()
        process_collect_statistic.join()

        exitcode = process_check_controller.exitcode
        assert not exitcode, (
            "Test Node controller evacuate failed with " "exit code: %s",
            exitcode,
        )


@pytest.mark.usefixtures('mos_workload_downtime_report')
@pytest.mark.usefixtures('mos_per_node_workload_check_after_test')
@pytest.mark.usefixtures('skip_by_network_backend')
@pytest.mark.network_backend('tf')
def test_tf_amphora_evacuate(openstack_client_manager, os_manager, request,
                             show_step):
    """Check migration of amphora LB.

        Scenario:
            1. Deploy LB with amphora
            2. Find host with amphora instance
            3. Create node maintenance request and wait instances are
            evacuated
            4. Check LB is working
    """

    show_step(1)
    az = settings.OPENSTACK_AVAILABILITY_ZONE_NAME
    hosts = openstack_client_manager.host.list([])
    hosts_az = [host for host in hosts if host.get('Zone') == az]
    assert len(hosts_az) >= 2, (f"Test requires not less than 2 compute "
                                f"nodes in az {az}")

    stack_id = uuid.uuid4()
    stack_name = f"si-test-loadbalancer-{stack_id}"
    template_path = file_utils.join(os.path.dirname(os.path.abspath(__file__)),
                                    "templates/loadbalancer.yaml")
    ssh_keys = utils.generate_keys()
    stack_params = {
        "id": str(stack_id),
        "availability_zone": az,
        "ssh_public_key": f"ssh-rsa {ssh_keys['public']}",
        "ssh_private_key": ssh_keys["private"]
    }
    openstack_client_manager.create_stack(request, stack_name, template_path,
                                          stack_params=stack_params)

    stack = openstack_client_manager.stack.show([stack_name])
    lb_fip = None
    net_name = None
    for output in stack['outputs']:
        if output['output_key'] == 'lb_floating_ip':
            lb_fip = output['output_value']
        if output['output_key'] == 'network_name':
            net_name = output['output_value']
    base_url = f"http://{lb_fip}"

    show_step(2)
    # Get amphora instance by network affiliation
    amphora_vm = None
    servers = openstack_client_manager.server.list(['--all'])
    for server in servers:
        if net_name in server['Networks'].keys():
            amphora_vm = openstack_client_manager.server.show([server['ID']])
            break
    host = amphora_vm['OS-EXT-SRV-ATTR:hypervisor_hostname']
    commons.LOG.info(f"Amphora instance landing on {host} host")
    check_loadbalancer(openstack_client_manager, 2, base_url)

    show_step(3)
    check_node_controller(openstack_client_manager, os_manager, hosts=[host])

    show_step(4)
    check_loadbalancer(openstack_client_manager, 2, base_url)
