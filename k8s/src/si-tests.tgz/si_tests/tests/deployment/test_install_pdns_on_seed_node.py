from si_tests import settings, logger
from si_tests.managers import bootstrap_manager
from si_tests.managers import pdns_manager

LOG = logger.logger


def test_install_pdns_on_seed_node():
    """Install PDNS Authoritative server and Recursor services on seed node

    - Recursor will redirect requests to Authoritative server only
      for the ".sitest" zone, other requests will be redirected
      to the server from settings.DNS_NAMESERVER
    """
    bootstrap = bootstrap_manager.BootstrapManager.get_si_config_bootstrap_manager()
    pdns = pdns_manager.PDNSManager(bootstrap_manager=bootstrap)
    # Do not use "local" zone because it is filtered as unsafe in systemd-resolve service by default
    local_zones = [settings.SEED_PDNS_LOCAL_ZONE]
    if settings.SEED_PDNS_WITH_RECURSOR:
        pdns.install_pdns(local_zones=local_zones, upstream_nameserver=settings.DNS_NAMESERVER,
                          server_version=settings.PDNS_VERSION,
                          recursor_version=settings.RECURSOR_VERSION)
    else:
        pdns.install_pdns_authoritative_only(server_version=settings.PDNS_VERSION,
                                             recursor_version=settings.RECURSOR_VERSION)

    # k0s API FQDN: publish '<KAAS_MGMT_API_FQDN> -> reserved mgmt API VIP' so the k0s
    # custom-cert flow can reach/issue the API cert by hostname (k0s rejects a bare IP
    # as the API server name). The FQDN resolves to the SVC-LBhost IPAM VIP; note that
    # spec.loadBalancerHost itself stays that IP (setting it to an FQDN is forbidden by
    # the admission controller).
    if settings.KAAS_MGMT_API_FQDN_ENABLED:
        assert settings.KAAS_MGMT_API_FQDN and settings.KAAS_MGMT_API_LB_IP, (
            "KAAS_MGMT_API_FQDN_ENABLED requires KAAS_MGMT_API_FQDN and "
            "KAAS_MGMT_API_LB_IP to be set")
        assert settings.KAAS_MGMT_API_FQDN.endswith(f".{settings.SEED_PDNS_LOCAL_ZONE}"), (
            f"KAAS_MGMT_API_FQDN '{settings.KAAS_MGMT_API_FQDN}' must be under the "
            f"local PowerDNS zone '.{settings.SEED_PDNS_LOCAL_ZONE}' to be resolvable")
        LOG.info(f"Publish mgmt API FQDN {settings.KAAS_MGMT_API_FQDN} -> "
                 f"{settings.KAAS_MGMT_API_LB_IP}")
        pdns.ensure_fqdn_a_record(settings.KAAS_MGMT_API_FQDN, settings.KAAS_MGMT_API_LB_IP)
