import pytest
import re
import time
from si_tests import logger
from si_tests import settings
from si_tests.managers.kaas_manager import Machine
from si_tests.utils import utils, waiters, exceptions
LOG = logger.logger


def patch_daemonset(cluster, pattername):
    ds = cluster.k8sclient.daemonsets.get(
        name=pattername, namespace="openstack")
    annotations = ds.read().to_dict()['spec']['template']['metadata']['annotations']
    LOG.info(f"Annotations before: {annotations}")
    ds.patch(body={"spec": {"template": {"metadata": {
        "annotations": {"si-team/restart-policy-checker" + utils.gen_random_string(8): ""}}}}})
    time.sleep(30)
    annotations = ds.read().to_dict()['spec']['template']['metadata']['annotations']
    LOG.info(f"Annotations after: {annotations}")


@pytest.mark.usefixtures('post_action_stop_mm_mode')
@pytest.mark.usefixtures('introspect_no_PRODX_51933_after_lcm')
@pytest.mark.parametrize(
    "target_k8s_label_key",
    [
        "openstack-compute-node",
        "openstack-control-plane",
    ],
    ids=["compute", "control"],
)
def test_openvswitch_restart_after_maintenance(kaas_manager, show_step, target_k8s_label_key):
    """Check that openstack controller works correctly with openvswitch pods restart policy.
       It should restart openvswitchpods after removing node maintenance
       Short description of openvswitch restarts logic (Why? When?):
        Restart of openvswitch may happen in the following scenarios:
         -config option change - will stay as it is now (i.e. not deterministic)
         -update of MOSK child cluster
         -upgrade of OpenStack - will stay as it is now (i.e. not deterministic)
        Always restart openvswitch pods only when:
         -clustermaintenancerequest exists
         -nodemainteanancerequest is removed for specific node. Which basically means
          everything is done with the node from LCM standpoint.
    Parametrization:
    - Restrict candidate target nodes to those having {target_k8s_label_key}=enabled.
    - When comparing pod names before/after cluster maintenance, compare only pods scheduled on
      nodes with that label.
    Scenario:
            1. Check cluster readiness, get one openvswitchpod, node and machine name
            2. Initiate cluster maintenance and find the target node
            3. Start nmr for selected node(target node is a node where openvswitchpod is running)
            4. Patch annotations in openvswitch daemonset(to change generation) because this is a reboot criteria
            5. Stop machine maintenance and check that pod is restarted by openstack-controller
            6. Stop cluster maintenance and check that we have same pod name
            7. Exit from mm mode (post action)
    """
    LOG.info(f"Target k8s label key for test: {target_k8s_label_key}")
    managed_ns = kaas_manager.get_namespace(settings.TARGET_NAMESPACE)
    cluster = managed_ns.get_cluster(settings.TARGET_CLUSTER)

    show_step(1)
    cluster.check.check_k8s_pods()
    cluster.check.check_k8s_pods(target_namespaces="openstack")
    cluster.check.check_cluster_readiness()

    ovs_pods = [pod for pod in cluster.k8sclient.pods.list(namespace='openstack')
                if re.match(settings.OPENVSWITCHD_PATTERN_NAME, pod.name)]
    LOG.info(f"List of openvswitchpods pods: {ovs_pods}")

    neutron_l3_pods = [pod for pod in cluster.k8sclient.pods.list(namespace='openstack')
                       if re.match(settings.NEUTRON_L3_PATTERN_NAME, pod.name)]
    LOG.info(f"List of neutron-l3-agent pods: {neutron_l3_pods}")
    if not ovs_pods:
        raise Exception("Looks like we don't have openvswitch pods on env. "
                        "Please check that Openstack is installed correctly")
    if not neutron_l3_pods:
        raise Exception("Looks like we don't have neutron-l3 pods on env. "
                        "Please check that Openstack is installed correctly")

    # Record initial openvswitch machines by labels, we need all of them
    LOG.info(f"Get machines with k8s label {target_k8s_label_key}=enabled")
    machines: list[Machine] = cluster.get_machines(
        k8s_labels={target_k8s_label_key: "enabled"},
        raise_if_empty=False,
    )
    if not machines:
        pytest.skip(f"No machines found with k8s label {target_k8s_label_key}=enabled")
    LOG.info(f"List of machines with k8s label {target_k8s_label_key}=enabled: {machines}")

    show_step(2)
    cluster.cluster_maintenance_start()
    target_machine = None
    # Check all openvswitch pods
    for selected_pod in ovs_pods:
        for machine in machines:
            k8s_node_name = machine.get_k8s_node_name()
            if k8s_node_name == selected_pod.node_name:
                LOG.info(f"Pod '{selected_pod.name}' found on K8s node name : {k8s_node_name}")
                target_machine = machine
                break
        if target_machine:
            break
    else:
        raise Exception(f"Any from pods: {ovs_pods} wasn't scaled to any machine in cluster")
        # Check do we have neutron l3 pods on this machine
    neutron_l3_pod = [pod for pod in neutron_l3_pods if pod.node_name == target_machine.get_k8s_node_name()]
    show_step(3)
    target_machine.machine_maintenance_start()
    show_step(4)
    patch_daemonset(cluster, settings.OPENVSWITCHD_PATTERN_NAME)
    if neutron_l3_pod:
        patch_daemonset(cluster, settings.NEUTRON_L3_PATTERN_NAME)
    # Check that selected ovs pod still exists
    try:
        LOG.info(f"Make sure that the pod {selected_pod.name} has not restarted")
        waiters.wait(lambda: selected_pod not in cluster.k8sclient.pods.list(namespace='openstack'),
                     timeout=30, interval=5)
        raise AssertionError(f"Pod {selected_pod.name} was restarted before we "
                             f"remove nodemaintenancerequest, but shouldn't")
    except exceptions.TimeoutError:
        pass

    if neutron_l3_pod:
        try:
            LOG.info(f"Make sure that the pod {neutron_l3_pod[0].name} has not restarted")
            waiters.wait(lambda: neutron_l3_pod[0] not in cluster.k8sclient.pods.list(namespace='openstack'),
                         timeout=30, interval=5)
            raise AssertionError(f"Pod {neutron_l3_pod[0].name} was restarted before we "
                                 f"remove nodemaintenancerequest, but shouldn't")
        except exceptions.TimeoutError:
            pass

    show_step(5)
    target_machine.machine_maintenance_stop()
    cluster.check.check_k8s_pods()
    cluster.check.check_k8s_pods(target_namespaces="openstack")
    # Get list of new ovs pods
    new_ovs_pods = [pod for pod in cluster.k8sclient.pods.list(namespace='openstack')
                    if re.match(settings.OPENVSWITCHD_PATTERN_NAME, pod.name)]
    LOG.info(f"List of openvswitchpods pods: {new_ovs_pods}")
    assert selected_pod not in new_ovs_pods, (
        f"Looks like that initial pod with name: {selected_pod.name} still "
        f"exists in cluster after nodemaintenancerequest was deleted")

    # Get list of new neutron-l3 pods
    if neutron_l3_pod:
        new_neutron_l3_pods = [pod for pod in cluster.k8sclient.pods.list(namespace='openstack')
                               if re.match(settings.NEUTRON_L3_PATTERN_NAME, pod.name)]
        LOG.info(f"List of neutron-l3 pods: {new_neutron_l3_pods}")
        assert neutron_l3_pod[0] not in new_neutron_l3_pods, \
            (f"Looks like that initial pod with name: {neutron_l3_pod[0].name} "
             f"still exists in cluster after nodemaintenancerequest was deleted")
        # Need to remove l3 neutron pod from list because we will try to process unexisted pod
        neutron_l3_pods.remove(neutron_l3_pod[0])

    show_step(6)
    target_node_name = target_machine.get_k8s_node_name()
    # In scope only the pods on the target node: they were already restarted during node
    # maintenance and must NOT restart again on CMR removal. Pods on other nodes may be
    # legitimately restarted by rockoon to match the bumped daemonset generation
    # (expected behavior, see PRODX-58886), so they are intentionally excluded.
    # Get list of new ovs and neutron-l3 pods before clustermaintenancerequest deletion
    pods_before_clmr = [pod for pod in cluster.k8sclient.pods.list(namespace='openstack')
                        if (re.match(settings.OPENVSWITCHD_PATTERN_NAME, pod.name)
                            or re.match(settings.NEUTRON_L3_PATTERN_NAME, pod.name))
                        and pod.node_name == target_node_name]
    cluster.cluster_maintenance_stop()
    cluster.check.check_k8s_pods()
    cluster.check.check_k8s_pods(target_namespaces="openstack")
    cluster.check.check_cluster_readiness()
    # Check that we have same pods after clustermaintenancerequest deletion
    pods_after_clmr = [pod for pod in cluster.k8sclient.pods.list(namespace='openstack')
                       if (re.match(settings.OPENVSWITCHD_PATTERN_NAME, pod.name)
                           or re.match(settings.NEUTRON_L3_PATTERN_NAME, pod.name))
                       and pod.node_name == target_node_name]

    assert pods_before_clmr == pods_after_clmr, (
        "Scoped pod names changed after cluster maintenance stop.\n"
        f"Pods before: {sorted([p.name for p in pods_before_clmr])} \n "
        f"are not same as after "
        f"clustermaintenancerequest deletion: {sorted([p.name for p in pods_after_clmr])}")
