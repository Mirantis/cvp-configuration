import os
import time
import base64
import yaml
from typing import List, Dict, Optional

from si_tests import logger
from si_tests import settings
from si_tests.utils import waiters, utils, exceptions, security_checks
from exec_helpers import SSHClient, SSHAuth

LOG = logger.logger


class KaasBaremetalChildTestBase:
    """Shared logic for all baremetal child cluster deployment tests."""

    def __init__(self, kaas_manager, proxy_manager):
        self.kaas_manager = kaas_manager
        self.proxy_manager = proxy_manager
        self.step = 1
        self.reuse_resources = False  # Allow test to re-use already defined `namespaces`

    # === 1. Collect env data ===
    def collect_env_data(self):
        self.cluster_name = settings.TARGET_CLUSTER
        self.namespace_name = settings.TARGET_NAMESPACE
        self.custom_indexes = settings.KAAS_CHILD_CLUSTER_SET_CUSTOM_INDEXES
        self.indexes = utils.generate_upgrade_indexes()
        self.release_name = self.kaas_manager.si_config.version_generators.get_child_cluster_release_name()
        LOG.info("Release name: {}".format(self.release_name))
        LOG.info("Available releases: {}".format(self.kaas_manager.get_clusterrelease_names()))
        assert self.release_name in self.kaas_manager.get_clusterrelease_names(), \
            (f"Release name {self.release_name}, "
             f"cluster release names {self.kaas_manager.get_clusterrelease_names()}")

        mgmt = self.kaas_manager.get_mgmt_cluster()
        self.region = mgmt.region_name
        self.mgmt_version = mgmt.spec['providerSpec']['value']['kaas']['release']
        LOG.info(f"KaaS mgmt version is:{self.mgmt_version}")
        LOG.info(f"Child cluster version is:{self.release_name}")
        cephdeploy_used = self.kaas_manager.cephdeploy_used()
        cephdeploy_new_api = self.kaas_manager.cephdeploy_new_api_used()

        with open(settings.KAAS_CHILD_CLUSTER_PUBLIC_KEY_FILE) as f:
            self.pub_key_content = f.read()
        # NIT: don't rename key-name schema, since it is used across whole tests
        self.public_key_name = f"{self.cluster_name}-key"
        self.child_dns = settings.KAAS_CHILD_CLUSTER_DNS
        self.allowed_distros = self.kaas_manager.get_allowed_distributions(self.release_name)
        LOG.info(f"Allowed distributions: {self.allowed_distros}")

        render_opts = {
            "mgmt_version": self.mgmt_version,
            "target_region": self.region,
            "target_cluster": self.cluster_name,
            "target_namespace": self.namespace_name,
            "machine_distribution": self.allowed_distros.get(settings.DISTRIBUTION_RELEVANCE, {}).get('id', ''),
            "pub_key_content": self.pub_key_content,
            "cephdeploy_used": cephdeploy_used,
            "cephdeploy_new_api": cephdeploy_new_api,
        }
        self.child_data = utils.render_child_data(self.kaas_manager.si_config, render_opts)
        self.child_cluster_data = self.child_data.get('child_config', {})
        self.bm_hosts_data = self.child_data.get('nodes', [])
        self.bm_update_group_data = self.child_data.get('groups', [])
        self.osdpl_node_overrides = {}
        self.metallb_config = self.child_data.get('metallb_config', {})
        self.tf = self.child_cluster_data.get('child_config', {}).get('tungstenfabric', {})
        self.ceph_cluster_pools = None

    # === 2. Namespace ===
    def create_namespace(self):
        LOG.info("Namespace name - %s", self.namespace_name)
        existing = [n.name for n in self.kaas_manager.get_namespaces()]
        if self.namespace_name not in existing:
            if self.child_data.get('namespace_config_raw'):
                self.ns = self.kaas_manager.create_namespace_raw(self.child_data['namespace_config_raw'])
            else:
                self.ns = self.kaas_manager.create_namespace(self.namespace_name)
        elif self.reuse_resources:
            self.ns = self.kaas_manager.get_namespace(self.namespace_name)
        else:
            raise Exception(f"Namespace {self.namespace_name} already exists!")

    # === 3. BM static resources: l2templates, subnets, bmh ===
    def create_cluster_subnets_l2_bmh(self):
        LOG.info("Create BM static resources, in NS: bmh, subnets, l2templates")
        self.ns.create_bm_statics(self.child_data)

    # === 4. Public Key ===
    def create_public_key(self):
        existing = [k.name for k in self.ns.get_publickeys()]
        if not self.child_data.get('public_keys_raw'):
            if self.public_key_name not in existing:
                LOG.info(f"Public key name - {self.public_key_name}")
                self.ns.create_publickey(self.public_key_name, self.pub_key_content)
        else:
            for pk in self.child_data['public_keys_raw']:
                if pk['metadata']['name'] not in existing:
                    self.ns.create_publickey_raw(pk)

    def _create_bmh_generated(self) -> None:
        """
        Generate and create BareMetalHostCredentials (BMHC) and BareMetalHost (BMH)
        from `bm_hosts_data` (non-raw path).
        """
        LOG.info("Creating BMHC/BMH using generated method")

        # === 1. Create BMHC (credentials) ===
        existing_bmhc = [bmhc.name for bmhc in self.ns.get_baremetalhostcredentials()]

        for node in self.bm_hosts_data:
            # Skip scale nodes
            if any(role in node.get('si_roles', []) for role in ['nodeforscale', 'child-scale-controller']):
                continue

            # Render BMH name
            bmh_name = utils.render_bmh_name(
                node['name'],
                self.cluster_name,
                node.get('bootUEFI', True),
                node['bmh_labels'],
                si_roles=node.get('si_roles', False)
            )
            cred_name = f"{node['name']}-cred"

            # Build node copy with derived names
            _node = node.copy()
            _node.update({'bmh_name': bmh_name, 'cred_name': cred_name})
            self.bm_nodes.append(_node)

            # Build secret data
            secret_data = {
                "username": node['ipmi']['username'],
                "password": node['ipmi']['password']
            }

            # Optional monitoring credentials
            if "kaas.mirantis.com/baremetalhost-credentials-name" in node.get('bmh_annotations', {}):
                if node['ipmi'].get('monitoringUsername'):
                    secret_data.update({
                        "monitoringUsername": node['ipmi']['monitoringUsername'],
                        "monitoringPassword": node['ipmi']['monitoringPassword']
                    })

                if cred_name not in existing_bmhc:
                    self.ns.create_baremetalhostcredential(
                        name=cred_name,
                        data=secret_data,
                        region=self.region,
                        provider="baremetal"
                    )
                else:
                    LOG.warning("BMHC: %s already exists, skipping", cred_name)
            else:
                raise Exception("IPMI credentials supported only via baremetalhostcredentials")

        existing_bmh = [bmh.name for bmh in self.ns.get_baremetalhosts()]

        for node in self.bm_nodes:
            bmh_name = node['bmh_name']

            if bmh_name in existing_bmh:
                LOG.warning("BareMetalHost: %s already exists, skipping", bmh_name)
                continue

            # Track control plane nodes
            if node['bmh_labels'].get("hostlabel.bm.kaas.mirantis.com/controlplane"):
                self.bm_ctrls.append(bmh_name)

            # Dummy provision: pause BMH
            if settings.KAAS_BM_DUMMY_PROVISION:
                ann = node.get('bmh_annotations', {})
                ann["baremetalhost.metal3.io/paused"] = "true"
                node['bmh_annotations'] = ann

            # OSDPL override
            if node.get('osdpl_node_override'):
                self.osdpl_node_overrides[node['name']] = node['osdpl_node_override']

            # Create BMH
            self.ns.create_baremetalhost(
                bmh_name=bmh_name,
                bmh_secret=node['cred_name'],
                bmh_mac=node['networks'][0]['mac'],
                bmh_ipmi=node['ipmi'],
                hardwareProfile=node.get('hardwareProfile', False),
                labels=node['bmh_labels'],
                annotations=node.get('bmh_annotations', {}),
                bootUEFI=node.get('bootUEFI', True),
                bmhi_credentials_name=node['cred_name']
            )

            # dnsmasq PRODX-7751 workaround
            time.sleep(settings.KAAS_BM_CHILD_SLEEP_PRODX_7751)

    def _create_bmh_raw(self) -> None:
        """
        Create BMHC, BMH, and BMHI using raw YAML definitions from child_data.
        """
        LOG.info("Creating BMHC/BMH/BMHI using raw methods")

        existing_bmhc = [bmhc.name for bmhc in self.ns.get_baremetalhostcredentials()]
        existing_bmh = [bmh.name for bmh in self.ns.get_baremetalhosts()]

        # === 1. Extract control plane BMH names ===
        self.bm_ctrls = [
                            i['metadata']['name']
                            for i in self.child_data.get('bmh_raw', [])
                            if 'hostlabel.bm.kaas.mirantis.com/controlplane' in i['metadata']['labels']
                        ] + [
                            i['metadata']['name']
                            for i in self.child_data.get('bmhi_raw', [])
                            if 'hostlabel.bm.kaas.mirantis.com/controlplane' in i['metadata']['labels']
                        ]

        # === 2. Create BMHC (raw) ===
        for bmhc in self.child_data.get('bmhc_raw', []):
            name = bmhc['metadata']['name']
            if name not in existing_bmhc:
                if not any(role in bmhc['metadata']['labels'].keys() for role in
                           ['si-role/nodeforscale', 'si-role/child-scale-controller']):
                    self.ns.create_baremetalhostcredential_raw(bmhc)
            else:
                LOG.warning("BMHC (raw): %s already exists, skipping", name)

        # === 3. Create BMH (raw) ===
        for bmh in self.child_data.get('bmh_raw', []):
            name = bmh['metadata']['name']
            if name not in existing_bmh:
                if not any(role in bmh['metadata']['labels'].keys() for role in
                           ['si-role/nodeforscale', 'si-role/child-scale-controller']):
                    self.ns.create_baremetalhost_raw(bmh)
                    time.sleep(settings.KAAS_BM_CHILD_SLEEP_PRODX_7751)
            else:
                LOG.warning("BMH (raw): %s already exists, skipping", name)

        # === 4. Create BMHI (raw) ===
        for bmhi in self.child_data.get('bmhi_raw', []):
            name = bmhi['metadata']['name']
            if name not in existing_bmh:
                if not any(role in bmhi['metadata']['labels'].keys() for role in
                           ['si-role/nodeforscale', 'si-role/child-scale-controller']):
                    self.ns.create_baremetalhostinventories_raw(bmhi)
                    time.sleep(settings.KAAS_BM_CHILD_SLEEP_PRODX_7751)
            else:
                LOG.warning("BMHI (raw): %s already exists, skipping", name)

        LOG.info("Raw BMHC/BMH/BMHI creation completed")

    # === 4-5. BMH Credentials & Hosts ===
    def create_bmh_profiles(self):
        self.bm_nodes = []
        self.bm_ctrls = []
        if not (bool(self.child_data.get('bmh_raw')) or bool(self.child_data.get('bmhi_raw'))):
            self._create_bmh_generated()
        else:
            self._create_bmh_raw()
        # Wait for control nodes to be ready (unless dummy)

        if not settings.KAAS_BM_DUMMY_PROVISION:
            if not settings.ASYNC_BMH_CONTROL_NODES_WAIT:
                self.bm_ctrls = []
            else:
                LOG.warning(f'Bmh provision wait scope limited to:{self.bm_ctrls}')
            if not self.reuse_resources:
                self.ns.wait_baremetalhosts_statuses(wait_status='ready', autotime=True, nodes=self.bm_ctrls)

    # === 6. Proxy ===
    def setup_proxy(self):
        if ((settings.KAAS_EXTERNAL_PROXY_ACCESS_STR or
             settings.KAAS_INSTALL_FAKE_PROXY) and
                not settings.KAAS_OFFLINE_DEPLOYMENT):
            LOG.error("Proxy variables is set but KAAS_OFFLINE_DEPLOYMENT "
                      "is False.Using Proxy on online deployments makes no sense.")
            raise RuntimeError("Proxy variables is set but KAAS_OFFLINE_DEPLOYMENT"
                               " is False")
        if settings.KAAS_EXTERNAL_PROXY_ACCESS_STR:
            LOG.info("Found KAAS_EXTERNAL_PROXY_ACCESS_STR. Creating "
                     f"proxyobject with proxy {settings.KAAS_EXTERNAL_PROXY_ACCESS_STR}")
            cert = None
            if settings.KAAS_SSL_PROXY_CERTIFICATE_FILE:
                with open(settings.KAAS_SSL_PROXY_CERTIFICATE_FILE, 'rb') as f:
                    cert = base64.b64encode(f.read()).decode()
            proxy_obj = self.ns.create_proxyobject(
                name=f"{self.cluster_name}-{settings.KAAS_PROXYOBJECT_NAME}",
                region=self.region,
                proxy_str=settings.KAAS_EXTERNAL_PROXY_ACCESS_STR,
                ca_cert=cert
            )
            return proxy_obj.data['metadata']['name']
        elif settings.KAAS_INSTALL_FAKE_PROXY:
            self.proxy_manager.deploy_proxy_sts()
            self.proxy_manager.deploy_proxy_svc()
            proxy_str = self.proxy_manager.generate_proxy_string()
            self.proxy_manager.check_proxy_conn()
            proxy_obj = self.ns.create_proxyobject(
                name=f"{self.cluster_name}-{settings.KAAS_PROXYOBJECT_NAME}",
                region=self.region,
                proxy_str=proxy_str
            )
            return proxy_obj.data['metadata']['name']
        return None

    # === 7. Cluster & Machines ===
    def create_cluster_and_machines(self, helm_releases):
        proxy_name = self.setup_proxy()

        if settings.MOSK_CHILD_DEPLOY_CEPH and not any(
                r['name'] == 'ceph-controller' and r.get('enabled', True) for r in helm_releases):
            raise RuntimeError("ceph-controller disabled but MOSK_CHILD_DEPLOY_CEPH enabled")

        existing = [c.name for c in self.ns.get_clusters()]
        if self.cluster_name in existing:
            self.cluster = self.ns.get_cluster(self.cluster_name)
            LOG.warning("Re-using cluster: %s", self.cluster_name)
        else:
            metallb_ip_range = None if self.child_data.get('metallb_config') \
                else self.child_cluster_data.get('metallb_ip_range')
            if not self.child_data.get('cluster_raw'):
                self.cluster = self.ns.create_cluster(
                    name=self.cluster_name,
                    release_name=self.release_name,
                    region=self.region,
                    provider="baremetal",
                    loadbalancer_host=self.child_cluster_data.get('loadbalancer_host'),
                    metallb_ip_range=metallb_ip_range,
                    metallb_pool_protocol=self.child_cluster_data.get("metallb_pool_protocol", "layer2"),
                    metallb_peers=self.child_cluster_data.get("metallb_peers"),
                    services_cidr="10.232.0.0/18",
                    pods_cidr="192.168.0.0/16",
                    nodes_cidr="10.12.10.0/24",
                    dns=settings.KAAS_CHILD_CLUSTER_DNS,
                    extra_helm_releases=helm_releases,
                    lma_enabled=settings.KAAS_CHILD_CLUSTER_DEPLOY_LMA,
                    dedicated_controlplane=self.child_cluster_data.get('dedicated_controlplane', True),
                    public_key_name=self.public_key_name,
                    proxy_name=proxy_name,
                    secure_overlay=settings.KAAS_CHILD_CLUSTER_SECURE_OVERLAY_ENABLED,
                    metallb_speaker=self.child_cluster_data.get("metallb_speaker"),
                    use_bgp_announcement=self.child_cluster_data.get("use_bgp_announcement"),
                    calico_mtu=self.child_cluster_data.get('calico_mtu'),
                )
            else:
                self.cluster = self.ns.create_cluster_raw(self.child_data['cluster_raw'])

        self.cluster.set_custom_hostnames_enabled(flag=settings.CUSTOM_HOSTNAMES)

        # Update groups
        upd_groups = {n['machine_labels'].get(
            "kaas.mirantis.com/update-group") for n in self.bm_hosts_data if n['machine_labels'].get(
            "kaas.mirantis.com/update-group")}
        for g in self.bm_update_group_data:
            if g.get('name') in upd_groups:
                self.cluster.create_update_group(
                    cluster_name=settings.TARGET_CLUSTER,
                    namespace=settings.TARGET_NAMESPACE,
                    name=g.get('name'),
                    index=g.get('index'),
                    concurrent_updates=g.get('concurrentUpdates')
                )
        for upd in self.child_data.get('updategroups_raw', []):
            if upd['metadata']['name'] not in [x.name for x in self.cluster.get_update_groups()]:
                self.cluster.create_update_group_raw(upd)

        # Day 1 pause mode
        version = self.cluster.get_desired_clusterrelease_version()
        day1_mode = 'manual' if (
            utils.clusterrelease_version_greater_than_or_equal_to_kaas_2_30_0(version) and
            settings.MACHINE_PAUSE_DURING_CREATION_ENABLED
        ) else 'auto'

        # Machines
        if self.child_data.get('bmh_raw') or self.child_data.get('bmhi_raw'):
            existing = [m.name for m in self.ns.get_machines()]
            for m in self.child_data['machines_raw']:
                if m['metadata']['name'] not in existing and not any(
                        r in m['metadata']['labels'].keys() for r in ['si-role/nodeforscale',
                                                                      'si-role/child-scale-controller']):
                    self.cluster.create_baremetal_machine_raw(m)
        else:
            for node in self.bm_nodes:
                dist = utils.get_distribution_for_node(self.kaas_manager, node, self.release_name)
                custom_bmhp = {
                    'namespace': self.namespace_name,
                    'name': node['bmh_profile']} if node.get('bmh_profile') else None
                index = self.indexes.__next__() if self.custom_indexes else None
                self.cluster.create_baremetal_machine(
                    genname=node['bmh_name'],
                    node_pubkey_name=self.public_key_name,
                    matchlabels={
                        'kaas.mirantis.com/baremetalhost-id': node[
                            'bmh_labels']['kaas.mirantis.com/baremetalhost-id']},
                    baremetalhostprofile=custom_bmhp,
                    l2TemplateSelector=node.get('l2TemplateSelector', {}),
                    labels=node['machine_labels'],
                    node_labels=node.get('node_labels', {}),
                    distribution=dist,
                    upgrade_index=index,
                    day1_provisioning=day1_mode,
                    day1_deployment=day1_mode,
                    static_ip_request=node.get('staticIPRequest'),
                )
                time.sleep(settings.KAAS_BM_CHILD_SLEEP_PRODX_7751)
        machines = self.cluster.get_machines_uncached()

        return machines, day1_mode

    # === Provisioning & Deployment ===
    def wait_provisioning(self, machines, day1_mode):
        if day1_mode == 'manual':
            self.cluster.check.check_machines_status(expected_status='AwaitsProvisioning')
            self.ns.wait_baremetalhosts_statuses(wait_status='available', autotime=True, nodes=self.bm_ctrls)
        if utils.clusterrelease_version_greater_than_or_equal_to_kaas_2_30_0(
                self.cluster.get_desired_clusterrelease_version()):
            self.cluster.set_day1_provisioning('auto', machines)
            self.cluster.check.check_day1_modes(machines, provisioning='auto')

        if settings.KAAS_BM_DUMMY_PROVISION:
            bmh_names = [n['bmh_name'] for n in self.bm_nodes]
            for i in range(0, len(bmh_names), settings.KAAS_BM_DUMMY_PROVISION_SIZE):
                batch = bmh_names[i:i + settings.KAAS_BM_DUMMY_PROVISION_SIZE]
                for name in batch:
                    bmh = self.ns.get_baremetalhost(name=name)
                    utils.remove_k8s_obj_annotations(bmh, ['baremetalhost.metal3.io/paused'])
                self.ns.wait_baremetalhosts_statuses(
                    wait_status={'provisioning', 'provisioned'}, nodes=batch, autotime=True)
        else:
            self.ns.wait_baremetalhosts_statuses(wait_status='provisioned', autotime=True, nodes=self.bm_ctrls)

    def wait_deployment(self, machines, day1_mode):
        if day1_mode == 'manual':
            self.cluster.check.check_machines_status(expected_status='AwaitsDeployment')
        if utils.clusterrelease_version_greater_than_or_equal_to_kaas_2_30_0(
                self.cluster.get_desired_clusterrelease_version()):
            self.cluster.set_day1_deployment('auto', machines)
            self.cluster.check.check_day1_modes(machines, deployment='auto')

        try:
            self.cluster.check.check_machines_status()
            self.cluster.check.check_cluster_nodes()
            self.cluster.check.check_helmbundles(timeout=3600)
            self.cluster.check.check_k8s_nodes()
        finally:
            self.cluster.store_machines_artifacts()

        self.cluster.apply_hotfix_labels(bm_nodes=self.bm_nodes)
        self.cluster.apply_nodes_annotations(bm_nodes=self.bm_nodes)
        self.cluster.check_bmhp_mapping()

    # === DPDK + Network ===
    def install_dpdk(self):
        if not settings.OPENSTACK_DEPLOY_DPDK:
            return
        machines = self.ns.get_cluster(self.cluster_name).get_machines()
        lkey, lvalue = settings.OPENSTACK_NODES_WITH_HUGEPAGES_LABEL.split('=')
        for m in machines:
            if m.get_k8s_node().read().metadata.labels.get(lkey) == lvalue:
                codename = m.get_distribution().split('/')[-1]
                pkg = utils.get_dpdk_driver_package(codename)
                m.run_cmd(f"sudo apt install -y {pkg}", timeout=600)
                break

    def check_network(self):
        if 'seed_ip' not in self.child_cluster_data:
            LOG.error("seed_ip missing in child_config")
            return
        try:
            waiters.wait(
                lambda: self._check_networks(self.ns, self.child_cluster_data['seed_ip']),
                timeout=60*30, interval=5
            )
            LOG.info("Network connectivity OK")
        except exceptions.TimeoutError:
            raise

    def _check_networks(self, ns, seed_ip: str) -> bool:
        """
        Verify full network connectivity between all IpamHosts via the seed bastion.
        Each host pings every other host's IP (except its own).
        # The Plan
        # 1. get all ipaddr objects in ns and extract IP addresses from them
        # 2. get all ipamhost objects in ns
        # 3. For each ipamhost:
        # 3.1 get PXE address and make ssh_client to it
        # 3.2 get corresponding l2template
        # 3.2.1 Get si/expected_ips from labels of the l2template
        # 3.2.2 If there is no expected_ips skip test for the ipamhost
        # 3.3 sort out IP addresses that belongs to the ipamhost from list
        #     of all IPs
        # 3.4 run ping for remaining IP addresses on the ipamhost

        Returns:
            bool: True if all pings succeed
        """
        LOG.debug("Starting network connectivity check via seed %s", seed_ip)

        # 1. Get all IP addresses from IpamIpAddr CRs
        ipaddrs = [
            i.read().to_dict()['status']['address']
            for i in ns.get_ipam_ipaddrs()
        ]
        LOG.debug(f"Collected {len(ipaddrs)} IP addresses: {ipaddrs}")

        # 2. Get all IpamHost CRs
        ipamhosts = [i.read().to_dict() for i in ns.get_ipam_hosts()]
        LOG.debug(f"Found {len(ipamhosts)} IpamHosts")

        if not ipamhosts:
            LOG.warning("No IpamHosts found. Skipping network check.")
            return True

        # 3. SSH client to seed (bastion)
        seed_key_file = os.path.expanduser(settings.SEED_SSH_PRIV_KEY_FILE)
        seed_key = utils.load_keyfile(seed_key_file)
        seed_key_rsa = utils.get_rsa_key(seed_key["private"])

        remote_seed = SSHClient(
            host=seed_ip,
            port=22,
            auth=SSHAuth(username=settings.SEED_SSH_LOGIN, key=seed_key_rsa)
        )
        remote_seed.logger.addHandler(logger.console)
        LOG.debug("SSH client to seed node initialized")

        # 4. Child cluster SSH key (for bastion access to child nodes)
        child_key_file = os.path.expanduser(settings.KAAS_CLUSTER_PRIVATE_KEY_FILE)
        child_key = utils.load_keyfile(child_key_file)
        child_key_rsa = utils.get_rsa_key(child_key["private"])

        # 5. Helper: extract bastion IP from IpamHost
        def get_bastion_ip(ipamhost: dict) -> str:
            name = ipamhost['metadata']['name']
            status = ipamhost['status']

            # Try osMetadataNetwork first
            if 'osMetadataNetwork' in status:
                networks = status['osMetadataNetwork'].get('networks', [])
                if networks:
                    return networks[0]['ip_address']

            # Fallback: nicMACmap
            if 'nicMACmap' in status:
                for iface in status['nicMACmap']:
                    if iface.get('primary'):
                        return iface['ip'].split('/')[0]

            raise Exception(f"Cannot determine bastion IP for IpamHost '{name}'")

        # 6.4. Main ping loop
        failed_pings: Dict[str, List[str]] = {}

        for ipamhost in ipamhosts:
            name = ipamhost['metadata']['name']
            try:
                bastion_ip = get_bastion_ip(ipamhost)
            except Exception as e:
                LOG.error("Failed to get bastion IP for %s: %s", name, e)
                failed_pings.setdefault("UNKNOWN", []).append(name)
                continue

            LOG.debug("Checking connectivity from %s (%s)", name, bastion_ip)

            # Skip if no netconfig or l2template
            netconfig_files = ipamhost['status'].get('netconfigFiles', [])
            l2template_ref = ipamhost['status'].get('l2TemplateRef', '')

            if not (netconfig_files and l2template_ref):
                LOG.info("No l2template/netconfig on '%s'. Skipping ping from this host.", name)
                continue

            # Parse netconfig
            netconfig = utils.get_np_struct_from_netconfigfiles(netconfig_files)
            l2template_name = l2template_ref.split('/')[-1]
            l2template = ns.get_l2template(l2template_name).read().to_dict()

            expected_ips_label = l2template['metadata'].get('labels', {}).get('si/expected_ips', '0')
            expected_ips = int(expected_ips_label)
            if expected_ips == 0:
                LOG.info("No 'si/expected_ips' label on L2Template '%s'. Skipping.", l2template_name)
                continue

            # Extract IPs owned by this host
            own_ips = set()
            for ifaces in netconfig.values():
                if not isinstance(ifaces, dict):
                    continue
                for iface in ifaces.values():
                    if not isinstance(iface, dict):
                        continue
                    for addr in iface.get('addresses', []):
                        ip = addr.split('/')[0]
                        own_ips.add(ip)

            LOG.debug("%s owns IPs: %s (expected: %d)", name, sorted(own_ips), expected_ips)
            if len(own_ips) != expected_ips:
                LOG.warning(
                    "IpamHost '%s' has %d IPs, but expected %d (from si/expected_ips)",
                    name, len(own_ips), expected_ips
                )

            # Ping all other IPs
            target_ips = [ip for ip in ipaddrs if ip not in own_ips]
            LOG.debug("Pinging %d targets from %s", len(target_ips), name)

            bastion_kwargs = {
                'hostname': bastion_ip,
                'auth': SSHAuth(username=settings.KAAS_CHILD_CLUSTER_SSH_LOGIN, key=child_key_rsa),
            }

            for ip in target_ips:
                LOG.debug("Ping %s → %s", bastion_ip, ip)
                success = waiters.icmp_ping(
                    host=ip,
                    ssh_client=remote_seed,
                    bastion_kwargs=bastion_kwargs,
                    timeout=5
                )
                if not success:
                    failed_pings.setdefault(bastion_ip, []).append(ip)
                LOG.debug("Ping %s from %s: %s", ip, name, "OK" if success else "FAILED")

        # 7. Final result
        if failed_pings:
            LOG.error("Network connectivity check FAILED")
            for src, targets in failed_pings.items():
                LOG.error("  From %s → failed to reach: %s", src, targets)
            return False
        else:
            LOG.info("Network connectivity check PASSED: all pings succeeded")
            return True

    # === Ceph ===
    def deploy_ceph(self) -> Optional[List[dict]]:
        """
        Deploy Ceph cluster according to configuration.
        Supports:
          - Raw CephDeployment
          - Raw MiraCeph
          - Auto-generated via child_config

        Returns:
            List[dict] | None: ceph_cluster_pools spec or None if not deployed
        """

        if not settings.MOSK_CHILD_DEPLOY_CEPH:
            LOG.info("MOSK_CHILD_DEPLOY_CEPH disabled. Skipping Ceph deployment.")
            return None

        LOG.info("Starting Ceph deployment")

        ceph_cluster_pools = None

        # === 1. Raw CephDeployment ===
        if self.child_data.get('cephdeployment_raw') and self.cluster.workaround.child_with_cephdeployment():
            LOG.info("Deploying CephDeployment from raw config")
            if self.cluster.workaround.child_with_new_cephdeployment_api():
                ceph_cluster_pools = self.child_data['cephdeployment_raw']['spec'].get(
                    'blockStorage', {}).get('pools', [])
            else:
                ceph_cluster_pools = self.child_data['cephdeployment_raw']['spec']['pools']

            cephdeployment_data = self.child_data['cephdeployment_raw']
            # add monitorIP field if found separate ceph frontend network
            if self.cluster.workaround.use_ceph_mon_ip():
                self.cluster.set_cephdeployment_data_nodes_monitor_ip(cephdeployment_data)

            self.ns.create_cephdeployment_raw(
                cluster_name=settings.TARGET_CLUSTER,
                data=cephdeployment_data
            )

        # === 3. Raw MiraCeph ===
        elif self.child_data.get('miraceph_raw'):
            LOG.info("Deploying MiraCeph from raw config")
            ceph_cluster_pools = self.child_data['miraceph_raw']['spec']['pools']
            self.ns.create_miraceph_raw(
                cluster_name=settings.TARGET_CLUSTER,
                data=self.child_data['miraceph_raw']
            )

        # === 4. Auto-generate Ceph cluster ===
        else:
            LOG.info("Auto-generating Ceph cluster from child_config")
            nodes_data = self.cluster.check.get_ceph_nodes(
                self.child_cluster_data, self.ns, self.bm_nodes
            )
            ceph_cluster_pools = self.child_cluster_data.get('ceph_pools_config')

            rgw = (
                self.child_cluster_data.get('ceph_rgw_config')
                if settings.CEPH_DEPLOY_RGW else None
            )
            cephfs = (
                self.child_cluster_data.get('cephfs_config')
                if settings.CEPH_DEPLOY_MDS else None
            )

            # Add MDS role to MON nodes if CephFS enabled
            if cephfs:
                for spec in nodes_data.values():
                    if 'mon' in spec.get('roles', []):
                        spec['roles'].append('mds')

            self.ns.create_ceph_cluster(
                name=settings.CEPH_CLUSTER_NAME,
                cluster_name=settings.TARGET_CLUSTER,
                hdd_type=self.child_cluster_data.get('cephClusterDeviceClass', 'hdd'),
                nodes_data=nodes_data,
                pools=ceph_cluster_pools,
                rgw=rgw,
                rook_config=self.child_cluster_data.get('ceph_rook_config'),
                network=self.child_cluster_data.get('ceph_network_config'),
                tolerations=self.child_cluster_data.get('ceph_tolerations'),
                cephfs=cephfs
            )

        # === Wait for Ceph health ===
        try:
            waiters.wait(
                lambda: self.cluster.check.check_child_ceph_cluster(check_health=True),
                timeout=90 * 60,
                interval=60,
                timeout_msg="Ceph cluster did not become healthy"
            )
            LOG.info("Ceph cluster is healthy")
        except exceptions.TimeoutError:
            LOG.error("Ceph health check failed")
            raise

        return ceph_cluster_pools

    def enable_tf_monitoring(self):
        if self.tf:
            LOG.info("Enable TF monitoring ")
            child_pr_spec = self.cluster.data['spec']['providerSpec']
            LOG.info("Current stacklight spec: {}".format(child_pr_spec))

            body = {
                "spec": {
                    "providerSpec": {
                        "value": {
                            "helmReleases": self.cluster.data.get(
                                "spec").get("providerSpec").get("value").get(
                                "helmReleases")
                        }
                    }
                }
            }
            lma_body = [x for x in
                        body['spec']['providerSpec']['value']['helmReleases']
                        if x['name'] == "stacklight"][0]
            lma_body['values'].update(
                {'tungstenFabricMonitoring': {'enabled': True}})
            self.kaas_manager.api.kaas_clusters.update(
                name=self.cluster_name, namespace=self.namespace_name, body=body)

            LOG.info("Cluster providerSpec after update {}".format(
                self.cluster.data['spec']['providerSpec']))
        # openstack-controller requires ceph cluster

    def add_osdpl_overrides(self):
        self.cluster.add_osdpl_overrides(self.osdpl_node_overrides)

    def store_k8s_artifacts(self):
        self.cluster.store_k8s_artifacts()

    def check_offline_isolation(self):
        if settings.KAAS_OFFLINE_DEPLOYMENT:
            LOG.info("Validating offline isolation")
            self.cluster.check.check_offline_isolation(settings.KAAS_EXTERNAL_PROXY_ACCESS_STR)
        else:
            LOG.info(
                f"Current value of KAAS_OFFLINE_DEPLOYMENT "
                f"is {settings.KAAS_OFFLINE_DEPLOYMENT}, so nothing to check ")

    def check_storage_etcd_quota(self):
        if settings.ETCD_STORAGE_QOUTA and self.cluster.lcm_type_is_ucp:
            LOG.info("Checking ETCD storage quota")
            assert self.cluster.check.check_etcd_quota_applied(), "ETCD quota not applied"
            self.cluster.check.check_etcd_storage_quota_negative()
        else:
            LOG.info("ETCD_STORAGE_QOUTA is false, skip the check")

    def check_ceph_monitor_ips_as_expected(self):
        self.cluster.check.check_ceph_monitor_ip_configured()

    # === Deploy AUDITD via HOC ===
    def deploy_auditd_hoc(self):
        """
        Run all final validation checks after cluster is up.
        Includes:
          - HostOSConfiguration Day2 state
          - BMH inventory
        """
        if self.cluster.workaround.deploy_auditd_via_hoc_child():
            self.cluster.day2operations.deploy_auditd_via_hoc()
        else:
            LOG.info(f"Skip Deploy AUDITD via HOC for cluster: {self.cluster.name} because "
                     f"it has version: {self.cluster.clusterrelease_version} and flag "
                     f"DEPLOY_AUDITD_VIA_HOC: {settings.DEPLOY_AUDITD_VIA_HOC}. Which is not "
                     f"eligible for this feature")

    # === Apply WA for the unpinned runc-ee package ===
    def apply_wa_runc(self):
        """Pin the runc-ee package version on all nodes of the child cluster

        In clusters deployed with MOSK 26.1 (Cluster release 21.1.0) the runc-ee package
        version is not pinned and is installed from a constantly updated repository. Because
        of that, lcm-ansible fails on the 'containerd : Install containerd.io packages' task
        while upgrading such clusters to MOSK 26.1.x (Cluster releases 21.1.x) patch releases
        or MOSK 26.2 (Cluster release 21.2.0):

            E: Packages were downgraded and -y was used without --allow-downgrades.

        WA: install the pinned version of runc-ee and hold the package on every node.
        """
        if not self.cluster.workaround.cluster_with_unpinned_runc_ee():
            LOG.info(f"Skip runc-ee WA for cluster: {self.cluster.name} because it has version: "
                     f"{self.cluster.clusterrelease_version}. Only clusters deployed with "
                     f"Cluster release 21.1.0 (MOSK 26.1) are affected")
            return

        pinned_version = '1.4.2m1-0ubuntu0.24.04.1'

        wa_cmd = (f"apt-get --allow-downgrades install runc-ee={pinned_version} -y "
                  f"--allow-change-held-packages && apt-mark hold runc-ee")

        for machine in self.cluster.get_machines():
            if machine.is_disabled():
                LOG.warning(f"Skip runc-ee WA on the machine {machine.name}: it is disabled")
                continue

            LOG.info(f"Installing and holding runc-ee={pinned_version} on the machine {machine.name}")
            machine.run_cmd(f"sudo bash -c '{wa_cmd}'", timeout=900)

            installed = machine.run_cmd("dpkg-query -W runc-ee").stdout_str
            held = machine.run_cmd("apt-mark showhold").stdout_str
            assert pinned_version in installed, \
                (f"Machine {machine.name}: runc-ee {pinned_version} is not installed after the WA. "
                 f"'dpkg-query -W runc-ee' returned: {installed}")
            assert 'runc-ee' in held.split(), \
                (f"Machine {machine.name}: runc-ee package is not held after the WA. "
                 f"'apt-mark showhold' returned: {held}")

    # === Final Checks ===
    def final_checks(self):
        """
        Run all final validation checks after cluster is up.
        Includes:
          - HostOSConfiguration Day2 state
          - BMH inventory
        """

        LOG.info("Running final validation checks")
        # === 1. BMH inventory presence ===
        LOG.info("Checking BMH inventory presence")
        self.cluster.check.check_bmh_inventory_presense()

        # === 2. HostOSConfiguration Day2 checks ===
        for hoc_raw in self.child_data.get('hostosconfiguration_raw', []):
            name = hoc_raw['metadata']['name']
            LOG.info("Validating HostOSConfiguration: %s", name)
            obj = self.cluster.namespace.get_hostosconfiguration(name)
            self.cluster.check.wait_lcmmachine_day2_stateitems(obj, [])
            self.cluster.check.get_hostosconfig_machines_status(obj)

        LOG.info("All final checks passed")

    def wait_for_ceph_readiness(self, ceph_cluster_pools: Optional[List[dict]]):
        if not settings.MOSK_CHILD_DEPLOY_CEPH:
            return

        LOG.info("Waiting for Ceph storage readiness")

        if self.cluster.workaround.child_with_cephdeployment():
            self.cluster.check.wait_cephdeploymenthealth_state(timeout=4000)
        else:
            self.cluster.check.wait_miracephhealth_state(timeout=4000)

        self.cluster.check.wait_default_storage(
            ceph_cluster_pools=ceph_cluster_pools,
            timeout=1200
        )

        if self.cluster.is_sl_enabled():
            self.cluster.check.wait_for_release_in_bundle(name="stacklight")

        self.cluster.check.check_actual_expected_pods(interval=30)
        self.cluster.check.check_ceph_pvc()

    def check_cluster_readeness(self):
        self.cluster.check.check_cluster_readiness(timeout=3600, interval=90)
        self.cluster.check.check_diagnostic_cluster_status()

        # Check helmbundles after ceph cluster deployed (e.g. Stacklight)
        self.cluster.check.check_helmbundles()
        self.cluster.check.check_deploy_stage_success()

        # Check/wait for correct docker service replicas in cluster
        if self.cluster.lcm_type_is_ucp:
            self.cluster.check.check_actual_expected_docker_services()
        # Check/wait for correct pods statuses in child cluster
        self.cluster.check.check_k8s_pods()
        self.cluster.check.check_actual_expected_pods(interval=30, check_all_nss=True)
        self.cluster.check.check_actual_expected_kernel_versions()
        self.cluster.check.check_overlay_encryption_functionality()
        self.cluster.check.check_k8s_profiling_settings()
        if not settings.DEPLOY_AUDITD_VIA_HOC:
            self.cluster.check.check_audit()
            if self.cluster.workaround.check_auditd_managed_field_value_child():
                self.cluster.check.check_audit_managed_value(expected_value=True)
        self.cluster.check.check_custom_hostnames_on_machines()
        self.cluster.check.check_actual_expected_distribution()
        if settings.DESIRED_RUNTIME:
            self.cluster.check.compare_cluster_runtime_with_desired()

    def apply_ptrace_mitigation(self):
        """
        Apply CVE-2026-46333 mitigation on all cluster nodes.

        Mitigation:
            kernel.yama.ptrace_scope=2
        """
        LOG.info("Applying ptrace mitigation on all cluster nodes")
        machines = self.cluster.get_machines_uncached()

        mitigation_cmd = (
            'echo "kernel.yama.ptrace_scope=2" '
            '> /etc/sysctl.d/ptrace-restrict.conf && '
            'sysctl --system'
        )

        for machine in machines:
            LOG.info(
                f"Applying ptrace mitigation on machine {machine.name}"
                )

            machine.run_cmd(
                f"sudo bash -c '{mitigation_cmd}'",
                timeout=300
            )

        waiters.wait(
            self.check_ptrace_mitigation_applied,
            timeout=300,
            interval=10,
            timeout_msg="ptrace mitigation was not applied on all machines"
        )

    def check_ptrace_mitigation_applied(self) -> bool:
        """
        Verify CVE-2026-46333 mitigation is applied on all nodes.

        Expected:
            kernel.yama.ptrace_scope = 2
        """

        machines = self.cluster.get_machines_uncached()
        machines_ptrace_map = {}

        for machine in machines:

            cmd = "sysctl kernel.yama.ptrace_scope"

            try:
                result = machine.run_cmd(cmd, verbose=False)
                output = result.stdout_str.strip()

                if "kernel.yama.ptrace_scope = 2" in output:
                    machines_ptrace_map[machine.name] = 2
                else:
                    machines_ptrace_map[machine.name] = output

            except Exception as e:
                LOG.warning(
                    f"Failed to check ptrace_scope on machine {machine.name}: {e}"
                )
                machines_ptrace_map[machine.name] = None

        is_applied = all(v == 2 for v in machines_ptrace_map.values())

        if not is_applied:
            LOG.warning(
                "ptrace mitigation is not fully applied. "
                "Expected value '2' on all machines, got:\n%s",
                yaml.dump(machines_ptrace_map)
            )

        return is_applied

    def check_unprivileged_ptrace_blocked(self) -> bool:
        """Verify unprivileged ptrace is blocked on all cluster nodes."""
        return security_checks.check_unprivileged_ptrace_blocked(self.cluster)

    def check_broken_fixed_ipamhosts(self):
        """This check should verify L2Template re-generation functionality for IpamHost objects.
        Users should expect that if they configured f.e. Subnets in a wrong manner and then
        fixed them, L2Template will be fixed too, and a new, correct Netplan config will be set up on
        affected machines
        """
        self._verify_broken_fixed_ipamhosts(self.ns, self.cluster)

    def _verify_broken_fixed_ipamhosts(self, ns, cluster):
        """Verify IpamHost ERR -> OK transition after fixing subnet label. """

        def _all_ipamhosts_exist() -> bool:
            machine_names = {m.name for m in cluster.get_machines()}
            ipamhost_names = {ih.name for ih in ns.get_ipam_hosts()}
            return machine_names == ipamhost_names

        def _check_state(ipamhosts, desired: str) -> bool:
            ipamhosts_with_wrong_state = [ih.name for ih in ipamhosts
                                          if ih.data.get('status', {}).get('state') != desired]
            if ipamhosts_with_wrong_state:
                LOG.info(f"_check_ipamhosts_state: ipamhosts that do not have desired state "
                         f"'{desired}': {ipamhosts_with_wrong_state}")
                return False
            return True

        broken_subnets = [s for s in ns.get_ipam_subnets()
                          if settings.KAAS_BM_TEST_BROKEN_FIXED_IPAMHOSTS_SUBNET_LABEL in
                          s.data.get('metadata', {}).get('labels', {}).keys()]
        assert len(broken_subnets) == 1, \
            ("We expect to have one and only one intentionally broken subnet labelled "
             f"with '{settings.KAAS_BM_TEST_BROKEN_FIXED_IPAMHOSTS_SUBNET_LABEL} "
             f"but the following subnets have been detected: '{[s.name for s in broken_subnets]}'")
        broken_subnet = broken_subnets[0]

        # Wait for IpamHost creation
        LOG.info("Check that IpamHost objects have been created for all existing machines")
        waiters.wait(
            _all_ipamhosts_exist,
            timeout=300, interval=10,
            timeout_msg="Not all machines have a corresponding ipamhost object created"
        )

        LOG.info("Check that IpamHost objects are in error state due to missed label for k8s-lcm subnet")
        ipamhosts = ns.get_ipam_hosts()
        ipamhost_brake_timeout_msg = ("Not all ipamhost objects have 'ERR' state (they should because there is "
                                      f"no label 'ipam/SVC-k8s-lcm' set for subnet {broken_subnet.name}")
        waiters.wait(
            lambda: _check_state(ipamhosts, 'ERR'),
            timeout=300, interval=10,
            timeout_msg=ipamhost_brake_timeout_msg
        )

        LOG.info(f"Patching subnet {broken_subnet.name} with label 'ipam/SVC-k8s-lcm'")
        broken_subnet.patch({'metadata': {'labels': {'ipam/SVC-k8s-lcm': 'enabled'}}})
        LOG.info("Wait till all ipamhosts update their state to 'OK'")
        ipamhost_repair_timeout_msg = ("Not all ipamhost objects have 'OK' state after adding label 'ipam/SVC-k8s-lcm' "
                                       f"to subnet {broken_subnet.name}")
        waiters.wait(
            lambda: _check_state(ipamhosts, 'OK'),
            timeout=300, interval=10,
            timeout_msg=ipamhost_repair_timeout_msg
        )
