# Copyright 2026 Mirantis, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License"); you may
# not use this file except in compliance with the License. You may obtain
# a copy of the License at
#
#      http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
# WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
# License for the specific language governing permissions and limitations
# under the License.

import random

import pytest

from si_tests.managers.support_dumps_manager import SupportDumpManager
from si_tests.fixtures.mcc_supportdump import check_supportdump_dump_in_pod, check_systemlogs_filtered_by_machine
from si_tests import logger, settings
from si_tests.utils import packaging_version as version

LOG = logger.logger


@pytest.mark.parametrize("_", [f"CLUSTER_NAME={settings.TARGET_CLUSTER}"])
@pytest.mark.usefixtures("supportdump_copy_from_pod")
@pytest.mark.usefixtures("supportdump_cleanup")
def test_create_supportdump(kaas_manager, _, show_step):
    """Verify lifecycle of a SupportDump.

    Scenario:
        1. Create a SupportDump for TARGET_CLUSTER
        2. Verify every collector reports the expected status
        3. Wait until the SupportDump CR reports the expected status
        4. Verify dump exists in supportdump-controller pod

    Postconditions:
        - Copy collected supportdump from pod to artifacts, if the test passed (optional)
        - Cleanup supportdump resources and data (optional)
    """

    cluster_namespace = settings.TARGET_NAMESPACE
    cluster_name = settings.TARGET_CLUSTER
    ns = kaas_manager.get_namespace(cluster_namespace)
    cluster = ns.get_cluster(cluster_name)

    if version.parse(kaas_manager.get_mgmt_cluster().get_kaasrelease_version()) < version.parse("kaas-2-32-0-rc"):
        pytest.skip(f"SupportDump is not supported on {kaas_manager.get_mgmt_cluster().get_kaasrelease_version()}")

    sd_manager = SupportDumpManager(cluster)
    sd_name = sd_manager.supportdump_name

    show_step(1)
    sd_manager.create_supportdump(sd_name)

    show_step(2)
    sd_manager.wait_supportdumps_collectors_status(sd_name)

    show_step(3)
    sd_manager.wait_supportdumps_status(sd_name)

    show_step(4)
    sd = sd_manager.get_supportdumps(name=sd_name)
    check_supportdump_dump_in_pod(kaas_manager, sd)


@pytest.mark.parametrize("_", [f"CLUSTER_NAME={settings.TARGET_CLUSTER}"])
@pytest.mark.usefixtures("supportdump_copy_from_pod")
@pytest.mark.usefixtures("supportdump_cleanup")
def test_create_supportdump_filtered_by_machine_name(kaas_manager, _, show_step):
    """Verify the systemLogs collector can be filtered down to a single machine by name.

    Scenario:
        1. Select one random machine from the target cluster's Machine CRs
        2. Create a SupportDump with a systemLogs collector filtered by that machine's name
        3. Verify every collector reports the expected status
        4. Wait until the SupportDump CR reports the expected status
        5. Verify dump exists in supportdump-controller pod
        6. Verify the collected systemLogs only contain data for the selected machine

    Postconditions:
        - Copy collected supportdump from pod to artifacts, if the test passed (optional)
        - Cleanup supportdump resources and data (optional)
    """

    cluster_namespace = settings.TARGET_NAMESPACE
    cluster_name = settings.TARGET_CLUSTER
    ns = kaas_manager.get_namespace(cluster_namespace)
    cluster = ns.get_cluster(cluster_name)

    if version.parse(kaas_manager.get_mgmt_cluster().get_kaasrelease_version()) < version.parse("kaas-2-32-0-rc"):
        pytest.skip(f"SupportDump is not supported on {kaas_manager.get_mgmt_cluster().get_kaasrelease_version()}")

    sd_manager = SupportDumpManager(cluster)
    sd_name = sd_manager.supportdump_name

    show_step(1)
    machines = cluster.get_machines()
    all_machine_names = [m.name for m in machines]
    target_machine = random.choice(machines)
    other_machine_names = [name for name in all_machine_names if name != target_machine.name]
    LOG.info(f"Selected machine '{target_machine.name}' out of {all_machine_names}")

    show_step(2)
    spec = {
        'targetCluster': cluster_name,
        'overallTimeout': settings.MCC_SUPPORTDUMP_COLLECT_TIMEOUT,
        'collectors': [{'systemLogs': {'machineNames': [target_machine.name]}}],
    }
    sd_manager.create_supportdump(sd_name, spec)

    show_step(3)
    sd_manager.wait_supportdumps_collectors_status(sd_name)

    show_step(4)
    sd_manager.wait_supportdumps_status(sd_name)

    show_step(5)
    sd = sd_manager.get_supportdumps(name=sd_name)
    dump_path = check_supportdump_dump_in_pod(kaas_manager, sd)

    show_step(6)
    check_systemlogs_filtered_by_machine(kaas_manager, sd, dump_path, [target_machine.name], other_machine_names)


@pytest.mark.parametrize("_", [f"CLUSTER_NAME={settings.TARGET_CLUSTER}"])
@pytest.mark.usefixtures("supportdump_copy_from_pod")
@pytest.mark.usefixtures("supportdump_cleanup")
def test_create_supportdump_filtered_by_machine_label(kaas_manager, _, show_step):
    """Verify the systemLogs collector can be filtered down to machines by a node label.

    Scenario:
        1. Find machines that already have the "openstack-compute-node: enabled" label
           (present on compute nodes of some clusters); skip if none is found
        2. Create a SupportDump with a systemLogs collector filtered by that label
        3. Verify every collector reports the expected status
        4. Wait until the SupportDump CR reports the expected status
        5. Verify dump exists in supportdump-controller pod
        6. Verify the collected systemLogs only contain data for the labeled machine(s)

    Postconditions:
        - Copy collected supportdump from pod to artifacts, if the test passed (optional)
        - Cleanup supportdump resources and data (optional)
    """

    cluster_namespace = settings.TARGET_NAMESPACE
    cluster_name = settings.TARGET_CLUSTER
    ns = kaas_manager.get_namespace(cluster_namespace)
    cluster = ns.get_cluster(cluster_name)

    if version.parse(kaas_manager.get_mgmt_cluster().get_kaasrelease_version()) < version.parse("kaas-2-32-0-rc"):
        pytest.skip(f"SupportDump is not supported on {kaas_manager.get_mgmt_cluster().get_kaasrelease_version()}")

    sd_manager = SupportDumpManager(cluster)
    sd_name = sd_manager.supportdump_name
    label_key, label_value = "openstack-compute-node", "enabled"

    show_step(1)
    machines = cluster.get_machines()
    all_machine_names = [m.name for m in machines]
    machines_by_label = [m for m in machines if m.k8snodelabels.get(label_key) == label_value]
    if not machines_by_label:
        pytest.skip(f"No machine with label '{label_key}: {label_value}' found in cluster {cluster_name}, "
                    f"skipping systemLogs nodeLabels filter check")
    labeled_machine_names = [m.name for m in machines_by_label]
    other_machine_names = [name for name in all_machine_names if name not in labeled_machine_names]
    LOG.info(f"Selected machine(s) {labeled_machine_names} with label '{label_key}: {label_value}', "
             f"out of {all_machine_names}")

    show_step(2)
    spec = {
        'targetCluster': cluster_name,
        'overallTimeout': settings.MCC_SUPPORTDUMP_COLLECT_TIMEOUT,
        'collectors': [{'systemLogs': {'nodeLabels': {label_key: label_value}}}],
    }
    sd_manager.create_supportdump(sd_name, spec)

    show_step(3)
    sd_manager.wait_supportdumps_collectors_status(sd_name)

    show_step(4)
    sd_manager.wait_supportdumps_status(sd_name)

    show_step(5)
    sd = sd_manager.get_supportdumps(name=sd_name)
    dump_path = check_supportdump_dump_in_pod(kaas_manager, sd)

    show_step(6)
    check_systemlogs_filtered_by_machine(kaas_manager, sd, dump_path, labeled_machine_names, other_machine_names)
