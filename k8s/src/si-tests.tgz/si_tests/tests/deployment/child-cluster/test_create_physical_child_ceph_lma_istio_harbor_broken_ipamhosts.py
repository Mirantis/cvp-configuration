
import pytest
from si_tests.tests.deployment.base_test_create_bm_child import KaasBaremetalChildTestBase
from si_tests import settings


@pytest.mark.usefixtures('log_step_time', 'log_method_time')
@pytest.mark.parametrize("_", [f"CLUSTER_NAME={settings.TARGET_CLUSTER}"])
@pytest.mark.usefixtures("store_cluster_description", 'introspect_child_target_objects',
                         'introspect_no_PRODX_51933_after_lcm')
def test_kaas_create_baremetal_child_lma_istio_broken_ipamhosts(kaas_manager, proxy_manager, show_step, _):
    """Deploy child cluster on top of management cluster.
        Scenario:
            1. Collecting env data
            2. Creating namespace
            3. Creating public key
            4. Create cluster l2 templates, subnets
            5. Creating secret for each BMH profile, BMH profiles
            6. Create BM machine
            7. Check that intentionally broken ipamhosts became fixed after adding
               a missed label 'ipam/SVC-k8s-lcm' to LCM subnet (optional)
            8. Wait BM hosts to be provisioned
            9. Waiting for machines are Ready and helmbundles are deployed
            10. Install DPDK driver on compute (optional)
            11. Create Ceph cluster
            12. Enable tf monitoring (optional)
            13. Apply osdpl overrides
            14. Collect and store k8s artifacts
            15. Waiting for KaaSCephCluster Ready
            16. Check cluster readiness
            17. Check offline isolation (optional)
            18. Check etcd quota (optional)
            19. Run final checks
        """

    test = KaasBaremetalChildTestBase(kaas_manager, proxy_manager)
    show_step(1)
    test.collect_env_data()
    show_step(2)
    test.create_namespace()
    show_step(3)
    test.create_public_key()
    show_step(4)
    test.create_cluster_subnets_l2_bmh()
    show_step(5)
    test.create_bmh_profiles()

    helm_releases = [{"name": h.strip()} for h in settings.KAAS_CHILD_CLUSTER_EXTRA_HELM_RELEASES]
    helm_releases.extend(settings.KAAS_CHILD_CLUSTER_EXTRA_HELM_RELEASES_JSON or [])
    show_step(6)
    machines, day1_mode = test.create_cluster_and_machines(helm_releases)
    show_step(7)
    test.check_broken_fixed_ipamhosts()
    show_step(8)
    test.wait_provisioning(machines, day1_mode)
    show_step(9)
    test.wait_deployment(machines, day1_mode)
    show_step(10)
    test.install_dpdk()
    # No network check in this path
    show_step(11)
    ceph_pools = test.deploy_ceph()
    show_step(12)
    test.enable_tf_monitoring()
    show_step(13)
    test.add_osdpl_overrides()
    show_step(14)
    test.store_k8s_artifacts()
    if ceph_pools:
        show_step(15)
        test.wait_for_ceph_readiness(ceph_pools)
    show_step(16)
    test.check_cluster_readeness()
    show_step(17)
    test.check_offline_isolation()
    show_step(18)
    test.check_storage_etcd_quota()
    show_step(19)
    test.final_checks()
