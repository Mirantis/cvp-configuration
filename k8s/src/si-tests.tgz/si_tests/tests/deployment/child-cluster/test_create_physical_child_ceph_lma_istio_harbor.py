import pytest
from si_tests.tests.deployment.base_test_create_bm_child import KaasBaremetalChildTestBase
from si_tests import settings


@pytest.mark.usefixtures('log_step_time', 'log_method_time')
@pytest.mark.parametrize("_", [f"CLUSTER_NAME={settings.TARGET_CLUSTER}"])
@pytest.mark.usefixtures("store_cluster_description", 'introspect_child_target_objects',
                         'introspect_no_PRODX_51933_after_lcm')
def test_kaas_create_baremetal_child_lma_istio(kaas_manager, proxy_manager, show_step, _):
    """Deploy child cluster on top of management cluster.

       Scenario:
           1. Collecting env data
           2. Creating namespace
           3. Create cluster l2 templates, subnets
           4. Creating public key
           5. Creating secret for each BMH profile, create BMH profiles
           6. Create BM machine
           7. Wait BM hosts to be provisioned
           8. Waiting for machines are Ready and helmbundles are deployed
           9. Install DPDK driver on compute (optional)
           10. Check networks
           11. Create Ceph cluster
           12. Enable tf monitoring (optional)
           13. Apply osdpl overrides
           14. Collect and store k8s artifacts
           15. Waiting for KaaSCephCluster Ready
           16. Check cluster readiness
           17. Apply and validate CVE-2026-46333 mitigation
           18. Check offline isolation (optional)
           19. Check etcd quota (optional)
           20. Check ceph monitor IPs applied correctly (optional)
           21. Deploy AUDITD via HOC (optional)
           22. Run final checks
           23. Apply WA with runc-ee to all nodes

       """
    test = KaasBaremetalChildTestBase(kaas_manager, proxy_manager)
    show_step(1)
    test.collect_env_data()
    show_step(2)
    test.create_namespace()
    show_step(3)
    test.create_cluster_subnets_l2_bmh()
    show_step(4)
    test.create_public_key()
    show_step(5)
    test.create_bmh_profiles()
    helm_releases = [{"name": h.strip()} for h in settings.KAAS_CHILD_CLUSTER_EXTRA_HELM_RELEASES]
    helm_releases.extend(settings.KAAS_CHILD_CLUSTER_EXTRA_HELM_RELEASES_JSON or [])
    show_step(6)
    machines, day1_mode = test.create_cluster_and_machines(helm_releases)
    show_step(7)
    test.wait_provisioning(machines, day1_mode)
    show_step(8)
    test.wait_deployment(machines, day1_mode)
    show_step(9)
    test.install_dpdk()
    show_step(10)
    test.check_network()
    show_step(11)
    ceph_pools = test.deploy_ceph()
    show_step(12)
    test.enable_tf_monitoring()
    show_step(13)
    test.add_osdpl_overrides()
    show_step(14)
    test.store_k8s_artifacts()
    if ceph_pools:
        show_step(15)
        test.wait_for_ceph_readiness(ceph_pools)
    show_step(16)
    test.check_cluster_readeness()
    # =========================
    # CVE-2026-46333 validation
    # =========================
    show_step(17)
    if settings.CVE_CHECK_ENABLED:
        test.apply_ptrace_mitigation()
        assert test.check_unprivileged_ptrace_blocked(), \
            "Unprivileged ptrace is still allowed after mitigation"
        test.check_cluster_readeness()
    show_step(18)
    test.check_offline_isolation()
    show_step(19)
    test.check_storage_etcd_quota()
    show_step(20)
    test.check_ceph_monitor_ips_as_expected()
    show_step(21)
    test.deploy_auditd_hoc()
    show_step(22)
    test.final_checks()
    show_step(23)
    test.apply_wa_runc()
