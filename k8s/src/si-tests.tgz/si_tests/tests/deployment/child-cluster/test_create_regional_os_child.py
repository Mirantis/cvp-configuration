import base64

import pytest
import yaml

from si_tests import settings
from si_tests import logger
from si_tests.utils import templates
from si_tests.utils import utils

LOG = logger.logger


@pytest.mark.usefixtures('log_step_time')
@pytest.mark.usefixtures('log_method_time')
@pytest.mark.parametrize("_", ["CLUSTER_NAME={0}"
                         .format(settings.KAAS_CHILD_CLUSTER_NAME)])
@pytest.mark.usefixtures("store_cluster_description")
@pytest.mark.usefixtures('introspect_child_deploy_objects')
def test_kaas_create_os_regional_child(kaas_manager, check_sg,
                                       proxy_manager, show_step, openstack_client, _):
    """Deploy child cluster on top of OS regional cluster.

    Scenario:
        1. Collecting env data
        2. Creating namespace
        3. Creating public key
        4. Creating OS credential
        5. Set proxy
        6. Configure bastion (optional)
        7. Create child cluster and machines with SL label
        8. Check cluster readiness
        9. Pod checks (optional)
        10. Check offline isolation (optional)
        11. Check bastion VM (optional)

    """

    # Collecting env data
    show_step(1)
    cluster_name = settings.KAAS_CHILD_CLUSTER_NAME
    namespace_name = settings.KAAS_NAMESPACE
    release_name = settings.KAAS_CHILD_CLUSTER_RELEASE_NAME
    external_network = settings.KAAS_EXTERNAL_NETWORK_ID
    LOG.info("Available releases: {}".format(
        kaas_manager.get_clusterrelease_names()))
    assert release_name in kaas_manager.get_clusterrelease_names()
    child_dns = settings.KAAS_CHILD_CLUSTER_DNS
    machine_image_names = settings.KAAS_CHILD_CLUSTER_MACHINE_IMAGE_NAME.split(',')
    machine_flavor_name = settings.KAAS_CHILD_CLUSTER_MACHINE_FLAVOR_NAME
    machine_az_name = settings.KAAS_CHILD_CLUSTER_AZ_NAME
    slave_nodes_count = int(settings.KAAS_CHILD_CLUSTER_SLAVE_NODES_COUNT)
    master_nodes_count = int(settings.KAAS_CHILD_CLUSTER_MASTER_NODES_COUNT)
    region = kaas_manager.get_mgmt_cluster().region_name
    rnd_string = utils.gen_random_string(6)

    # Creating namespace
    show_step(2)
    LOG.info("Namespace name - %s", namespace_name)
    ns = kaas_manager.get_or_create_namespace(namespace_name)

    # Creating public key
    show_step(3)
    public_key_name = "{cluster_name}-{rnd_string}-key".format(
        cluster_name=cluster_name, rnd_string=rnd_string)
    LOG.info("Public key name - {public_key_name}".format(
        public_key_name=public_key_name))
    with open(settings.KAAS_CHILD_CLUSTER_PUBLIC_KEY_FILE) as pub_key:
        pub_key_content = pub_key.read()
    ns.create_publickey(public_key_name, pub_key_content)

    # Creating openstack credentials
    show_step(4)
    credential_name = "{cluster_name}-{rnd_string}-cred".format(
        cluster_name=cluster_name, rnd_string=rnd_string)
    LOG.info("Credential name - {credential_name}".format(
        credential_name=credential_name))
    clouds_yaml_str = templates.render_template(settings.CLOUDS_YAML_PATH)
    ns.create_openstack_credential(name=credential_name,
                                   clouds_yaml_str=clouds_yaml_str,
                                   region=region)
    ns.wait_openstack_resources_available(credential_name)

    helm_releases = []
    for hrelease in settings.KAAS_CHILD_CLUSTER_EXTRA_HELM_RELEASES:
        helm_releases.append({"name": hrelease})

    if ((settings.KAAS_EXTERNAL_PROXY_ACCESS_STR or
         settings.KAAS_INSTALL_FAKE_PROXY) and
            not settings.KAAS_OFFLINE_DEPLOYMENT):
        LOG.error("Proxy variables is set but KAAS_OFFLINE_DEPLOYMENT "
                  "is False.Using Proxy on online deployments makes no sense.")
        raise RuntimeError("Proxy variables is set but KAAS_OFFLINE_DEPLOYMENT"
                           " is False")

    if settings.KAAS_OFFLINE_DEPLOYMENT:
        offline_security_group = [check_sg['name']]
        LOG.info('Offline deployment is enabled. External network will be '
                 'restricted on child cluster nodes. Using '
                 'security group: {0}'.format(
                     [check_sg['name']]))
    else:
        offline_security_group = None

    show_step(5)
    if settings.KAAS_EXTERNAL_PROXY_ACCESS_STR:
        LOG.info("Found KAAS_EXTERNAL_PROXY_ACCESS_STR. Creating "
                 f"proxyobject with proxy {settings.KAAS_EXTERNAL_PROXY_ACCESS_STR}")
        if settings.KAAS_SSL_PROXY_CERTIFICATE_FILE:
            with open(settings.KAAS_SSL_PROXY_CERTIFICATE_FILE, 'r') as f:
                proxy_cert_content = base64.b64encode(f.read().encode("utf-8")).decode()
                LOG.info("Using proxy with custom certificate")
        else:
            proxy_cert_content = None
        proxy_access_str = settings.KAAS_EXTERNAL_PROXY_ACCESS_STR
        proxy_object = ns.create_proxyobject(
            name=f"{cluster_name}-{settings.KAAS_PROXYOBJECT_NAME}",
            region=region,
            proxy_str=proxy_access_str,
            ca_cert=proxy_cert_content)
        proxy_object_name = proxy_object.data['metadata']['name']
    elif settings.KAAS_INSTALL_FAKE_PROXY:
        LOG.info("Variable KAAS_EXTERNAL_PROXY_ACCESS_STR is not set but"
                 "KAAS_INSTALL_FAKE_PROXY is enabled. Fake squid proxy will "
                 "be installed on management cluster to use it in child.")
        proxy_manager.deploy_proxy_sts()
        proxy_manager.deploy_proxy_svc()
        proxy_access_str = proxy_manager.generate_proxy_string()
        proxy_manager.check_proxy_conn()
        proxy_object = ns.create_proxyobject(
            name=f"{cluster_name}-{settings.KAAS_PROXYOBJECT_NAME}",
            region=region,
            proxy_str=proxy_access_str)
        proxy_object_name = proxy_object.data['metadata']['name']
    else:
        proxy_object_name = None

    show_step(6)
    if settings.KAAS_BASTION_CONFIG:
        bastion = settings.KAAS_BASTION_OS_CONFIG
        LOG.info("Use custom bastion config:\n{0}".format(yaml.dump(bastion)))
    else:
        LOG.info("Deploy child cluster without additional bastion config")
        bastion = None

    show_step(7)
    cluster = ns.create_cluster(
        cluster_name,
        release_name,
        credential_name,
        external_network_id=external_network,
        region=region,
        provider="openstack",
        services_cidr="10.96.0.0/16",
        pods_cidr="192.168.0.0/16",
        nodes_cidr="10.10.10.0/24",
        dns=child_dns,
        extra_helm_releases=helm_releases,
        lma_enabled=settings.KAAS_CHILD_CLUSTER_DEPLOY_LMA,
        public_key_name=public_key_name,
        proxy_name=proxy_object_name,
        secure_overlay=settings.KAAS_CHILD_CLUSTER_SECURE_OVERLAY_ENABLED,
        bastion=bastion)

    # Check or set customHostnamesEnabled flag in Cluster object to match settings.CUSTOM_HOSTNAMES
    cluster.set_custom_hostnames_enabled(flag=settings.CUSTOM_HOSTNAMES)

    labels = \
        [{'key': k, 'value': v} for k, v in
         cluster.get_allowed_node_labels().items()]
    stacklight_nodes_count = \
        3 if slave_nodes_count >= 3 else slave_nodes_count

    for n in range(master_nodes_count):
        cluster.create_os_machine(
            node_type="master",
            region=region,
            node_flavor=machine_flavor_name,
            node_image=machine_image_names[n % len(machine_image_names)],
            node_az=machine_az_name,
            node_sg=offline_security_group)

    # create stacklight related nodes first to match SL labels
    for n in range(stacklight_nodes_count):
        cluster.create_os_machine(
            node_type="node",
            region=region,
            node_flavor=machine_flavor_name,
            node_image=machine_image_names[n % len(machine_image_names)],
            node_az=machine_az_name,
            node_labels=labels,
            node_sg=offline_security_group)

    slave_nodes_count -= stacklight_nodes_count

    for n in range(slave_nodes_count):
        cluster.create_os_machine(
            node_type="node",
            region=region,
            node_flavor=machine_flavor_name,
            node_image=machine_image_names[n % len(machine_image_names)],
            node_az=machine_az_name,
            node_sg=offline_security_group)

    # Waiting for machines are Ready and helmbundles are deployed
    cluster.check.check_machines_status()
    cluster.check.check_cluster_nodes()

    machines = [
        x for x in cluster.get_machines(machine_type="worker")
        if 'nodeLabels' in x.spec['providerSpec']['value'].keys() and
           labels == x.nodeLabels
    ]
    assert len(machines) == stacklight_nodes_count, \
        "Not all machines have expected nodeLabels"

    for machine in machines:
        machine.check_k8s_nodes_has_labels()

    cluster.check.check_k8s_nodes()

    show_step(8)
    cluster.check.check_cluster_readiness()
    cluster.check.check_deploy_stage_success()
    cluster.check.check_helmbundles()

    # Collecting artifacts
    cluster.store_k8s_artifacts()

    # Check that Machines hostnames are created with respect to Cluster flag 'customHostnamesEnabled'
    cluster.check.check_custom_hostnames_on_machines()

    show_step(9)
    if settings.RUN_POD_CHECKS:
        cluster.check.check_k8s_pods()
        cluster.check.check_actual_expected_docker_services()
        cluster.check.check_actual_expected_pods(timeout=3200, interval=30,
                                                 check_all_nss=True)
    cluster.check.check_overlay_encryption_functionality()
    cluster.provider_resources.save_artifact()

    show_step(10)
    if settings.KAAS_OFFLINE_DEPLOYMENT:
        cluster.check.check_offline_isolation(
            settings.KAAS_EXTERNAL_PROXY_ACCESS_STR)

    show_step(11)
    if bastion:
        LOG.info(f"New bastion IP = {cluster.bastion_ip} for cluster {cluster.name}")
        LOG.info("Check ssh to KaaS machine vie bastion VM")
        machines = cluster.get_machines()
        target_machine = machines[0]
        cluster.check.check_connection_via_bastion(target_machine)
        LOG.info("Check bastion parameters VM in OpenStack")
        cluster_status = cluster.data.get('status') or {}
        vm_id = cluster_status.get('providerStatus', {}).get('bastion', {}).get('serverUUID')
        cluster.check.check_os_vm(openstack_client=openstack_client,
                                  vm_id=vm_id,
                                  image=bastion['image'],
                                  flavor=bastion['flavor'],
                                  az_name=bastion['availabilityZone'],
                                  metadata=bastion['serverMetadata'],
                                  boot_from_volume=bastion['bootFromVolume']['enabled'],
                                  volume_size=bastion['bootFromVolume']['volumeSize'])
    else:
        LOG.info("Current cluster does not have own bastion node")
