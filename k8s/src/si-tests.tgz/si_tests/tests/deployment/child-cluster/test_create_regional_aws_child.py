import pytest
import yaml

from si_tests import settings
from si_tests import logger
from si_tests.utils import utils

LOG = logger.logger


@pytest.mark.usefixtures('log_step_time')
@pytest.mark.usefixtures('log_method_time')
@pytest.mark.parametrize("_", ["CLUSTER_NAME={0}"
                               .format(settings.KAAS_CHILD_CLUSTER_NAME)])
@pytest.mark.usefixtures("store_cluster_description")
@pytest.mark.usefixtures('introspect_child_deploy_objects')
def test_kaas_create_aws_regional_child(kaas_manager, proxy_manager, show_step, _):
    """Deploy AWS child cluster on top of AWS regional cluster.

    Scenario:
        1. Collecting env data
        2. Creating namespace
        3. Creating public key
        4. Creating AWS credential
        5. Set proxy
        6. Configure bastion (optional)
        7. Create child cluster
        8. Check cluster readiness
        9. Pod checks (optional)
        10. Check offline isolation (optional)
        11. Check bastion VM (optional)

    """

    # Collecting env data
    show_step(1)
    cluster_name = settings.KAAS_CHILD_CLUSTER_NAME
    namespace_name = settings.KAAS_NAMESPACE
    release_name = settings.KAAS_CHILD_CLUSTER_RELEASE_NAME
    LOG.info("Available releases: {}".format(
        kaas_manager.get_clusterrelease_names()))
    assert release_name in kaas_manager.get_clusterrelease_names()
    child_dns = settings.KAAS_CHILD_CLUSTER_DNS
    ami = settings.KAAS_CHILD_CLUSTER_MACHINE_IMAGE_NAME
    instance_type = settings.KAAS_CHILD_CLUSTER_MACHINE_FLAVOR_NAME
    slave_nodes_count = int(settings.KAAS_CHILD_CLUSTER_SLAVE_NODES_COUNT)
    master_nodes_count = int(settings.KAAS_CHILD_CLUSTER_MASTER_NODES_COUNT)
    region = kaas_manager.get_mgmt_cluster().region_name
    rnd_string = utils.gen_random_string(6)

    # Creating namespace
    show_step(2)
    LOG.info("Namespace name - %s", namespace_name)
    ns = kaas_manager.get_or_create_namespace(namespace_name)

    # Creating public key
    show_step(3)
    public_key_name = "{cluster_name}-{rnd_string}-key".format(
        cluster_name=cluster_name, rnd_string=rnd_string)
    LOG.info("Public key name - {public_key_name}".format(
        public_key_name=public_key_name))
    with open(settings.KAAS_CHILD_CLUSTER_PUBLIC_KEY_FILE) as pub_key:
        pub_key_content = pub_key.read()
    ns.create_publickey(public_key_name, pub_key_content)

    # Get aws bootstrap credentials from management cluster
    aws_key_id, aws_secret_access_key = kaas_manager.get_aws_credential(
        "cloud-config", "default")

    # Creating aws credential
    show_step(4)
    credential_name = "{cluster_name}-{rnd_string}-cred".format(
        cluster_name=cluster_name, rnd_string=rnd_string)
    LOG.info("Credential name - {credential_name}".format(
        credential_name=credential_name))
    ns.create_aws_credential(
        credential_name, aws_key_id,
        aws_secret_access_key, region=region)

    helm_releases = []
    for hrelease in settings.KAAS_CHILD_CLUSTER_EXTRA_HELM_RELEASES:
        helm_releases.append({"name": hrelease})

    if ((settings.KAAS_EXTERNAL_PROXY_ACCESS_STR or
         settings.KAAS_INSTALL_FAKE_PROXY) and
            not settings.KAAS_OFFLINE_DEPLOYMENT):
        LOG.error("Proxy variables is set but KAAS_OFFLINE_DEPLOYMENT "
                  "is False.Using Proxy on online deployments makes no sense.")
        raise RuntimeError("Proxy variables is set but KAAS_OFFLINE_DEPLOYMENT"
                           " is False")
    show_step(5)
    if settings.KAAS_EXTERNAL_PROXY_ACCESS_STR:
        LOG.info('Proxy mode is enabled. However, external network will not '
                 'be restricted on child cluster nodes. Please consider limit '
                 'internet connection on your own. (Native internet isolation '
                 'is not available for AWS inside si-tests now)')
        proxy_access_str = settings.KAAS_EXTERNAL_PROXY_ACCESS_STR
        proxy_object = ns.create_proxyobject(
            name=f"{cluster_name}-{settings.KAAS_PROXYOBJECT_NAME}",
            region=region,
            proxy_str=proxy_access_str)
        proxy_object_name = proxy_object.data['metadata']['name']
    elif settings.KAAS_INSTALL_FAKE_PROXY:
        proxy_manager.deploy_proxy_sts()
        proxy_manager.deploy_proxy_svc()
        proxy_access_str = proxy_manager.generate_proxy_string()
        proxy_manager.check_proxy_conn()
        proxy_object = ns.create_proxyobject(
            name=f"{cluster_name}-{settings.KAAS_PROXYOBJECT_NAME}",
            region=region,
            proxy_str=proxy_access_str)
        proxy_object_name = proxy_object.data['metadata']['name']
    else:
        proxy_object_name = None

    show_step(6)
    if settings.KAAS_BASTION_CONFIG:
        bastion = settings.KAAS_AWS_BASTION_CONFIG
        LOG.info("Use custom bastion config:\n{0}".format(yaml.dump(bastion)))
    else:
        LOG.info("Deploy child cluster without additional bastion config")
        bastion = None

    show_step(7)
    cluster = ns.create_cluster(
        cluster_name,
        release_name,
        credential_name,
        region=region,
        provider="aws",
        services_cidr="10.96.0.0/16",
        pods_cidr="192.168.0.0/16",
        nodes_cidr="10.10.10.0/24",
        dns=child_dns,
        extra_helm_releases=helm_releases,
        lma_enabled=settings.KAAS_CHILD_CLUSTER_DEPLOY_LMA,
        public_key_name=public_key_name,
        proxy_name=proxy_object_name,
        secure_overlay=settings.KAAS_CHILD_CLUSTER_SECURE_OVERLAY_ENABLED,
        bastion=bastion)

    for node in range(master_nodes_count):
        cluster.create_aws_machine(
            node_type="master",
            instance_type=instance_type,
            ami=ami,
            region=region
        )

    for node in range(slave_nodes_count):
        cluster.create_aws_machine(
            node_type="node",
            instance_type=instance_type,
            ami=ami,
            region=region
        )

    show_step(8)
    # Waiting for machines are Ready and helm bundles are deployed
    cluster.check.check_machines_status()
    cluster.check.check_cluster_nodes()
    cluster.check.check_cluster_readiness()
    cluster.check.check_helmbundles()
    cluster.check.check_deploy_stage_success()

    # Collecting artifacts
    cluster.store_k8s_artifacts()

    show_step(9)
    if settings.RUN_POD_CHECKS:
        cluster.check.check_k8s_pods()
        cluster.check.check_actual_expected_docker_services()
        cluster.check.check_actual_expected_pods(timeout=3200, interval=30,
                                                 check_all_nss=True)
    cluster.check.check_overlay_encryption_functionality()
    cluster.provider_resources.save_artifact()

    show_step(10)
    if settings.KAAS_OFFLINE_DEPLOYMENT:
        cluster.check.check_offline_isolation(
            settings.KAAS_EXTERNAL_PROXY_ACCESS_STR)

    show_step(11)
    if bastion:
        LOG.info(f"New bastion IP = {cluster.bastion_ip} for cluster {cluster.name}")
        LOG.info("Check ssh to KaaS machine vie bastion VM")
        machines = cluster.get_machines()
        target_machine = machines[0]
        cluster.check.check_connection_via_bastion(target_machine)
        LOG.info("Check bastion parameters VM in AWS")
        cluster_status = cluster.data.get('status') or {}
        instance_id = cluster_status.get('providerStatus', {}).get('bastion', {}).get('id')
        cluster.check.check_aws_vm(instance_id=instance_id,
                                   instance_type=bastion['instanceType'],
                                   ami_id=bastion['amiId'])
