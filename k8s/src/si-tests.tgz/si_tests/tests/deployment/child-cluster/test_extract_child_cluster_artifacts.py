from si_tests import settings


def test_extract_child_cluster_artifacts(kaas_manager):
    """Extract child cluster artifacts from an existing cluster
    """

    cluster_name = settings.TARGET_CLUSTER
    namespace_name = settings.TARGET_NAMESPACE

    ns = kaas_manager.get_namespace(namespace_name)
    child_cluster = ns.get_cluster(cluster_name)

    # Collecting artifacts
    child_cluster.store_k8s_artifacts()
