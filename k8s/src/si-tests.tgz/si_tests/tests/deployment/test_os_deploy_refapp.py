from si_tests.deployments.deploy_refapp import Refapp


def test_deploy_refapp(openstack_client_manager):
    """KUBECONFIG is required"""
    Refapp(openstack_client_manager).deploy()
