import base64
import exec_helpers
import json
import pytest
import yaml

from si_tests.utils import packaging_version as version
from si_tests import settings
from si_tests import logger
import si_tests.utils.templates as templates_utils
from si_tests.utils import utils, waiters, exceptions
from si_tests.utils.utils import Provider

LOG = logger.logger


# Used for vsphere params
def parse_vsphere_params(x):
    return ''.join((x.split("/", 3)[3:]))


def test_kaas_ui(kaas_manager, kaas_ui_prerequisites):
    lb_host = None
    child_data = dict()
    writer_password = kaas_manager.si_config.get_keycloak_user_password('writer')
    pod_namespace = settings.KAAS_UI_TEST_NAMESPACE

    mgmt_cluster = kaas_manager.get_mgmt_cluster()
    if mgmt_cluster.provider == Provider.baremetal:
        cloud_provider = 'bm'
        cluster_name = settings.TARGET_CLUSTER
        namespace_name = settings.TARGET_NAMESPACE
        with open(settings.KAAS_CHILD_CLUSTER_PUBLIC_KEY_FILE) as pub_key:
            pub_key_content = pub_key.read()
        mgmt_version = mgmt_cluster.spec['providerSpec']['value']['kaas']['release']
        LOG.info(f"KaaS mgmt version is:{mgmt_version}")
        release_name = kaas_manager.si_config.version_generators.get_child_cluster_release_name()
        cephdeploy_used = kaas_manager.cephdeploy_used(clusterrelease_version=release_name)
        cephdeploy_new_api = kaas_manager.cephdeploy_new_api_used(clusterrelease_version=release_name)
        allowed_distros = kaas_manager.get_allowed_distributions(release_name)
        render_opts = {
            "mgmt_version": mgmt_version,
            "target_cluster": cluster_name,
            "target_namespace": namespace_name,
            "machine_distribution": allowed_distros.get(settings.DISTRIBUTION_RELEVANCE, {}).get('id', ''),
            "pub_key_content": pub_key_content,
            "cephdeploy_used": cephdeploy_used,
            "cephdeploy_new_api": cephdeploy_new_api,
        }
        # UI test require clusterrelease obj in extra_data
        LOG.info('Acquiring ClusterRelease obj')
        extra_data = kaas_manager.get_clusterrelease(name=settings.KAAS_CHILD_CLUSTER_RELEASE_NAME,
                                                     namespace='default').data
        child_data = utils.render_child_data(kaas_manager.si_config,
                                             render_opts,
                                             extra_data={'clusterrelease': extra_data})
        # TODO(alexz): need to delete it after..?
        _bm_secret_name = 'bm-child-data.yaml'
        LOG.info(f'Creating cm {pod_namespace}/{_bm_secret_name}')
        ns = kaas_manager.get_namespace(pod_namespace)
        try:
            ns.create_secret(_bm_secret_name, {
                _bm_secret_name: str(base64.b64encode(yaml.dump(child_data).encode('ascii')).decode())
                }
            )
        except Exception as exc:
            if "AlreadyExists" in str(exc) or "409" in str(exc):
                LOG.info(f'Secret {pod_namespace}/{_bm_secret_name} already exists, skipping creation')
            else:
                raise

    elif mgmt_cluster.provider == Provider.openstack:
        cloud_provider = 'openstack'
    elif mgmt_cluster.provider == Provider.aws:
        cloud_provider = 'aws'
    else:
        raise Exception(f"Unknown provider: {mgmt_cluster.provider}")

    LOG.info(f"Selected provider:{cloud_provider}")

    if settings.KAAS_UI_TEST_IMAGE_TAG:
        kaas_version = settings.KAAS_UI_TEST_IMAGE_TAG
    else:
        pod_list = kaas_manager.api.api_core.list_namespaced_pod(
            namespace='kaas', label_selector='app.kubernetes.io/instance=kaas-ui').to_dict()['items'][0]
        kaas_version = pod_list['spec']['containers'][0]['image'].split(':')[1]

    kaas_service = kaas_manager.api.api_core.read_namespaced_service(name='kaas-kaas-ui',
                                                                     namespace='kaas').to_dict()
    LOG.debug(kaas_service)
    kaas_ui_ip = \
        kaas_service['status']['load_balancer']['ingress'][0]['ip'] or \
        kaas_service['status']['load_balancer']['ingress'][0]['hostname']
    cdn_region = settings.CDN_REGION
    artifacts_region_map = settings.ARTIFACTS_REGION_MAPPING
    ui_image_base = artifacts_region_map[cdn_region]["images_base_url"]

    # KAAS_UI_TEST_TYPE is comma-separated — we run the pod once per
    # entry. With a single value (the default) the test behaves
    # exactly as before: single run, flat artifact layout. With two
    # or more values each run's artifacts are nested under
    # ARTIFACTS_DIR/<test_type>/ so successive runs can't clobber
    # the earlier ones.
    test_types = [t.strip() for t in settings.KAAS_UI_TEST_TYPE.split(',') if t.strip()]
    separate_artifacts = len(test_types) > 1

    def _run_ui_pod(test_type):
        """Spin up the UI test pod, wait for it to finish, copy reports
        out, optionally tear it down. Fails the pytest run if the pod
        didn't report ./test_passed — this short-circuits any further
        runs so the second invocation never starts after a first
        failure.
        """
        # Sanitize test_type for use in k8s names and filesystem paths:
        # ':' and '_' both become '-' (RFC 1123 + nicer artifact paths).
        sanitized = test_type.replace(":", "-").replace("_", "-") if separate_artifacts else ''
        suffix = f'-{sanitized}' if separate_artifacts else ''
        pod_name = settings.KAAS_UI_TEST_POD_NAME + '-playwright' + suffix
        ns_name = settings.KAAS_UI_E2E_TEST_NS_PREFIX + '-playwright' + suffix

        # Delete the pod before test if it is running
        if kaas_manager.api.pods.present(name=pod_name, namespace=pod_namespace):
            LOG.info(f"Pod '{pod_name}' already exists, deleting")
            kaas_manager.api.pods.get(name=pod_name, namespace=pod_namespace).delete()

        options = {
            'CLOUD_PROVIDER': cloud_provider,
            'KAAS_UI_ADDRESS': kaas_ui_ip,
            'KAAS_UI_E2E_TEST_NS_NAME_PREFIX': ns_name,
            'KAAS_UI_PASSWORD': writer_password,
            'KAAS_UI_PORT': kaas_service['spec']['ports'][0]['port'],
            'KAAS_UI_TEST_IMAGE': f"{ui_image_base}/{settings.KAAS_UI_TEST_IMAGE}:{kaas_version}",
            'KAAS_UI_TEST_POD_NAME': pod_name,
            'KAAS_UI_TEST_TYPE': test_type,
            'KAAS_UI_USERNAME': 'writer',
            'LOADBALANCER_HOST': lb_host,
            'NEW_PATH': '/playwright-tests',
            # TODO: remove after 2.31.x EOL.
            'CHILD_CREATE_ONLY_SCENARIO':
                settings.KAAS_UI_CHILD_CREATE_ONLY_SCENARIO,
        }

        templates = templates_utils.render_template(settings.KAAS_UI_TEST_POD_YAML, options)
        LOG.debug(templates)
        json_body = json.dumps(yaml.load(templates, Loader=yaml.SafeLoader))

        pod = kaas_manager.api.pods.create(name=pod_name, namespace=pod_namespace, body=json.loads(json_body))
        pod.wait_phase('Running', timeout=3000)
        LOG.info(f"UI tests (type={test_type}) uses image "
                 f"{pod.data['status']['container_statuses'][0]['image_id']}")

        # Per-run artifact roots. In single-run mode we preserve the
        # original layout (reports under ARTIFACTS_DIR/reports,
        # screenshots/videos extracted to ARTIFACTS_DIR top-level) so
        # downstream CI scripts that expect those paths keep working.
        if separate_artifacts:
            artifacts_root = f"{settings.ARTIFACTS_DIR}/{sanitized}"
            reports_dst = f"{artifacts_root}/reports"
            screenshots_dst = f"{artifacts_root}/screenshots"
            videos_dst = f"{artifacts_root}/videos"
        else:
            reports_dst = f"{settings.ARTIFACTS_DIR}/reports"
            screenshots_dst = None
            videos_dst = None

        try:
            pod.wait_test(filepath='./test_*', timeout=7200)
        finally:
            exec_helpers.Subprocess().check_call(f"mkdir -p {reports_dst}")
            if separate_artifacts:
                exec_helpers.Subprocess().check_call(
                    f"mkdir -p {screenshots_dst} {videos_dst}")

            res = pod.exec(['/bin/sh', '-c',
                            f'ls -la {settings.KAAS_UI_TEST_REPORTS_DIR}/reports'])
            LOG.info(f"Reports in pod {pod_namespace}/{pod_name}:"
                     f"{settings.KAAS_UI_TEST_REPORTS_DIR}/reports :\n{res}")

            pod.cp_from_pod(source_dir=settings.KAAS_UI_TEST_REPORTS_DIR + '/reports',
                            destination=reports_dst, container=pod_name)
            if separate_artifacts:
                pod.cp_from_pod(source_dir=settings.KAAS_UI_TEST_REPORTS_DIR + '/screenshots',
                                destination=screenshots_dst, container=pod_name)
                pod.cp_from_pod(source_dir=settings.KAAS_UI_TEST_REPORTS_DIR + '/videos',
                                destination=videos_dst, container=pod_name)
            else:
                pod.cp_from_pod(source_dir=settings.KAAS_UI_TEST_REPORTS_DIR + '/screenshots',
                                container=pod_name)
                pod.cp_from_pod(source_dir=settings.KAAS_UI_TEST_REPORTS_DIR + '/videos',
                                container=pod_name)

        if not settings.KEEP_KAAS_UI_TEST_POD_AFTER:
            pod.delete()
        if not pod.check_file_exists('./test_passed'):
            location = f"artifacts/{test_type}" if separate_artifacts else "artifacts"
            pytest.fail(f"Some kaas UI tests failed for KAAS_UI_TEST_TYPE='{test_type}'. "
                        f"See detailed report in {location}.")

    LOG.info(f"Running kaas-ui pod 1/{len(test_types)} with "
             f"KAAS_UI_TEST_TYPE='{test_types[0]}'")
    _run_ui_pod(test_types[0])

    # TODO: drop the legacy clause after 2.31.x EOL.
    if cloud_provider == "bm" and (
            'e2e:ceph_verify' in test_types
            or settings.KAAS_UI_CHILD_CREATE_ONLY_SCENARIO):
        tgt_ns = kaas_manager.get_namespace(settings.TARGET_NAMESPACE)
        tgt_cluster = tgt_ns.get_cluster(name=settings.TARGET_CLUSTER)
        # START: copy-paste from test_create_physical_child_ceph_lma_istio_harbor.py
        if settings.MOSK_CHILD_DEPLOY_CEPH:
            if tgt_cluster.workaround.child_with_cephdeployment():
                LOG.info("Create CephDeployment using raw methods")
                network_missed = False
                if tgt_cluster.workaround.child_with_new_cephdeployment_api():
                    ceph_cluster_pools = child_data['cephdeployment_raw']['spec'].get('blockStorage', {})['pools']
                    if not child_data.get('cephdeployment_raw').get('spec').get(
                                          'cluster', {}).get('network', {}).get('addressRanges', None):
                        network_missed = True
                else:
                    ceph_cluster_pools = child_data['cephdeployment_raw']['spec']['pools']
                    if not child_data.get('cephdeployment_raw').get('spec').get('network', None):
                        network_missed = True
                if network_missed:
                    pytest.fail(f'No network settings has been provided in cephdeployment_raw!\n'
                                f'Please fix env_config_name={settings.ENV_CONFIG_NAME}')
                cluster_name = child_data['cluster_raw']['metadata']['name']
                # add monitorIP field if found separate ceph frontend network
                if tgt_cluster.workaround.use_ceph_mon_ip():
                    tgt_cluster.set_cephdeployment_data_nodes_monitor_ip(child_data['cephdeployment_raw'])
                tgt_ns.create_cephdeployment_raw(cluster_name=cluster_name, data=child_data['cephdeployment_raw'])
            else:
                LOG.info("Create MiraCeph using raw methods")
                if not child_data.get('miraceph_raw').get('spec').get('network', None):
                    pytest.fail(f'No network settings has been provided in miraceph_raw!\n'
                                f'Please fix env_config_name={settings.ENV_CONFIG_NAME}')
                cluster_name = child_data['cluster_raw']['metadata']['name']
                tgt_ns.create_miraceph_raw(cluster_name=cluster_name, data=child_data['miraceph_raw'])
                ceph_cluster_pools = child_data['miraceph_raw']['spec']['pools']
            try:
                waiters.wait(lambda: tgt_cluster.check.check_child_ceph_cluster(check_health=True),
                             timeout=90 * 60, interval=60)
            except exceptions.TimeoutError as e:
                LOG.error("Tired waiting for ceph cluster correct status,"
                          "events from management cluster:")
                raise e

            tgt_cluster.check.wait_default_storage(ceph_cluster_pools=ceph_cluster_pools, timeout=30 * 60)
            if tgt_cluster.is_sl_enabled():
                # wait while provider understands that ceph is alive
                # and re-generates helmbundle with stacklight
                tgt_cluster.check.wait_for_release_in_bundle(name="stacklight")
            tgt_cluster.check.check_actual_expected_pods(interval=30)
            # Check Ceph pvc
            tgt_cluster.check.check_ceph_pvc()
        # END: copy-paste from test_create_physical_child_ceph_lma_istio_harbor.py
        # perform checks
        tgt_cluster.check.check_cluster_readiness(timeout=3600, interval=90)
        tgt_cluster.check.check_helmbundles()
        tgt_cluster.check.check_deploy_stage_success()
        if tgt_cluster.lcm_type_is_ucp:
            tgt_cluster.check.check_actual_expected_docker_services()
        tgt_cluster.check.check_k8s_pods()
        tgt_cluster.check.check_actual_expected_pods(interval=30, check_all_nss=True)
        tgt_cluster.check.check_actual_expected_kernel_versions()
        tgt_cluster.check.check_actual_expected_distribution()
        #  we need to store data only for -bm clusters, since in -bm ci we mimic -ui deployment as usual deployment
        # so need to have all expected artifacts.
        tgt_cluster.store_k8s_artifacts()

    if version.parse(mgmt_cluster.get_kaasrelease_version()) >= version.parse('kaas-2-32-0-rc'):
        # Remaining UI pod runs (test_types[1:]). These execute AFTER the
        # BM-ceph block above so they can exercise the now-Ceph-ready
        # child cluster. With a single value in KAAS_UI_TEST_TYPE this
        # loop is empty and the test ends here exactly as it used to.
        for idx, test_type in enumerate(test_types[1:], start=2):
            LOG.info(f"Running kaas-ui pod {idx}/{len(test_types)} with "
                     f"KAAS_UI_TEST_TYPE='{test_type}'")
            _run_ui_pod(test_type)
