"""Unit tests for k0s / ucp LCM-type detection on the Cluster object.

These cover the regression that the release *name* is not a reliable
indicator of the LCM engine: an upcoming ``mosk-27-1`` release runs on k0s,
so detection must read the ClusterRelease ``spec.lcmType`` (or the live
cluster status), never parse the name.
"""
import pytest

from si_tests.managers import kaas_manager


class _FakeReadable:
    """Mimics the k8s object wrapper used by Cluster.data (read().to_dict())."""

    def __init__(self, data):
        self._data = data

    def read(self):
        return self

    def to_dict(self):
        return self._data


class _FakeClusterRelease:
    def __init__(self, lcm_type):
        spec = {} if lcm_type is None else {'lcmType': lcm_type}
        self.data = {'spec': spec}


class _FakeManager:
    def __init__(self, releases):
        # releases: {release_name: lcm_type}
        self._releases = releases

    def get_clusterrelease(self, name, namespace=None):
        if name not in self._releases:
            raise KeyError("ClusterRelease {0} not found".format(name))
        return _FakeClusterRelease(self._releases[name])


def _make_cluster(status_lcm_type=None, status_release=None,
                  spec_release=None, releases=None):
    """Build a Cluster with mocked backing data, bypassing __init__."""
    cluster = kaas_manager.Cluster.__new__(kaas_manager.Cluster)
    data = {'spec': {'providerSpec': {'value': {'release': spec_release}}}}
    if status_lcm_type is None and status_release is None:
        data['status'] = None
    else:
        current = {}
        if status_lcm_type is not None:
            current['lcmType'] = status_lcm_type
        if status_release is not None:
            current['name'] = status_release
        data['status'] = {
            'providerStatus': {'releaseRefs': {'current': current}}}
    # Name-mangled private attributes backing Cluster.data and Cluster.__manager
    setattr(cluster, '_Cluster__cluster', _FakeReadable(data))
    setattr(cluster, '_Cluster__manager', _FakeManager(releases or {}))
    return cluster


# --- lcm_type_by_release -----------------------------------------------------

def test_lcm_type_by_release_explicit_release_name():
    cluster = _make_cluster(releases={'k0s-22-0-0': 'k0s', 'mosk-21-2-0': 'ucp'})
    assert cluster.lcm_type_by_release('k0s-22-0-0') == 'k0s'
    assert cluster.lcm_type_by_release('mosk-21-2-0') == 'ucp'


def test_lcm_type_by_release_mosk_named_release_running_k0s():
    # The whole point: name says mosk-*, but lcmType is k0s.
    cluster = _make_cluster(releases={'mosk-27-1': 'k0s'})
    assert cluster.lcm_type_by_release('mosk-27-1') == 'k0s'


def test_lcm_type_by_release_defaults_to_status_release():
    cluster = _make_cluster(status_lcm_type='k0s', status_release='mosk-27-1',
                            releases={'mosk-27-1': 'k0s'})
    assert cluster.lcm_type_by_release() == 'k0s'


def test_lcm_type_by_release_defaults_to_spec_release_without_status():
    cluster = _make_cluster(spec_release='mosk-27-1', releases={'mosk-27-1': 'k0s'})
    assert cluster.lcm_type_by_release() == 'k0s'


def test_lcm_type_by_release_missing_lcmtype_defaults_to_ucp():
    cluster = _make_cluster(releases={'legacy-1-0': None})
    assert cluster.lcm_type_by_release('legacy-1-0') == 'ucp'


# --- is_k0s ------------------------------------------------------------------

def test_is_k0s_true_for_mosk_named_k0s_release():
    cluster = _make_cluster(status_release='mosk-27-1', releases={'mosk-27-1': 'k0s'})
    assert cluster.is_k0s is True


def test_is_k0s_false_for_ucp_release():
    cluster = _make_cluster(status_release='mke-20-1-0', releases={'mke-20-1-0': 'ucp'})
    assert cluster.is_k0s is False


# --- k0s_enabled -------------------------------------------------------------

@pytest.mark.parametrize('status_lcm_type,expected', [
    ('k0s', True),
    ('ucp', False),
    ('kubespray', False),
])
def test_k0s_enabled_from_live_status(status_lcm_type, expected):
    cluster = _make_cluster(status_lcm_type=status_lcm_type,
                            status_release='some-release')
    assert cluster.k0s_enabled() is expected


def test_k0s_enabled_falls_back_to_release_when_no_status():
    cluster = _make_cluster(spec_release='mosk-27-1', releases={'mosk-27-1': 'k0s'})
    assert cluster.k0s_enabled() is True


def test_k0s_enabled_false_for_ucp_release_when_no_status():
    cluster = _make_cluster(spec_release='mosk-21-2-0', releases={'mosk-21-2-0': 'ucp'})
    assert cluster.k0s_enabled() is False
