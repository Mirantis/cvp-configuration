"""Unit tests for the LCM-engine abstraction (managers/lcm_engine.py).

They verify that ``get_lcm_engine`` returns the right implementation and the
right engine-specific command surface for a mocked ``lcm_type``, without a
real cluster. The mocked Cluster helpers are reused from the k0s-detection
tests.
"""
from si_tests.managers import lcm_engine
from si_tests.tests.self.test_k0s_detection import _make_cluster


def test_factory_returns_k0s_engine_for_k0s_cluster():
    cluster = _make_cluster(status_lcm_type='k0s', status_release='mosk-27-1')
    engine = lcm_engine.get_lcm_engine(cluster)
    assert isinstance(engine, lcm_engine.K0sEngine)
    assert engine.name == 'k0s'


def test_factory_returns_mke_engine_for_ucp_cluster():
    cluster = _make_cluster(status_lcm_type='ucp', status_release='mke-3-7-0')
    engine = lcm_engine.get_lcm_engine(cluster)
    assert isinstance(engine, lcm_engine.MkeEngine)
    assert engine.name == 'ucp'


def test_factory_falls_back_to_release_without_status():
    # No live status yet -> decide by ClusterRelease spec.lcmType.
    cluster = _make_cluster(spec_release='k0s-22-0-0',
                            releases={'k0s-22-0-0': 'k0s'})
    engine = lcm_engine.get_lcm_engine(cluster)
    assert isinstance(engine, lcm_engine.K0sEngine)


def test_k0s_engine_surface():
    cluster = _make_cluster(status_lcm_type='k0s')
    engine = lcm_engine.get_lcm_engine(cluster)
    assert engine.runtime_sock() == 'unix:///run/k0s/containerd.sock'
    assert 'kube-apiserver' in engine.control_component_names
    # k0s must NOT expose ucp-* component names.
    assert not any(n.startswith('ucp-') for n in engine.control_component_names)


def test_mke_engine_surface():
    cluster = _make_cluster(status_lcm_type='ucp')
    engine = lcm_engine.get_lcm_engine(cluster)
    assert 'docker.sock' in engine.runtime_sock()
    assert 'ucp-kube-apiserver' in engine.control_component_names
