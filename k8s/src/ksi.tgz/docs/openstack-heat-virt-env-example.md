# Test environment using openstack heat backend

| :warning: WARNING                                                    |
|:---------------------------------------------------------------------|
| Current state of templates and logic around: PoC for internal usage. |
| Don't expect it would be easy to re-use out-of-the box               |
| Please refer to them, only like examples.                            |

## Description

This document ***only*** shows how-to locally run current set of tests, to
get k0rdent-bm virtual env, based on Openstack backend.
This document describes *only example* based on `KSI_ENV_CONFIG_NAME="os-virtual"`, but potentially steps should be same
for
any kind of -bm environment.

## Openstack Env backend overview:

Configuration endpoints:

```text
Main configuration files:
tree -L 2 test_env_data/labs/os-virtual/
test_env_data/labs/os-virtual/
├── ansible_data # configs, required for finish setup openstack-backed nodes( seed node\kvm nodes\etc)
│   ├── 001_basic_setup.yaml
│   └── inventory
├── bootstrap_data  # configs, required for k8s|k0s spawn seed-node, and for init first cluster(aka, target cluster)
│   ├── baremetalhosts.metal3.io
│   ├── bootstrap_k0s_clusterconfig
│   ├── clusterdeployments.k0rdent.mirantis.com
│   ├── clustertemplates.k0rdent.mirantis.com
│   ├── credentials.k0rdent.mirantis.com
│   ├── data.yaml.j2
│   ├── helmreleases.helm.toolkit.fluxcd.io
│   ├── helmrepositories.source.toolkit.fluxcd.io
│   ├── main.yaml.j2
│   ├── managements.k0rdent.mirantis.com
│   ├── providertemplates.k0rdent.mirantis.com
│   └── secrets
└── heat_data
    ├── chunks -> ../../../heat/chunks
    ├── env.yaml -> ../../../heat/envs/env1_default.yaml # end user configuration for env1_virtual_lab.hot
    └── heat.hot -> ../../../heat/env1_virtual_lab.hot
```

Heat-stack configuration basics:

```text
cat test_env_data/labs/os-virtual/heat_data/env.yaml 
parameter_defaults:
  # Openstack KeyPait object name, for seed,kvm underlay only
  key_pair: change_me
  seed_node_flavor: kaas-bm.worker.Disk60ram12vcpu8
  # group1 - as for current config, group1- is KVM hosts.
  group1_image: jammy-server-cloudimg-amd64-disk-kvm-20250702
  group1_flavor: kaas-bm.master.Disk120ram24vcpu18
  group1_vm_count: 3
  # group2|3 currently not used, so disabled.
  group2_vm_count: 0 
  ...
```

### `os-virtual` schematic:

![Schematic overview](./images/os-virtual.svg)

tl;tr: `os-virtual` is as simple as possible, as hardcoded config as possible, which allow:
1) Spawn `seed node` - which is VM in Openstack
2) Spawn +3 (or other amount) VM's, each will be:
    - used as KVM host to manage only one nested-VM for target -bm cluster
    - expose `ipmi` endpoint to control `nested-VM` via `ipmi` protocol
3) Install and configure `k0s` with `kcm` on seed
4) Install `k0rdent-baremetal` on top of `k0s` at seed node
5) Configure baremetal templates to inspec,provision,and deploy `k0rdent` cluster on top of `nested-VM's`

## StepByStep `basic` spawn example:

All phases, split into `.sh` files - just to highlight process and required `env` variables:

```text
# ksi/
tree -L 1
.
├── env1_p1_test_infra.sh  # stage1
├── env1_p2_1_remote_setup_infra.sh  # stage2 and etc
├── env1_p2_2_remote_install_k0s.sh
├── env1_p3_remote_install_kcm.sh
├── env1_p4_remote_install_metal3.sh
├── id_ed_ksiuser  << private key, to access seed node
```

Stage1: spawn seed node and `ksi_config.yaml`

```shell
#!/bin/env bash

set -ex

export KSI_OS_CLOUDS_YAML_PATH="path/to/my/private/clouds.yaml"
export KSI_OS_CLOUD_NAME="mycloud"
export KSI_KEEP_ENV_BEFORE='false'
#
export KSI_ENV_NAME='user-ksi1'
export KSI_ENV_CONFIG_NAME="os-virtual"
export KSI_ARTIFACTS_DIR="_temp/${KSI_ENV_NAME}/artifacts/"
rm -rf "${KSI_ARTIFACTS_DIR}"
mkdir -p ${KSI_ARTIFACTS_DIR}
# KSI REMOTE DATA
export KSI_SEED_SSH_PRIV_KEY_FILE='id_ed_ksiuser'
ksi-runtest config-create  > "${KSI_ARTIFACTS_DIR}/ksi_config.yaml"
export KSI_CONFIG_PATH="${KSI_ARTIFACTS_DIR}/ksi_config.yaml"
#
py.test --color=yes --junit-xml=${KSI_ARTIFACTS_DIR}/tests_report.xml si_tests/tests/infra/openstack/test_create_env.py
```

Stage2.1: **KSI_RUN_ON_REMOTE=true** Configure `os-virtual`` env, including `ansible` and other preparations around.

```shell

#!/bin/env bash

set -ex
export KSI_ENV_NAME='user-ksi1'
export KSI_RUN_ON_REMOTE='true'
export KSI_ENV_CONFIG_NAME="os-virtual"
export KSI_ARTIFACTS_DIR="_temp/${KSI_ENV_NAME}/artifacts/"
export KSI_CONFIG_PATH="${KSI_ARTIFACTS_DIR}/ksi_config.yaml"
export KSI_SEED_WORKSPACE_PATH_USE_CACHE=true
#
R_TEST="si_tests/tests/infra/openstack/test_setup_env.py"
ksi-runtest exec --config-path=${KSI_ARTIFACTS_DIR}/ksi_config.yaml '--command=py.test --color=yes '${R_TEST}' 2>&1'
````

Stage2.2: **KSI_RUN_ON_REMOTE=true** Install `k0s` at remote seed node

```shell
#!/bin/env bash
set -ex
# prepare test bins
if [ -f 'bin/kubectl' ]; then
  mkdir bin
  curl -L "https://dl.k8s.io/release/$(curl -L -s https://dl.k8s.io/release/stable.txt)/bin/linux/amd64/kubectl" --output bin/kubectl
  curl -sSL https://get.helm.sh/helm-v3.17.3-linux-amd64.tar.gz | tar xz --strip-components=1 -C bin/ linux-amd64/helm
  chmod 0755 bin/*
fi
#
export KSI_ENV_NAME='user-ksi1'
export KSI_RUN_ON_REMOTE='true'
export KSI_ENV_CONFIG_NAME="os-virtual"
export KSI_ARTIFACTS_DIR="_temp/${KSI_ENV_NAME}/artifacts/"
export KSI_CONFIG_PATH="${KSI_ARTIFACTS_DIR}/ksi_config.yaml"
export KSI_SEED_WORKSPACE_PATH_USE_CACHE=true
export KSI_K0S_APPLY_REGISTRY_HACK=true
# since we hardcode path for dev-runs, need to fix reverse-sync also..
export KSI_SEED_DOWNLOAD_DIRS="_temp:_temp"
#
R_TEST="si_tests/tests/bootstrap/test_install_seed_install_k0s.py"
ksi-runtest exec --config-path=${KSI_ARTIFACTS_DIR}/ksi_config.yaml '--command=py.test --color=yes '${R_TEST}' 2>&1'
```

Stage3: **KSI_RUN_ON_REMOTE=true** Install `k0s` at remote seed node

```shell
#!/bin/env bash
set -ex

export KSI_ENV_NAME='user-ksi1'
export KSI_RUN_ON_REMOTE='true'
export KSI_ENV_CONFIG_NAME="os-virtual"
export KSI_ARTIFACTS_DIR="_temp/${KSI_ENV_NAME}/artifacts/"
export KSI_CONFIG_PATH="${KSI_ARTIFACTS_DIR}/ksi_config.yaml"
export KSI_SEED_WORKSPACE_PATH_USE_CACHE=true
export KSI_SEED_DOWNLOAD_DIRS="_temp:_temp"
#
export KUBECONFIG="${KSI_ARTIFACTS_DIR}/bootstrap_kubeconfig.yaml"
#
export KSI_KCM_SOURCE="opensource"
export KSI_KCM_CHART_VERSION="0.3.0"
#
R_TEST="si_tests/tests/bootstrap/test_install_kcm.py"

ksi-runtest exec --config-path=${KSI_ARTIFACTS_DIR}/ksi_config.yaml '--command=py.test --color=yes '${R_TEST}' 2>&1'
```

Stage4: **KSI_RUN_ON_REMOTE=true** Install `k0rdent-bm` chunks

```shell
#!/bin/env bash
set -ex

# prepare test bins
if [ -f 'bin/kubectl' ]; then
  mkdir bin
  curl -L "https://dl.k8s.io/release/$(curl -L -s https://dl.k8s.io/release/stable.txt)/bin/linux/amd64/kubectl" --output bin/kubectl
  curl -sSL https://get.helm.sh/helm-v3.17.3-linux-amd64.tar.gz | tar xz --strip-components=1 -C bin/ linux-amd64/helm
  chmod 0755 bin/*
fi
#
export KSI_ENV_NAME='user-ksi1'
export KSI_RUN_ON_REMOTE='true'
export KSI_ENV_CONFIG_NAME="os-virtual"
export KSI_ARTIFACTS_DIR="_temp/${KSI_ENV_NAME}/artifacts/"
export KSI_CONFIG_PATH="${KSI_ARTIFACTS_DIR}/ksi_config.yaml"
export KSI_SEED_WORKSPACE_PATH_USE_CACHE=true
#
export KSI_KUBECONFIG_PATH="${KSI_ARTIFACTS_DIR}/bootstrap_kubeconfig.yaml"
#
export KSI_SECRET_REGISTRY_CI_MIRANTIS_COM_USERNAME='XXXXXXXXx'
export KSI_SECRET_REGISTRY_CI_MIRANTIS_COM_PASSWORD='YYYYYYYYY'
#
export KSI_KCM_SOURCE="opensource"
export KSI_BAREMETAL_CAPI_PROVIDER_METAL3_CHART_VERSION='0.0.0-518373e'

R_TEST="si_tests/tests/bootstrap/test_install_seed_install_bm.py"
ksi-runtest exec --config-path=${KSI_ARTIFACTS_DIR}/ksi_config.yaml '--command=py.test --color=yes --junit-xml=artifacts/tests_report.xml '${R_TEST}' 2>&1'
```

### `os-virtual` FAQs:

Q: how-to get access to ipmi\console for VMs?
A:

```text
# aquire kvm's ip:
$ cat labs/os-virtual/ansible_data/inventory/kvm/kvm* |grep ansible_host:
      ansible_host: 192.168.10.30
      ansible_host: 192.168.10.31
      ansible_host: 192.168.10.32
# ssh to host:
$ ssh -q root@192.168.10.30 virsh list --all
 Id   Name       State
--------------------------
 2    kvm1vm01   running
$ Access via ipmitool(from seed): 
ipmitool -I lanplus -H 192.168.10.30 -p 27001 -U admin -P r00tme chassis power status
Chassis Power is on
```
  