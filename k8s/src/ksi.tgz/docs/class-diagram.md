### Class diagram as of 5/5/2025

![Class Diagram](images/classes.png)

### How to Generate?
```
# in root dir of ksi
# Graphviz must be installed
pip install pylint
pyreverse -o png -d docs/images si_tests/
```