# Ingress Test Suite

## Overview

This suite tests Ingress services.

## Pre-requisites

- Working CNCF Kubernetes installation (KinD/k0s/Minikube/etc...)
- KUBECONFIG file
- KCM Build uploaded to accessible registry

## Detailed description of checks inside bootstrap test (test_ingress.py)

Checks include:
 - Access target cluster and check that cluster is Ready and accessible
 - Test services availability via external IPs

### Execution

```bash
py.test $(KSI_HOME)/si_tests/inference/test_ingress.py
```

### Expected pods check

Not yet appliable.







