from si_tests import settings


def test_check_cld_readiness(kcm_manager):
    """Check the child cluster readiness"""
    ns = kcm_manager.get_namespace(settings.TARGET_NAMESPACE)
    cld = ns.get_cluster_deployment(settings.TARGET_CLD)
    cld.check.check_cluster_readiness(timeout=600)
    cld.check.check_k8s_pods()
    cld.check.check_k8s_nodes()
