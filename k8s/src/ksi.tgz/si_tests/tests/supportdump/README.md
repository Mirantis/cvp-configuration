# Support Bundle
This module:
- Downloads the support bundle binary from github
- Renders template based off of user config
- Gets the support dump based off of KSI_KUBECONFIG_PATH
- Verifies that the expected files are in the support dump.
- Support dump will be available in root ksi directory

# Variables

## Required
KSI_KUBECONFIG_PATH - Path to kubeconfig to take the support bundle from.

## Optional
KSI_SUPPORT_BUNDLE_VERSION - Version of support bundle to download from github. (Default: 0.117.0)
KSI_SUPPORT_BUNDLE_NAMESPACE - Namespace in which kcm is installed. (Default: kcm-system)

# Example Run
```
make create-kind-cluster
make test-install-enterprise
make test-gather-support-dump
```
