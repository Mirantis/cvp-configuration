from si_tests import settings
from si_tests import logger

LOG = logger.logger


def test_create_region(kcm_manager, show_step):
    """Create a region object and check that region entities created in target cluster

    Scenario:
        1. Gather environment config
        2. Access target cluster and check that cluster is Ready and accessible
        3. Create region object
        4. Wait for region to become Ready
        5. Check expected pods and cluster state
    """
    show_step(1)
    ns = kcm_manager.get_namespace(settings.KSI_TARGET_NAMESPACE)
    cld = ns.get_cluster_deployment(settings.KSI_TARGET_CLD)
    region_name = settings.KSI_KCM_REGION_NAME
    assert region_name, "Variable KSI_KCM_REGION_NAME can not be empty"

    # NOTE(va4st): Defaultly enable cert-manager for regional clusters
    cert_manager = True
    if cld.kof_role == 'regional':
        LOG.info(f"Regional kof role detected for clusterdeployment {cld.namespace}/{cld.name}. ")
        cert_manager = False
        cld.add_regional_combo_labels()

    show_step(2)
    # Limit readiness check since we should have already deployed working cluster
    cld.check.check_cluster_readiness(timeout=300)
    cld.check.check_actual_expected_pods()
    LOG.info(f"Clusterdeployment {cld.namespace}/{cld.name} checked and ready.")

    show_step(3)
    if settings.KSI_KCM_REGION_MODE == 'kubeconfig':
        kubeconfig_name = f"{cld.name}-kubeconfig"
        region = kcm_manager.create_kcm_region(kubeconfig_name=kubeconfig_name, cert_manager_enabled=cert_manager)
    else:
        region = kcm_manager.create_kcm_region(clusterdeployment=cld, cert_manager_enabled=cert_manager)

    show_step(4)
    region.wait_for_readiness()

    show_step(5)
    cld.check.check_k8s_nodes()
    cld.check.check_k8s_pods()
    cld._refresh_expected_objects()
    cld.check.check_actual_expected_pods()
