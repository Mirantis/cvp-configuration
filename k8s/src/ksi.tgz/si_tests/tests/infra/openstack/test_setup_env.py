import os.path

import pytest
from si_tests import logger
from si_tests import settings
from si_tests.managers.ansible_manager import AnsibleManager
import si_tests.utils.utils as utils

LOG = logger.logger


@pytest.mark.usefixtures('log_step_time')
@pytest.mark.usefixtures('log_method_time')
def test_infra_setup(show_step):
    """Prepare env

    Scenario:
        1. Init ansible env, at seed node
        2. Process ansible tasks
    """
    show_step(1)
    if not os.path.isdir(settings.KSI_ANSIBLE_PB_PATH):
        pytest.skip(f'Target {settings.KSI_ANSIBLE_PB_PATH} not found. Skip.')
    ansible_manager = AnsibleManager()
    ansible_manager.ansible_install_and_init()
    pbooks = utils.list_files_in_dir(settings.KSI_ANSIBLE_PB_PATH)
    show_step(2)
    LOG.info(f"Acquired from {settings.KSI_ANSIBLE_PB_PATH} playbooks:\n{pbooks}")
    for playbook in pbooks:
        LOG.info(f'Attempt to run {playbook}')
        ansible_manager.ansible_run(os.path.join(settings.KSI_ANSIBLE_PB_PATH, playbook),
                                    f"{settings.KSI_ANSIBLE_PB_PATH}/inventory/")
