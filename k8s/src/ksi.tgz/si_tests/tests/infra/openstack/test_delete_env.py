import pytest
from si_tests import logger
from si_tests import settings

LOG = logger.logger


def test_infra_delete_stack(openstack_client, show_step):
    """Delete env's heat stack and verify deletion.

    Scenario:
        1. Delete openstack heat stack
    """
    stack_name = settings.KSI_ENV_NAME
    if not stack_name:
        LOG.error(f"SKIP: Required settings.KSI_ENV_NAME=={stack_name}")
        pytest.skip("No settings.KSI_ENV_NAME passed, skipping")

    show_step(1)
    if not openstack_client._current_stack:
        LOG.error(f"SKIP: stack with name {stack_name} not found.")
        pytest.skip("No stack found, skipping")
    LOG.info(f"Removing heat stack {stack_name}:{openstack_client._current_stack.id}")
    openstack_client.delete_stack()
    LOG.info(f'Done deleting stack {stack_name}')
