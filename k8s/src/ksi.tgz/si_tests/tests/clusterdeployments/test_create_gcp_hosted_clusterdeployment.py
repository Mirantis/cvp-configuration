import pytest

from si_tests import settings
from si_tests import logger
from si_tests.utils import utils, k8s_utils, kcm_utils

LOG = logger.logger


@pytest.mark.create_cd
@pytest.mark.gcp_hosted
@pytest.mark.usefixtures('log_step_time')
@pytest.mark.usefixtures('log_method_time')
@pytest.mark.usefixtures('store_cluster_kubeconfig')
@pytest.mark.parametrize("_", [f"CLUSTER_NAME={settings.KSI_CLUSTER_DEPLOYMENT_NAME}"])
def test_create_gcp_hosted_standalone_cluster(kcm_manager, show_step, _):
    """Deploy managed hosted clusterdeployment on GCP

    Scenario:
        1. Collect env data and determine regional/host cluster
        2. Gather host cluster based on environment/region data
        3. Generate unique names and auth parameters
        4. Gather network config of the host cluster for hosted deployment
        5. Create or get NS and check cluster templates presence
        6. Create auth
        7. Prepare clusterdeployment config
        8. Create clusterdeployment
        9. Wait for clusterdeployment progress to finish
        10. Check k8s nodes
        11. Sync CoreDNS Corefile with management cluster
        12. Check expected pods and its statuses
    """
    show_step(1)
    cluster_name = settings.KSI_CLUSTER_DEPLOYMENT_NAME
    namespace_name = settings.KSI_CLUSTER_DEPLOYMENT_NAMESPACE
    host_cluster_ns, host_cluster_name = kcm_utils.determine_hosted_parameters(kcm_manager)

    show_step(2)
    host_cluster, host_kcm_manager, cld_manager = kcm_utils.determine_host_clusters(kcm_manager,
                                                                                    host_cluster_ns,
                                                                                    host_cluster_name)

    show_step(3)
    auth_suffix = f"ksi-gcp-auth-{utils.gen_random_string(4)}"
    auth_secret_name = f"{auth_suffix}-secret"
    cred_name = f"{auth_suffix}-cred"

    show_step(4)
    # Gathering network config of the host cluster for hosted deployment using mgmt cluster
    LOG.info(f"Gathering network config of the host cluster {host_cluster_ns}/{host_cluster_name} ")
    infracluster = host_cluster.clusterobject.infracluster
    project = infracluster.data['spec']['project']
    region = infracluster.data['spec']['region']
    network_name = infracluster.data['spec']['network']['name']

    show_step(5)
    ns = cld_manager.get_or_create_namespace(namespace_name)
    host_cluster_ns = host_kcm_manager.get_or_create_namespace(host_cluster_ns)

    clustertemplate = (settings.KSI_KCM_CLUSTER_TEMPLATE_NAME or
                       ns.get_latest_template_by_prefix('gcp-hosted-cp', strategy='chart'))
    available_templates = [tmpl.name for tmpl in ns.get_cluster_templates()]
    assert clustertemplate in available_templates, (f"Clustertemplate {clustertemplate} not found in namespace "
                                                    f"{ns.name}. Available templates: {available_templates}")

    show_step(6)
    auth_sec = ns.create_gcp_auth_secret(name=auth_secret_name)
    # NOTE(va4st): For GCP there no separated auth. Only secret required
    cred = ns.create_credential(name=cred_name, cred_object=auth_sec)
    cred.wait_for_readiness()
    sveltos_template = host_cluster_ns.create_sveltos_resource_template_cm_using_secret(auth_sec, provider='gcp')
    assert sveltos_template.read(), "sveltos resource template not created"

    show_step(7)
    # TODO(va4st): make configurable through settings and add parameters verification before testrun
    config = ns.get_cluster_config(provider='gcp-hosted',
                                   project=project,
                                   network_name=network_name,
                                   region=region)

    show_step(8)
    cld = ns.create_cluster_deployment(name=cluster_name,
                                       template=clustertemplate,
                                       credential=cred,
                                       config=config)
    LOG.info(f"Created clusterdeployment {cld.namespace}/{cld.name}")

    show_step(9)
    cld.check.check_cluster_readiness(expected_condition_cld_fails={'Paused': ''})

    show_step(10)
    cld.check.check_k8s_nodes()

    show_step(11)
    if cld_manager.kof.dns_backend == 'manual':
        corefile = k8s_utils.get_corefile(cld_manager.api)
        k8s_utils.override_coredns_configmap(cld.k8sclient, corefile)
        coredns_deployment = cld.k8sclient.deployments.get(name='coredns', namespace='kube-system')
        coredns_deployment.rollout_restart()

    show_step(12)
    cld.check.check_k8s_pods()
    cld.check.check_actual_expected_pods()
