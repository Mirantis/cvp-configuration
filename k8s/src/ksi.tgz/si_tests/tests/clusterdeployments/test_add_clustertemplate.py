from si_tests import settings
from si_tests import logger

LOG = logger.logger


def test_add_clustertemplate(kcm_manager, show_step):
    """Add ClusterTemplate object from a Jinja2 template

    Scenario:
        1. Create or get NS
        2. Create ClusterTemplate
    """
    show_step(1)
    namespace_name = settings.KCM_CLUSTER_DEPLOYMENT_NAMESPACE
    ns = kcm_manager.get_or_create_namespace(namespace_name)

    show_step(2)
    assert settings.CUSTOM_CLUSTERTEMPLATE_PATH
    ns.create_cluster_template_from_file(settings.CUSTOM_CLUSTERTEMPLATE_PATH)
