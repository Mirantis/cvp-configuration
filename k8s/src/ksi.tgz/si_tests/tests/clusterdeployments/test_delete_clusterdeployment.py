from si_tests import settings
from si_tests import logger

LOG = logger.logger


def test_delete_clusterdeployment(kcm_manager, show_step):
    """Check removal of the clusterdeployment

    Scenario:
        1. Gather evnironment config
        3. Remove clusterdeployment and wait for deletion
    """

    show_step(1)
    ns = kcm_manager.get_namespace(settings.TARGET_NAMESPACE)
    cld = ns.get_cluster_deployment(settings.TARGET_CLD)

    show_step(2)
    cld.check.delete_clusterdeployment_and_check()
    LOG.info(f"ClusterDeployment {cld.namespace}/{cld.name} successfully removed.")
