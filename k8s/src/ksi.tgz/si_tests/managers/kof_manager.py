#    Copyright 2025 Mirantis, Inc.
#
#    Licensed under the Apache License, Version 2.0 (the "License"); you may
#    not use this file except in compliance with the License. You may obtain
#    a copy of the License at
#
#         http://www.apache.org/licenses/LICENSE-2.0
#
#    Unless required by applicable law or agreed to in writing, software
#    distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
#    WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
#    License for the specific language governing permissions and limitations
#    under the License.

import base64
import json
import tempfile
import yaml

from si_tests import settings
from si_tests import logger
from si_tests.utils import utils, exceptions

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from si_tests.managers.kcm_manager import Manager

LOG = logger.logger


class KOFManager(object):
    """KOF installation manager"""

    def __init__(self, kcm_manager: "Manager"):
        self.kcm_manager: "Manager" = kcm_manager
        self._helmmgr = None
        self._kof_version = None
        self._expected_pods_path = None
        self._cld_expected_pods_path = None

    @property
    def helmmgr(self):
        if not self._helmmgr:
            self._helmmgr = self.kcm_manager.helmmgr
        return self._helmmgr

    @property
    def kof_version(self):
        """Return kof version based on installed charts
        :return:
        """
        # NOTE(va4st): Assuming that all kof components have same versions. As a base take kof-operators as first
        # kof chart installed into cluster.
        if not self._kof_version:
            if self.is_kof_operators_present():
                self._kof_version = self.get_kof_operators_chart_metadata()['version']
            elif self.kcm_manager.condition.oss_1_4_0_and_lower() and self.is_kof_istio_present():
                self._kof_version = self.get_kof_istio_chart_metadata()['version']
            else:
                LOG.warning("No installed kof version found. Using static versioning.")
                self._kof_version = settings.KSI_KOF_CHART_VERSION
        return self._kof_version

    @property
    def template_path(self):
        """Return kof expected pods template based on helm version
        :return:
        """
        if not self._expected_pods_path:
            name = f"kof-{self.kof_version.replace('.', '-')}"
            path_prefix = ['kof/']
            self._expected_pods_path = utils.discover_and_check_expected_pods_template_path(name, path_prefix)
        return self._expected_pods_path

    @property
    def cld_template_path(self):
        """Return kof expected pods template based on helm version that will be used in clusterdeployments
        :return:
        """
        if not self._cld_expected_pods_path:
            name = f"kof-cld-{self.kof_version.replace('.', '-')}"
            path_prefix = ['kof/']
            self._cld_expected_pods_path = utils.discover_and_check_expected_pods_template_path(name, path_prefix)
        return self._cld_expected_pods_path

    @property
    def dns_backend(self):
        """Return kof deployment dns backend based on installed charts and values
        :return:
        """
        if self.kof_ms_deployed():
            if self.kof_is_deployed():
                return 'istio'
            elif self.is_auto_dns_enabled():
                return 'auto-dns'
            else:
                return 'manual'
        return None

    def is_kof_operators_installed(self):
        """Verify that required CRD (opentelemetry) present"""
        return True if self.kcm_manager.api.opentelemetry_collectors.available else False

    def is_kof_operators_present(self, verbose=False) -> bool:
        """Verify that kof-operators HR persists in cluster"""
        return self.helmmgr.is_release_present(settings.KSI_KOF_OP_CHART_NAME, verbose)

    def is_kof_mothership_present(self, verbose=False) -> bool:
        """Verify that kof-mothership HR persists in cluster"""
        return self.helmmgr.is_release_present(settings.KSI_KOF_MS_CHART_NAME, verbose)

    def is_kof_regional_present(self, verbose=False) -> bool:
        """Verify that kof-regional HR persists in cluster"""
        return self.helmmgr.is_release_present(settings.KSI_KOF_RE_CHART_NAME, verbose)

    def is_kof_child_present(self, verbose=False) -> bool:
        """Verify that kof-child HR persists in cluster"""
        return self.helmmgr.is_release_present(settings.KSI_KOF_CH_CHART_NAME, verbose)

    def is_kof_istio_present(self, verbose=False) -> bool:
        """Verify that kof-istio HR persists in cluster"""
        return self.helmmgr.is_release_present(settings.KSI_KOF_IS_CHART_NAME, verbose)

    def is_kof_collectors_present(self, verbose=False) -> bool:
        """Verify that kof-istio HR persists in cluster"""
        return self.helmmgr.is_release_present(settings.KSI_KOF_CO_CHART_NAME, verbose)

    def kof_op_deployed(self) -> bool:
        """Verify that kof-operators chart deployed"""
        return True if self.get_kof_operators_chart_status() == 'deployed' else False

    def kof_ms_deployed(self) -> bool:
        """Verify that kof-mothership chart deployed"""
        return True if self.get_kof_mothership_chart_status() == 'deployed' else False

    def kof_re_deployed(self) -> bool:
        """Verify that kof-regional chart deployed"""
        return True if self.get_kof_regional_chart_status() == 'deployed' else False

    def kof_ch_deployed(self) -> bool:
        """Verify that kof-child chart deployed"""
        return True if self.get_kof_child_chart_status() == 'deployed' else False

    def kof_is_deployed(self) -> bool:
        """Verify that kof-istio chart deployed"""
        return True if self.get_kof_istio_chart_status() == 'deployed' else False

    def kof_co_deployed(self) -> bool:
        """Verify that kof-collectors chart deployed"""
        return True if self.get_kof_collectors_chart_status() == 'deployed' else False

    def get_kof_operators_chart_status(self, verbose=False):
        meta = self.get_kof_operators_chart_metadata()
        if not meta:
            return None
        status = meta.get('status', None)
        if verbose:
            LOG.info(f"{settings.KSI_KOF_OP_CHART_NAME} chart status is {status}")
        return status

    def get_kof_operators_chart_metadata(self):
        if self.helmmgr.is_release_present(settings.KSI_KOF_OP_CHART_NAME):
            return self.helmmgr.get_metadata(settings.KSI_KOF_OP_CHART_NAME, settings.KSI_KOF_NAMESPACE)
        else:
            return None

    def get_kof_mothership_chart_status(self, verbose=False):
        meta = self.get_kof_mothership_chart_metadata()
        if not meta:
            return None
        status = meta.get('status', None)
        if verbose:
            LOG.info(f"{settings.KSI_KOF_MS_CHART_NAME} chart status is {status}")
        return status

    def get_kof_mothership_chart_metadata(self):
        if self.helmmgr.is_release_present(settings.KSI_KOF_MS_CHART_NAME):
            return self.helmmgr.get_metadata(settings.KSI_KOF_MS_CHART_NAME, settings.KSI_KOF_NAMESPACE)
        else:
            return {}

    def get_mothership_deployed_values(self):
        if self.helmmgr.is_release_present(settings.KSI_KOF_MS_CHART_NAME):
            return self.helmmgr.get_release_values(settings.KSI_KOF_MS_CHART_NAME, settings.KSI_KOF_NAMESPACE)
        else:
            return {}

    def get_kof_regional_chart_status(self, verbose=False):
        meta = self.get_kof_regional_chart_metadata()
        if not meta:
            return None
        status = meta.get('status', None)
        if verbose:
            LOG.info(f"{settings.KSI_KOF_RE_CHART_NAME} chart status is {status}")
        return status

    def get_kof_regional_chart_metadata(self):
        if self.helmmgr.is_release_present(settings.KSI_KOF_RE_CHART_NAME):
            return self.helmmgr.get_metadata(settings.KSI_KOF_RE_CHART_NAME, settings.KSI_KOF_NAMESPACE)
        else:
            return {}

    def get_kof_istio_chart_status(self, verbose=False):
        meta = self.get_kof_istio_chart_metadata()
        if not meta:
            return None
        status = meta.get('status', None)
        if verbose:
            LOG.info(f"{settings.KSI_KOF_IS_CHART_NAME} chart status is {status}")
        return status

    def get_kof_collectors_chart_metadata(self):
        if self.helmmgr.is_release_present(settings.KSI_KOF_CO_CHART_NAME):
            return self.helmmgr.get_metadata(settings.KSI_KOF_CO_CHART_NAME, settings.KSI_KOF_NAMESPACE)
        else:
            return {}

    def get_kof_collectors_chart_status(self, verbose=False):
        meta = self.get_kof_collectors_chart_metadata()
        if not meta:
            return None
        status = meta.get('status', None)
        if verbose:
            LOG.info(f"{settings.KSI_KOF_CO_CHART_NAME} chart status is {status}")
        return status

    def get_kof_istio_chart_metadata(self):
        if self.helmmgr.is_release_present(settings.KSI_KOF_IS_CHART_NAME):
            return self.helmmgr.get_metadata(settings.KSI_KOF_IS_CHART_NAME, settings.KSI_KOF_ISTIO_NAMESPACE)
        else:
            return {}

    def get_kof_child_chart_status(self, verbose=False):
        meta = self.get_kof_child_chart_metadata()
        if not meta:
            return None
        status = meta.get('status', None)
        if verbose:
            LOG.info(f"{settings.KSI_KOF_CH_CHART_NAME} chart status is {status}")
        return status

    def get_kof_child_chart_metadata(self):
        if self.helmmgr.is_release_present(settings.KSI_KOF_CH_CHART_NAME):
            return self.helmmgr.get_metadata(settings.KSI_KOF_CH_CHART_NAME, settings.KSI_KOF_NAMESPACE)
        else:
            return {}

    def get_airgapped_image_versions(self):
        """Pinning versions for airgap deployments

        This func designed to achieve compatibility of ksi functions with different kof versions since few
        dependent charts have no separated tag variables for images and should be set through values

        SBOM example where to search specific image:
        https://get.mirantis.com/k0rdent-enterprise/1.2.0-rc7/full_images_list.txt
        """
        if self.kcm_manager.condition.kof_1_1_0_series():
            versions = {
                'helm': '3.14.0',

            }
        elif self.kcm_manager.condition.kof_1_5_0_series():
            versions = {
                'helm': '3.14.0',
                'target-allocator': 'v0.140.0',
                'k8s-sidecar': '2.1.4'
            }
        else:
            raise exceptions.UnsupportedKOFVersion(version=self.kof_version)
        LOG.info(f"KSI pinned kof {self.kof_version} image versions:\n{yaml.dump(versions)}")
        return versions

    def get_global_values(self, registry, reg_ca_secret=None):
        """Get global repository values for kof charts installation"""
        imgs = self.get_airgapped_image_versions()

        values = {
            'global': {
                'registry': registry,
                'imageRegistry': registry,
                'image': {
                    'registry': registry,
                },
                'hub': f"{registry}/istio",
                'helmChartsRepo': f"oci://{registry}/charts"
            },
            'cert-manager-istio-csr': {
                'image': {
                    'repository': f"{registry}/jetstack/cert-manager-istio-csr"
                }
            },
            'cert-manager-service-template': {
                'verifyJobImage': f"{registry}/alpine/helm:{imgs['helm']}",
                'repo': {
                    'url': f"oci://{registry}/charts"
                }
            },
            'ingress-nginx-service-template': {
                'verifyJobImage': f"{registry}/alpine/helm:{imgs['helm']}",
                'repo': {
                    'url': f"oci://{registry}/charts"
                }
            },
            'cluster-api-visualizer': {
                'image': {
                    'repository': registry,
                }
            },
            'grafana-operator': {
                'image': {
                    'repository': f"{registry}/grafana/grafana-operator"
                }
            },
            'external-dns': {
                'image': {
                    'repository': f"{registry}/external-dns/external-dns"
                }
            },
            'jaeger-operator': {
                'image': {
                    'repository': f"{registry}/jaegertracing/jaeger-operator"
                }
            },
            'opencost': {
                'opencost': {
                    'exporter': {
                        'image': {
                            'registry': registry
                        }
                    },
                    'ui': {
                        'image': {
                            'registry': registry
                        }
                    }
                }
            },
            'opentelemetry-operator': {
                'manager': {
                    'image': {
                        'repository': f"{registry}/opentelemetry-operator/opentelemetry-operator"
                    },
                    'collectorImage': {
                        'repository': f"{registry}/otel/opentelemetry-collector-contrib"
                    }
                },
                'kubeRBACProxy': {
                    'image': {
                        'repository': f"{registry}/brancz/kube-rbac-proxy"
                    }
                }
            },
            'storage': {
                'cert-manager': {
                    'cluster-issuer': {
                        'provider': 'self-signed'
                    }
                }
            },
            'kcm': {
                'kof': {
                    'operator': {
                        'image': {
                            'repository': 'kof/kof-operator-controller'
                        }
                    },
                    'repo': {
                        'spec': {
                            'url': f"oci://{registry}/charts"
                        }
                    }
                }
            }
        }
        if reg_ca_secret:
            ref = {
                'name': reg_ca_secret
            }
            values['cert-manager-service-template']['repo']['certSecretRef'] = ref
            values['ingress-nginx-service-template']['repo']['certSecretRef'] = ref
            values['kcm']['kof']['repo']['spec']['certSecretRef'] = ref

        if self.kcm_manager.condition.kof_1_2_0_and_above():
            kube_otel_values = {
                "cleanupJob": {
                    "image": {
                        "repository": f"{registry}/bitnami/kubectl"
                    }
                },
                "collectors": {
                    "target-allocator": {
                        "targetAllocator": {
                            "image": f"{registry}/opentelemetry-operator/target-allocator:{imgs['target-allocator']}"
                        }
                    },
                    "daemon": {
                        "image": {
                            "repository": f"{registry}/kof/kof-opentelemetry-collector-contrib"
                        }
                    }
                },
                "kube-state-metrics": {
                    "initContainers": [
                        {
                            "image": f"{registry}/kiwigrid/k8s-sidecar:{imgs['k8s-sidecar']}"
                        }
                    ],
                    "containers": [
                        {
                            "image": f"{registry}/kiwigrid/k8s-sidecar:{imgs['k8s-sidecar']}"
                        }
                    ]
                },

            }
            values['opentelemetry-kube-stack'] = kube_otel_values
        return values

    @staticmethod
    def get_mothership_values(install_templates=True,
                              storage_class=None,
                              auto_dns=None,
                              dns_secret_name=None):

        def get_dns_dict(profile, secret):
            dns_dict = {
                'kof': {
                    'clusterProfiles': {
                        profile: {
                            'matchLabels': {
                                f"k0rdent.mirantis.com/{profile}": "true"
                            },
                            'secrets': [
                                secret
                            ]
                        }
                    }
                }
            }
            return dns_dict

        values = {
            'kcm': {
                'installTemplates': install_templates
            },
            'victoria-metrics-operator': {
                'crds': {
                    'cleanup': {
                        'enabled': True
                    }
                }
            }
        }

        if settings.KSI_KOF_SOURCE not in ['enterprise', 'custom-enterprise']:
            chunk = {
                'repository': settings.KSI_KOF_OSS_VICTORIA_CLEANUP_IMAGE_REPO
            }
            values['victoria-metrics-operator']['crds']['cleanup']['image'] = chunk

        if storage_class:
            values['global']['storageClass'] = storage_class

        auto_dns_config = ''
        if auto_dns == 'aws':
            auto_dns_config = get_dns_dict('kof-aws-dns-secrets', dns_secret_name)
        elif auto_dns == 'azure':
            auto_dns_config = get_dns_dict('kof-azure-dns-secrets', dns_secret_name)

        if auto_dns_config:
            values['kcm']['kof'] = auto_dns_config['kof']

        LOG.info(f"kof-mothership values:\n{yaml.dump(values)}")

        return values

    def is_auto_dns_enabled(self):
        """Check if auto-dns is enabled in kof-mothership deployed values
        :return: bool
        """
        vals = self.get_mothership_deployed_values()
        dns_marks = ['kof-aws-dns-secrets', 'kof-azure-dns-secrets', 'kof-openstack-dns-secrets']
        for mark in dns_marks:
            if vals.get('kof', {}).get('clusterProfiles', {}).get(mark, None):
                return True
        return False

    @staticmethod
    def mothership_custom_repo_chunk(custom_repo):
        custom_repo_val = {
            'cert-manager-service-template': {
                'helm': {
                    'repository': {
                        'name': 'cert-manager',
                        'url': f"oci://{custom_repo}/charts",
                        'type': 'oci'
                    },
                    'charts': [
                        {
                            'name': 'cert-manager',
                            'version': 'v1.17.2'
                        }
                    ]
                },
                'namespace': 'kcm-system'
            }
        }
        return custom_repo_val

    def get_kof_collectors_values(self, mesh=None, value=None, insecure=False):
        """Get values for kof-collectors chart deployment
        It's different values for Istio and all other variants

        :param insecure:
        :param mesh: Istio or anything else
        :param value: In case of Istio - this is regional cluster name. In any other case - domain
        :return:
        """

        if mesh == 'istio':
            values = {
                'kcm': {
                    # always enable monitoring for kcm
                    'monitoring': True
                },
                'opencost': {
                    'opencost': {
                        'prometheus': {
                            'existingSecretName': "",
                            'external': {
                                'url': f"http://{value}-vmselect:8481/select/0/prometheus"
                            }
                        }
                    }
                }
            }
            if not self.kcm_manager.condition.kof_1_2_0_and_above():
                # NOTE(va4st): kof < 1.2.0 (including enterprise 1.1.0)
                kof_chunk = {
                    'basic_auth': False,
                    'logs': {
                        'endpoint': f"http://{value}-logs-insert:9481/insert/opentelemetry/v1/logs"
                    },
                    'metrics': {
                        'endpoint': f"http://{value}-vminsert:8480/insert/0/prometheus/api/v1/write"
                    },
                    'traces': {
                        'endpoint': f"http://{value}-jaeger-collector:4318"
                    }
                }
                values['kof'] = kof_chunk

            # NOTE(va4st): It's intended to have different conditions. in case of future changes - the new condition
            # should be added to gather resulted values. If the keys from previous conditional version will be used -
            # utils.merge_dicts should resolve the problem. However, if exact keys will be used - it needs to be
            # overridden.
            if self.kcm_manager.condition.kof_1_2_0_and_above():
                # NOTE(va4st): kof >= 1.2.0 (including enterprise 1.2.0+)
                otel_stack = {
                    "clusterName": "mothership",
                    "defaultCRConfig": {
                        "config": {
                            "processors": {
                                "resource/k8sclustername": {
                                    "attributes": [
                                        {
                                            "action": "insert",
                                            "key": "k8s.cluster.name",
                                            "value": "mothership"
                                        },
                                        {
                                            "action": "insert",
                                            "key": "k8s.cluster.namespace",
                                            "value": "kcm-system"
                                        }
                                    ]
                                }
                            },
                            "exporters": {
                                "prometheusremotewrite": {
                                    "endpoint": f"http://{value}-vminsert:8480/insert/0/prometheus/api/v1/write",
                                    "external_labels": {
                                        "cluster": "mothership",
                                        "clusterNamespace": "kcm-system"
                                    }
                                },
                                "otlphttp/logs": {
                                    "logs_endpoint": f"http://{value}-logs-insert:9481/insert/opentelemetry/v1/logs"
                                },
                                "otlphttp/traces": {
                                    "endpoint": f"http://{value}-jaeger-collector:4318"
                                }
                            }
                        }
                    }
                }
                values['opentelemetry-kube-stack'] = otel_stack
        else:
            values = {
                'kcm': {
                    # always enable monitoring for kcm
                    'monitoring': True
                },
                'opencost': {
                    'opencost': {
                        'prometheus': {
                            'external': {
                                'url': f"https://vmauth.{value}/vm/select/0/prometheus"
                            }
                        }
                    }
                }
            }
            if not self.kcm_manager.condition.kof_1_2_0_and_above():
                kof_chunk = {
                    'logs': {
                        'endpoint': f"https://vmauth.{value}/vls/insert/opentelemetry/v1/logs"
                    },
                    'metrics': {
                        'endpoint': f"https://vmauth.{value}/vm/insert/0/prometheus/api/v1/write"
                    },
                    'traces': {
                        'endpoint': f"https://jaeger.{value}/collector"
                    }
                }
                values['kof'] = kof_chunk

            if self.kcm_manager.condition.kof_1_2_0_and_above():
                otel_stack = {
                    "clusterName": "mothership",
                    "defaultCRConfig": {
                        "env": [
                            {
                                "name": "KOF_VM_USER",
                                "valueFrom": {
                                    "secretKeyRef": {
                                        "key": "username",
                                        "name": "storage-vmuser-credentials"
                                    }
                                }
                            },
                            {
                                "name": "KOF_VM_PASSWORD",
                                "valueFrom": {
                                    "secretKeyRef": {
                                        "key": "password",
                                        "name": "storage-vmuser-credentials"
                                    }
                                }
                            },
                            {
                                "name": "KOF_JAEGER_USER",
                                "valueFrom": {
                                    "secretKeyRef": {
                                        "key": "username",
                                        "name": "jaeger-admin-credentials"
                                    }
                                }
                            },
                            {
                                "name": "KOF_JAEGER_PASSWORD",
                                "valueFrom": {
                                    "secretKeyRef": {
                                        "key": "password",
                                        "name": "jaeger-admin-credentials"
                                    }
                                }
                            }
                        ],
                        "config": {
                            "processors": {
                                "resource/k8sclustername": {
                                    "attributes": [
                                        {
                                            "action": "insert",
                                            "key": "k8s.cluster.name",
                                            "value": "mothership"
                                        },
                                        {
                                            "action": "insert",
                                            "key": "k8s.cluster.namespace",
                                            "value": "kcm-system"
                                        }
                                    ]
                                }
                            },
                            "extensions": {
                                "basicauth/metrics": {
                                    "client_auth": {
                                        "username": "${env:KOF_VM_USER}",
                                        "password": "${env:KOF_VM_PASSWORD}"
                                    }
                                },
                                "basicauth/logs": {
                                    "client_auth": {
                                        "username": "${env:KOF_VM_USER}",
                                        "password": "${env:KOF_VM_PASSWORD}"
                                    }
                                },
                                "basicauth/traces": {
                                    "client_auth": {
                                        "username": "${env:KOF_JAEGER_USER}",
                                        "password": "${env:KOF_JAEGER_PASSWORD}"
                                    }
                                }
                            },
                            "exporters": {
                                "prometheusremotewrite": {
                                    "endpoint": f"https://vmauth.{value}/vm/insert/0/prometheus/api/v1/write",
                                    "auth": {
                                        "authenticator": "basicauth/metrics"
                                    },
                                    "external_labels": {
                                        "cluster": "mothership",
                                        "clusterNamespace": "kcm-system"
                                    }
                                },
                                "otlphttp/logs": {
                                    "logs_endpoint": f"https://vmauth.{value}/vli/insert/opentelemetry/v1/logs",
                                    "auth": {
                                        "authenticator": "basicauth/logs"
                                    }
                                },
                                "otlphttp/traces": {
                                    "endpoint": f"https://jaeger.{value}/collector",
                                    "auth": {
                                        "authenticator": "basicauth/traces"
                                    }
                                }
                            },
                            "service": {
                                "extensions": [
                                    "basicauth/metrics",
                                    "basicauth/logs",
                                    "basicauth/traces"
                                ]
                            }
                        }
                    },
                    "collectors": {
                        "daemon": {
                            "config": {
                                "service": {
                                    "extensions": [
                                        "basicauth/metrics",
                                        "basicauth/logs",
                                        "basicauth/traces",
                                        "k8s_observer",
                                        "file_storage/filelogreceiver",
                                        "file_storage/filelogsyslogreceiver",
                                        "file_storage/filelogk8sauditreceiver",
                                        "file_storage/journaldreceiver"
                                    ]
                                }
                            }
                        }
                    },
                    "cleanupJob": {
                        "image": {
                            "repository": settings.KSI_KOF_OSS_VICTORIA_CLEANUP_IMAGE_REPO
                        }
                    }
                }
                values['opentelemetry-kube-stack'] = otel_stack

        if insecure:
            if not self.kcm_manager.condition.kof_1_2_0_and_above():
                tls_opts = {
                    'kof': {
                        'logs': {
                            "tls_options": {
                                "insecure_skip_verify": True
                            }
                        },
                        'metrics': {
                            "tls_options": {
                                "insecure_skip_verify": True
                            }
                        },
                        'traces': {
                            "tls_options": {
                                "insecure_skip_verify": True
                            }
                        }
                    }
                }
                utils.merge_dicts(values, tls_opts)
            elif self.kcm_manager.condition.kof_1_2_0_and_above():
                values['opencost']['opencost']['prometheus']['insecureSkipVerify'] = True
                tls_values = {
                    "insecure_skip_verify": True
                }
                values['opentelemetry-kube-stack']['defaultCRConfig']['config']['exporters']['prometheusremotewrite'][
                    'tls'] = tls_values
                values['opentelemetry-kube-stack']['defaultCRConfig']['config']['exporters']['otlphttp/logs'][
                    'tls'] = tls_values
                values['opentelemetry-kube-stack']['defaultCRConfig']['config']['exporters']['otlphttp/traces'][
                    'tls'] = tls_values

        return values

    def install_named_kof_chart(self, chart_name, chart_namespace, values=None, source=None, custom_registry=None):
        ep_values = None
        if not source:
            source = settings.KSI_KOF_SOURCE
        cert_data = None

        if source == 'enterprise':
            registry = settings.KSI_KOF_REPO_DICT['enterprise-repo']
        elif source == 'custom-enterprise':
            kcm_helmrepo = self.kcm_manager.api.helmrepositories.get(
                settings.KSI_KCM_TEMPLATES_REPO_NAME, settings.KSI_KCM_NAMESPACE)
            if not custom_registry:
                custom_registry = settings.KSI_KOF_CUSTOM_REGISTRY or kcm_helmrepo.url_raw
            assert custom_registry, ('KSI_KOF_CUSTOM_REGISTRY can not be empty with '
                                     'KSI_KOF_SOURCE=custom-enterprise')
            registry = custom_registry
            cert_secret_name = self.kcm_manager.mgmt.cert_secret_name
            if cert_secret_name:
                LOG.warning(f"Automated gathering cert data from secret {cert_secret_name}")
                cert_secret = self.kcm_manager.api.secrets.get(name=cert_secret_name,
                                                               namespace=settings.KSI_KCM_NAMESPACE)
                cert_data = base64.b64decode(cert_secret.read().data['ca.crt']).decode("utf-8")
            else:
                LOG.warning("No cert secret name found in management object. Assuming no certs needed for registry.")
            ep_values = self.get_global_values(registry, reg_ca_secret=cert_secret_name)
        else:
            registry = settings.KSI_KOF_REPO_DICT['oss-repo']

        if values and ep_values:
            utils.merge_dicts(values, ep_values)
        elif ep_values:
            values = ep_values

        if values:
            LOG.info(f"Values for {chart_name} installation: \n{yaml.dump(values)}")
        else:
            LOG.info(f"No values for {chart_name} provided. Using defaults.")

        chart_path = f"oci://{registry}/charts/{chart_name}"

        if values:
            with tempfile.NamedTemporaryFile(mode="w") as values_path:
                yaml.dump(values, values_path)
                self.helmmgr.install_chart(chart_name=chart_name,
                                           chart_path=chart_path,
                                           version=settings.KSI_KOF_CHART_VERSION,
                                           values_path=[values_path.name],
                                           namespace=chart_namespace,
                                           source=source,
                                           cert_text=cert_data)
        else:
            self.helmmgr.install_chart(chart_name=chart_name,
                                       chart_path=chart_path,
                                       version=settings.KSI_KOF_CHART_VERSION,
                                       namespace=chart_namespace,
                                       source=source)

    def install_kof_istio(self, source=None):
        if self.is_kof_istio_present():
            LOG.info(f"{settings.KSI_KOF_IS_CHART_NAME} chart already present in cluster")
            return
        self.install_named_kof_chart(settings.KSI_KOF_IS_CHART_NAME, settings.KSI_KOF_ISTIO_NAMESPACE, source=source)

    def uninstall_kof_istio(self):
        if not self.is_kof_istio_present():
            LOG.info(f"{settings.KSI_KOF_IS_CHART_NAME} chart not exist in cluster")
            return
        self.helmmgr.delete_chart(chart_name=settings.KSI_KOF_IS_CHART_NAME,
                                  namespace=settings.KSI_KOF_ISTIO_NAMESPACE,
                                  cascade='foreground')

    def install_kof_collectors(self, values=None, source=None):
        if self.is_kof_collectors_present():
            LOG.info(f"{settings.KSI_KOF_CO_CHART_NAME} chart already present in cluster")
            return
        self.install_named_kof_chart(settings.KSI_KOF_CO_CHART_NAME, settings.KSI_KOF_NAMESPACE,
                                     values=values, source=source)

    def uninstall_kof_collectors(self):
        if not self.is_kof_collectors_present():
            LOG.info(f"{settings.KSI_KOF_CO_CHART_NAME} chart not exist in cluster")
            return
        self.helmmgr.delete_chart(chart_name=settings.KSI_KOF_CO_CHART_NAME,
                                  namespace=settings.KSI_KOF_NAMESPACE,
                                  cascade='foreground')

    def install_kof_operators(self, source=None):
        if self.is_kof_operators_present():
            LOG.info(f"{settings.KSI_KOF_OP_CHART_NAME} chart already present in cluster")
            return
        self.install_named_kof_chart(settings.KSI_KOF_OP_CHART_NAME, settings.KSI_KOF_NAMESPACE, source=source)

    def uninstall_kof_operators(self):
        if not self.is_kof_operators_present():
            LOG.info(f"{settings.KSI_KOF_OP_CHART_NAME} chart not exist in cluster")
            return
        self.helmmgr.delete_chart(chart_name=settings.KSI_KOF_OP_CHART_NAME,
                                  namespace=settings.KSI_KOF_NAMESPACE,
                                  cascade='foreground')

    def install_kof_mothership(self, values=None, source=None):
        if self.is_kof_mothership_present():
            LOG.info(f"{settings.KSI_KOF_MS_CHART_NAME} chart already present in cluster")
            return
        self.install_named_kof_chart(settings.KSI_KOF_MS_CHART_NAME, settings.KSI_KOF_NAMESPACE,
                                     values=values, source=source)

    def uninstall_kof_mothership(self):
        if not self.is_kof_mothership_present():
            LOG.info(f"{settings.KSI_KOF_MS_CHART_NAME} chart not present in cluster")
            return
        self.helmmgr.delete_chart(chart_name=settings.KSI_KOF_MS_CHART_NAME,
                                  namespace=settings.KSI_KOF_NAMESPACE,
                                  cascade='foreground')

    def install_kof_regional(self, values=None, source=None):
        if self.is_kof_regional_present():
            LOG.info(f"{settings.KSI_KOF_RE_CHART_NAME} chart already present in cluster")
            return
        self.install_named_kof_chart(settings.KSI_KOF_RE_CHART_NAME, settings.KSI_KOF_NAMESPACE,
                                     values=values, source=source)

    def uninstall_kof_regional(self):
        if not self.is_kof_regional_present():
            LOG.info(f"{settings.KSI_KOF_RE_CHART_NAME} chart not present in cluster")
            return
        self.helmmgr.delete_chart(chart_name=settings.KSI_KOF_RE_CHART_NAME,
                                  namespace=settings.KSI_KOF_NAMESPACE,
                                  cascade='foreground')

    def install_kof_child(self, values=None, source=None):
        if self.is_kof_child_present():
            LOG.info(f"{settings.KSI_KOF_CH_CHART_NAME} chart already present in cluster")
            return
        self.install_named_kof_chart(settings.KSI_KOF_CH_CHART_NAME, settings.KSI_KOF_NAMESPACE,
                                     values=values, source=source)

    def uninstall_kof_child(self):
        if not self.is_kof_child_present():
            LOG.info(f"{settings.KSI_KOF_CH_CHART_NAME} chart not present in cluster")
            return
        self.helmmgr.delete_chart(chart_name=settings.KSI_KOF_CH_CHART_NAME,
                                  namespace=settings.KSI_KOF_NAMESPACE,
                                  cascade='foreground')

    def get_child_labels(self):
        if self.kof_ms_deployed():
            child_labels = {
                'k0rdent.mirantis.com/kof-cluster-role': 'child'
            }
            if self.kof_is_deployed():
                # update specific labels for Istio regional
                labels = {
                    'k0rdent.mirantis.com/istio-role': 'child'
                }
            else:
                labels = {
                    'k0rdent.mirantis.com/kof-storage-secrets': 'true'
                }
            utils.merge_dicts(child_labels, labels)
            return child_labels
        else:
            return None

    def get_child_annotations(self):
        annotations = {}
        if self.dns_backend == 'manual':
            if not self.kcm_manager.condition.kof_1_2_0_and_above():
                coll_object = {
                    "kof": {
                        "logs": {
                            "tls_options": {
                                "insecure_skip_verify": True
                            }
                        },
                        "metrics": {
                            "tls_options": {
                                "insecure_skip_verify": True
                            }
                        },
                        "traces": {
                            "tls_options": {
                                "insecure_skip_verify": True
                            }
                        }
                    }
                }
            else:
                coll_object = {
                    "opencost": {
                        "opencost": {
                            "prometheus": {
                                "insecureSkipVerify": True
                            }
                        }
                    },
                    "opentelemetry-kube-stack": {
                        "defaultCRConfig": {
                            "config": {
                                "exporters": {
                                    "prometheusremotewrite": {
                                        "tls": {
                                            "insecure_skip_verify": True
                                        }
                                    },
                                    "otlphttp/logs": {
                                        "tls": {
                                            "insecure_skip_verify": True
                                        }
                                    },
                                    "otlphttp/traces": {
                                        "tls": {
                                            "insecure_skip_verify": True
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            annotations = {
                "k0rdent.mirantis.com/kof-collectors-values": json.dumps(coll_object, indent=2)
            }
        return annotations

    @staticmethod
    def get_regional_config(storageclass=None):
        body = {
        }
        if storageclass:
            sc_chunk = {
                'k0rdent.mirantis.com/kof-storage-class': storageclass
            }
            body['clusterAnnotations'] = sc_chunk
        return body

    def get_regional_labels(self):
        regional_labels = {
            'k0rdent.mirantis.com/kof-cluster-role': 'regional'
        }
        if self.kof_is_deployed():
            # for Istio - regional or child role == child due different contexts
            labels = {
                'k0rdent.mirantis.com/istio-role': 'child'
            }
            utils.merge_dicts(regional_labels, labels)
        else:
            # any other regional having these values
            labels = {
                'k0rdent.mirantis.com/kof-storage-secrets': 'true'
            }
            utils.merge_dicts(regional_labels, labels)
        return regional_labels

    def get_regional_annotations(self, domain):
        annotations = None
        if not self.kof_is_deployed():
            annotations = {
                'clusterAnnotations': {
                    'k0rdent.mirantis.com/kof-regional-domain': domain,
                    'k0rdent.mirantis.com/kof-cert-email': settings.KSI_KOF_EMAIL
                }
            }
        return annotations
