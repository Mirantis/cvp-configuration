# flake8: noqa

# import apis into api package
from si_tests.clients.gcore.box_api.api.api_keys_api import APIKeysApi
from si_tests.clients.gcore.box_api.api.apps_api import AppsApi
from si_tests.clients.gcore.box_api.api.audit_logs_api import AuditLogsApi
from si_tests.clients.gcore.box_api.api.autodiscovery_api import AutodiscoveryApi
from si_tests.clients.gcore.box_api.api.capacity_api import CapacityApi
from si_tests.clients.gcore.box_api.api.dashboard_api import DashboardApi
from si_tests.clients.gcore.box_api.api.flavors_api import FlavorsApi
from si_tests.clients.gcore.box_api.api.inferences_api import InferencesApi
from si_tests.clients.gcore.box_api.api.jupyter_lab_api import JupyterLabApi
from si_tests.clients.gcore.box_api.api.metrics_api import MetricsApi
from si_tests.clients.gcore.box_api.api.namespaces_api import NamespacesApi
from si_tests.clients.gcore.box_api.api.node_groups_api import NodeGroupsApi
from si_tests.clients.gcore.box_api.api.nodes_api import NodesApi
from si_tests.clients.gcore.box_api.api.pods_api import PodsApi
from si_tests.clients.gcore.box_api.api.projects_api import ProjectsApi
from si_tests.clients.gcore.box_api.api.pull_secrets_api import PullSecretsApi
from si_tests.clients.gcore.box_api.api.quotas_api import QuotasApi
from si_tests.clients.gcore.box_api.api.regions_api import RegionsApi
from si_tests.clients.gcore.box_api.api.registries_api import RegistriesApi
from si_tests.clients.gcore.box_api.api.registry_users_api import RegistryUsersApi
from si_tests.clients.gcore.box_api.api.secrets_api import SecretsApi
from si_tests.clients.gcore.box_api.api.slurm_api import SlurmApi
from si_tests.clients.gcore.box_api.api.tls_secrets_api import TLSSecretsApi
from si_tests.clients.gcore.box_api.api.user_groups_api import UserGroupsApi
from si_tests.clients.gcore.box_api.api.users_api import UsersApi
from si_tests.clients.gcore.box_api.api.volumes_api import VolumesApi

