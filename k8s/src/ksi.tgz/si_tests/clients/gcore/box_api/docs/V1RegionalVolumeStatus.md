# V1RegionalVolumeStatus


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**status** | **str** | Status is the volume status in a given region, e.g. \&quot;Active\&quot; or \&quot;Pending\&quot;. | [optional] 
**status_message** | **str** | StatusMessage explains the reason for the status if any, e.g. an error message. | [optional] 

## Example

```python
from si_tests.clients.gcore.box_api.models.v1_regional_volume_status import V1RegionalVolumeStatus

# TODO update the JSON string below
json = "{}"
# create an instance of V1RegionalVolumeStatus from a JSON string
v1_regional_volume_status_instance = V1RegionalVolumeStatus.from_json(json)
# print the JSON string representation of the object
print(V1RegionalVolumeStatus.to_json())

# convert the object into a dict
v1_regional_volume_status_dict = v1_regional_volume_status_instance.to_dict()
# create an instance of V1RegionalVolumeStatus from a dict
v1_regional_volume_status_from_dict = V1RegionalVolumeStatus.from_dict(v1_regional_volume_status_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


