# SchemasShortFlavor


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **str** | Name is the name of the flavor | 

## Example

```python
from si_tests.clients.gcore.box_api.models.schemas_short_flavor import SchemasShortFlavor

# TODO update the JSON string below
json = "{}"
# create an instance of SchemasShortFlavor from a JSON string
schemas_short_flavor_instance = SchemasShortFlavor.from_json(json)
# print the JSON string representation of the object
print(SchemasShortFlavor.to_json())

# convert the object into a dict
schemas_short_flavor_dict = schemas_short_flavor_instance.to_dict()
# create an instance of SchemasShortFlavor from a dict
schemas_short_flavor_from_dict = SchemasShortFlavor.from_dict(schemas_short_flavor_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


