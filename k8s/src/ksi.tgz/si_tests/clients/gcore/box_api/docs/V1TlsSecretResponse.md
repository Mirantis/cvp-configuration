# V1TlsSecretResponse


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **str** |  | [optional] 

## Example

```python
from si_tests.clients.gcore.box_api.models.v1_tls_secret_response import V1TlsSecretResponse

# TODO update the JSON string below
json = "{}"
# create an instance of V1TlsSecretResponse from a JSON string
v1_tls_secret_response_instance = V1TlsSecretResponse.from_json(json)
# print the JSON string representation of the object
print(V1TlsSecretResponse.to_json())

# convert the object into a dict
v1_tls_secret_response_dict = v1_tls_secret_response_instance.to_dict()
# create an instance of V1TlsSecretResponse from a dict
v1_tls_secret_response_from_dict = V1TlsSecretResponse.from_dict(v1_tls_secret_response_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


