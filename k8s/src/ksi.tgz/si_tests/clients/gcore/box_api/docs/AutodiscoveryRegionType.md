# AutodiscoveryRegionType

Type of the region.

## Enum

* `CoreRegionType` (value: `'core'`)

* `SubRegionType` (value: `'edge'`)

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


