# V1MetricsQueryResponse


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**data** | [**V1MetricsQueryData**](V1MetricsQueryData.md) |  | [optional] 
**status** | **str** |  | [optional] 

## Example

```python
from si_tests.clients.gcore.box_api.models.v1_metrics_query_response import V1MetricsQueryResponse

# TODO update the JSON string below
json = "{}"
# create an instance of V1MetricsQueryResponse from a JSON string
v1_metrics_query_response_instance = V1MetricsQueryResponse.from_json(json)
# print the JSON string representation of the object
print(V1MetricsQueryResponse.to_json())

# convert the object into a dict
v1_metrics_query_response_dict = v1_metrics_query_response_instance.to_dict()
# create an instance of V1MetricsQueryResponse from a dict
v1_metrics_query_response_from_dict = V1MetricsQueryResponse.from_dict(v1_metrics_query_response_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


