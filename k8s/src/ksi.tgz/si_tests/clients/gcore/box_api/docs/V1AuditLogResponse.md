# V1AuditLogResponse


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **str** |  | [optional] 
**object_name** | **str** |  | [optional] 
**object_project** | **str** |  | [optional] 
**object_resource** | **str** |  | [optional] 
**response_status_code** | **str** |  | [optional] 
**source_ips** | **List[str]** |  | [optional] 
**status** | **str** |  | [optional] 
**time** | **str** |  | [optional] 
**user_groups** | **List[str]** |  | [optional] 
**username** | **str** |  | [optional] 
**verb** | **str** |  | [optional] 

## Example

```python
from si_tests.clients.gcore.box_api.models.v1_audit_log_response import V1AuditLogResponse

# TODO update the JSON string below
json = "{}"
# create an instance of V1AuditLogResponse from a JSON string
v1_audit_log_response_instance = V1AuditLogResponse.from_json(json)
# print the JSON string representation of the object
print(V1AuditLogResponse.to_json())

# convert the object into a dict
v1_audit_log_response_dict = v1_audit_log_response_instance.to_dict()
# create an instance of V1AuditLogResponse from a dict
v1_audit_log_response_from_dict = V1AuditLogResponse.from_dict(v1_audit_log_response_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


