# V1RegistryUserResponse


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **str** | Name of the user | [optional] 
**pull_secret_name** | **str** | PullSecretName of the user | [optional] 
**read_only** | **bool** | ReadOnly of the user | [optional] 
**registry_name** | **str** | RegistryName of the user | [optional] 

## Example

```python
from si_tests.clients.gcore.box_api.models.v1_registry_user_response import V1RegistryUserResponse

# TODO update the JSON string below
json = "{}"
# create an instance of V1RegistryUserResponse from a JSON string
v1_registry_user_response_instance = V1RegistryUserResponse.from_json(json)
# print the JSON string representation of the object
print(V1RegistryUserResponse.to_json())

# convert the object into a dict
v1_registry_user_response_dict = v1_registry_user_response_instance.to_dict()
# create an instance of V1RegistryUserResponse from a dict
v1_registry_user_response_from_dict = V1RegistryUserResponse.from_dict(v1_registry_user_response_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


