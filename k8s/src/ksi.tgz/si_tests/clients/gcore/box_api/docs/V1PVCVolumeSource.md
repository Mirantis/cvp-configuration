# V1PVCVolumeSource

PVC is the PVC volume configuration

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**access_mode** | **str** | AccessMode is the volume access mode, one of ReadOnlyMany, ReadWriteMany | 
**capacity** | **str** | Capacity is the volume size, e.g. \&quot;5Gi\&quot; | 
**storage_class** | **str** | StorageClass is the storage class to use | 

## Example

```python
from si_tests.clients.gcore.box_api.models.v1_pvc_volume_source import V1PVCVolumeSource

# TODO update the JSON string below
json = "{}"
# create an instance of V1PVCVolumeSource from a JSON string
v1_pvc_volume_source_instance = V1PVCVolumeSource.from_json(json)
# print the JSON string representation of the object
print(V1PVCVolumeSource.to_json())

# convert the object into a dict
v1_pvc_volume_source_dict = v1_pvc_volume_source_instance.to_dict()
# create an instance of V1PVCVolumeSource from a dict
v1_pvc_volume_source_from_dict = V1PVCVolumeSource.from_dict(v1_pvc_volume_source_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


