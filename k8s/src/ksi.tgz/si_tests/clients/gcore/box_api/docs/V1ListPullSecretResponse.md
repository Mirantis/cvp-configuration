# V1ListPullSecretResponse


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**count** | **int** | Count of the pull secrets | [optional] 
**results** | [**List[V1PullSecretResponse]**](V1PullSecretResponse.md) | Results of the pull secrets | [optional] 

## Example

```python
from si_tests.clients.gcore.box_api.models.v1_list_pull_secret_response import V1ListPullSecretResponse

# TODO update the JSON string below
json = "{}"
# create an instance of V1ListPullSecretResponse from a JSON string
v1_list_pull_secret_response_instance = V1ListPullSecretResponse.from_json(json)
# print the JSON string representation of the object
print(V1ListPullSecretResponse.to_json())

# convert the object into a dict
v1_list_pull_secret_response_dict = v1_list_pull_secret_response_instance.to_dict()
# create an instance of V1ListPullSecretResponse from a dict
v1_list_pull_secret_response_from_dict = V1ListPullSecretResponse.from_dict(v1_list_pull_secret_response_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


