# V1PullSecretResponse


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**login** | **str** | Login of the pull secret | [optional] 
**name** | **str** | Name of the pull secret | [optional] 
**password** | **str** | Password of the pull secret | [optional] 
**registry** | **str** | Registry of the pull secret | [optional] 

## Example

```python
from si_tests.clients.gcore.box_api.models.v1_pull_secret_response import V1PullSecretResponse

# TODO update the JSON string below
json = "{}"
# create an instance of V1PullSecretResponse from a JSON string
v1_pull_secret_response_instance = V1PullSecretResponse.from_json(json)
# print the JSON string representation of the object
print(V1PullSecretResponse.to_json())

# convert the object into a dict
v1_pull_secret_response_dict = v1_pull_secret_response_instance.to_dict()
# create an instance of V1PullSecretResponse from a dict
v1_pull_secret_response_from_dict = V1PullSecretResponse.from_dict(v1_pull_secret_response_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


