# V1RegionResponse


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **str** | Name of the region | [optional] 
**type** | **str** | Type of the region. | [optional] 

## Example

```python
from si_tests.clients.gcore.box_api.models.v1_region_response import V1RegionResponse

# TODO update the JSON string below
json = "{}"
# create an instance of V1RegionResponse from a JSON string
v1_region_response_instance = V1RegionResponse.from_json(json)
# print the JSON string representation of the object
print(V1RegionResponse.to_json())

# convert the object into a dict
v1_region_response_dict = v1_region_response_instance.to_dict()
# create an instance of V1RegionResponse from a dict
v1_region_response_from_dict = V1RegionResponse.from_dict(v1_region_response_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


