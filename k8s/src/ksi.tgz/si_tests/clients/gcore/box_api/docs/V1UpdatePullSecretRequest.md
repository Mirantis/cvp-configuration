# V1UpdatePullSecretRequest


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**login** | **str** | Login of the pull secret | [optional] 
**password** | **str** | Password of the pull secret | [optional] 
**registry** | **str** | Registry of the pull secret | [optional] 

## Example

```python
from si_tests.clients.gcore.box_api.models.v1_update_pull_secret_request import V1UpdatePullSecretRequest

# TODO update the JSON string below
json = "{}"
# create an instance of V1UpdatePullSecretRequest from a JSON string
v1_update_pull_secret_request_instance = V1UpdatePullSecretRequest.from_json(json)
# print the JSON string representation of the object
print(V1UpdatePullSecretRequest.to_json())

# convert the object into a dict
v1_update_pull_secret_request_dict = v1_update_pull_secret_request_instance.to_dict()
# create an instance of V1UpdatePullSecretRequest from a dict
v1_update_pull_secret_request_from_dict = V1UpdatePullSecretRequest.from_dict(v1_update_pull_secret_request_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


