# ApiServicesRegistriesV1PreheatPolicy


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**filters** | [**ApiServicesRegistriesV1PreheatPolicyFilters**](ApiServicesRegistriesV1PreheatPolicyFilters.md) |  | [optional] 
**name** | **str** | Name of the preheat policy | [optional] 
**trigger** | [**ApiServicesRegistriesV1PreheatPolicyTrigger**](ApiServicesRegistriesV1PreheatPolicyTrigger.md) |  | [optional] 

## Example

```python
from si_tests.clients.gcore.box_api.models.api_services_registries_v1_preheat_policy import ApiServicesRegistriesV1PreheatPolicy

# TODO update the JSON string below
json = "{}"
# create an instance of ApiServicesRegistriesV1PreheatPolicy from a JSON string
api_services_registries_v1_preheat_policy_instance = ApiServicesRegistriesV1PreheatPolicy.from_json(json)
# print the JSON string representation of the object
print(ApiServicesRegistriesV1PreheatPolicy.to_json())

# convert the object into a dict
api_services_registries_v1_preheat_policy_dict = api_services_registries_v1_preheat_policy_instance.to_dict()
# create an instance of ApiServicesRegistriesV1PreheatPolicy from a dict
api_services_registries_v1_preheat_policy_from_dict = ApiServicesRegistriesV1PreheatPolicy.from_dict(api_services_registries_v1_preheat_policy_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


