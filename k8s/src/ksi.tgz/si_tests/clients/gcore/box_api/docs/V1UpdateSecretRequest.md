# V1UpdateSecretRequest


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**data** | **Dict[str, str]** | Data fields to store in the secret | [optional] 
**type** | **str** | Type of the secret | [optional] 

## Example

```python
from si_tests.clients.gcore.box_api.models.v1_update_secret_request import V1UpdateSecretRequest

# TODO update the JSON string below
json = "{}"
# create an instance of V1UpdateSecretRequest from a JSON string
v1_update_secret_request_instance = V1UpdateSecretRequest.from_json(json)
# print the JSON string representation of the object
print(V1UpdateSecretRequest.to_json())

# convert the object into a dict
v1_update_secret_request_dict = v1_update_secret_request_instance.to_dict()
# create an instance of V1UpdateSecretRequest from a dict
v1_update_secret_request_from_dict = V1UpdateSecretRequest.from_dict(v1_update_secret_request_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


