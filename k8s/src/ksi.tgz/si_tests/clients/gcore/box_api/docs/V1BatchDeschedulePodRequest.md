# V1BatchDeschedulePodRequest


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**pods** | [**List[V1DeschedulePodRequest]**](V1DeschedulePodRequest.md) |  | 

## Example

```python
from si_tests.clients.gcore.box_api.models.v1_batch_deschedule_pod_request import V1BatchDeschedulePodRequest

# TODO update the JSON string below
json = "{}"
# create an instance of V1BatchDeschedulePodRequest from a JSON string
v1_batch_deschedule_pod_request_instance = V1BatchDeschedulePodRequest.from_json(json)
# print the JSON string representation of the object
print(V1BatchDeschedulePodRequest.to_json())

# convert the object into a dict
v1_batch_deschedule_pod_request_dict = v1_batch_deschedule_pod_request_instance.to_dict()
# create an instance of V1BatchDeschedulePodRequest from a dict
v1_batch_deschedule_pod_request_from_dict = V1BatchDeschedulePodRequest.from_dict(v1_batch_deschedule_pod_request_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


