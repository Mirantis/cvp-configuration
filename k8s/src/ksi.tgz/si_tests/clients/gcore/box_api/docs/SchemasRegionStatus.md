# SchemasRegionStatus


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**components** | [**Dict[str, SchemasComponentStatus]**](SchemasComponentStatus.md) | Components contain the status of individual components within the region. | [optional] 
**status** | **str** | Status describes the current state of the deployment in a specific region. | [optional] 

## Example

```python
from si_tests.clients.gcore.box_api.models.schemas_region_status import SchemasRegionStatus

# TODO update the JSON string below
json = "{}"
# create an instance of SchemasRegionStatus from a JSON string
schemas_region_status_instance = SchemasRegionStatus.from_json(json)
# print the JSON string representation of the object
print(SchemasRegionStatus.to_json())

# convert the object into a dict
schemas_region_status_dict = schemas_region_status_instance.to_dict()
# create an instance of SchemasRegionStatus from a dict
schemas_region_status_from_dict = SchemasRegionStatus.from_dict(schemas_region_status_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


