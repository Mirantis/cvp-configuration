# V1SlurmClusterResponse


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**created_at** | **str** | CreatedAt is the time when the Slurm cluster was created, in RFC-3339 format. | [optional] 
**login** | [**V1SlurmClusterLoginConfig**](V1SlurmClusterLoginConfig.md) |  | [optional] 
**region_name** | **str** | RegionName is the name of the region in which the cluster exists. | [optional] 
**status** | **str** | Status of the Slurm cluster. | [optional] 
**worker** | [**V1SlurmClusterWorkerConfig**](V1SlurmClusterWorkerConfig.md) |  | [optional] 

## Example

```python
from si_tests.clients.gcore.box_api.models.v1_slurm_cluster_response import V1SlurmClusterResponse

# TODO update the JSON string below
json = "{}"
# create an instance of V1SlurmClusterResponse from a JSON string
v1_slurm_cluster_response_instance = V1SlurmClusterResponse.from_json(json)
# print the JSON string representation of the object
print(V1SlurmClusterResponse.to_json())

# convert the object into a dict
v1_slurm_cluster_response_dict = v1_slurm_cluster_response_instance.to_dict()
# create an instance of V1SlurmClusterResponse from a dict
v1_slurm_cluster_response_from_dict = V1SlurmClusterResponse.from_dict(v1_slurm_cluster_response_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


