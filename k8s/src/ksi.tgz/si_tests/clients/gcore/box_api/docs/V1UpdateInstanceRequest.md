# V1UpdateInstanceRequest


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**flavor_name** | **str** | FlavorName represents the name of the new hardware configuration (CPU, memory) for the JupyterLab instance. | [optional] 
**region_name** | **str** | RegionName represents the new region for migrating the JupyterLab instance. | [optional] 
**volume_name** | **str** | VolumeName represents the name of the new storage volume for the JupyterLab instance. | [optional] 

## Example

```python
from si_tests.clients.gcore.box_api.models.v1_update_instance_request import V1UpdateInstanceRequest

# TODO update the JSON string below
json = "{}"
# create an instance of V1UpdateInstanceRequest from a JSON string
v1_update_instance_request_instance = V1UpdateInstanceRequest.from_json(json)
# print the JSON string representation of the object
print(V1UpdateInstanceRequest.to_json())

# convert the object into a dict
v1_update_instance_request_dict = v1_update_instance_request_instance.to_dict()
# create an instance of V1UpdateInstanceRequest from a dict
v1_update_instance_request_from_dict = V1UpdateInstanceRequest.from_dict(v1_update_instance_request_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


