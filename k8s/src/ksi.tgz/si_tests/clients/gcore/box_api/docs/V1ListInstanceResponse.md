# V1ListInstanceResponse


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**count** | **int** |  | 
**results** | [**List[V1GetInstanceResponse]**](V1GetInstanceResponse.md) |  | 

## Example

```python
from si_tests.clients.gcore.box_api.models.v1_list_instance_response import V1ListInstanceResponse

# TODO update the JSON string below
json = "{}"
# create an instance of V1ListInstanceResponse from a JSON string
v1_list_instance_response_instance = V1ListInstanceResponse.from_json(json)
# print the JSON string representation of the object
print(V1ListInstanceResponse.to_json())

# convert the object into a dict
v1_list_instance_response_dict = v1_list_instance_response_instance.to_dict()
# create an instance of V1ListInstanceResponse from a dict
v1_list_instance_response_from_dict = V1ListInstanceResponse.from_dict(v1_list_instance_response_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


