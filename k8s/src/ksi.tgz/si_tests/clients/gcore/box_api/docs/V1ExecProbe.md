# V1ExecProbe

Exec is probe type which sending commands to container

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**command** | **List[str]** | Command is an array of commands to execute in the container. | [optional] 

## Example

```python
from si_tests.clients.gcore.box_api.models.v1_exec_probe import V1ExecProbe

# TODO update the JSON string below
json = "{}"
# create an instance of V1ExecProbe from a JSON string
v1_exec_probe_instance = V1ExecProbe.from_json(json)
# print the JSON string representation of the object
print(V1ExecProbe.to_json())

# convert the object into a dict
v1_exec_probe_dict = v1_exec_probe_instance.to_dict()
# create an instance of V1ExecProbe from a dict
v1_exec_probe_from_dict = V1ExecProbe.from_dict(v1_exec_probe_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


