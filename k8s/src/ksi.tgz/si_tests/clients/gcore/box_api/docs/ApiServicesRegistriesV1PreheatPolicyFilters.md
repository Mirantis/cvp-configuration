# ApiServicesRegistriesV1PreheatPolicyFilters

Filters of the preheat policy

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**labels** | **List[str]** | Labels of the preheat policy | [optional] 
**repositories** | **List[str]** | Repositories of the preheat policy | [optional] 
**tags** | **List[str]** | Tags of the preheat policy | [optional] 

## Example

```python
from si_tests.clients.gcore.box_api.models.api_services_registries_v1_preheat_policy_filters import ApiServicesRegistriesV1PreheatPolicyFilters

# TODO update the JSON string below
json = "{}"
# create an instance of ApiServicesRegistriesV1PreheatPolicyFilters from a JSON string
api_services_registries_v1_preheat_policy_filters_instance = ApiServicesRegistriesV1PreheatPolicyFilters.from_json(json)
# print the JSON string representation of the object
print(ApiServicesRegistriesV1PreheatPolicyFilters.to_json())

# convert the object into a dict
api_services_registries_v1_preheat_policy_filters_dict = api_services_registries_v1_preheat_policy_filters_instance.to_dict()
# create an instance of ApiServicesRegistriesV1PreheatPolicyFilters from a dict
api_services_registries_v1_preheat_policy_filters_from_dict = ApiServicesRegistriesV1PreheatPolicyFilters.from_dict(api_services_registries_v1_preheat_policy_filters_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


