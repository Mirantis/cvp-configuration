# V1CreateFlavorRequest


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**cpu** | **str** | CPU is the maximum amount of CPU in millicores. | 
**gpu** | **str** | GPU is the maximum amount of gpu. | [optional] 
**gpu_compute_capability** | **str** | GPUComputeCapability is Nvidia hardware generation, e.g. \&quot;8.0\&quot; for Ampere. | [optional] 
**gpu_memory** | **str** | GPUMemory is the maximum amount of VRAM. | [optional] 
**gpu_model** | **str** | GPUModel is the model of the GPU. | [optional] 
**is_gpu_shared** | **bool** | GPUShared is a flag to enable using shared GPU. | [optional] 
**memory** | **str** | Memory is the maximum amount of memory. | 
**name** | **str** | Name of the flavor | 

## Example

```python
from si_tests.clients.gcore.box_api.models.v1_create_flavor_request import V1CreateFlavorRequest

# TODO update the JSON string below
json = "{}"
# create an instance of V1CreateFlavorRequest from a JSON string
v1_create_flavor_request_instance = V1CreateFlavorRequest.from_json(json)
# print the JSON string representation of the object
print(V1CreateFlavorRequest.to_json())

# convert the object into a dict
v1_create_flavor_request_dict = v1_create_flavor_request_instance.to_dict()
# create an instance of V1CreateFlavorRequest from a dict
v1_create_flavor_request_from_dict = V1CreateFlavorRequest.from_dict(v1_create_flavor_request_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


