# V1ListQuotasResponse


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**count** | **int** | Count of the quotas | [optional] 
**results** | [**List[ApiServicesQuotasV1QuotaResponse]**](ApiServicesQuotasV1QuotaResponse.md) | Results of the quotas | [optional] 

## Example

```python
from si_tests.clients.gcore.box_api.models.v1_list_quotas_response import V1ListQuotasResponse

# TODO update the JSON string below
json = "{}"
# create an instance of V1ListQuotasResponse from a JSON string
v1_list_quotas_response_instance = V1ListQuotasResponse.from_json(json)
# print the JSON string representation of the object
print(V1ListQuotasResponse.to_json())

# convert the object into a dict
v1_list_quotas_response_dict = v1_list_quotas_response_instance.to_dict()
# create an instance of V1ListQuotasResponse from a dict
v1_list_quotas_response_from_dict = V1ListQuotasResponse.from_dict(v1_list_quotas_response_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


