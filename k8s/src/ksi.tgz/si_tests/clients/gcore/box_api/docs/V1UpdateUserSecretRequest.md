# V1UpdateUserSecretRequest


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**secret** | **str** | Secret of the user | 

## Example

```python
from si_tests.clients.gcore.box_api.models.v1_update_user_secret_request import V1UpdateUserSecretRequest

# TODO update the JSON string below
json = "{}"
# create an instance of V1UpdateUserSecretRequest from a JSON string
v1_update_user_secret_request_instance = V1UpdateUserSecretRequest.from_json(json)
# print the JSON string representation of the object
print(V1UpdateUserSecretRequest.to_json())

# convert the object into a dict
v1_update_user_secret_request_dict = v1_update_user_secret_request_instance.to_dict()
# create an instance of V1UpdateUserSecretRequest from a dict
v1_update_user_secret_request_from_dict = V1UpdateUserSecretRequest.from_dict(v1_update_user_secret_request_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


