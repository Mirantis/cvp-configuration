# V1GetPodsMetricsResponse


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**count** | **int** |  | [optional] 
**results** | [**List[V1GetMetricsForPodResponse]**](V1GetMetricsForPodResponse.md) |  | [optional] 

## Example

```python
from si_tests.clients.gcore.box_api.models.v1_get_pods_metrics_response import V1GetPodsMetricsResponse

# TODO update the JSON string below
json = "{}"
# create an instance of V1GetPodsMetricsResponse from a JSON string
v1_get_pods_metrics_response_instance = V1GetPodsMetricsResponse.from_json(json)
# print the JSON string representation of the object
print(V1GetPodsMetricsResponse.to_json())

# convert the object into a dict
v1_get_pods_metrics_response_dict = v1_get_pods_metrics_response_instance.to_dict()
# create an instance of V1GetPodsMetricsResponse from a dict
v1_get_pods_metrics_response_from_dict = V1GetPodsMetricsResponse.from_dict(v1_get_pods_metrics_response_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


