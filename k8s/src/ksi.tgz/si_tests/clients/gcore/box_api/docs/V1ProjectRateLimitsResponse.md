# V1ProjectRateLimitsResponse


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**public** | [**List[ApiServicesProjectsV1PublicRateLimitResponse]**](ApiServicesProjectsV1PublicRateLimitResponse.md) | Public shared model rate limits | [optional] 

## Example

```python
from si_tests.clients.gcore.box_api.models.v1_project_rate_limits_response import V1ProjectRateLimitsResponse

# TODO update the JSON string below
json = "{}"
# create an instance of V1ProjectRateLimitsResponse from a JSON string
v1_project_rate_limits_response_instance = V1ProjectRateLimitsResponse.from_json(json)
# print the JSON string representation of the object
print(V1ProjectRateLimitsResponse.to_json())

# convert the object into a dict
v1_project_rate_limits_response_dict = v1_project_rate_limits_response_instance.to_dict()
# create an instance of V1ProjectRateLimitsResponse from a dict
v1_project_rate_limits_response_from_dict = V1ProjectRateLimitsResponse.from_dict(v1_project_rate_limits_response_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


