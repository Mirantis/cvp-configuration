# ApiServicesInferenceV1Flavor

Flavor of the inference

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**cpu** | **str** | CPU amount of the flavor | [optional] 
**gpu** | **str** | GPU amount of the flavor | [optional] 
**gpu_model** | **str** | GpuModel of the flavor | [optional] 
**memory** | **str** | Memory amount of the flavor | [optional] 
**name** | **str** | Name of the flavor | [optional] 

## Example

```python
from si_tests.clients.gcore.box_api.models.api_services_inference_v1_flavor import ApiServicesInferenceV1Flavor

# TODO update the JSON string below
json = "{}"
# create an instance of ApiServicesInferenceV1Flavor from a JSON string
api_services_inference_v1_flavor_instance = ApiServicesInferenceV1Flavor.from_json(json)
# print the JSON string representation of the object
print(ApiServicesInferenceV1Flavor.to_json())

# convert the object into a dict
api_services_inference_v1_flavor_dict = api_services_inference_v1_flavor_instance.to_dict()
# create an instance of ApiServicesInferenceV1Flavor from a dict
api_services_inference_v1_flavor_from_dict = ApiServicesInferenceV1Flavor.from_dict(api_services_inference_v1_flavor_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


