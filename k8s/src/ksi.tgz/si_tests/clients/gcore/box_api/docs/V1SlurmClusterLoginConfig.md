# V1SlurmClusterLoginConfig

Login node configuration.

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**address** | **str** | Address of the load balancer used to SSH into login nodes. | [optional] 
**ssh_keys** | **List[str]** | SSHKeys is the list of public keys authorized for SSH connection to Slurm login nodes. | [optional] 

## Example

```python
from si_tests.clients.gcore.box_api.models.v1_slurm_cluster_login_config import V1SlurmClusterLoginConfig

# TODO update the JSON string below
json = "{}"
# create an instance of V1SlurmClusterLoginConfig from a JSON string
v1_slurm_cluster_login_config_instance = V1SlurmClusterLoginConfig.from_json(json)
# print the JSON string representation of the object
print(V1SlurmClusterLoginConfig.to_json())

# convert the object into a dict
v1_slurm_cluster_login_config_dict = v1_slurm_cluster_login_config_instance.to_dict()
# create an instance of V1SlurmClusterLoginConfig from a dict
v1_slurm_cluster_login_config_from_dict = V1SlurmClusterLoginConfig.from_dict(v1_slurm_cluster_login_config_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


