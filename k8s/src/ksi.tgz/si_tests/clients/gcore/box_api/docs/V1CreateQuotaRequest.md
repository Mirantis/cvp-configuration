# V1CreateQuotaRequest


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**limits** | **Dict[str, str]** |  | 

## Example

```python
from si_tests.clients.gcore.box_api.models.v1_create_quota_request import V1CreateQuotaRequest

# TODO update the JSON string below
json = "{}"
# create an instance of V1CreateQuotaRequest from a JSON string
v1_create_quota_request_instance = V1CreateQuotaRequest.from_json(json)
# print the JSON string representation of the object
print(V1CreateQuotaRequest.to_json())

# convert the object into a dict
v1_create_quota_request_dict = v1_create_quota_request_instance.to_dict()
# create an instance of V1CreateQuotaRequest from a dict
v1_create_quota_request_from_dict = V1CreateQuotaRequest.from_dict(v1_create_quota_request_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


