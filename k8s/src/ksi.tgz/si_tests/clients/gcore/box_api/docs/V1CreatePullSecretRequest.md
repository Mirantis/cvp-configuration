# V1CreatePullSecretRequest


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**login** | **str** | Login of the pull secret | 
**name** | **str** | Name of the pull secret | 
**password** | **str** | Password of the pull secret | 
**registry** | **str** | Registry of the pull secret | 

## Example

```python
from si_tests.clients.gcore.box_api.models.v1_create_pull_secret_request import V1CreatePullSecretRequest

# TODO update the JSON string below
json = "{}"
# create an instance of V1CreatePullSecretRequest from a JSON string
v1_create_pull_secret_request_instance = V1CreatePullSecretRequest.from_json(json)
# print the JSON string representation of the object
print(V1CreatePullSecretRequest.to_json())

# convert the object into a dict
v1_create_pull_secret_request_dict = v1_create_pull_secret_request_instance.to_dict()
# create an instance of V1CreatePullSecretRequest from a dict
v1_create_pull_secret_request_from_dict = V1CreatePullSecretRequest.from_dict(v1_create_pull_secret_request_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


