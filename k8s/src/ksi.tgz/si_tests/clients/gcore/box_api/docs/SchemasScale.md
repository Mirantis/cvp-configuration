# SchemasScale

Scale represents the scaling parameters of a component.

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**max** | **int** | Max is the maximum number of replicas the container can be scaled up to. | [optional] 
**min** | **int** | Min is the minimum number of replicas the component can be scaled down to. | [optional] 

## Example

```python
from si_tests.clients.gcore.box_api.models.schemas_scale import SchemasScale

# TODO update the JSON string below
json = "{}"
# create an instance of SchemasScale from a JSON string
schemas_scale_instance = SchemasScale.from_json(json)
# print the JSON string representation of the object
print(SchemasScale.to_json())

# convert the object into a dict
schemas_scale_dict = schemas_scale_instance.to_dict()
# create an instance of SchemasScale from a dict
schemas_scale_from_dict = SchemasScale.from_dict(schemas_scale_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


