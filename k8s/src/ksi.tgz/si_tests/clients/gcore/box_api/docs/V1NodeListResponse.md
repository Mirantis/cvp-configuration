# V1NodeListResponse


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**count** | **int** |  | [optional] 
**results** | [**List[V1Node]**](V1Node.md) |  | [optional] 

## Example

```python
from si_tests.clients.gcore.box_api.models.v1_node_list_response import V1NodeListResponse

# TODO update the JSON string below
json = "{}"
# create an instance of V1NodeListResponse from a JSON string
v1_node_list_response_instance = V1NodeListResponse.from_json(json)
# print the JSON string representation of the object
print(V1NodeListResponse.to_json())

# convert the object into a dict
v1_node_list_response_dict = v1_node_list_response_instance.to_dict()
# create an instance of V1NodeListResponse from a dict
v1_node_list_response_from_dict = V1NodeListResponse.from_dict(v1_node_list_response_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


