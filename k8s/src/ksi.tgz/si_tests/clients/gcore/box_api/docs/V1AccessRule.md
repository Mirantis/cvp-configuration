# V1AccessRule


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**access_type** | **str** | AccessType type of access to the namespace. Possible values are rw/ro (read-write/read-only) | 
**namespace_name** | **str** | Namespace name | 

## Example

```python
from si_tests.clients.gcore.box_api.models.v1_access_rule import V1AccessRule

# TODO update the JSON string below
json = "{}"
# create an instance of V1AccessRule from a JSON string
v1_access_rule_instance = V1AccessRule.from_json(json)
# print the JSON string representation of the object
print(V1AccessRule.to_json())

# convert the object into a dict
v1_access_rule_dict = v1_access_rule_instance.to_dict()
# create an instance of V1AccessRule from a dict
v1_access_rule_from_dict = V1AccessRule.from_dict(v1_access_rule_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


