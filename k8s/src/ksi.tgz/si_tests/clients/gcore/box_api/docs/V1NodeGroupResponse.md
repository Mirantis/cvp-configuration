# V1NodeGroupResponse


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**created_at** | **str** | CreatedAt is the time when the node group was created | [optional] 
**custom_labels** | **Dict[str, str]** | CustomLabels contains the list of custom labels | [optional] 
**name** | **str** | Name of the node group | [optional] 
**namespaces** | **List[str]** | Namespaces contains the list of namespaces | [optional] 
**node_refs** | **Dict[str, List[str]]** | NodeRefs contains the list of node references by region | [optional] 

## Example

```python
from si_tests.clients.gcore.box_api.models.v1_node_group_response import V1NodeGroupResponse

# TODO update the JSON string below
json = "{}"
# create an instance of V1NodeGroupResponse from a JSON string
v1_node_group_response_instance = V1NodeGroupResponse.from_json(json)
# print the JSON string representation of the object
print(V1NodeGroupResponse.to_json())

# convert the object into a dict
v1_node_group_response_dict = v1_node_group_response_instance.to_dict()
# create an instance of V1NodeGroupResponse from a dict
v1_node_group_response_from_dict = V1NodeGroupResponse.from_dict(v1_node_group_response_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


