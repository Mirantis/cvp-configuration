# V1CreateSlurmClusterWorkerConfig

Worker node configuration.

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**flavor_name** | **str** | FlavorName is the name of the flavor to use when creating worker nodes. Determines slurmd resource requirements and limits. | 
**size** | **int** | Size of the worker pool, i.e. number of node instances. | 
**volume_name** | **str** | VolumeName is the name of the volume to use by worker nodes for spool. | 

## Example

```python
from si_tests.clients.gcore.box_api.models.v1_create_slurm_cluster_worker_config import V1CreateSlurmClusterWorkerConfig

# TODO update the JSON string below
json = "{}"
# create an instance of V1CreateSlurmClusterWorkerConfig from a JSON string
v1_create_slurm_cluster_worker_config_instance = V1CreateSlurmClusterWorkerConfig.from_json(json)
# print the JSON string representation of the object
print(V1CreateSlurmClusterWorkerConfig.to_json())

# convert the object into a dict
v1_create_slurm_cluster_worker_config_dict = v1_create_slurm_cluster_worker_config_instance.to_dict()
# create an instance of V1CreateSlurmClusterWorkerConfig from a dict
v1_create_slurm_cluster_worker_config_from_dict = V1CreateSlurmClusterWorkerConfig.from_dict(v1_create_slurm_cluster_worker_config_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


