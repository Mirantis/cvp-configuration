# SchemasParameterOverride


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**value** | **str** | Value is the new value assigned to the overridden parameter. | 

## Example

```python
from si_tests.clients.gcore.box_api.models.schemas_parameter_override import SchemasParameterOverride

# TODO update the JSON string below
json = "{}"
# create an instance of SchemasParameterOverride from a JSON string
schemas_parameter_override_instance = SchemasParameterOverride.from_json(json)
# print the JSON string representation of the object
print(SchemasParameterOverride.to_json())

# convert the object into a dict
schemas_parameter_override_dict = schemas_parameter_override_instance.to_dict()
# create an instance of SchemasParameterOverride from a dict
schemas_parameter_override_from_dict = SchemasParameterOverride.from_dict(schemas_parameter_override_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


