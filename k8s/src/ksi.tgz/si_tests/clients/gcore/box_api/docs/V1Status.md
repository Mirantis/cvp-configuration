# V1Status


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**address** | **str** | Address of the container | [optional] 
**deployment_status** | [**V1DeploymentStatus**](V1DeploymentStatus.md) |  | [optional] 
**status** | **str** | Status is the status of the container | [optional] 
**status_message** | **str** | StatusMessage is the message of the status | [optional] 

## Example

```python
from si_tests.clients.gcore.box_api.models.v1_status import V1Status

# TODO update the JSON string below
json = "{}"
# create an instance of V1Status from a JSON string
v1_status_instance = V1Status.from_json(json)
# print the JSON string representation of the object
print(V1Status.to_json())

# convert the object into a dict
v1_status_dict = v1_status_instance.to_dict()
# create an instance of V1Status from a dict
v1_status_from_dict = V1Status.from_dict(v1_status_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


