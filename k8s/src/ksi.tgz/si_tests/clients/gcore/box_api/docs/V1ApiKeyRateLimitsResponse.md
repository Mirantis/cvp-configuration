# V1ApiKeyRateLimitsResponse


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**public** | [**List[ApiServicesApikeysV1PublicRateLimitResponse]**](ApiServicesApikeysV1PublicRateLimitResponse.md) | Public shared model rate limits | [optional] 

## Example

```python
from si_tests.clients.gcore.box_api.models.v1_api_key_rate_limits_response import V1ApiKeyRateLimitsResponse

# TODO update the JSON string below
json = "{}"
# create an instance of V1ApiKeyRateLimitsResponse from a JSON string
v1_api_key_rate_limits_response_instance = V1ApiKeyRateLimitsResponse.from_json(json)
# print the JSON string representation of the object
print(V1ApiKeyRateLimitsResponse.to_json())

# convert the object into a dict
v1_api_key_rate_limits_response_dict = v1_api_key_rate_limits_response_instance.to_dict()
# create an instance of V1ApiKeyRateLimitsResponse from a dict
v1_api_key_rate_limits_response_from_dict = V1ApiKeyRateLimitsResponse.from_dict(v1_api_key_rate_limits_response_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


