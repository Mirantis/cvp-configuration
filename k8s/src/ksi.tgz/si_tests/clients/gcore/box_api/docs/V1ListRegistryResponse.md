# V1ListRegistryResponse


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**count** | **int** | Count of the registries | [optional] 
**results** | [**List[ApiServicesRegistriesV1RegistryResponse]**](ApiServicesRegistriesV1RegistryResponse.md) | Results contains registries | [optional] 

## Example

```python
from si_tests.clients.gcore.box_api.models.v1_list_registry_response import V1ListRegistryResponse

# TODO update the JSON string below
json = "{}"
# create an instance of V1ListRegistryResponse from a JSON string
v1_list_registry_response_instance = V1ListRegistryResponse.from_json(json)
# print the JSON string representation of the object
print(V1ListRegistryResponse.to_json())

# convert the object into a dict
v1_list_registry_response_dict = v1_list_registry_response_instance.to_dict()
# create an instance of V1ListRegistryResponse from a dict
v1_list_registry_response_from_dict = V1ListRegistryResponse.from_dict(v1_list_registry_response_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


