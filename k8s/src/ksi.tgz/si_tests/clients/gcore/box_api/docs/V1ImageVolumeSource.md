# V1ImageVolumeSource

Image is the Image volume configuration

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**reference** | **str** | Reference is the OCI image reference to use. | 

## Example

```python
from si_tests.clients.gcore.box_api.models.v1_image_volume_source import V1ImageVolumeSource

# TODO update the JSON string below
json = "{}"
# create an instance of V1ImageVolumeSource from a JSON string
v1_image_volume_source_instance = V1ImageVolumeSource.from_json(json)
# print the JSON string representation of the object
print(V1ImageVolumeSource.to_json())

# convert the object into a dict
v1_image_volume_source_dict = v1_image_volume_source_instance.to_dict()
# create an instance of V1ImageVolumeSource from a dict
v1_image_volume_source_from_dict = V1ImageVolumeSource.from_dict(v1_image_volume_source_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


