# V1CreateVolumeRequest


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**empty_dir** | [**V1EmptyDirVolumeSource**](V1EmptyDirVolumeSource.md) |  | [optional] 
**image** | [**V1ImageVolumeSource**](V1ImageVolumeSource.md) |  | [optional] 
**name** | **str** | Name is the volume name | 
**pvc** | [**V1PVCVolumeSource**](V1PVCVolumeSource.md) |  | [optional] 
**regions** | **List[str]** | Regions is the list of regions where the volume should be available. | 

## Example

```python
from si_tests.clients.gcore.box_api.models.v1_create_volume_request import V1CreateVolumeRequest

# TODO update the JSON string below
json = "{}"
# create an instance of V1CreateVolumeRequest from a JSON string
v1_create_volume_request_instance = V1CreateVolumeRequest.from_json(json)
# print the JSON string representation of the object
print(V1CreateVolumeRequest.to_json())

# convert the object into a dict
v1_create_volume_request_dict = v1_create_volume_request_instance.to_dict()
# create an instance of V1CreateVolumeRequest from a dict
v1_create_volume_request_from_dict = V1CreateVolumeRequest.from_dict(v1_create_volume_request_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


