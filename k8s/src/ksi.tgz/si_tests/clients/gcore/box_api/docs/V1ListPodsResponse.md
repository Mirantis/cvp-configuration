# V1ListPodsResponse


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**count** | **int** |  | [optional] 
**results** | [**List[ApiServicesPodsV1Pod]**](ApiServicesPodsV1Pod.md) |  | [optional] 

## Example

```python
from si_tests.clients.gcore.box_api.models.v1_list_pods_response import V1ListPodsResponse

# TODO update the JSON string below
json = "{}"
# create an instance of V1ListPodsResponse from a JSON string
v1_list_pods_response_instance = V1ListPodsResponse.from_json(json)
# print the JSON string representation of the object
print(V1ListPodsResponse.to_json())

# convert the object into a dict
v1_list_pods_response_dict = v1_list_pods_response_instance.to_dict()
# create an instance of V1ListPodsResponse from a dict
v1_list_pods_response_from_dict = V1ListPodsResponse.from_dict(v1_list_pods_response_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


