# ApiServicesOverviewV1RegistryResponse


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **str** | Name of the registry | [optional] 
**namespace** | **str** | Namespace of the registry | [optional] 
**preheat_policies** | [**List[ApiServicesOverviewV1PreheatPolicy]**](ApiServicesOverviewV1PreheatPolicy.md) | PreheatPolicies of the registry | [optional] 
**public** | **bool** | Public of the registry | [optional] 
**status** | **str** | Status of the registry, e.g. Pending, Ready, Deleting | [optional] 
**storage_limit** | **str** | StorageLimit of the registry | [optional] 
**url** | **str** | URL of the registry | [optional] 

## Example

```python
from si_tests.clients.gcore.box_api.models.api_services_overview_v1_registry_response import ApiServicesOverviewV1RegistryResponse

# TODO update the JSON string below
json = "{}"
# create an instance of ApiServicesOverviewV1RegistryResponse from a JSON string
api_services_overview_v1_registry_response_instance = ApiServicesOverviewV1RegistryResponse.from_json(json)
# print the JSON string representation of the object
print(ApiServicesOverviewV1RegistryResponse.to_json())

# convert the object into a dict
api_services_overview_v1_registry_response_dict = api_services_overview_v1_registry_response_instance.to_dict()
# create an instance of ApiServicesOverviewV1RegistryResponse from a dict
api_services_overview_v1_registry_response_from_dict = ApiServicesOverviewV1RegistryResponse.from_dict(api_services_overview_v1_registry_response_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


