# V1QuotaResponse


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**limits** | **Dict[str, str]** | Values must follow the Kubernetes quantity format. See the documentation for details: https://kubernetes.io/docs/reference/kubernetes-api/common-definitions/quantity/ | [optional] 
**namespace** | **str** | Namespace name | [optional] 
**usage** | **Dict[str, Dict[str, str]]** | Actual resource usage values. This is a map of region-name -&gt; resource-type -&gt; quota-value. Values must follow the Kubernetes quantity format. See the documentation for details: https://kubernetes.io/docs/reference/kubernetes-api/common-definitions/quantity/ | [optional] 

## Example

```python
from si_tests.clients.gcore.box_api.models.v1_quota_response import V1QuotaResponse

# TODO update the JSON string below
json = "{}"
# create an instance of V1QuotaResponse from a JSON string
v1_quota_response_instance = V1QuotaResponse.from_json(json)
# print the JSON string representation of the object
print(V1QuotaResponse.to_json())

# convert the object into a dict
v1_quota_response_dict = v1_quota_response_instance.to_dict()
# create an instance of V1QuotaResponse from a dict
v1_quota_response_from_dict = V1QuotaResponse.from_dict(v1_quota_response_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


