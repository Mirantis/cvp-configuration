# V1ListSlurmClustersResponse


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**count** | **int** | Count is the number of returned Slurm clusters. | [optional] 
**results** | [**List[V1SlurmClusterResponse]**](V1SlurmClusterResponse.md) | Results is a list of Slurm clusters. | [optional] 

## Example

```python
from si_tests.clients.gcore.box_api.models.v1_list_slurm_clusters_response import V1ListSlurmClustersResponse

# TODO update the JSON string below
json = "{}"
# create an instance of V1ListSlurmClustersResponse from a JSON string
v1_list_slurm_clusters_response_instance = V1ListSlurmClustersResponse.from_json(json)
# print the JSON string representation of the object
print(V1ListSlurmClustersResponse.to_json())

# convert the object into a dict
v1_list_slurm_clusters_response_dict = v1_list_slurm_clusters_response_instance.to_dict()
# create an instance of V1ListSlurmClustersResponse from a dict
v1_list_slurm_clusters_response_from_dict = V1ListSlurmClustersResponse.from_dict(v1_list_slurm_clusters_response_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


