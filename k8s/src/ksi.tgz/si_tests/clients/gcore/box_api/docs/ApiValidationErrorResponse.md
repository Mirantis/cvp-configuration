# ApiValidationErrorResponse


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**error** | **str** |  | [optional] 
**fields** | **Dict[str, str]** |  | [optional] 
**type** | **str** |  | [optional] 

## Example

```python
from si_tests.clients.gcore.box_api.models.api_validation_error_response import ApiValidationErrorResponse

# TODO update the JSON string below
json = "{}"
# create an instance of ApiValidationErrorResponse from a JSON string
api_validation_error_response_instance = ApiValidationErrorResponse.from_json(json)
# print the JSON string representation of the object
print(ApiValidationErrorResponse.to_json())

# convert the object into a dict
api_validation_error_response_dict = api_validation_error_response_instance.to_dict()
# create an instance of ApiValidationErrorResponse from a dict
api_validation_error_response_from_dict = ApiValidationErrorResponse.from_dict(api_validation_error_response_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


