# V1PatchSlurmClusterWorkerConfig

Worker node configuration.

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**size** | **int** | Size of the worker pool, i.e. number of node instances. | [optional] 

## Example

```python
from si_tests.clients.gcore.box_api.models.v1_patch_slurm_cluster_worker_config import V1PatchSlurmClusterWorkerConfig

# TODO update the JSON string below
json = "{}"
# create an instance of V1PatchSlurmClusterWorkerConfig from a JSON string
v1_patch_slurm_cluster_worker_config_instance = V1PatchSlurmClusterWorkerConfig.from_json(json)
# print the JSON string representation of the object
print(V1PatchSlurmClusterWorkerConfig.to_json())

# convert the object into a dict
v1_patch_slurm_cluster_worker_config_dict = v1_patch_slurm_cluster_worker_config_instance.to_dict()
# create an instance of V1PatchSlurmClusterWorkerConfig from a dict
v1_patch_slurm_cluster_worker_config_from_dict = V1PatchSlurmClusterWorkerConfig.from_dict(v1_patch_slurm_cluster_worker_config_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


