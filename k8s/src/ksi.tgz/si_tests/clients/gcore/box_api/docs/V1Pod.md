# V1Pod


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**inference_flavor_name** | **str** | InferenceFlavorName of the pod | [optional] 
**inference_name** | **str** | InferenceName of the pod | [optional] 
**name** | **str** | Name of the pod | [optional] 
**namespace** | **str** | Namespace of the pod | [optional] 
**node_name** | **str** | NodeName where pod allocated | [optional] 
**region_name** | **str** | RegionName of the pod | [optional] 
**requested_resources** | **Dict[str, str]** | RequestedResources of the pod | [optional] 

## Example

```python
from si_tests.clients.gcore.box_api.models.v1_pod import V1Pod

# TODO update the JSON string below
json = "{}"
# create an instance of V1Pod from a JSON string
v1_pod_instance = V1Pod.from_json(json)
# print the JSON string representation of the object
print(V1Pod.to_json())

# convert the object into a dict
v1_pod_dict = v1_pod_instance.to_dict()
# create an instance of V1Pod from a dict
v1_pod_from_dict = V1Pod.from_dict(v1_pod_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


