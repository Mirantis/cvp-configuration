# V1CreateScaleRequest


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**cooldown_period** | **int** | CooldownPeriod is the time in seconds that the container should wait before last scaling event | [optional] 
**max** | **int** | Max is the maximum number of replicas the container can be scaled up to. | 
**min** | **int** | Min is the minimum number of replicas the container can be scaled down to. Default: 0 | [optional] 
**polling_interval** | **int** |  | [optional] 
**triggers** | [**V1CreateScaleTriggers**](V1CreateScaleTriggers.md) |  | 

## Example

```python
from si_tests.clients.gcore.box_api.models.v1_create_scale_request import V1CreateScaleRequest

# TODO update the JSON string below
json = "{}"
# create an instance of V1CreateScaleRequest from a JSON string
v1_create_scale_request_instance = V1CreateScaleRequest.from_json(json)
# print the JSON string representation of the object
print(V1CreateScaleRequest.to_json())

# convert the object into a dict
v1_create_scale_request_dict = v1_create_scale_request_instance.to_dict()
# create an instance of V1CreateScaleRequest from a dict
v1_create_scale_request_from_dict = V1CreateScaleRequest.from_dict(v1_create_scale_request_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


