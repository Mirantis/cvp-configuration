# ApiServicesNodegroupsV1ListNodesResponse


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**count** | **int** | Count of regions | [optional] 
**results** | [**List[ApiServicesNodegroupsV1NodeResponse]**](ApiServicesNodegroupsV1NodeResponse.md) | Results contains the list of regions | [optional] 

## Example

```python
from si_tests.clients.gcore.box_api.models.api_services_nodegroups_v1_list_nodes_response import ApiServicesNodegroupsV1ListNodesResponse

# TODO update the JSON string below
json = "{}"
# create an instance of ApiServicesNodegroupsV1ListNodesResponse from a JSON string
api_services_nodegroups_v1_list_nodes_response_instance = ApiServicesNodegroupsV1ListNodesResponse.from_json(json)
# print the JSON string representation of the object
print(ApiServicesNodegroupsV1ListNodesResponse.to_json())

# convert the object into a dict
api_services_nodegroups_v1_list_nodes_response_dict = api_services_nodegroups_v1_list_nodes_response_instance.to_dict()
# create an instance of ApiServicesNodegroupsV1ListNodesResponse from a dict
api_services_nodegroups_v1_list_nodes_response_from_dict = ApiServicesNodegroupsV1ListNodesResponse.from_dict(api_services_nodegroups_v1_list_nodes_response_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


