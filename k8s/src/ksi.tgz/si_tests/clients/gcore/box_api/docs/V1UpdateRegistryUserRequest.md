# V1UpdateRegistryUserRequest


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**read_only** | **bool** | ReadOnly of the user | [optional] 

## Example

```python
from si_tests.clients.gcore.box_api.models.v1_update_registry_user_request import V1UpdateRegistryUserRequest

# TODO update the JSON string below
json = "{}"
# create an instance of V1UpdateRegistryUserRequest from a JSON string
v1_update_registry_user_request_instance = V1UpdateRegistryUserRequest.from_json(json)
# print the JSON string representation of the object
print(V1UpdateRegistryUserRequest.to_json())

# convert the object into a dict
v1_update_registry_user_request_dict = v1_update_registry_user_request_instance.to_dict()
# create an instance of V1UpdateRegistryUserRequest from a dict
v1_update_registry_user_request_from_dict = V1UpdateRegistryUserRequest.from_dict(v1_update_registry_user_request_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


