# V1DeploymentStatus

DeploymentStatus is the status of the deployment

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ready** | **int** | Ready is the number of ready replicas | [optional] 
**total** | **int** | Total is the total number of replicas | [optional] 

## Example

```python
from si_tests.clients.gcore.box_api.models.v1_deployment_status import V1DeploymentStatus

# TODO update the JSON string below
json = "{}"
# create an instance of V1DeploymentStatus from a JSON string
v1_deployment_status_instance = V1DeploymentStatus.from_json(json)
# print the JSON string representation of the object
print(V1DeploymentStatus.to_json())

# convert the object into a dict
v1_deployment_status_dict = v1_deployment_status_instance.to_dict()
# create an instance of V1DeploymentStatus from a dict
v1_deployment_status_from_dict = V1DeploymentStatus.from_dict(v1_deployment_status_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


