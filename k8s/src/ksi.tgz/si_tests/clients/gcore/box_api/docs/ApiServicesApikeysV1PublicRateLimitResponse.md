# ApiServicesApikeysV1PublicRateLimitResponse


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**max_requests_per_minute** | **int** | MaxRequestsPerMinute is the maximum requests per minute limit | [optional] 
**max_tokens_per_minute** | **int** | MaxTokensPerMinute is the maximum tokens per minute limit | [optional] 
**model_name** | **str** | ModelName is the name of the model this limit applies to | [optional] 

## Example

```python
from si_tests.clients.gcore.box_api.models.api_services_apikeys_v1_public_rate_limit_response import ApiServicesApikeysV1PublicRateLimitResponse

# TODO update the JSON string below
json = "{}"
# create an instance of ApiServicesApikeysV1PublicRateLimitResponse from a JSON string
api_services_apikeys_v1_public_rate_limit_response_instance = ApiServicesApikeysV1PublicRateLimitResponse.from_json(json)
# print the JSON string representation of the object
print(ApiServicesApikeysV1PublicRateLimitResponse.to_json())

# convert the object into a dict
api_services_apikeys_v1_public_rate_limit_response_dict = api_services_apikeys_v1_public_rate_limit_response_instance.to_dict()
# create an instance of ApiServicesApikeysV1PublicRateLimitResponse from a dict
api_services_apikeys_v1_public_rate_limit_response_from_dict = ApiServicesApikeysV1PublicRateLimitResponse.from_dict(api_services_apikeys_v1_public_rate_limit_response_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


