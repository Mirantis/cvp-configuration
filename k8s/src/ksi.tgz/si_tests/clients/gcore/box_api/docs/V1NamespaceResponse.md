# V1NamespaceResponse


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**created_at** | **str** | CreatedAt is the time when the project was created | [optional] 
**name** | **str** | Name of the project | [optional] 

## Example

```python
from si_tests.clients.gcore.box_api.models.v1_namespace_response import V1NamespaceResponse

# TODO update the JSON string below
json = "{}"
# create an instance of V1NamespaceResponse from a JSON string
v1_namespace_response_instance = V1NamespaceResponse.from_json(json)
# print the JSON string representation of the object
print(V1NamespaceResponse.to_json())

# convert the object into a dict
v1_namespace_response_dict = v1_namespace_response_instance.to_dict()
# create an instance of V1NamespaceResponse from a dict
v1_namespace_response_from_dict = V1NamespaceResponse.from_dict(v1_namespace_response_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


