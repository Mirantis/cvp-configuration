# ApiServicesDefaultquotasV1QuotaResponse


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**limits** | **Dict[str, Dict[str, str]]** | Limits defines the maximum allowed resource values. This is a map of region-name -&gt; resource-type -&gt; quota-value. Values must follow the Kubernetes quantity format. See the documentation for details: https://kubernetes.io/docs/reference/kubernetes-api/common-definitions/quantity/ | [optional] 

## Example

```python
from si_tests.clients.gcore.box_api.models.api_services_defaultquotas_v1_quota_response import ApiServicesDefaultquotasV1QuotaResponse

# TODO update the JSON string below
json = "{}"
# create an instance of ApiServicesDefaultquotasV1QuotaResponse from a JSON string
api_services_defaultquotas_v1_quota_response_instance = ApiServicesDefaultquotasV1QuotaResponse.from_json(json)
# print the JSON string representation of the object
print(ApiServicesDefaultquotasV1QuotaResponse.to_json())

# convert the object into a dict
api_services_defaultquotas_v1_quota_response_dict = api_services_defaultquotas_v1_quota_response_instance.to_dict()
# create an instance of ApiServicesDefaultquotasV1QuotaResponse from a dict
api_services_defaultquotas_v1_quota_response_from_dict = ApiServicesDefaultquotasV1QuotaResponse.from_dict(api_services_defaultquotas_v1_quota_response_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


