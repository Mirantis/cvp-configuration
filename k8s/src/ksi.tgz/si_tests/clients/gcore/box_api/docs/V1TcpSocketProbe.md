# V1TcpSocketProbe

TcpSocket is probe type which check TCP socket

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**port** | **int** | Port is the port to use for the TCP connection. | [optional] 

## Example

```python
from si_tests.clients.gcore.box_api.models.v1_tcp_socket_probe import V1TcpSocketProbe

# TODO update the JSON string below
json = "{}"
# create an instance of V1TcpSocketProbe from a JSON string
v1_tcp_socket_probe_instance = V1TcpSocketProbe.from_json(json)
# print the JSON string representation of the object
print(V1TcpSocketProbe.to_json())

# convert the object into a dict
v1_tcp_socket_probe_dict = v1_tcp_socket_probe_instance.to_dict()
# create an instance of V1TcpSocketProbe from a dict
v1_tcp_socket_probe_from_dict = V1TcpSocketProbe.from_dict(v1_tcp_socket_probe_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


