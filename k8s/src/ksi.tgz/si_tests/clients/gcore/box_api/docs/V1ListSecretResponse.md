# V1ListSecretResponse


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**count** | **int** |  | [optional] 
**results** | [**List[ApiServicesSecretsV1SecretResponse]**](ApiServicesSecretsV1SecretResponse.md) |  | [optional] 

## Example

```python
from si_tests.clients.gcore.box_api.models.v1_list_secret_response import V1ListSecretResponse

# TODO update the JSON string below
json = "{}"
# create an instance of V1ListSecretResponse from a JSON string
v1_list_secret_response_instance = V1ListSecretResponse.from_json(json)
# print the JSON string representation of the object
print(V1ListSecretResponse.to_json())

# convert the object into a dict
v1_list_secret_response_dict = v1_list_secret_response_instance.to_dict()
# create an instance of V1ListSecretResponse from a dict
v1_list_secret_response_from_dict = V1ListSecretResponse.from_dict(v1_list_secret_response_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


