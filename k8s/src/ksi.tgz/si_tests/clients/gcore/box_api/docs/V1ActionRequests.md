# V1ActionRequests


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**action** | **str** | Action is the type of action to perform on the nodes, possible values are \&quot;cordon\&quot;, \&quot;uncordon\&quot;, \&quot;drain\&quot;, \&quot;undrain\&quot;. | [optional] 
**nodes_per_region** | [**List[V1NodesPerRegion]**](V1NodesPerRegion.md) | Nodes is a list of nodes per region to perform the action on. | [optional] 

## Example

```python
from si_tests.clients.gcore.box_api.models.v1_action_requests import V1ActionRequests

# TODO update the JSON string below
json = "{}"
# create an instance of V1ActionRequests from a JSON string
v1_action_requests_instance = V1ActionRequests.from_json(json)
# print the JSON string representation of the object
print(V1ActionRequests.to_json())

# convert the object into a dict
v1_action_requests_dict = v1_action_requests_instance.to_dict()
# create an instance of V1ActionRequests from a dict
v1_action_requests_from_dict = V1ActionRequests.from_dict(v1_action_requests_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


