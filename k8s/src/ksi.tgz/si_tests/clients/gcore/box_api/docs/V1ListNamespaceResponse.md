# V1ListNamespaceResponse


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**count** | **int** | Count of projects | [optional] 
**results** | [**List[V1NamespaceResponse]**](V1NamespaceResponse.md) | Results of projects | [optional] 

## Example

```python
from si_tests.clients.gcore.box_api.models.v1_list_namespace_response import V1ListNamespaceResponse

# TODO update the JSON string below
json = "{}"
# create an instance of V1ListNamespaceResponse from a JSON string
v1_list_namespace_response_instance = V1ListNamespaceResponse.from_json(json)
# print the JSON string representation of the object
print(V1ListNamespaceResponse.to_json())

# convert the object into a dict
v1_list_namespace_response_dict = v1_list_namespace_response_instance.to_dict()
# create an instance of V1ListNamespaceResponse from a dict
v1_list_namespace_response_from_dict = V1ListNamespaceResponse.from_dict(v1_list_namespace_response_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


