# V1ListFlavorResponse


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**count** | **int** |  | [optional] 
**results** | [**List[V1FlavorResponse]**](V1FlavorResponse.md) |  | [optional] 

## Example

```python
from si_tests.clients.gcore.box_api.models.v1_list_flavor_response import V1ListFlavorResponse

# TODO update the JSON string below
json = "{}"
# create an instance of V1ListFlavorResponse from a JSON string
v1_list_flavor_response_instance = V1ListFlavorResponse.from_json(json)
# print the JSON string representation of the object
print(V1ListFlavorResponse.to_json())

# convert the object into a dict
v1_list_flavor_response_dict = v1_list_flavor_response_instance.to_dict()
# create an instance of V1ListFlavorResponse from a dict
v1_list_flavor_response_from_dict = V1ListFlavorResponse.from_dict(v1_list_flavor_response_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


