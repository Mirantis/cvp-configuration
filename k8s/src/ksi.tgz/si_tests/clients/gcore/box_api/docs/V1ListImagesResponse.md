# V1ListImagesResponse


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**count** | **int** | Count of the images | [optional] 
**results** | [**List[V1ImageResponse]**](V1ImageResponse.md) | Results contains images | [optional] 

## Example

```python
from si_tests.clients.gcore.box_api.models.v1_list_images_response import V1ListImagesResponse

# TODO update the JSON string below
json = "{}"
# create an instance of V1ListImagesResponse from a JSON string
v1_list_images_response_instance = V1ListImagesResponse.from_json(json)
# print the JSON string representation of the object
print(V1ListImagesResponse.to_json())

# convert the object into a dict
v1_list_images_response_dict = v1_list_images_response_instance.to_dict()
# create an instance of V1ListImagesResponse from a dict
v1_list_images_response_from_dict = V1ListImagesResponse.from_dict(v1_list_images_response_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


