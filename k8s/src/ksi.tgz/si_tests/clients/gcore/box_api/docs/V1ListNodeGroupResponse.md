# V1ListNodeGroupResponse


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**count** | **int** | Count of regions | [optional] 
**results** | [**List[V1NodeGroupResponse]**](V1NodeGroupResponse.md) | Results contains the list of node groups | [optional] 

## Example

```python
from si_tests.clients.gcore.box_api.models.v1_list_node_group_response import V1ListNodeGroupResponse

# TODO update the JSON string below
json = "{}"
# create an instance of V1ListNodeGroupResponse from a JSON string
v1_list_node_group_response_instance = V1ListNodeGroupResponse.from_json(json)
# print the JSON string representation of the object
print(V1ListNodeGroupResponse.to_json())

# convert the object into a dict
v1_list_node_group_response_dict = v1_list_node_group_response_instance.to_dict()
# create an instance of V1ListNodeGroupResponse from a dict
v1_list_node_group_response_from_dict = V1ListNodeGroupResponse.from_dict(v1_list_node_group_response_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


