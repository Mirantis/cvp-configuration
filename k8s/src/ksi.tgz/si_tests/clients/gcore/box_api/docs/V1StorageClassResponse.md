# V1StorageClassResponse


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **str** | Name is the storage class name | [optional] 
**scope** | **str** | Scope is the storage class scope, one of: \&quot;global\&quot;, \&quot;regional\&quot;, \&quot;local\&quot; | [optional] 

## Example

```python
from si_tests.clients.gcore.box_api.models.v1_storage_class_response import V1StorageClassResponse

# TODO update the JSON string below
json = "{}"
# create an instance of V1StorageClassResponse from a JSON string
v1_storage_class_response_instance = V1StorageClassResponse.from_json(json)
# print the JSON string representation of the object
print(V1StorageClassResponse.to_json())

# convert the object into a dict
v1_storage_class_response_dict = v1_storage_class_response_instance.to_dict()
# create an instance of V1StorageClassResponse from a dict
v1_storage_class_response_from_dict = V1StorageClassResponse.from_dict(v1_storage_class_response_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


