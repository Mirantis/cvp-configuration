# V1ProbeConfiguration

StartupProbe probe for created deployments

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**enabled** | **bool** |  | [optional] 
**probe** | [**V1ContainerProbe**](V1ContainerProbe.md) |  | [optional] 

## Example

```python
from si_tests.clients.gcore.box_api.models.v1_probe_configuration import V1ProbeConfiguration

# TODO update the JSON string below
json = "{}"
# create an instance of V1ProbeConfiguration from a JSON string
v1_probe_configuration_instance = V1ProbeConfiguration.from_json(json)
# print the JSON string representation of the object
print(V1ProbeConfiguration.to_json())

# convert the object into a dict
v1_probe_configuration_dict = v1_probe_configuration_instance.to_dict()
# create an instance of V1ProbeConfiguration from a dict
v1_probe_configuration_from_dict = V1ProbeConfiguration.from_dict(v1_probe_configuration_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


