# SchemasComponentConfigurationPatch


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**exposed** | **bool** | Exposed component will obtain public address | [optional] 
**flavor** | **str** | Flavor specifies the chosen flavor or variant of the component. | [optional] 
**parameter_overrides** | [**Dict[str, SchemasParameterOverride]**](SchemasParameterOverride.md) | ParameterOverrides holds a map of parameter overrides for customization. The map&#39;s keys match the keys in the catalog component data. | [optional] 
**scale** | [**SchemasScalePatch**](SchemasScalePatch.md) |  | [optional] 

## Example

```python
from si_tests.clients.gcore.box_api.models.schemas_component_configuration_patch import SchemasComponentConfigurationPatch

# TODO update the JSON string below
json = "{}"
# create an instance of SchemasComponentConfigurationPatch from a JSON string
schemas_component_configuration_patch_instance = SchemasComponentConfigurationPatch.from_json(json)
# print the JSON string representation of the object
print(SchemasComponentConfigurationPatch.to_json())

# convert the object into a dict
schemas_component_configuration_patch_dict = schemas_component_configuration_patch_instance.to_dict()
# create an instance of SchemasComponentConfigurationPatch from a dict
schemas_component_configuration_patch_from_dict = SchemasComponentConfigurationPatch.from_dict(schemas_component_configuration_patch_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


