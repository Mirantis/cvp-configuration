# si_tests.clients.gcore.box_api.DashboardApi

All URIs are relative to *http://localhost*

Method | HTTP request | Description
------------- | ------------- | -------------
[**v1_get_overview**](DashboardApi.md#v1_get_overview) | **GET** /v1/admin/dashboard/overview | Get overview


# **v1_get_overview**
> V1OverviewResponse v1_get_overview()

Get overview

### Example


```python
import si_tests.clients.gcore.box_api
from si_tests.clients.gcore.box_api.models.v1_overview_response import V1OverviewResponse
from si_tests.clients.gcore.box_api.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = si_tests.clients.gcore.box_api.Configuration(
    host = "http://localhost"
)


# Enter a context with an instance of the API client
with si_tests.clients.gcore.box_api.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = si_tests.clients.gcore.box_api.DashboardApi(api_client)

    try:
        # Get overview
        api_response = api_instance.v1_get_overview()
        print("The response of DashboardApi->v1_get_overview:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling DashboardApi->v1_get_overview: %s\n" % e)
```



### Parameters

This endpoint does not need any parameter.

### Return type

[**V1OverviewResponse**](V1OverviewResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | OK |  -  |
**404** | Not Found |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

