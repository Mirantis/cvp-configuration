# V1NodesPerRegion


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**core_region** | **str** | CoreRegion is the region where the nodes are located | [optional] 
**nodes** | **List[str]** | Nodes is a list of node names in the specified region | [optional] 

## Example

```python
from si_tests.clients.gcore.box_api.models.v1_nodes_per_region import V1NodesPerRegion

# TODO update the JSON string below
json = "{}"
# create an instance of V1NodesPerRegion from a JSON string
v1_nodes_per_region_instance = V1NodesPerRegion.from_json(json)
# print the JSON string representation of the object
print(V1NodesPerRegion.to_json())

# convert the object into a dict
v1_nodes_per_region_dict = v1_nodes_per_region_instance.to_dict()
# create an instance of V1NodesPerRegion from a dict
v1_nodes_per_region_from_dict = V1NodesPerRegion.from_dict(v1_nodes_per_region_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


