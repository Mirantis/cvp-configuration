# V1SubRegionResponse


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**billing_name** | **str** | BillingName the billing name of the edge region | [optional] 
**core_region** | **str** | CoreRegion the name of the core region for the edge region | [optional] 
**domain** | **str** | Domain of the region | [optional] 
**gateway_name** | **str** | GatewayName the name of the gateway | [optional] 
**latitude** | **str** | Latitude of the edge region | [optional] 
**longitude** | **str** | Longitude of the edge region | [optional] 
**name** | **str** | Name of the edge region | [optional] 
**nodes** | [**List[ApiServicesAutodiscoveriesV1NodeResponse]**](ApiServicesAutodiscoveriesV1NodeResponse.md) | Nodes the list of nodes in the edge region | [optional] 
**type** | [**AutodiscoveryRegionType**](AutodiscoveryRegionType.md) |  | [optional] 

## Example

```python
from si_tests.clients.gcore.box_api.models.v1_sub_region_response import V1SubRegionResponse

# TODO update the JSON string below
json = "{}"
# create an instance of V1SubRegionResponse from a JSON string
v1_sub_region_response_instance = V1SubRegionResponse.from_json(json)
# print the JSON string representation of the object
print(V1SubRegionResponse.to_json())

# convert the object into a dict
v1_sub_region_response_dict = v1_sub_region_response_instance.to_dict()
# create an instance of V1SubRegionResponse from a dict
v1_sub_region_response_from_dict = V1SubRegionResponse.from_dict(v1_sub_region_response_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


