# V1Probes

Probes are kubernetes probes configurations

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**liveness_probe** | [**V1ProbeConfiguration**](V1ProbeConfiguration.md) |  | [optional] 
**readiness_probe** | [**V1ProbeConfiguration**](V1ProbeConfiguration.md) |  | [optional] 
**startup_probe** | [**V1ProbeConfiguration**](V1ProbeConfiguration.md) |  | [optional] 

## Example

```python
from si_tests.clients.gcore.box_api.models.v1_probes import V1Probes

# TODO update the JSON string below
json = "{}"
# create an instance of V1Probes from a JSON string
v1_probes_instance = V1Probes.from_json(json)
# print the JSON string representation of the object
print(V1Probes.to_json())

# convert the object into a dict
v1_probes_dict = v1_probes_instance.to_dict()
# create an instance of V1Probes from a dict
v1_probes_from_dict = V1Probes.from_dict(v1_probes_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


