# ApiServicesUsersV1SecretResponse


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**secret** | **str** |  | [optional] 

## Example

```python
from si_tests.clients.gcore.box_api.models.api_services_users_v1_secret_response import ApiServicesUsersV1SecretResponse

# TODO update the JSON string below
json = "{}"
# create an instance of ApiServicesUsersV1SecretResponse from a JSON string
api_services_users_v1_secret_response_instance = ApiServicesUsersV1SecretResponse.from_json(json)
# print the JSON string representation of the object
print(ApiServicesUsersV1SecretResponse.to_json())

# convert the object into a dict
api_services_users_v1_secret_response_dict = api_services_users_v1_secret_response_instance.to_dict()
# create an instance of ApiServicesUsersV1SecretResponse from a dict
api_services_users_v1_secret_response_from_dict = ApiServicesUsersV1SecretResponse.from_dict(api_services_users_v1_secret_response_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


