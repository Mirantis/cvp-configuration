# V1RefreshRequest


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**refresh_token** | **str** | RefreshToken is the token to refresh access tokens | 

## Example

```python
from si_tests.clients.gcore.box_api.models.v1_refresh_request import V1RefreshRequest

# TODO update the JSON string below
json = "{}"
# create an instance of V1RefreshRequest from a JSON string
v1_refresh_request_instance = V1RefreshRequest.from_json(json)
# print the JSON string representation of the object
print(V1RefreshRequest.to_json())

# convert the object into a dict
v1_refresh_request_dict = v1_refresh_request_instance.to_dict()
# create an instance of V1RefreshRequest from a dict
v1_refresh_request_from_dict = V1RefreshRequest.from_dict(v1_refresh_request_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


