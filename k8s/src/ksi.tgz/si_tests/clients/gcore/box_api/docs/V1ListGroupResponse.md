# V1ListGroupResponse


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**count** | **int** | Count of the groups | [optional] 
**results** | [**List[V1GroupResponse]**](V1GroupResponse.md) | Results contains groups | [optional] 

## Example

```python
from si_tests.clients.gcore.box_api.models.v1_list_group_response import V1ListGroupResponse

# TODO update the JSON string below
json = "{}"
# create an instance of V1ListGroupResponse from a JSON string
v1_list_group_response_instance = V1ListGroupResponse.from_json(json)
# print the JSON string representation of the object
print(V1ListGroupResponse.to_json())

# convert the object into a dict
v1_list_group_response_dict = v1_list_group_response_instance.to_dict()
# create an instance of V1ListGroupResponse from a dict
v1_list_group_response_from_dict = V1ListGroupResponse.from_dict(v1_list_group_response_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


