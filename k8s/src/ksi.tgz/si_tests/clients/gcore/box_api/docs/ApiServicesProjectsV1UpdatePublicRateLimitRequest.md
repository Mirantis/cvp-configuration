# ApiServicesProjectsV1UpdatePublicRateLimitRequest


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**max_requests_per_minute** | **int** | MaxRequestsPerMinute is the maximum requests per minute limit | [optional] 
**max_tokens_per_minute** | **int** | MaxTokensPerMinute is the maximum tokens per minute limit | [optional] 
**model_name** | **str** | ModelName is the name of the model this limit applies to | [optional] 

## Example

```python
from si_tests.clients.gcore.box_api.models.api_services_projects_v1_update_public_rate_limit_request import ApiServicesProjectsV1UpdatePublicRateLimitRequest

# TODO update the JSON string below
json = "{}"
# create an instance of ApiServicesProjectsV1UpdatePublicRateLimitRequest from a JSON string
api_services_projects_v1_update_public_rate_limit_request_instance = ApiServicesProjectsV1UpdatePublicRateLimitRequest.from_json(json)
# print the JSON string representation of the object
print(ApiServicesProjectsV1UpdatePublicRateLimitRequest.to_json())

# convert the object into a dict
api_services_projects_v1_update_public_rate_limit_request_dict = api_services_projects_v1_update_public_rate_limit_request_instance.to_dict()
# create an instance of ApiServicesProjectsV1UpdatePublicRateLimitRequest from a dict
api_services_projects_v1_update_public_rate_limit_request_from_dict = ApiServicesProjectsV1UpdatePublicRateLimitRequest.from_dict(api_services_projects_v1_update_public_rate_limit_request_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


