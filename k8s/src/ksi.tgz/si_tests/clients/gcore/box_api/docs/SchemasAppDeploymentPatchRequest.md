# SchemasAppDeploymentPatchRequest


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**api_keys** | **List[str]** | ApiKeys specifies a new set of API keys for all application components | [optional] 
**components_configuration** | [**Dict[str, SchemasComponentConfigurationPatch]**](SchemasComponentConfigurationPatch.md) | ComponentsConfiguration contains updated configurations for components in the deployment. | [optional] 
**regions** | **List[str]** | Regions list the geographical regions to be updated for the deployment. | [optional] 

## Example

```python
from si_tests.clients.gcore.box_api.models.schemas_app_deployment_patch_request import SchemasAppDeploymentPatchRequest

# TODO update the JSON string below
json = "{}"
# create an instance of SchemasAppDeploymentPatchRequest from a JSON string
schemas_app_deployment_patch_request_instance = SchemasAppDeploymentPatchRequest.from_json(json)
# print the JSON string representation of the object
print(SchemasAppDeploymentPatchRequest.to_json())

# convert the object into a dict
schemas_app_deployment_patch_request_dict = schemas_app_deployment_patch_request_instance.to_dict()
# create an instance of SchemasAppDeploymentPatchRequest from a dict
schemas_app_deployment_patch_request_from_dict = SchemasAppDeploymentPatchRequest.from_dict(schemas_app_deployment_patch_request_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


