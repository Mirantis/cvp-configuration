# V1FlavorRef

Flavor of the inference

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **str** | Name of the flavor | [optional] 

## Example

```python
from si_tests.clients.gcore.box_api.models.v1_flavor_ref import V1FlavorRef

# TODO update the JSON string below
json = "{}"
# create an instance of V1FlavorRef from a JSON string
v1_flavor_ref_instance = V1FlavorRef.from_json(json)
# print the JSON string representation of the object
print(V1FlavorRef.to_json())

# convert the object into a dict
v1_flavor_ref_dict = v1_flavor_ref_instance.to_dict()
# create an instance of V1FlavorRef from a dict
v1_flavor_ref_from_dict = V1FlavorRef.from_dict(v1_flavor_ref_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


