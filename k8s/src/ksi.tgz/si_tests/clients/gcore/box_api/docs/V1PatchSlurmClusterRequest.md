# V1PatchSlurmClusterRequest


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**worker** | [**V1PatchSlurmClusterWorkerConfig**](V1PatchSlurmClusterWorkerConfig.md) |  | [optional] 

## Example

```python
from si_tests.clients.gcore.box_api.models.v1_patch_slurm_cluster_request import V1PatchSlurmClusterRequest

# TODO update the JSON string below
json = "{}"
# create an instance of V1PatchSlurmClusterRequest from a JSON string
v1_patch_slurm_cluster_request_instance = V1PatchSlurmClusterRequest.from_json(json)
# print the JSON string representation of the object
print(V1PatchSlurmClusterRequest.to_json())

# convert the object into a dict
v1_patch_slurm_cluster_request_dict = v1_patch_slurm_cluster_request_instance.to_dict()
# create an instance of V1PatchSlurmClusterRequest from a dict
v1_patch_slurm_cluster_request_from_dict = V1PatchSlurmClusterRequest.from_dict(v1_patch_slurm_cluster_request_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


