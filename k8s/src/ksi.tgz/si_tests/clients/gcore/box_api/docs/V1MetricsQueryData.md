# V1MetricsQueryData


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**result** | **object** |  | [optional] 
**result_type** | **str** |  | [optional] 

## Example

```python
from si_tests.clients.gcore.box_api.models.v1_metrics_query_data import V1MetricsQueryData

# TODO update the JSON string below
json = "{}"
# create an instance of V1MetricsQueryData from a JSON string
v1_metrics_query_data_instance = V1MetricsQueryData.from_json(json)
# print the JSON string representation of the object
print(V1MetricsQueryData.to_json())

# convert the object into a dict
v1_metrics_query_data_dict = v1_metrics_query_data_instance.to_dict()
# create an instance of V1MetricsQueryData from a dict
v1_metrics_query_data_from_dict = V1MetricsQueryData.from_dict(v1_metrics_query_data_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


