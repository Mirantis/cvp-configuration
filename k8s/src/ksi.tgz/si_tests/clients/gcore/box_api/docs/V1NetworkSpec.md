# V1NetworkSpec

Network is the network configuration.

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**network_attachment** | **str** | NetworkAttachment is the name of the NetworkAttachmentDefinition. | 
**rdma_resources** | **Dict[str, str]** | RDMAResources defines RDMA-capable device resources. | [optional] 

## Example

```python
from si_tests.clients.gcore.box_api.models.v1_network_spec import V1NetworkSpec

# TODO update the JSON string below
json = "{}"
# create an instance of V1NetworkSpec from a JSON string
v1_network_spec_instance = V1NetworkSpec.from_json(json)
# print the JSON string representation of the object
print(V1NetworkSpec.to_json())

# convert the object into a dict
v1_network_spec_dict = v1_network_spec_instance.to_dict()
# create an instance of V1NetworkSpec from a dict
v1_network_spec_from_dict = V1NetworkSpec.from_dict(v1_network_spec_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


