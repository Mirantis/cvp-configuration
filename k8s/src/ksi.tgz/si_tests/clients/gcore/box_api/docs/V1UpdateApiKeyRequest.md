# V1UpdateApiKeyRequest


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**description** | **str** | Description of the API key used for authentication with deployed inference applications | [optional] 

## Example

```python
from si_tests.clients.gcore.box_api.models.v1_update_api_key_request import V1UpdateApiKeyRequest

# TODO update the JSON string below
json = "{}"
# create an instance of V1UpdateApiKeyRequest from a JSON string
v1_update_api_key_request_instance = V1UpdateApiKeyRequest.from_json(json)
# print the JSON string representation of the object
print(V1UpdateApiKeyRequest.to_json())

# convert the object into a dict
v1_update_api_key_request_dict = v1_update_api_key_request_instance.to_dict()
# create an instance of V1UpdateApiKeyRequest from a dict
v1_update_api_key_request_from_dict = V1UpdateApiKeyRequest.from_dict(v1_update_api_key_request_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


