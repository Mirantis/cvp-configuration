# V1InferenceAPIKeySecretResponse


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**secret** | **str** | Secret of the inference apikey | [optional] 
**status** | **str** | Status of the inference apikey | [optional] 

## Example

```python
from si_tests.clients.gcore.box_api.models.v1_inference_api_key_secret_response import V1InferenceAPIKeySecretResponse

# TODO update the JSON string below
json = "{}"
# create an instance of V1InferenceAPIKeySecretResponse from a JSON string
v1_inference_api_key_secret_response_instance = V1InferenceAPIKeySecretResponse.from_json(json)
# print the JSON string representation of the object
print(V1InferenceAPIKeySecretResponse.to_json())

# convert the object into a dict
v1_inference_api_key_secret_response_dict = v1_inference_api_key_secret_response_instance.to_dict()
# create an instance of V1InferenceAPIKeySecretResponse from a dict
v1_inference_api_key_secret_response_from_dict = V1InferenceAPIKeySecretResponse.from_dict(v1_inference_api_key_secret_response_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


