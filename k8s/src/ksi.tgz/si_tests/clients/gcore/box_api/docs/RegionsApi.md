# si_tests.clients.gcore.box_api.RegionsApi

All URIs are relative to *http://localhost*

Method | HTTP request | Description
------------- | ------------- | -------------
[**v1_list_regions**](RegionsApi.md#v1_list_regions) | **GET** /v1/regions | List regions


# **v1_list_regions**
> V1ListRegionResponse v1_list_regions()

List regions

### Example


```python
import si_tests.clients.gcore.box_api
from si_tests.clients.gcore.box_api.models.v1_list_region_response import V1ListRegionResponse
from si_tests.clients.gcore.box_api.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = si_tests.clients.gcore.box_api.Configuration(
    host = "http://localhost"
)


# Enter a context with an instance of the API client
with si_tests.clients.gcore.box_api.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = si_tests.clients.gcore.box_api.RegionsApi(api_client)

    try:
        # List regions
        api_response = api_instance.v1_list_regions()
        print("The response of RegionsApi->v1_list_regions:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling RegionsApi->v1_list_regions: %s\n" % e)
```



### Parameters

This endpoint does not need any parameter.

### Return type

[**V1ListRegionResponse**](V1ListRegionResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | OK |  -  |
**404** | Not Found |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

