# V1CpuTrigger

Cpu trigger configuration

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**threshold** | **int** | Threshold in percentage of CPU usage that triggers the scaling | [optional] 

## Example

```python
from si_tests.clients.gcore.box_api.models.v1_cpu_trigger import V1CpuTrigger

# TODO update the JSON string below
json = "{}"
# create an instance of V1CpuTrigger from a JSON string
v1_cpu_trigger_instance = V1CpuTrigger.from_json(json)
# print the JSON string representation of the object
print(V1CpuTrigger.to_json())

# convert the object into a dict
v1_cpu_trigger_dict = v1_cpu_trigger_instance.to_dict()
# create an instance of V1CpuTrigger from a dict
v1_cpu_trigger_from_dict = V1CpuTrigger.from_dict(v1_cpu_trigger_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


