# V1CreateSecretRequest


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**data** | **Dict[str, str]** | Data fields to store in the secret | 
**name** | **str** | Name of the secret | 
**type** | **str** | Type of the secret | 

## Example

```python
from si_tests.clients.gcore.box_api.models.v1_create_secret_request import V1CreateSecretRequest

# TODO update the JSON string below
json = "{}"
# create an instance of V1CreateSecretRequest from a JSON string
v1_create_secret_request_instance = V1CreateSecretRequest.from_json(json)
# print the JSON string representation of the object
print(V1CreateSecretRequest.to_json())

# convert the object into a dict
v1_create_secret_request_dict = v1_create_secret_request_instance.to_dict()
# create an instance of V1CreateSecretRequest from a dict
v1_create_secret_request_from_dict = V1CreateSecretRequest.from_dict(v1_create_secret_request_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


