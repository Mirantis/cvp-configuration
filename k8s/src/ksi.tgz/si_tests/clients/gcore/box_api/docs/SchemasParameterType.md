# SchemasParameterType

Type determines the type of the parameter.

## Enum

* `ParameterTypeString` (value: `'string'`)

* `ParameterTypeInteger` (value: `'integer'`)

* `ParameterTypeFloat` (value: `'float'`)

* `ParameterTypeEnum` (value: `'enum'`)

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


