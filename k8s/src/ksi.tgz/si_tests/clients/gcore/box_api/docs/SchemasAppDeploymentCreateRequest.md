# SchemasAppDeploymentCreateRequest


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**api_keys** | **List[str]** | ApiKeys specifies a list of API keys which will be applied to each component of the application | [optional] 
**application_name** | **str** | ApplicationName is the identifier of application from catalog | 
**components_configuration** | [**Dict[str, SchemasComponentConfiguration]**](SchemasComponentConfiguration.md) | ComponentsConfiguration specifies the configurations of the application&#39;s components. | 
**name** | **str** | Name is the desired name for the new deployment. | 
**regions** | **List[str]** | Regions list the geographical regions where the deployment should be created. | 

## Example

```python
from si_tests.clients.gcore.box_api.models.schemas_app_deployment_create_request import SchemasAppDeploymentCreateRequest

# TODO update the JSON string below
json = "{}"
# create an instance of SchemasAppDeploymentCreateRequest from a JSON string
schemas_app_deployment_create_request_instance = SchemasAppDeploymentCreateRequest.from_json(json)
# print the JSON string representation of the object
print(SchemasAppDeploymentCreateRequest.to_json())

# convert the object into a dict
schemas_app_deployment_create_request_dict = schemas_app_deployment_create_request_instance.to_dict()
# create an instance of SchemasAppDeploymentCreateRequest from a dict
schemas_app_deployment_create_request_from_dict = SchemasAppDeploymentCreateRequest.from_dict(schemas_app_deployment_create_request_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


