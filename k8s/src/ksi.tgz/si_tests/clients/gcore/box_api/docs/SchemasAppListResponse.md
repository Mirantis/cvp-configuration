# SchemasAppListResponse


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**count** | **int** |  | 
**results** | [**List[SchemasApp]**](SchemasApp.md) |  | 

## Example

```python
from si_tests.clients.gcore.box_api.models.schemas_app_list_response import SchemasAppListResponse

# TODO update the JSON string below
json = "{}"
# create an instance of SchemasAppListResponse from a JSON string
schemas_app_list_response_instance = SchemasAppListResponse.from_json(json)
# print the JSON string representation of the object
print(SchemasAppListResponse.to_json())

# convert the object into a dict
schemas_app_list_response_dict = schemas_app_list_response_instance.to_dict()
# create an instance of SchemasAppListResponse from a dict
schemas_app_list_response_from_dict = SchemasAppListResponse.from_dict(schemas_app_list_response_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


