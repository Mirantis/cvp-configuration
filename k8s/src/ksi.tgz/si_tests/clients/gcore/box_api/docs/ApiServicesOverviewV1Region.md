# ApiServicesOverviewV1Region


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **str** | Name of the region | [optional] 
**type** | **str** | Type of the region. | [optional] 

## Example

```python
from si_tests.clients.gcore.box_api.models.api_services_overview_v1_region import ApiServicesOverviewV1Region

# TODO update the JSON string below
json = "{}"
# create an instance of ApiServicesOverviewV1Region from a JSON string
api_services_overview_v1_region_instance = ApiServicesOverviewV1Region.from_json(json)
# print the JSON string representation of the object
print(ApiServicesOverviewV1Region.to_json())

# convert the object into a dict
api_services_overview_v1_region_dict = api_services_overview_v1_region_instance.to_dict()
# create an instance of ApiServicesOverviewV1Region from a dict
api_services_overview_v1_region_from_dict = ApiServicesOverviewV1Region.from_dict(api_services_overview_v1_region_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


