# ApiServicesQuotasV1CreateQuotaRequest


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**limits** | **Dict[str, Dict[str, str]]** | Limits defines the maximum allowed resource values. This is a map of region-name -&gt; resource-type -&gt; quota-value. Values must follow the Kubernetes quantity format. See the documentation for details: https://kubernetes.io/docs/reference/kubernetes-api/common-definitions/quantity/ | [optional] 

## Example

```python
from si_tests.clients.gcore.box_api.models.api_services_quotas_v1_create_quota_request import ApiServicesQuotasV1CreateQuotaRequest

# TODO update the JSON string below
json = "{}"
# create an instance of ApiServicesQuotasV1CreateQuotaRequest from a JSON string
api_services_quotas_v1_create_quota_request_instance = ApiServicesQuotasV1CreateQuotaRequest.from_json(json)
# print the JSON string representation of the object
print(ApiServicesQuotasV1CreateQuotaRequest.to_json())

# convert the object into a dict
api_services_quotas_v1_create_quota_request_dict = api_services_quotas_v1_create_quota_request_instance.to_dict()
# create an instance of ApiServicesQuotasV1CreateQuotaRequest from a dict
api_services_quotas_v1_create_quota_request_from_dict = ApiServicesQuotasV1CreateQuotaRequest.from_dict(api_services_quotas_v1_create_quota_request_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


