# V1Cluster


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**available_resources** | **Dict[str, str]** | AvailableResources contains available resources used in the installation | [optional] 
**capacity** | **Dict[str, int]** | Capacity of the region | [optional] 
**edge_regions** | **List[str]** | KateRegions contains the list of Edge regions connected the cluster | [optional] 
**name** | **str** | Name of the cluster | [optional] 
**total_resources** | **Dict[str, str]** | TotalResources contains the total resources of the installation | [optional] 
**used_resources** | **Dict[str, str]** | UsedResources contains used resources used in the installation | [optional] 

## Example

```python
from si_tests.clients.gcore.box_api.models.v1_cluster import V1Cluster

# TODO update the JSON string below
json = "{}"
# create an instance of V1Cluster from a JSON string
v1_cluster_instance = V1Cluster.from_json(json)
# print the JSON string representation of the object
print(V1Cluster.to_json())

# convert the object into a dict
v1_cluster_dict = v1_cluster_instance.to_dict()
# create an instance of V1Cluster from a dict
v1_cluster_from_dict = V1Cluster.from_dict(v1_cluster_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


