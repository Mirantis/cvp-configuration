# ApiServicesAutodiscoveriesV1NodeResponse


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**cluster_name** | **str** | ClusterName the name of the cluster the node belongs to | [optional] 
**gpu_model** | **str** | GpuModel the model of the GPU if node has one | [optional] 
**name** | **str** | Name of the node | [optional] 
**region_name** | **str** | RegionName the name of the region the node belongs to | [optional] 

## Example

```python
from si_tests.clients.gcore.box_api.models.api_services_autodiscoveries_v1_node_response import ApiServicesAutodiscoveriesV1NodeResponse

# TODO update the JSON string below
json = "{}"
# create an instance of ApiServicesAutodiscoveriesV1NodeResponse from a JSON string
api_services_autodiscoveries_v1_node_response_instance = ApiServicesAutodiscoveriesV1NodeResponse.from_json(json)
# print the JSON string representation of the object
print(ApiServicesAutodiscoveriesV1NodeResponse.to_json())

# convert the object into a dict
api_services_autodiscoveries_v1_node_response_dict = api_services_autodiscoveries_v1_node_response_instance.to_dict()
# create an instance of ApiServicesAutodiscoveriesV1NodeResponse from a dict
api_services_autodiscoveries_v1_node_response_from_dict = ApiServicesAutodiscoveriesV1NodeResponse.from_dict(api_services_autodiscoveries_v1_node_response_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


