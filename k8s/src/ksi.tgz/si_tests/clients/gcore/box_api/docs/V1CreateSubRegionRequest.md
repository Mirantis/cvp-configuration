# V1CreateSubRegionRequest


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**billing_name** | **str** | BillingName of the logical region | 
**core_region** | **str** | CoreRegion the name of the core region for the logical region | 
**latitude** | **str** | Latitude of the subregion | 
**longitude** | **str** | Longitude of the subregion | 
**name** | **str** | Name of the logical region | 
**node_names** | **List[str]** | NodeNames the name of the nodes in the logical region | [optional] 

## Example

```python
from si_tests.clients.gcore.box_api.models.v1_create_sub_region_request import V1CreateSubRegionRequest

# TODO update the JSON string below
json = "{}"
# create an instance of V1CreateSubRegionRequest from a JSON string
v1_create_sub_region_request_instance = V1CreateSubRegionRequest.from_json(json)
# print the JSON string representation of the object
print(V1CreateSubRegionRequest.to_json())

# convert the object into a dict
v1_create_sub_region_request_dict = v1_create_sub_region_request_instance.to_dict()
# create an instance of V1CreateSubRegionRequest from a dict
v1_create_sub_region_request_from_dict = V1CreateSubRegionRequest.from_dict(v1_create_sub_region_request_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


