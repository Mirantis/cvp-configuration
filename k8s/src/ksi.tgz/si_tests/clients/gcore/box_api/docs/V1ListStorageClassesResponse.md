# V1ListStorageClassesResponse


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**count** | **int** | Count of the storage classes | [optional] 
**results** | [**List[V1StorageClassResponse]**](V1StorageClassResponse.md) | Results contains storage classes | [optional] 

## Example

```python
from si_tests.clients.gcore.box_api.models.v1_list_storage_classes_response import V1ListStorageClassesResponse

# TODO update the JSON string below
json = "{}"
# create an instance of V1ListStorageClassesResponse from a JSON string
v1_list_storage_classes_response_instance = V1ListStorageClassesResponse.from_json(json)
# print the JSON string representation of the object
print(V1ListStorageClassesResponse.to_json())

# convert the object into a dict
v1_list_storage_classes_response_dict = v1_list_storage_classes_response_instance.to_dict()
# create an instance of V1ListStorageClassesResponse from a dict
v1_list_storage_classes_response_from_dict = V1ListStorageClassesResponse.from_dict(v1_list_storage_classes_response_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


