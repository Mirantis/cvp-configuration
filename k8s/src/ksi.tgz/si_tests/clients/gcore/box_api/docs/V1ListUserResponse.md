# V1ListUserResponse


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**count** | **int** | Count of the users | [optional] 
**results** | [**List[V1UserResponse]**](V1UserResponse.md) | Results contains users | [optional] 

## Example

```python
from si_tests.clients.gcore.box_api.models.v1_list_user_response import V1ListUserResponse

# TODO update the JSON string below
json = "{}"
# create an instance of V1ListUserResponse from a JSON string
v1_list_user_response_instance = V1ListUserResponse.from_json(json)
# print the JSON string representation of the object
print(V1ListUserResponse.to_json())

# convert the object into a dict
v1_list_user_response_dict = v1_list_user_response_instance.to_dict()
# create an instance of V1ListUserResponse from a dict
v1_list_user_response_from_dict = V1ListUserResponse.from_dict(v1_list_user_response_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


