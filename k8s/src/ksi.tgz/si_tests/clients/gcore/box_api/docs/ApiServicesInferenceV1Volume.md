# ApiServicesInferenceV1Volume


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**claim_name** | **str** | ClaimName of the volume  Deprecated: Kept for backwards compatibility. Please use volumes instead. | [optional] 
**empty_dir_size_limit** | **str** | EmptyDirSizeLimit is the size limit of the emptyDir volume  Deprecated: Kept for backwards compatibility. Please use volumes instead. | [optional] 
**image_reference** | **str** | ImageReference of the volume if provided volume will be created as ImageVolume  Deprecated: Kept for backwards compatibility. Please use volumes instead. | [optional] 
**mount_path** | **str** | MountPath of the volume | [optional] 
**name** | **str** | Name of the volume. | [optional] 
**sub_path** | **str** | SubPath of the volume | [optional] 

## Example

```python
from si_tests.clients.gcore.box_api.models.api_services_inference_v1_volume import ApiServicesInferenceV1Volume

# TODO update the JSON string below
json = "{}"
# create an instance of ApiServicesInferenceV1Volume from a JSON string
api_services_inference_v1_volume_instance = ApiServicesInferenceV1Volume.from_json(json)
# print the JSON string representation of the object
print(ApiServicesInferenceV1Volume.to_json())

# convert the object into a dict
api_services_inference_v1_volume_dict = api_services_inference_v1_volume_instance.to_dict()
# create an instance of ApiServicesInferenceV1Volume from a dict
api_services_inference_v1_volume_from_dict = ApiServicesInferenceV1Volume.from_dict(api_services_inference_v1_volume_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


