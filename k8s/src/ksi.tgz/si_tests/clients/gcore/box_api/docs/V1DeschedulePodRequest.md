# V1DeschedulePodRequest


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**node_name** | **str** |  | 
**pod_name** | **str** |  | 
**pod_namespace** | **str** |  | 
**region_name** | **str** |  | 

## Example

```python
from si_tests.clients.gcore.box_api.models.v1_deschedule_pod_request import V1DeschedulePodRequest

# TODO update the JSON string below
json = "{}"
# create an instance of V1DeschedulePodRequest from a JSON string
v1_deschedule_pod_request_instance = V1DeschedulePodRequest.from_json(json)
# print the JSON string representation of the object
print(V1DeschedulePodRequest.to_json())

# convert the object into a dict
v1_deschedule_pod_request_dict = v1_deschedule_pod_request_instance.to_dict()
# create an instance of V1DeschedulePodRequest from a dict
v1_deschedule_pod_request_from_dict = V1DeschedulePodRequest.from_dict(v1_deschedule_pod_request_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


