# V1GroupResponse


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**access_rules** | [**List[V1AccessRule]**](V1AccessRule.md) | AccessRules to the namespaces | [optional] 
**created_at** | **str** | CreatedAt is the time when the users group was created | [optional] 
**is_super_user** | **bool** | IsSuperUser flag to indicate if the user is superuser | [optional] 
**name** | **str** | Name of the group | [optional] 

## Example

```python
from si_tests.clients.gcore.box_api.models.v1_group_response import V1GroupResponse

# TODO update the JSON string below
json = "{}"
# create an instance of V1GroupResponse from a JSON string
v1_group_response_instance = V1GroupResponse.from_json(json)
# print the JSON string representation of the object
print(V1GroupResponse.to_json())

# convert the object into a dict
v1_group_response_dict = v1_group_response_instance.to_dict()
# create an instance of V1GroupResponse from a dict
v1_group_response_from_dict = V1GroupResponse.from_dict(v1_group_response_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


