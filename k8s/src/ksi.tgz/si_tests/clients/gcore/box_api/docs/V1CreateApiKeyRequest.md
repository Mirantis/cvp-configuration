# V1CreateApiKeyRequest


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**description** | **str** | Description of the API key | [optional] 
**expires_at** | **str** | When the API key will expire | [optional] 
**name** | **str** | Name of the API key used for authentication with deployed inference applications | 

## Example

```python
from si_tests.clients.gcore.box_api.models.v1_create_api_key_request import V1CreateApiKeyRequest

# TODO update the JSON string below
json = "{}"
# create an instance of V1CreateApiKeyRequest from a JSON string
v1_create_api_key_request_instance = V1CreateApiKeyRequest.from_json(json)
# print the JSON string representation of the object
print(V1CreateApiKeyRequest.to_json())

# convert the object into a dict
v1_create_api_key_request_dict = v1_create_api_key_request_instance.to_dict()
# create an instance of V1CreateApiKeyRequest from a dict
v1_create_api_key_request_from_dict = V1CreateApiKeyRequest.from_dict(v1_create_api_key_request_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


