# V1Scale


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**cooldown_period** | **int** | CooldownPeriod is the time in seconds that the container should wait before last scaling event | [optional] 
**max** | **int** | Max replicas of the inference | [optional] 
**min** | **int** | Min replicas of the inference | [optional] 
**polling_interval** | **int** |  | [optional] 
**triggers** | [**V1TriggersResponse**](V1TriggersResponse.md) |  | [optional] 

## Example

```python
from si_tests.clients.gcore.box_api.models.v1_scale import V1Scale

# TODO update the JSON string below
json = "{}"
# create an instance of V1Scale from a JSON string
v1_scale_instance = V1Scale.from_json(json)
# print the JSON string representation of the object
print(V1Scale.to_json())

# convert the object into a dict
v1_scale_dict = v1_scale_instance.to_dict()
# create an instance of V1Scale from a dict
v1_scale_from_dict = V1Scale.from_dict(v1_scale_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


