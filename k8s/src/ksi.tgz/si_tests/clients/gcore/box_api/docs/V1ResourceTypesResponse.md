# V1ResourceTypesResponse


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**count** | **int** | Count of regions | [optional] 
**results** | **List[str]** | Results contains the list of regions | [optional] 

## Example

```python
from si_tests.clients.gcore.box_api.models.v1_resource_types_response import V1ResourceTypesResponse

# TODO update the JSON string below
json = "{}"
# create an instance of V1ResourceTypesResponse from a JSON string
v1_resource_types_response_instance = V1ResourceTypesResponse.from_json(json)
# print the JSON string representation of the object
print(V1ResourceTypesResponse.to_json())

# convert the object into a dict
v1_resource_types_response_dict = v1_resource_types_response_instance.to_dict()
# create an instance of V1ResourceTypesResponse from a dict
v1_resource_types_response_from_dict = V1ResourceTypesResponse.from_dict(v1_resource_types_response_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


