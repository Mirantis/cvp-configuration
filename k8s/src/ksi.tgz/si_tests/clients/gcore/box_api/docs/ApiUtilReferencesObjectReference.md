# ApiUtilReferencesObjectReference


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**kind** | **str** | Kind represents the type of the referenced object (e.g., AppDeployment, SlurmCluster). | [optional] 
**name** | **str** | Name of the referenced object. | [optional] 
**project** | **str** | Project where the object resides. | [optional] 

## Example

```python
from si_tests.clients.gcore.box_api.models.api_util_references_object_reference import ApiUtilReferencesObjectReference

# TODO update the JSON string below
json = "{}"
# create an instance of ApiUtilReferencesObjectReference from a JSON string
api_util_references_object_reference_instance = ApiUtilReferencesObjectReference.from_json(json)
# print the JSON string representation of the object
print(ApiUtilReferencesObjectReference.to_json())

# convert the object into a dict
api_util_references_object_reference_dict = api_util_references_object_reference_instance.to_dict()
# create an instance of ApiUtilReferencesObjectReference from a dict
api_util_references_object_reference_from_dict = ApiUtilReferencesObjectReference.from_dict(api_util_references_object_reference_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


