# V1CreateInstanceRequest


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**flavor_name** | **str** | FlavorName represents the hardware configuration (CPU, memory) for the JupyterLab instance. | 
**name** | **str** | Name represents the name of the JupyterLab instance to be created. | 
**region_name** | **str** | RegionName represents the region where the JupyterLab instance will be deployed. | 
**volume_name** | **str** | VolumeName represents the name of the storage volume to be attached to the JupyterLab instance. | 

## Example

```python
from si_tests.clients.gcore.box_api.models.v1_create_instance_request import V1CreateInstanceRequest

# TODO update the JSON string below
json = "{}"
# create an instance of V1CreateInstanceRequest from a JSON string
v1_create_instance_request_instance = V1CreateInstanceRequest.from_json(json)
# print the JSON string representation of the object
print(V1CreateInstanceRequest.to_json())

# convert the object into a dict
v1_create_instance_request_dict = v1_create_instance_request_instance.to_dict()
# create an instance of V1CreateInstanceRequest from a dict
v1_create_instance_request_from_dict = V1CreateInstanceRequest.from_dict(v1_create_instance_request_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


