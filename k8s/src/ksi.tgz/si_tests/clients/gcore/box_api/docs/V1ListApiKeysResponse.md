# V1ListApiKeysResponse


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**count** | **int** | Count of API keys used for authentication with deployed inference applications | [optional] 
**results** | [**List[V1GetApiKeyResponse]**](V1GetApiKeyResponse.md) | List of API keys used for authentication with deployed inference applications | [optional] 

## Example

```python
from si_tests.clients.gcore.box_api.models.v1_list_api_keys_response import V1ListApiKeysResponse

# TODO update the JSON string below
json = "{}"
# create an instance of V1ListApiKeysResponse from a JSON string
v1_list_api_keys_response_instance = V1ListApiKeysResponse.from_json(json)
# print the JSON string representation of the object
print(V1ListApiKeysResponse.to_json())

# convert the object into a dict
v1_list_api_keys_response_dict = v1_list_api_keys_response_instance.to_dict()
# create an instance of V1ListApiKeysResponse from a dict
v1_list_api_keys_response_from_dict = V1ListApiKeysResponse.from_dict(v1_list_api_keys_response_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


