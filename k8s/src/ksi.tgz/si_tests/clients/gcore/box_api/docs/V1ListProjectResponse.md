# V1ListProjectResponse


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**count** | **int** | Count of projects | [optional] 
**results** | [**List[V1ProjectResponse]**](V1ProjectResponse.md) | Results of projects | [optional] 

## Example

```python
from si_tests.clients.gcore.box_api.models.v1_list_project_response import V1ListProjectResponse

# TODO update the JSON string below
json = "{}"
# create an instance of V1ListProjectResponse from a JSON string
v1_list_project_response_instance = V1ListProjectResponse.from_json(json)
# print the JSON string representation of the object
print(V1ListProjectResponse.to_json())

# convert the object into a dict
v1_list_project_response_dict = v1_list_project_response_instance.to_dict()
# create an instance of V1ListProjectResponse from a dict
v1_list_project_response_from_dict = V1ListProjectResponse.from_dict(v1_list_project_response_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


