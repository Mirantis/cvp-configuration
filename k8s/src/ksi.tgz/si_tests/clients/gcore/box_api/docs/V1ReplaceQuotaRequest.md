# V1ReplaceQuotaRequest


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**limits** | **Dict[str, Dict[str, str]]** | Limits defines the maximum allowed resource values. This is a map of region-name -&gt; resource-type -&gt; quota-value. Values must follow the Kubernetes quantity format. See the documentation for details: https://kubernetes.io/docs/reference/kubernetes-api/common-definitions/quantity/ | 

## Example

```python
from si_tests.clients.gcore.box_api.models.v1_replace_quota_request import V1ReplaceQuotaRequest

# TODO update the JSON string below
json = "{}"
# create an instance of V1ReplaceQuotaRequest from a JSON string
v1_replace_quota_request_instance = V1ReplaceQuotaRequest.from_json(json)
# print the JSON string representation of the object
print(V1ReplaceQuotaRequest.to_json())

# convert the object into a dict
v1_replace_quota_request_dict = v1_replace_quota_request_instance.to_dict()
# create an instance of V1ReplaceQuotaRequest from a dict
v1_replace_quota_request_from_dict = V1ReplaceQuotaRequest.from_dict(v1_replace_quota_request_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


