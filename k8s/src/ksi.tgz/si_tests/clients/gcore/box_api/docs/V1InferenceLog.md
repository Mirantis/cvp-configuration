# V1InferenceLog


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**message** | **str** |  | [optional] 
**pod** | **str** |  | [optional] 
**region** | **str** |  | [optional] 
**time** | **str** |  | [optional] 

## Example

```python
from si_tests.clients.gcore.box_api.models.v1_inference_log import V1InferenceLog

# TODO update the JSON string below
json = "{}"
# create an instance of V1InferenceLog from a JSON string
v1_inference_log_instance = V1InferenceLog.from_json(json)
# print the JSON string representation of the object
print(V1InferenceLog.to_json())

# convert the object into a dict
v1_inference_log_dict = v1_inference_log_instance.to_dict()
# create an instance of V1InferenceLog from a dict
v1_inference_log_from_dict = V1InferenceLog.from_dict(v1_inference_log_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


