# SchemasAppDeploymentList


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**count** | **int** | The Count indicates the total number of deployments in the list. | [optional] 
**results** | [**List[SchemasAppDeployment]**](SchemasAppDeployment.md) | Results contains the list of AI application deployments. | [optional] 

## Example

```python
from si_tests.clients.gcore.box_api.models.schemas_app_deployment_list import SchemasAppDeploymentList

# TODO update the JSON string below
json = "{}"
# create an instance of SchemasAppDeploymentList from a JSON string
schemas_app_deployment_list_instance = SchemasAppDeploymentList.from_json(json)
# print the JSON string representation of the object
print(SchemasAppDeploymentList.to_json())

# convert the object into a dict
schemas_app_deployment_list_dict = schemas_app_deployment_list_instance.to_dict()
# create an instance of SchemasAppDeploymentList from a dict
schemas_app_deployment_list_from_dict = SchemasAppDeploymentList.from_dict(schemas_app_deployment_list_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


