# V1UpdateSubRegionRequest


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**billing_name** | **str** | BillingName of the logical region | [optional] 
**has_gpu** | **bool** | HasGpu indicates if the logical region has a GPU | [optional] 
**latitude** | **str** | Latitude of the subregion | [optional] 
**longitude** | **str** | Longitude of the subregion | [optional] 
**node_names** | **List[str]** | NodeNames the name of the nodes in the logical region | [optional] 

## Example

```python
from si_tests.clients.gcore.box_api.models.v1_update_sub_region_request import V1UpdateSubRegionRequest

# TODO update the JSON string below
json = "{}"
# create an instance of V1UpdateSubRegionRequest from a JSON string
v1_update_sub_region_request_instance = V1UpdateSubRegionRequest.from_json(json)
# print the JSON string representation of the object
print(V1UpdateSubRegionRequest.to_json())

# convert the object into a dict
v1_update_sub_region_request_dict = v1_update_sub_region_request_instance.to_dict()
# create an instance of V1UpdateSubRegionRequest from a dict
v1_update_sub_region_request_from_dict = V1UpdateSubRegionRequest.from_dict(v1_update_sub_region_request_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


