# V1CreateRegistryUserRequest


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **str** | Name of the user | 
**read_only** | **bool** | ReadOnly of the user | [optional] 

## Example

```python
from si_tests.clients.gcore.box_api.models.v1_create_registry_user_request import V1CreateRegistryUserRequest

# TODO update the JSON string below
json = "{}"
# create an instance of V1CreateRegistryUserRequest from a JSON string
v1_create_registry_user_request_instance = V1CreateRegistryUserRequest.from_json(json)
# print the JSON string representation of the object
print(V1CreateRegistryUserRequest.to_json())

# convert the object into a dict
v1_create_registry_user_request_dict = v1_create_registry_user_request_instance.to_dict()
# create an instance of V1CreateRegistryUserRequest from a dict
v1_create_registry_user_request_from_dict = V1CreateRegistryUserRequest.from_dict(v1_create_registry_user_request_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


