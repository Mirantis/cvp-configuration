# V1UserResponse


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**access_rules** | [**List[V1AccessRule]**](V1AccessRule.md) | AccessRules to the namespaces | [optional] 
**created_at** | **str** | CreatedAt is the time when the user was created | [optional] 
**email** | **str** | Email of the user | [optional] 
**groups** | **List[str]** | Groups the user belongs to | [optional] 
**is_super_user** | **bool** | IsSuperUser flag to indicate if the user is superuser | [optional] 
**name** | **str** | Name of the user | [optional] 

## Example

```python
from si_tests.clients.gcore.box_api.models.v1_user_response import V1UserResponse

# TODO update the JSON string below
json = "{}"
# create an instance of V1UserResponse from a JSON string
v1_user_response_instance = V1UserResponse.from_json(json)
# print the JSON string representation of the object
print(V1UserResponse.to_json())

# convert the object into a dict
v1_user_response_dict = v1_user_response_instance.to_dict()
# create an instance of V1UserResponse from a dict
v1_user_response_from_dict = V1UserResponse.from_dict(v1_user_response_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


