# V1RegistryUserRef

RegistryUser is the user of the inference, if provided we use this user and his credentials to deploy the inference instead of pull_secret field

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **str** | Name of the user | [optional] 

## Example

```python
from si_tests.clients.gcore.box_api.models.v1_registry_user_ref import V1RegistryUserRef

# TODO update the JSON string below
json = "{}"
# create an instance of V1RegistryUserRef from a JSON string
v1_registry_user_ref_instance = V1RegistryUserRef.from_json(json)
# print the JSON string representation of the object
print(V1RegistryUserRef.to_json())

# convert the object into a dict
v1_registry_user_ref_dict = v1_registry_user_ref_instance.to_dict()
# create an instance of V1RegistryUserRef from a dict
v1_registry_user_ref_from_dict = V1RegistryUserRef.from_dict(v1_registry_user_ref_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


