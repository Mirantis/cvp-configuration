# V1CreateSlurmClusterLoginConfig

Login node configuration.

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ssh_keys** | **List[str]** | SSHKeys is the list of public keys authorized for SSH connection to Slurm login nodes. Each key must be specified in the &#x60;.ssh/authorized_keys&#x60; format. | 

## Example

```python
from si_tests.clients.gcore.box_api.models.v1_create_slurm_cluster_login_config import V1CreateSlurmClusterLoginConfig

# TODO update the JSON string below
json = "{}"
# create an instance of V1CreateSlurmClusterLoginConfig from a JSON string
v1_create_slurm_cluster_login_config_instance = V1CreateSlurmClusterLoginConfig.from_json(json)
# print the JSON string representation of the object
print(V1CreateSlurmClusterLoginConfig.to_json())

# convert the object into a dict
v1_create_slurm_cluster_login_config_dict = v1_create_slurm_cluster_login_config_instance.to_dict()
# create an instance of V1CreateSlurmClusterLoginConfig from a dict
v1_create_slurm_cluster_login_config_from_dict = V1CreateSlurmClusterLoginConfig.from_dict(v1_create_slurm_cluster_login_config_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


