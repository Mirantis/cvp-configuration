# V1CreateTlsSecretRequest


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**crt** | **str** |  | 
**key** | **str** |  | 
**name** | **str** |  | 

## Example

```python
from si_tests.clients.gcore.box_api.models.v1_create_tls_secret_request import V1CreateTlsSecretRequest

# TODO update the JSON string below
json = "{}"
# create an instance of V1CreateTlsSecretRequest from a JSON string
v1_create_tls_secret_request_instance = V1CreateTlsSecretRequest.from_json(json)
# print the JSON string representation of the object
print(V1CreateTlsSecretRequest.to_json())

# convert the object into a dict
v1_create_tls_secret_request_dict = v1_create_tls_secret_request_instance.to_dict()
# create an instance of V1CreateTlsSecretRequest from a dict
v1_create_tls_secret_request_from_dict = V1CreateTlsSecretRequest.from_dict(v1_create_tls_secret_request_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


