# V1CreateNamespaceRequest


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **str** | Name of the project | 

## Example

```python
from si_tests.clients.gcore.box_api.models.v1_create_namespace_request import V1CreateNamespaceRequest

# TODO update the JSON string below
json = "{}"
# create an instance of V1CreateNamespaceRequest from a JSON string
v1_create_namespace_request_instance = V1CreateNamespaceRequest.from_json(json)
# print the JSON string representation of the object
print(V1CreateNamespaceRequest.to_json())

# convert the object into a dict
v1_create_namespace_request_dict = v1_create_namespace_request_instance.to_dict()
# create an instance of V1CreateNamespaceRequest from a dict
v1_create_namespace_request_from_dict = V1CreateNamespaceRequest.from_dict(v1_create_namespace_request_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


