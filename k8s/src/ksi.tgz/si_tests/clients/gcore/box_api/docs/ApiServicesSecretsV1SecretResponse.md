# ApiServicesSecretsV1SecretResponse


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**data** | **Dict[str, str]** |  | [optional] 
**name** | **str** |  | [optional] 
**type** | **str** |  | [optional] 

## Example

```python
from si_tests.clients.gcore.box_api.models.api_services_secrets_v1_secret_response import ApiServicesSecretsV1SecretResponse

# TODO update the JSON string below
json = "{}"
# create an instance of ApiServicesSecretsV1SecretResponse from a JSON string
api_services_secrets_v1_secret_response_instance = ApiServicesSecretsV1SecretResponse.from_json(json)
# print the JSON string representation of the object
print(ApiServicesSecretsV1SecretResponse.to_json())

# convert the object into a dict
api_services_secrets_v1_secret_response_dict = api_services_secrets_v1_secret_response_instance.to_dict()
# create an instance of ApiServicesSecretsV1SecretResponse from a dict
api_services_secrets_v1_secret_response_from_dict = ApiServicesSecretsV1SecretResponse.from_dict(api_services_secrets_v1_secret_response_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


