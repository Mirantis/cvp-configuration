# V1GetApiKeyResponse


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**created_at** | **str** | When the API key was created | [optional] 
**description** | **str** | Description of the API key | [optional] 
**expires_at** | **str** | When the API key will expire | [optional] 
**inferences** | **List[str]** | List of inference deployments where this API key is used for authentication | [optional] 
**name** | **str** | Name of the API key used for authentication with deployed inference applications | [optional] 

## Example

```python
from si_tests.clients.gcore.box_api.models.v1_get_api_key_response import V1GetApiKeyResponse

# TODO update the JSON string below
json = "{}"
# create an instance of V1GetApiKeyResponse from a JSON string
v1_get_api_key_response_instance = V1GetApiKeyResponse.from_json(json)
# print the JSON string representation of the object
print(V1GetApiKeyResponse.to_json())

# convert the object into a dict
v1_get_api_key_response_dict = v1_get_api_key_response_instance.to_dict()
# create an instance of V1GetApiKeyResponse from a dict
v1_get_api_key_response_from_dict = V1GetApiKeyResponse.from_dict(v1_get_api_key_response_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


