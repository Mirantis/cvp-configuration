# V1HttpTrigger

Http trigger configuration

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**rate** | **int** | Rate is the number of pending requests that triggers the scaling | [optional] 
**window** | **int** | Window is the time in seconds that used for aggregation of requests for rate calculation | [optional] 

## Example

```python
from si_tests.clients.gcore.box_api.models.v1_http_trigger import V1HttpTrigger

# TODO update the JSON string below
json = "{}"
# create an instance of V1HttpTrigger from a JSON string
v1_http_trigger_instance = V1HttpTrigger.from_json(json)
# print the JSON string representation of the object
print(V1HttpTrigger.to_json())

# convert the object into a dict
v1_http_trigger_dict = v1_http_trigger_instance.to_dict()
# create an instance of V1HttpTrigger from a dict
v1_http_trigger_from_dict = V1HttpTrigger.from_dict(v1_http_trigger_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


