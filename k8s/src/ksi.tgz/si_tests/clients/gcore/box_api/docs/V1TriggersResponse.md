# V1TriggersResponse


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**cpu** | [**V1CpuTrigger**](V1CpuTrigger.md) |  | [optional] 
**gpu_memory** | [**V1GpuMemoryTrigger**](V1GpuMemoryTrigger.md) |  | [optional] 
**gpu_utilization** | [**V1GpuUtilizationTrigger**](V1GpuUtilizationTrigger.md) |  | [optional] 
**http** | [**V1HttpTrigger**](V1HttpTrigger.md) |  | [optional] 
**memory** | [**V1MemoryTrigger**](V1MemoryTrigger.md) |  | [optional] 
**sqs** | [**V1SqsTrigger**](V1SqsTrigger.md) |  | [optional] 

## Example

```python
from si_tests.clients.gcore.box_api.models.v1_triggers_response import V1TriggersResponse

# TODO update the JSON string below
json = "{}"
# create an instance of V1TriggersResponse from a JSON string
v1_triggers_response_instance = V1TriggersResponse.from_json(json)
# print the JSON string representation of the object
print(V1TriggersResponse.to_json())

# convert the object into a dict
v1_triggers_response_dict = v1_triggers_response_instance.to_dict()
# create an instance of V1TriggersResponse from a dict
v1_triggers_response_from_dict = V1TriggersResponse.from_dict(v1_triggers_response_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


