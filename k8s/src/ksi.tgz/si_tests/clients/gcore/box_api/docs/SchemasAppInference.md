# SchemasAppInference


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**flavor** | **str** |  | [optional] 
**name** | **str** |  | [optional] 

## Example

```python
from si_tests.clients.gcore.box_api.models.schemas_app_inference import SchemasAppInference

# TODO update the JSON string below
json = "{}"
# create an instance of SchemasAppInference from a JSON string
schemas_app_inference_instance = SchemasAppInference.from_json(json)
# print the JSON string representation of the object
print(SchemasAppInference.to_json())

# convert the object into a dict
schemas_app_inference_dict = schemas_app_inference_instance.to_dict()
# create an instance of SchemasAppInference from a dict
schemas_app_inference_from_dict = SchemasAppInference.from_dict(schemas_app_inference_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


