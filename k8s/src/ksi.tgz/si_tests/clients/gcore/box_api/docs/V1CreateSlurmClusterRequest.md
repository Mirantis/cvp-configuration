# V1CreateSlurmClusterRequest


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**login** | [**V1CreateSlurmClusterLoginConfig**](V1CreateSlurmClusterLoginConfig.md) |  | 
**region_name** | **str** | RegionName is the name of the region in which the cluster should be created. Only core regions are supported. | 
**worker** | [**V1CreateSlurmClusterWorkerConfig**](V1CreateSlurmClusterWorkerConfig.md) |  | 

## Example

```python
from si_tests.clients.gcore.box_api.models.v1_create_slurm_cluster_request import V1CreateSlurmClusterRequest

# TODO update the JSON string below
json = "{}"
# create an instance of V1CreateSlurmClusterRequest from a JSON string
v1_create_slurm_cluster_request_instance = V1CreateSlurmClusterRequest.from_json(json)
# print the JSON string representation of the object
print(V1CreateSlurmClusterRequest.to_json())

# convert the object into a dict
v1_create_slurm_cluster_request_dict = v1_create_slurm_cluster_request_instance.to_dict()
# create an instance of V1CreateSlurmClusterRequest from a dict
v1_create_slurm_cluster_request_from_dict = V1CreateSlurmClusterRequest.from_dict(v1_create_slurm_cluster_request_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


