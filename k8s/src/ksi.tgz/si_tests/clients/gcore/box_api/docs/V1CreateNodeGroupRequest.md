# V1CreateNodeGroupRequest


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**custom_labels** | **Dict[str, str]** | CustomLabels contains the list of custom labels | [optional] 
**name** | **str** | Name of the node group | 
**namespaces** | **List[str]** | Namespaces contains the list of namespaces | [optional] 
**node_refs** | **Dict[str, List[str]]** | NodeRefs contains the list of node references by region | [optional] 

## Example

```python
from si_tests.clients.gcore.box_api.models.v1_create_node_group_request import V1CreateNodeGroupRequest

# TODO update the JSON string below
json = "{}"
# create an instance of V1CreateNodeGroupRequest from a JSON string
v1_create_node_group_request_instance = V1CreateNodeGroupRequest.from_json(json)
# print the JSON string representation of the object
print(V1CreateNodeGroupRequest.to_json())

# convert the object into a dict
v1_create_node_group_request_dict = v1_create_node_group_request_instance.to_dict()
# create an instance of V1CreateNodeGroupRequest from a dict
v1_create_node_group_request_from_dict = V1CreateNodeGroupRequest.from_dict(v1_create_node_group_request_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


