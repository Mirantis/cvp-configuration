# V1RegistryRef

Registry is the local container registry of the inference. Used together with registry_image and registry_user.

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **str** | Name of the registry | [optional] 

## Example

```python
from si_tests.clients.gcore.box_api.models.v1_registry_ref import V1RegistryRef

# TODO update the JSON string below
json = "{}"
# create an instance of V1RegistryRef from a JSON string
v1_registry_ref_instance = V1RegistryRef.from_json(json)
# print the JSON string representation of the object
print(V1RegistryRef.to_json())

# convert the object into a dict
v1_registry_ref_dict = v1_registry_ref_instance.to_dict()
# create an instance of V1RegistryRef from a dict
v1_registry_ref_from_dict = V1RegistryRef.from_dict(v1_registry_ref_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


