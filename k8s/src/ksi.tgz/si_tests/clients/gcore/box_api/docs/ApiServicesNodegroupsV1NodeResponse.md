# ApiServicesNodegroupsV1NodeResponse


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**capacity** | **Dict[str, str]** | Capacity contains the capacity of the node | [optional] 
**gpu_model** | **str** | GpuModel the model of the GPU if node has one | [optional] 
**name** | **str** | Name of the node | [optional] 
**node_group** | **str** | NodeGroup is the name of the node group if node in the group | [optional] 
**region_name** | **str** | RegionName the name of the region the node belongs to | [optional] 
**resources** | **Dict[str, str]** | Resources contains the resources allocated to the node group | [optional] 

## Example

```python
from si_tests.clients.gcore.box_api.models.api_services_nodegroups_v1_node_response import ApiServicesNodegroupsV1NodeResponse

# TODO update the JSON string below
json = "{}"
# create an instance of ApiServicesNodegroupsV1NodeResponse from a JSON string
api_services_nodegroups_v1_node_response_instance = ApiServicesNodegroupsV1NodeResponse.from_json(json)
# print the JSON string representation of the object
print(ApiServicesNodegroupsV1NodeResponse.to_json())

# convert the object into a dict
api_services_nodegroups_v1_node_response_dict = api_services_nodegroups_v1_node_response_instance.to_dict()
# create an instance of ApiServicesNodegroupsV1NodeResponse from a dict
api_services_nodegroups_v1_node_response_from_dict = ApiServicesNodegroupsV1NodeResponse.from_dict(api_services_nodegroups_v1_node_response_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


