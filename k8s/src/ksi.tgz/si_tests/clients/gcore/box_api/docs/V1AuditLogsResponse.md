# V1AuditLogsResponse


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**count** | **int** | Count of user actions | [optional] 
**results** | [**List[V1AuditLogResponse]**](V1AuditLogResponse.md) |  | [optional] 

## Example

```python
from si_tests.clients.gcore.box_api.models.v1_audit_logs_response import V1AuditLogsResponse

# TODO update the JSON string below
json = "{}"
# create an instance of V1AuditLogsResponse from a JSON string
v1_audit_logs_response_instance = V1AuditLogsResponse.from_json(json)
# print the JSON string representation of the object
print(V1AuditLogsResponse.to_json())

# convert the object into a dict
v1_audit_logs_response_dict = v1_audit_logs_response_instance.to_dict()
# create an instance of V1AuditLogsResponse from a dict
v1_audit_logs_response_from_dict = V1AuditLogsResponse.from_dict(v1_audit_logs_response_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


