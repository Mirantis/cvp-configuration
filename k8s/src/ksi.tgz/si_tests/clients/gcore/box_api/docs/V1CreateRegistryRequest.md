# V1CreateRegistryRequest


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **str** | Name of the registry | 
**preheat_policies** | [**List[ApiServicesRegistriesV1PreheatPolicy]**](ApiServicesRegistriesV1PreheatPolicy.md) | PreheatPolicies of the registry | [optional] 
**public** | **bool** | Public of the registry | [optional] 
**storage_limit** | **str** | StorageLimit of the registry | [optional] 

## Example

```python
from si_tests.clients.gcore.box_api.models.v1_create_registry_request import V1CreateRegistryRequest

# TODO update the JSON string below
json = "{}"
# create an instance of V1CreateRegistryRequest from a JSON string
v1_create_registry_request_instance = V1CreateRegistryRequest.from_json(json)
# print the JSON string representation of the object
print(V1CreateRegistryRequest.to_json())

# convert the object into a dict
v1_create_registry_request_dict = v1_create_registry_request_instance.to_dict()
# create an instance of V1CreateRegistryRequest from a dict
v1_create_registry_request_from_dict = V1CreateRegistryRequest.from_dict(v1_create_registry_request_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


