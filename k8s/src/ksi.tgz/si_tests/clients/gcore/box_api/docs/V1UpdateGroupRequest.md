# V1UpdateGroupRequest


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**access_rules** | [**List[V1AccessRule]**](V1AccessRule.md) | AccessRules to the namespaces | [optional] 
**is_super_user** | **bool** | IsSuperUser flag to indicate if the user is superuser | 

## Example

```python
from si_tests.clients.gcore.box_api.models.v1_update_group_request import V1UpdateGroupRequest

# TODO update the JSON string below
json = "{}"
# create an instance of V1UpdateGroupRequest from a JSON string
v1_update_group_request_instance = V1UpdateGroupRequest.from_json(json)
# print the JSON string representation of the object
print(V1UpdateGroupRequest.to_json())

# convert the object into a dict
v1_update_group_request_dict = v1_update_group_request_instance.to_dict()
# create an instance of V1UpdateGroupRequest from a dict
v1_update_group_request_from_dict = V1UpdateGroupRequest.from_dict(v1_update_group_request_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


