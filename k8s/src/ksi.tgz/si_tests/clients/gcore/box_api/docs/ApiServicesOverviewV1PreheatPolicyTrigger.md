# ApiServicesOverviewV1PreheatPolicyTrigger

Trigger of the preheat policy

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**schedule** | **str** | Schedule of the preheat policy trigger | [optional] 
**type** | **str** | Type of the preheat policy trigger | [optional] 

## Example

```python
from si_tests.clients.gcore.box_api.models.api_services_overview_v1_preheat_policy_trigger import ApiServicesOverviewV1PreheatPolicyTrigger

# TODO update the JSON string below
json = "{}"
# create an instance of ApiServicesOverviewV1PreheatPolicyTrigger from a JSON string
api_services_overview_v1_preheat_policy_trigger_instance = ApiServicesOverviewV1PreheatPolicyTrigger.from_json(json)
# print the JSON string representation of the object
print(ApiServicesOverviewV1PreheatPolicyTrigger.to_json())

# convert the object into a dict
api_services_overview_v1_preheat_policy_trigger_dict = api_services_overview_v1_preheat_policy_trigger_instance.to_dict()
# create an instance of ApiServicesOverviewV1PreheatPolicyTrigger from a dict
api_services_overview_v1_preheat_policy_trigger_from_dict = ApiServicesOverviewV1PreheatPolicyTrigger.from_dict(api_services_overview_v1_preheat_policy_trigger_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


