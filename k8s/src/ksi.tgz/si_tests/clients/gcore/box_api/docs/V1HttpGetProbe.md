# V1HttpGetProbe

HttpGet is probe type which sending HTTP requests to container

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**headers** | **Dict[str, str]** | Headers are additional HTTP headers to include in the request. | [optional] 
**host** | **str** | Host is the hostname or IP address to use for the HTTP GET request. | [optional] 
**path** | **str** | Path is the URL path to use for the HTTP GET request. | [optional] 
**port** | **int** | Port is the port to use for the HTTP GET request. | [optional] 
**var_schema** | **str** | Schema is the protocol to use (e.g., \&quot;http\&quot; or \&quot;https\&quot;). | [optional] 

## Example

```python
from si_tests.clients.gcore.box_api.models.v1_http_get_probe import V1HttpGetProbe

# TODO update the JSON string below
json = "{}"
# create an instance of V1HttpGetProbe from a JSON string
v1_http_get_probe_instance = V1HttpGetProbe.from_json(json)
# print the JSON string representation of the object
print(V1HttpGetProbe.to_json())

# convert the object into a dict
v1_http_get_probe_dict = v1_http_get_probe_instance.to_dict()
# create an instance of V1HttpGetProbe from a dict
v1_http_get_probe_from_dict = V1HttpGetProbe.from_dict(v1_http_get_probe_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


