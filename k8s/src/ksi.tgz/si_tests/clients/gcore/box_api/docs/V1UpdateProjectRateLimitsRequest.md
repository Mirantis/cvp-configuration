# V1UpdateProjectRateLimitsRequest


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**public** | [**List[ApiServicesProjectsV1UpdatePublicRateLimitRequest]**](ApiServicesProjectsV1UpdatePublicRateLimitRequest.md) |  | [optional] 

## Example

```python
from si_tests.clients.gcore.box_api.models.v1_update_project_rate_limits_request import V1UpdateProjectRateLimitsRequest

# TODO update the JSON string below
json = "{}"
# create an instance of V1UpdateProjectRateLimitsRequest from a JSON string
v1_update_project_rate_limits_request_instance = V1UpdateProjectRateLimitsRequest.from_json(json)
# print the JSON string representation of the object
print(V1UpdateProjectRateLimitsRequest.to_json())

# convert the object into a dict
v1_update_project_rate_limits_request_dict = v1_update_project_rate_limits_request_instance.to_dict()
# create an instance of V1UpdateProjectRateLimitsRequest from a dict
v1_update_project_rate_limits_request_from_dict = V1UpdateProjectRateLimitsRequest.from_dict(v1_update_project_rate_limits_request_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


