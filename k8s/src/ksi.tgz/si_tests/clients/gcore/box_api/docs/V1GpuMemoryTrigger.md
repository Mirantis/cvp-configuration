# V1GpuMemoryTrigger

GpuMemory trigger configuration

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**threshold** | **int** | Threshold in percentage of GPU memory usage that triggers the scaling | [optional] 

## Example

```python
from si_tests.clients.gcore.box_api.models.v1_gpu_memory_trigger import V1GpuMemoryTrigger

# TODO update the JSON string below
json = "{}"
# create an instance of V1GpuMemoryTrigger from a JSON string
v1_gpu_memory_trigger_instance = V1GpuMemoryTrigger.from_json(json)
# print the JSON string representation of the object
print(V1GpuMemoryTrigger.to_json())

# convert the object into a dict
v1_gpu_memory_trigger_dict = v1_gpu_memory_trigger_instance.to_dict()
# create an instance of V1GpuMemoryTrigger from a dict
v1_gpu_memory_trigger_from_dict = V1GpuMemoryTrigger.from_dict(v1_gpu_memory_trigger_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


