# V1ListRegionResponse


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**count** | **int** | Count of regions | [optional] 
**results** | [**List[V1RegionResponse]**](V1RegionResponse.md) | Results contains the list of regions | [optional] 

## Example

```python
from si_tests.clients.gcore.box_api.models.v1_list_region_response import V1ListRegionResponse

# TODO update the JSON string below
json = "{}"
# create an instance of V1ListRegionResponse from a JSON string
v1_list_region_response_instance = V1ListRegionResponse.from_json(json)
# print the JSON string representation of the object
print(V1ListRegionResponse.to_json())

# convert the object into a dict
v1_list_region_response_dict = v1_list_region_response_instance.to_dict()
# create an instance of V1ListRegionResponse from a dict
v1_list_region_response_from_dict = V1ListRegionResponse.from_dict(v1_list_region_response_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


