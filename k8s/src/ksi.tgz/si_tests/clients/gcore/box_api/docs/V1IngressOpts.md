# V1IngressOpts

IngressOpts additional options for ingress

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**disable_response_buffering** | **bool** | DisableResponseBuffering disables response buffering | [optional] 
**read_timeout** | **int** | ReadTimeout is the read timeout for the reverse proxy | [optional] 

## Example

```python
from si_tests.clients.gcore.box_api.models.v1_ingress_opts import V1IngressOpts

# TODO update the JSON string below
json = "{}"
# create an instance of V1IngressOpts from a JSON string
v1_ingress_opts_instance = V1IngressOpts.from_json(json)
# print the JSON string representation of the object
print(V1IngressOpts.to_json())

# convert the object into a dict
v1_ingress_opts_dict = v1_ingress_opts_instance.to_dict()
# create an instance of V1IngressOpts from a dict
v1_ingress_opts_from_dict = V1IngressOpts.from_dict(v1_ingress_opts_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


