# V1RegistryImageRef

RegistryImage is the image of the inference, if provided we use this image to deploy the inference instead of image field

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **str** | Name of the image | [optional] 
**tag** | **str** | Tag of the image | [optional] 

## Example

```python
from si_tests.clients.gcore.box_api.models.v1_registry_image_ref import V1RegistryImageRef

# TODO update the JSON string below
json = "{}"
# create an instance of V1RegistryImageRef from a JSON string
v1_registry_image_ref_instance = V1RegistryImageRef.from_json(json)
# print the JSON string representation of the object
print(V1RegistryImageRef.to_json())

# convert the object into a dict
v1_registry_image_ref_dict = v1_registry_image_ref_instance.to_dict()
# create an instance of V1RegistryImageRef from a dict
v1_registry_image_ref_from_dict = V1RegistryImageRef.from_dict(v1_registry_image_ref_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


