# SchemasExposeAddress


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**address** | **str** | Address is a global access endpoint for a component | [optional] 

## Example

```python
from si_tests.clients.gcore.box_api.models.schemas_expose_address import SchemasExposeAddress

# TODO update the JSON string below
json = "{}"
# create an instance of SchemasExposeAddress from a JSON string
schemas_expose_address_instance = SchemasExposeAddress.from_json(json)
# print the JSON string representation of the object
print(SchemasExposeAddress.to_json())

# convert the object into a dict
schemas_expose_address_dict = schemas_expose_address_instance.to_dict()
# create an instance of SchemasExposeAddress from a dict
schemas_expose_address_from_dict = SchemasExposeAddress.from_dict(schemas_expose_address_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


