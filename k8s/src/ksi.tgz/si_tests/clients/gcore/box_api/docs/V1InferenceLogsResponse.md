# V1InferenceLogsResponse


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**count** | **int** |  | [optional] 
**results** | [**List[V1InferenceLog]**](V1InferenceLog.md) |  | [optional] 

## Example

```python
from si_tests.clients.gcore.box_api.models.v1_inference_logs_response import V1InferenceLogsResponse

# TODO update the JSON string below
json = "{}"
# create an instance of V1InferenceLogsResponse from a JSON string
v1_inference_logs_response_instance = V1InferenceLogsResponse.from_json(json)
# print the JSON string representation of the object
print(V1InferenceLogsResponse.to_json())

# convert the object into a dict
v1_inference_logs_response_dict = v1_inference_logs_response_instance.to_dict()
# create an instance of V1InferenceLogsResponse from a dict
v1_inference_logs_response_from_dict = V1InferenceLogsResponse.from_dict(v1_inference_logs_response_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


