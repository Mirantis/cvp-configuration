# V1ImageResponse


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**display_name** | **str** | DisplayName of the image | [optional] 
**name** | **str** | Name of the image | [optional] 
**repository** | **str** | Repository of the image | [optional] 
**size** | **str** | Size of the image | [optional] 
**tags** | **List[str]** | Tags of the image | [optional] 

## Example

```python
from si_tests.clients.gcore.box_api.models.v1_image_response import V1ImageResponse

# TODO update the JSON string below
json = "{}"
# create an instance of V1ImageResponse from a JSON string
v1_image_response_instance = V1ImageResponse.from_json(json)
# print the JSON string representation of the object
print(V1ImageResponse.to_json())

# convert the object into a dict
v1_image_response_dict = v1_image_response_instance.to_dict()
# create an instance of V1ImageResponse from a dict
v1_image_response_from_dict = V1ImageResponse.from_dict(v1_image_response_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


