# V1GetMetricsForPodResponse


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**cpu_utilization** | **float** | CPU utilization in millicores | [optional] 
**gpu_model** | **str** |  | [optional] 
**gpu_node** | **str** |  | [optional] 
**gpu_utilization** | **int** | GPU utilization in percent | [optional] 
**name** | **str** |  | [optional] 
**namespace** | **str** |  | [optional] 
**ram_utilization** | **int** | RAM utilization in MiB | [optional] 
**vram_utilization** | **int** | VRAM utilization in MiB | [optional] 

## Example

```python
from si_tests.clients.gcore.box_api.models.v1_get_metrics_for_pod_response import V1GetMetricsForPodResponse

# TODO update the JSON string below
json = "{}"
# create an instance of V1GetMetricsForPodResponse from a JSON string
v1_get_metrics_for_pod_response_instance = V1GetMetricsForPodResponse.from_json(json)
# print the JSON string representation of the object
print(V1GetMetricsForPodResponse.to_json())

# convert the object into a dict
v1_get_metrics_for_pod_response_dict = v1_get_metrics_for_pod_response_instance.to_dict()
# create an instance of V1GetMetricsForPodResponse from a dict
v1_get_metrics_for_pod_response_from_dict = V1GetMetricsForPodResponse.from_dict(v1_get_metrics_for_pod_response_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


