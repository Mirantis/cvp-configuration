# V1EmptyDirVolumeSource

EmptyDir is the EmptyDir volume configuration

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**medium** | **str** | Medium specifies the storage backing for EmptyDir, such as default disk, memory (tmpfs) Accepts \&quot;\&quot;, \&quot;Memory\&quot; | [optional] 
**size_limit** | **str** | SizeLimit is the size limit for an EmptyDir storage | 

## Example

```python
from si_tests.clients.gcore.box_api.models.v1_empty_dir_volume_source import V1EmptyDirVolumeSource

# TODO update the JSON string below
json = "{}"
# create an instance of V1EmptyDirVolumeSource from a JSON string
v1_empty_dir_volume_source_instance = V1EmptyDirVolumeSource.from_json(json)
# print the JSON string representation of the object
print(V1EmptyDirVolumeSource.to_json())

# convert the object into a dict
v1_empty_dir_volume_source_dict = v1_empty_dir_volume_source_instance.to_dict()
# create an instance of V1EmptyDirVolumeSource from a dict
v1_empty_dir_volume_source_from_dict = V1EmptyDirVolumeSource.from_dict(v1_empty_dir_volume_source_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


