# V1MemoryTrigger

Memory trigger configuration

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**threshold** | **int** | Trehsold in percentage of memory usage that triggers the scaling | [optional] 

## Example

```python
from si_tests.clients.gcore.box_api.models.v1_memory_trigger import V1MemoryTrigger

# TODO update the JSON string below
json = "{}"
# create an instance of V1MemoryTrigger from a JSON string
v1_memory_trigger_instance = V1MemoryTrigger.from_json(json)
# print the JSON string representation of the object
print(V1MemoryTrigger.to_json())

# convert the object into a dict
v1_memory_trigger_dict = v1_memory_trigger_instance.to_dict()
# create an instance of V1MemoryTrigger from a dict
v1_memory_trigger_from_dict = V1MemoryTrigger.from_dict(v1_memory_trigger_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


