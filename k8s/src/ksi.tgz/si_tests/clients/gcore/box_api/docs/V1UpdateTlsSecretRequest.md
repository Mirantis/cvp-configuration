# V1UpdateTlsSecretRequest


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**crt** | **str** |  | [optional] 
**key** | **str** |  | [optional] 

## Example

```python
from si_tests.clients.gcore.box_api.models.v1_update_tls_secret_request import V1UpdateTlsSecretRequest

# TODO update the JSON string below
json = "{}"
# create an instance of V1UpdateTlsSecretRequest from a JSON string
v1_update_tls_secret_request_instance = V1UpdateTlsSecretRequest.from_json(json)
# print the JSON string representation of the object
print(V1UpdateTlsSecretRequest.to_json())

# convert the object into a dict
v1_update_tls_secret_request_dict = v1_update_tls_secret_request_instance.to_dict()
# create an instance of V1UpdateTlsSecretRequest from a dict
v1_update_tls_secret_request_from_dict = V1UpdateTlsSecretRequest.from_dict(v1_update_tls_secret_request_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


