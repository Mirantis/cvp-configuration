# SchemasComponentStatus


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**error** | **str** | Error provides details about any errors encountered during the component&#39;s operation. | [optional] 
**status** | **str** | Status describes the current state of the component. | [optional] 

## Example

```python
from si_tests.clients.gcore.box_api.models.schemas_component_status import SchemasComponentStatus

# TODO update the JSON string below
json = "{}"
# create an instance of SchemasComponentStatus from a JSON string
schemas_component_status_instance = SchemasComponentStatus.from_json(json)
# print the JSON string representation of the object
print(SchemasComponentStatus.to_json())

# convert the object into a dict
schemas_component_status_dict = schemas_component_status_instance.to_dict()
# create an instance of SchemasComponentStatus from a dict
schemas_component_status_from_dict = SchemasComponentStatus.from_dict(schemas_component_status_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


