#    Copyright 2025 Mirantis, Inc.
#
#    Licensed under the Apache License, Version 2.0 (the "License"); you may
#    not use this file except in compliance with the License. You may obtain
#    a copy of the License at
#
#         http://www.apache.org/licenses/LICENSE-2.0
#
#    Unless required by applicable law or agreed to in writing, software
#    distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
#    WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
#    License for the specific language governing permissions and limitations
#    under the License.
#
# This file is designed as common module for built-in k8s client that does not depends on parent of k8s cluster
# object and can be used in different places with only one requirement - K8sCluster object.
import re
import base64

from si_tests import logger
from si_tests.utils import waiters, exceptions
from si_tests import settings
from kubernetes.client.rest import ApiException

from typing import TYPE_CHECKING, Optional, List, Tuple

if TYPE_CHECKING:
    from si_tests.clients.k8s import K8sCluster

LOG = logger.logger


def __get_replica_number(client: "K8sCluster", obj, namespace):
    """Return desired number of replicas/scheduled pods according to
       the pod owner specification (e.g. statefulset).
    """
    kind, name = obj.split('/')
    desired_num = 0
    if kind == 'ReplicaSet':
        desired_num = client.replicasets.get(
            name=name, namespace=namespace).desired_replicas
    elif kind == 'StatefulSet':
        desired_num = client.statefulsets.get(
            name=name, namespace=namespace).desired_replicas
    elif kind == 'DaemonSet':
        desired_num = client.daemonsets.get(
            name=name, namespace=namespace).desired_replicas
    else:
        LOG.warning(f"Unknown kind {kind}")
    return desired_num


def compare_objects(client: "K8sCluster",
                    expected_pods_dict,
                    exclude_jobs,
                    exclude_removed_nodes,
                    exclude_incorrect_affinity,
                    check_all_nss):
    failed = {}
    namespaces = expected_pods_dict.keys()
    actual_list = [pod for pod in
                   client.pods.list_raw().to_dict()['items']]

    if exclude_jobs:
        before_filtering = \
            set([x['metadata']['name'] for x in actual_list])
        actual_list = \
            [x for x in actual_list if not (
                    x['metadata']['owner_references'] and
                    x['metadata'][
                        'owner_references'][0]['kind'] == 'Job')]
        after_filtering = \
            set([x['metadata']['name'] for x in actual_list])
        LOG.debug(f"These pods are jobs and will be filtered out: "
                  f"{before_filtering - after_filtering}")

    if exclude_removed_nodes:
        # After cluster scale down, some pods may be still mapped on the
        # removed nodes. Garbage collector may clean these pods in few hours
        # but we can ignore such pods here
        node_names = [node.name for node in client.nodes.list_all()]
        before_filtering = set([x['metadata']['name'] for x in actual_list])

        new_actual_list = []
        filtered_nodes = set()
        for pod in actual_list:
            pod_name = f"{pod['metadata']['namespace']}/{pod['metadata']['name']}"

            node_name = pod['spec']['node_name']
            if node_name is not None and node_name not in node_names:
                LOG.warning(f"Pod {pod_name} node name is bound to non-existing node {node_name}, "
                            f"skip check the pod")
                filtered_nodes.add(node_name)
                continue

            node_selector = pod['spec']['node_selector'] or {}
            node_selector_hostname = node_selector.get('kubernetes.io/hostname')
            if node_selector_hostname is not None and node_selector_hostname not in node_names:
                LOG.warning(f"Pod {pod_name} node selector is bound to non-existing hostname "
                            f"{node_selector_hostname}, skip check the pod")
                filtered_nodes.add(node_selector_hostname)
                continue

            new_actual_list.append(pod)
        actual_list = new_actual_list
        filtered_nodes = list(filtered_nodes)

        after_filtering = set([x['metadata']['name'] for x in actual_list])

        if before_filtering - after_filtering:
            LOG.warning(f"These pods will be ignored because assigned to non-existing nodes "
                        f"{filtered_nodes} : {before_filtering - after_filtering}")

    if exclude_incorrect_affinity:
        # After changing node labels, some pods may no longer match the node affinity
        before_filtering = set([x['metadata']['name'] for x in actual_list])

        actual_list = [x for x in actual_list
                       if not (x['status'].get('phase', '') == 'Failed'
                               and x['status'].get('reason') == 'NodeAffinity')]

        after_filtering = set([x['metadata']['name'] for x in actual_list])

        if before_filtering - after_filtering:
            LOG.warning(f"These pods will be ignored because of wrong NodeAffinity: "
                        f"{before_filtering - after_filtering}")

    # constant
    excluded_pods = [
        'conformance',
    ]
    # special exclusions
    for excl_pod in excluded_pods:
        actual_list = \
            [x for x in actual_list
             if not x['metadata']['name'].startswith(excl_pod)]

    other_ns_pods = [pod for pod in actual_list
                     if pod['metadata']['namespace'] not in namespaces]
    actual_list = [pod for pod in actual_list
                   if pod['metadata']['namespace'] in namespaces]

    not_checked = [pod['metadata']['name'] for pod in actual_list]

    # sort names of expected pods so that
    # long names come first. "/no_owner" tag is excluded
    for ns in namespaces:
        expected_pods_lst = sorted(
            list(expected_pods_dict[ns].keys()),
            key=lambda x: len(x.split("/")[0]), reverse=True
        )
        for pod in expected_pods_lst:
            desired_num = expected_pods_dict[ns][pod]
            prefix = pod.split("/")[0]
            compare_list = \
                [pod for pod in actual_list
                 if pod['metadata']['name'].startswith(prefix) and
                 pod['metadata']['name'] in not_checked and
                 pod['metadata']['namespace'] == ns]

            if not compare_list:
                failed[prefix] = {"actual": 0,
                                  "desired/expected": desired_num}
                continue

            if '/no_owner' in pod:
                # for pods that are marked "no_owner" we do not fetch
                # owner and use # of pods from the file
                LOG.debug(f"Number of pods "
                          f"for {prefix} group will be checked "
                          f"according to expected pods list")
            else:
                # get owner kind and name for the first pod in list
                first_pod = compare_list[0]
                owner_references = \
                    first_pod['metadata']['owner_references']
                kind_name = f"{owner_references[0]['kind']}/" \
                            f"{owner_references[0]['name']}"

                if kind_name.split('/')[0] == "Node":
                    # Starting from 1.17 mirror pods have
                    # Node/node-name in owner_references
                    LOG.warning(f"No replica count info for pod "
                                f"{first_pod['metadata']['name']}. "
                                f"Using expected number ({desired_num}) "
                                f"from the list")
                    # Better to handle this type of pods as '/no_owner'
                    LOG.info("Please add '/no_owner' for this group of"
                             " pods to expected pods list file")
                else:
                    try:
                        replicas_num = __get_replica_number(
                            client,
                            kind_name,
                            first_pod['metadata']['namespace']
                        )
                        LOG.debug(f"First pod is "
                                  f"{first_pod['metadata']['name']}, "
                                  f"owner: {kind_name}, "
                                  f"replica #: {replicas_num}")
                        if int(replicas_num) != int(desired_num):
                            if kind_name.startswith("DaemonSet"):
                                LOG.warning(f"Replicas num ({replicas_num}) from {kind_name} "
                                            f"is not equal to the "
                                            f"number ({desired_num}) in expected "
                                            f"pod list. Pod: {prefix} . "
                                            f"Assuming DaemonSet replicas as expected pods number")
                                desired_num = int(replicas_num)
                            else:
                                LOG.warning(f"Replicas num ({replicas_num}) from {kind_name} "
                                            f"is not equal to the "
                                            f"number ({desired_num}) in expected "
                                            f"pod list. Pod: {prefix}")
                            # PRODX-30560, DaemonSets may have different replicas
                            # on different labs because of node taints or labels.
                            # So do not fail the check until found a better solution.
                            # failed[prefix] = {"object replicas": replicas_num,
                            #                  "desired/expected": desired_num}
                    except (Exception, ApiException) as e:
                        LOG.error(e)
                        LOG.error(f"Cannot process {prefix} "
                                  f"group of pods. Skipping")
                        failed[prefix] = {"actual": 0,
                                          "desired/expected": desired_num}
                        continue
            if int(desired_num) != len(compare_list):
                failed[prefix] = {"actual": len(compare_list),
                                  "desired/expected": desired_num}
            not_checked = [x for x in not_checked
                           if x not in [pod['metadata']['name']
                                        for pod in compare_list]]

            actual_ns = set([pod['metadata']['namespace']
                             for pod in compare_list])
            if set([ns]) != actual_ns:
                failed[prefix] = {"actual namespace": actual_ns,
                                  "desired/expected": ns}

    if other_ns_pods:
        for pod in other_ns_pods:
            LOG.error(f"Extra pod {pod['metadata']['name']} "
                      f"found in {pod['metadata']['namespace']} "
                      f"namespace")
            if check_all_nss:
                not_checked.append(pod['metadata']['name'])

    if failed or not_checked:
        result = {"Pods mismatch": failed,
                  "Not checked pods": not_checked}
        LOG.warning(f"Compare pod check failed: {result}")
        return result


def wait_expected_pods(client: "K8sCluster",
                       timeout=settings.KSI_CHECK_ACTUAL_EXPECTED_PODS_TIMEOUT,
                       interval=10,
                       expected_pods=None,
                       exclude_jobs=True,
                       exclude_removed_nodes=True,
                       exclude_incorrect_affinity=True,
                       check_all_nss=False):
    try:
        waiters.wait(lambda: not compare_objects(
            client,
            expected_pods_dict=expected_pods,
            exclude_jobs=exclude_jobs,
            exclude_removed_nodes=exclude_removed_nodes,
            exclude_incorrect_affinity=exclude_incorrect_affinity,
            check_all_nss=check_all_nss),
                     timeout=timeout, interval=interval)
    except exceptions.TimeoutError:
        result = compare_objects(client,
                                 expected_pods_dict=expected_pods,
                                 exclude_jobs=exclude_jobs,
                                 exclude_removed_nodes=exclude_removed_nodes,
                                 exclude_incorrect_affinity=exclude_incorrect_affinity,
                                 check_all_nss=check_all_nss)
        if result:
            err = f"Timeout waiting for pods. " \
                  f"After {timeout}s there are some fails: " \
                  f"{result}"
            raise TimeoutError(err)
    LOG.info("All pods and their replicas are found")


def get_corefile(client: "K8sCluster", name='coredns', namespace='kube-system'):
    cm = client.configmaps.get(name, namespace)
    return cm.read().data["Corefile"]


def override_coredns_configmap(client: "K8sCluster", corefile, name='coredns', namespace='kube-system'):
    """Update the coredns configmap with new Corefile

    :param namespace: cm namespace
    :param name: cm name
    :param client: k8s client
    :param corefile: corefile
    :return:
    """
    assert corefile, "Corefile can not be empty"
    LOG.info(f"Overriding Corefile:\n {corefile}")
    cm = client.configmaps.get(name, namespace)
    cm_data = cm.data
    cm_data['data']["Corefile"] = corefile
    cm.patch(body=cm_data)


def get_kubeconfig_from_secret(client: "K8sCluster", secret=None, cluster_name='',
                               namespace=settings.KSI_KCM_NAMESPACE):
    """Get kubeconfig for the cluster from secret

    :param secret: secret object
    :param namespace: Cluster namespace
    :param cluster_name: Cluster deployment name
    :param client: k8s Cluster client
        Returns tuple with kubeconfig name and content in yaml format
    """
    secret_name = secret.name or "{}-kubeconfig".format(cluster_name)
    LOG.debug("Fetching kubeconfig of {} cluster deployment".format(cluster_name))
    assert client.secrets.present(secret_name, namespace=namespace), (
        f"Secret {namespace}/{secret_name} not found. May be not populated yet.")
    kubeconfig_secret = client.secrets.get(
        secret_name, namespace=namespace)
    kubeconfig = kubeconfig_secret.read()
    assert kubeconfig.data, f"Secret {namespace}/{secret_name} is empty"
    kubeconfig = kubeconfig.data.get('value')
    assert kubeconfig, f"Secret {namespace}/{secret_name} doesn't contain kubeconfig"
    kubeconfig = base64.b64decode(kubeconfig).decode("utf-8")
    name = secret_name
    content = kubeconfig
    return name, content


# NOTE(va4st): Partial AI slop
class CorefileEditor:
    def __init__(self, corefile: str):
        self.original_corefile = corefile
        self.corefile = corefile

    def find_zone_block(self, zone=".:53") -> Optional[re.Match]:
        pattern = rf"""
            ^(\s*)({re.escape(zone)}\s*\{{)   # indent=1, head=2
            (.*?)                             # body=3
            ^\1(\}})                          # tail=4
        """
        return re.search(pattern, self.corefile, flags=re.DOTALL | re.MULTILINE | re.VERBOSE)

    def _replace_match(self, match: re.Match, new_zone_block: str):
        start, end = match.span(0)
        self.corefile = self.corefile[:start] + new_zone_block + self.corefile[end:]

    def has_plugin(self, plugin_name, zone=".:53") -> bool:
        match = self.find_zone_block(zone)
        if not match:
            return False
        _, _, body, _ = match.groups()
        return re.search(rf"^\s*{re.escape(plugin_name)}(\s|$|\{{)", body, flags=re.MULTILINE) is not None

    def insert_plugin(self, plugin_block: str, before_plugin="forward", zone=".:53") -> bool:
        match = self.find_zone_block(zone)
        if not match:
            raise ValueError(f"Zone block '{zone}' not found in Corefile")

        _, head, body, tail = match.groups()

        plugin_block = plugin_block.rstrip()  # Clean trailing spaces

        if plugin_block in body:
            return False

        body_stripped = body.strip("\n")  # Strip only newlines for proper formatting

        if before_plugin:
            m = re.search(rf"^(\s*{re.escape(before_plugin)}\b.*)$",
                          body_stripped, flags=re.MULTILINE)
            if m:
                insert_at = m.start(1)
                new_body = (
                        body_stripped[:insert_at].rstrip("\n")
                        + "\n" + plugin_block + "\n"
                        + body_stripped[insert_at:].lstrip("\n")
                )
            else:
                new_body = body_stripped.rstrip("\n") + "\n" + plugin_block
        else:
            new_body = body_stripped.rstrip("\n") + "\n" + plugin_block

        new_zone_block = f"{head}\n{new_body}\n{tail}"
        self._replace_match(match, new_zone_block)
        return True

    def insert_hosts_entries(self, entries: List[Tuple[str, str]], before_plugin="forward", zone=".:53") -> bool:
        host_lines = [f"        {ip} {domain}" for ip, domain in entries]
        plugin_block = (
                "    hosts {\n"
                + "\n".join(host_lines)
                + "\n        fallthrough\n"
                  "    }"
        )
        return self.insert_plugin(plugin_block, before_plugin, zone)

    def insert_hosts_entry(self, ip, domain, before_plugin="forward", zone=".:53") -> bool:
        return self.insert_hosts_entries([(ip, domain)], before_plugin, zone)

    def remove_hosts_entries(self, entries: List[Tuple[str, str]], zone=".:53") -> bool:
        match = self.find_zone_block(zone)
        if not match:
            return False

        _, head, body, tail = match.groups()

        def remove_lines(block: str) -> str:
            for ip, domain in entries:
                line_pattern = re.escape(f"{ip} {domain}")
                block = re.sub(rf"^\s*{line_pattern}\s*$", "", block, flags=re.MULTILINE)
            return block

        new_body = re.sub(r'(hosts\s*\{.*?^\s*\})', lambda m: remove_lines(m.group(0)),
                          body, flags=re.DOTALL | re.MULTILINE)

        if new_body == body:
            return False

        new_zone_block = f"{head}{new_body}{tail}"
        self._replace_match(match, new_zone_block)
        return True

    def remove_hosts_plugin(self, zone=".:53") -> bool:
        return self.remove_plugin("hosts", zone)

    def remove_plugin(self, plugin_name, zone=".:53") -> bool:
        match = self.find_zone_block(zone)
        if not match:
            return False

        _, head, body, tail = match.groups()

        clr_body = re.sub(rf"^\s*{re.escape(plugin_name)}\s*\{{.*?^\s*\}}\s*$", "",
                          body, flags=re.DOTALL | re.MULTILINE)
        clr_body = re.sub(rf"^\s*{re.escape(plugin_name)}\b.*$", "", clr_body, flags=re.MULTILINE)

        if clr_body == body:
            return False

        new_zone_block = f"{head}{clr_body}{tail}"
        self._replace_match(match, new_zone_block)
        return True

    def insert_template_record(self, qtype: str, name: str, target_hostname: str, ttl: int = 60,
                               before_plugin: str = "forward", zone: str = ".:53") -> bool:
        """Insert template record block

        :param qtype: "CNAME" / "A" / "AAAA"
        :param name: fqdn inside zone (like "vmauth.example.com")
        :param target_hostname: fqdn of any hyperscaler lb (like "xxx.elb.amazonaws.com")
        :param ttl: ttl param for record
        :param before_plugin: plugin name before which to insert template record
        :param zone: corefile zone
        :return: True if inserted, False if already exists
        """
        qtype = qtype.upper().strip()
        name = name.rstrip(".")
        target_hostname = target_hostname.rstrip(".")

        plugin_block = (
            f"    template IN {qtype} {name} {{\n"
            f"        answer \"{{{{ .Name }}}} {ttl} IN CNAME {target_hostname}.\"\n"
            f"    }}"
        )

        return self.insert_plugin(plugin_block, before_plugin=before_plugin, zone=zone)

    def insert_alias_templates(self, name: str, target_hostname: str, ttl: int = 60,
                               before_plugin: str = "forward", zone: str = ".:53") -> bool:
        """Adding three blocks of template records for aliasing (A/AAAA/CNAME)

        :param target_hostname: fqdn of any hyperscaler lb (like "xxx.elb.amazonaws.com")
        :param name: fqdn inside zone (like "vmauth.example.com")
        :param ttl: ttl param for records
        :param before_plugin: plugin name before which to insert template records
        :param zone: corefile zone
        :return: True if at least one record inserted, False if all already exist
        """
        changed = False
        for qtype in ("CNAME", "A", "AAAA"):
            if self.insert_template_record(qtype=qtype,
                                           name=name,
                                           target_hostname=target_hostname,
                                           ttl=ttl,
                                           before_plugin=before_plugin,
                                           zone=zone):
                changed = True
        return changed

    def insert_alias_templates_bulk(self, entries: List[Tuple[str, str]], ttl: int = 60,
                                    before_plugin: str = "forward", zone: str = ".:53") -> bool:
        """Insert multiple aliases templates to zone

        :param entries: [(target_hostname, name), ...]
        :param ttl: ttl param for records
        :param before_plugin: plugin name before which to insert templates
        :param zone: corefile zone
        :return: True if at least one record inserted, False if all already exist
        """
        changed = False
        for target_hostname, name in entries:
            if self.insert_alias_templates(name=name, target_hostname=target_hostname, ttl=ttl,
                                           before_plugin=before_plugin, zone=zone):
                changed = True
        return changed

    def insert_cname_template(self, target_hostname: str, name: str, ttl: int = 60,
                              before_plugin: str = "forward", zone: str = ".:53") -> bool:
        """Add template block CNAME name -> target_hostname

        :param before_plugin: plugin name before which to insert cname template
        :param zone: corefile zone
        :param ttl: ttl param for cname record
        :param target_hostname: fqdn of any hyperscaler lb (like "xxx.elb.amazonaws.com")
        :param name: fqdn inside zone (like "vmauth.example.com")
        """
        # normalize dots
        name = name.rstrip(".")
        target_hostname = target_hostname.rstrip(".")

        plugin_block = (
            f"    template IN CNAME {name} {{\n"
            f"        answer \"{{{{ .Name }}}} {ttl} IN CNAME {target_hostname}.\"\n"
            f"    }}"
        )

        return self.insert_plugin(plugin_block, before_plugin=before_plugin, zone=zone)

    def insert_cname_templates(self, entries: List[Tuple[str, str]], ttl: int = 60,
                               before_plugin: str = "forward", zone: str = ".:53") -> bool:
        """Insert multiple CNAME templates to zone

        :param ttl: ttl param for cname records
        :param zone: corefile zone
        :param before_plugin: plugin name before which to insert cname templates
        :param entries: list of tuples: [(target_hostname, target_fqdn)]
        :return
        """
        changed = False
        for target_hostname, name in entries:
            if self.insert_cname_template(target_hostname=target_hostname, name=name, ttl=ttl,
                                          before_plugin=before_plugin, zone=zone):
                changed = True
        return changed

    def has_cname_template(self, name: str, zone: str = ".:53") -> bool:
        """Check if template IN CNAME name { ... } exists for specific name

        :param name: fqdn inside zone (like "vmauth.example.com")
        :param zone: corefile zone
        :return: True if exists, False otherwise
        """
        match = self.find_zone_block(zone)
        if not match:
            return False
        _, _, body, _ = match.groups()
        name = name.rstrip(".")
        return re.search(rf"^\s*template\s+IN\s+CNAME\s+{re.escape(name)}(\s|\{{)", body,
                         flags=re.MULTILINE) is not None

    def remove_cname_template(self, name: str, zone: str = ".:53") -> bool:
        """Remove `template IN CNAME name { ... } from zone` for specific name

        :param name: fqdn inside zone (like "vmauth.example.com")
        :param zone: corefile zone
        :return: True if removed, False if not found
        """
        match = self.find_zone_block(zone)
        if not match:
            return False

        _, head, body, tail = match.groups()
        name = name.rstrip(".")

        pattern = rf"""
            ^\s*template\s+IN\s+CNAME\s+{re.escape(name)}\s*\{{.*?^\s*\}}\s*$
        """

        new_body = re.sub(pattern, "", body, flags=re.DOTALL | re.MULTILINE | re.VERBOSE)

        if new_body == body:
            return False

        new_zone_block = f"{head}{new_body}{tail}"
        self.corefile = self.corefile.replace(match.group(0), new_zone_block)
        return True

    def ensure_zone_block(self,
                          zone: str,
                          default_plugins: Optional[List[str]] = None,
                          insert_at_end: bool = False) -> bool:
        """Check and create zone block if missing.

        :param zone: corefile zone
        :param default_plugins: list of plugin lines to insert in new zone block
        :param insert_at_end: if True, insert new zone block at the end of core
        """
        if self.find_zone_block(zone):
            return False  # already exists

        default_plugins = default_plugins or ["errors", "cache 30", "forward . /etc/resolv.conf"]

        plugins_text = "\n".join(f"    {p}" for p in default_plugins)

        core = self.corefile.rstrip() + "\n"

        new_block = (
            f"{zone} {{\n"
            f"{plugins_text}\n"
            f"}}\n"
        )

        if insert_at_end:
            self.corefile = core + new_block
        else:
            m = re.search(r"^\s*[^ \t\n]+\s*\{", core, flags=re.MULTILINE)
            if m:
                idx = m.start()
                self.corefile = core[:idx] + new_block + core[idx:]
            else:
                self.corefile = core + new_block

        return True

    def compact_zone(self, zone=".:53") -> bool:
        match = self.find_zone_block(zone)
        if not match:
            return False

        _, head, body, tail = match.groups()

        # NOTE(va4st): drop trailing spaces from each line
        lines = [ln.rstrip() for ln in body.splitlines()]

        # NOTE(va4st): remove consecutive blank lines
        compacted = []
        blank = False
        for ln in lines:
            if ln.strip() == "":
                if not blank:
                    compacted.append("")
                blank = True
            else:
                compacted.append(ln)
                blank = False

        new_body = "\n".join(compacted).strip("\n")
        new_zone_block = f"{head}\n{new_body}\n{tail}"
        self._replace_match(match, new_zone_block)
        return True

    def get(self) -> str:
        return self.corefile

    def reset(self):
        self.corefile = self.original_corefile
