apiVersion: troubleshoot.sh/v1beta2
kind: SupportBundle
metadata:
  name: support-bundle
spec:
  collectors:
  - logs:
      namespace: {{ namespace }}
      name: logs/{{ namespace }}
  - logs:
      namespace: projectsveltos
      name: logs/projectsveltos
  - logs:
      namespace: kube-system
      name: logs/kube-system
  - logs:
      namespace: kubevirt
      name: logs/kubevirt
  - logs:
      namespace: cdi
      name: logs/cdi