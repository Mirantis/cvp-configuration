class NotEnoughNodes(Exception):
    pass


class InvalidConfigException(Exception):
    pass


class NoPackageInstalled(Exception):
    pass
